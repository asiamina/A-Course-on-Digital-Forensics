package com.qk.plugin.qkfx;
public class Manager implements com.quicksdk.plugin.IPluginInit {
    final public static String TAG;
    public Manager()
    {
        return;
    }
    public void registerPlugins(com.quicksdk.plugin.PluginManager p3)
    {
        android.util.Log.d("plugin.qkfx", "registerPlugins");
        p3.registerPlugin(com.quicksdk.plugin.PluginNode.SET_GAME_ROLE, new com.qk.plugin.qkfx.SetGameRolePlugin());
        return;
    }
}
