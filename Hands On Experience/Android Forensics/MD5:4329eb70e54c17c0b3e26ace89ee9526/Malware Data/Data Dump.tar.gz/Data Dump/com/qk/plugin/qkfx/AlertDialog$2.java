package com.qk.plugin.qkfx;
 class AlertDialog$2 implements android.content.DialogInterface$OnKeyListener {
    final synthetic com.qk.plugin.qkfx.AlertDialog this$0;
     AlertDialog$2(com.qk.plugin.qkfx.AlertDialog p1)
    {
        this.this$0 = p1;
        return;
    }
    public boolean onKey(android.content.DialogInterface p2, int p3, android.view.KeyEvent p4)
    {
        return 0;
    }
}
