package com.qk.plugin.qkfx;
 class CloseDrawable extends android.graphics.drawable.Drawable {
    private android.graphics.Paint paint;
    private android.graphics.Canvas canvas;
    private int width;
    private android.graphics.Bitmap bitmap;
    public CloseDrawable()
    {
        this.paint = new android.graphics.Paint(4);
        this.bitmap = android.graphics.Bitmap.createBitmap(480, 854, android.graphics.Bitmap$Config.ARGB_8888);
        this.canvas = new android.graphics.Canvas();
        this.canvas.setBitmap(this.bitmap);
        this.width = Math.min(this.bitmap.getWidth(), this.bitmap.getHeight());
        return;
    }
    public void draw(android.graphics.Canvas p4)
    {
        p4.drawBitmap(this.bitmap, 0, 0, 0);
        return;
    }
    public int getIntrinsicHeight()
    {
        return this.width;
    }
    public int getIntrinsicWidth()
    {
        return this.width;
    }
    public int getOpacity()
    {
        return -3;
    }
    public void init(int p7, int p8, int p9, String p10)
    {
        p9 /= 2;
        this.paint.setColor(android.graphics.Color.parseColor(p10));
        this.paint.setStyle(android.graphics.Paint$Style.FILL);
        this.canvas.drawRect(0, 0, ((float) p7), ((float) p8), this.paint);
        v5 = new android.graphics.Paint(4);
        v5.setColor(android.graphics.Color.parseColor("#ffffff"));
        v5.setStyle(android.graphics.Paint$Style.STROKE);
        v5.setStrokeWidth(6.0);
        v5.setAntiAlias(1);
        this.canvas.drawLine(((float) ((p7 / 2) - p9)), ((float) ((p8 / 2) - p9)), ((float) ((p7 / 2) + p9)), ((float) ((p8 / 2) + p9)), v5);
        this.canvas.drawLine(((float) ((p7 / 2) - p9)), ((float) ((p8 / 2) + p9)), ((float) ((p7 / 2) + p9)), ((float) ((p8 / 2) - p9)), v5);
        return;
    }
    public void setAlpha(int p2)
    {
        this.paint.setAlpha(p2);
        return;
    }
    public void setColorFilter(android.graphics.ColorFilter p2)
    {
        this.paint.setColorFilter(p2);
        return;
    }
}
