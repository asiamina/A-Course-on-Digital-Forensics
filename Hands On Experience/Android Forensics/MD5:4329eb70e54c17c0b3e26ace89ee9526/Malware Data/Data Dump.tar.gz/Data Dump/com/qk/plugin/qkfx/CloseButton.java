package com.qk.plugin.qkfx;
 class CloseButton extends android.widget.Button {
    public CloseButton(android.content.Context p3)
    {
        this(p3);
        this.getMyBackground(60, 60, 26);
        this.setBackgroundDrawable(this);
        return;
    }
    private android.graphics.drawable.Drawable getMyBackground(int p8, int p9, int p10)
    {
        v1 = new com.qk.plugin.qkfx.CloseDrawable();
        v1.init(p8, p9, p10, "#e026adf0");
        v2 = new com.qk.plugin.qkfx.CloseDrawable();
        v2.init(p8, p9, p10, "#e01974a1");
        v0 = new android.graphics.drawable.StateListDrawable();
        v3 = new int[1];
        v3[0] = 2.3694026042448817e-38;
        v0.addState(v3, v2);
        v3 = new int[1];
        v3[0] = -1.6947496715221809e+38;
        v0.addState(v3, v1);
        return v0;
    }
    public void init(int p2, int p3, int p4)
    {
        this.getMyBackground(p2, p3, p4);
        this.setBackgroundDrawable(this);
        return;
    }
}
