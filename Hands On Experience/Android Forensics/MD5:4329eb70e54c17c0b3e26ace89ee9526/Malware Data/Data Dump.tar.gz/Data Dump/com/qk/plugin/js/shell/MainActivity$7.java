package com.qk.plugin.js.shell;
 class MainActivity$7 implements com.quicksdk.notifier.LogoutNotifier {
    final synthetic com.qk.plugin.js.shell.MainActivity this$0;
     MainActivity$7(com.qk.plugin.js.shell.MainActivity p1)
    {
        this.this$0 = p1;
        return;
    }
    public void onFailed(String p7, String p8)
    {
        android.util.Log.d("jsShell.ma", new StringBuilder("lgout failed msg:").append(p7).append(",trace:").append(p8).toString());
        v2 = new org.json.JSONObject();
        v2.put("action", "logoutNotify");
        v0 = new org.json.JSONObject();
        v0.put("status", 0);
        v0.put("message", new StringBuilder("msg:").append(p7).append(",trace:").append(p8).toString());
        v2.put("data", v0);
        com.qk.plugin.js.shell.MainActivity.access$1(this.this$0, v2);
        return;
    }
    public void onSuccess()
    {
        android.util.Log.d("jsShell.ma", "lgout success");
        v2 = new org.json.JSONObject();
        v2.put("action", "logoutNotify");
        v0 = new org.json.JSONObject();
        v0.put("status", 1);
        v2.put("data", v0);
        com.qk.plugin.js.shell.MainActivity.access$1(this.this$0, v2);
        return;
    }
}
