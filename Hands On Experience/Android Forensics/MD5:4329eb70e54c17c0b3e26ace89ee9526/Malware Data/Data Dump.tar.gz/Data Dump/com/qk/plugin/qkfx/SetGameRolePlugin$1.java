package com.qk.plugin.qkfx;
 class SetGameRolePlugin$1 implements java.lang.Runnable {
    final synthetic com.qk.plugin.qkfx.SetGameRolePlugin this$0;
     SetGameRolePlugin$1(com.qk.plugin.qkfx.SetGameRolePlugin p1)
    {
        this.this$0 = p1;
        return;
    }
    public void run()
    {
        com.qk.plugin.qkfx.SetGameRolePlugin.access$1(this.this$0, new com.qk.plugin.qkfx.AlertDialog(com.qk.plugin.qkfx.SetGameRolePlugin.access$0(this.this$0)));
        com.quicksdk.net.Connect.getInstance().getGameRoleData(com.qk.plugin.qkfx.SetGameRolePlugin.access$0(this.this$0), com.qk.plugin.qkfx.SetGameRolePlugin.access$2(this.this$0).getUID(), com.qk.plugin.qkfx.SetGameRolePlugin.access$3(this.this$0).getGameRoleID(), new com.qk.plugin.qkfx.PluginHandler(this.this$0));
        return;
    }
}
