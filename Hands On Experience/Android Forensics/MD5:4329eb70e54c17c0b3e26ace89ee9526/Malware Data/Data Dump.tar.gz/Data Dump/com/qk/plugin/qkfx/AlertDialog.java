package com.qk.plugin.qkfx;
public class AlertDialog extends android.app.Dialog {
    private android.widget.Button closeButton;
    public AlertDialog(android.app.Activity p6)
    {
        this(p6, p6.getResources().getIdentifier("qk_game_style_loading", "style", p6.getPackageName()));
        this.setCancelable(0);
        this.setOnCancelListener(new com.qk.plugin.qkfx.AlertDialog$1(this));
        this.setOnKeyListener(new com.qk.plugin.qkfx.AlertDialog$2(this));
        v0 = new com.qk.plugin.qkfx.AlertDialogLayout(p6);
        this.setContentView(v0, v0.getMyLayoutParams());
        this.closeButton = this.findViewById(10004);
        if (this.closeButton != 0) {
            this.closeButton.setOnClickListener(new com.qk.plugin.qkfx.AlertDialog$3(this));
        }
        return;
    }
    public AlertDialog(com.qk.plugin.qkfx.AlertDialogLayout p6)
    {
        this(p6.getContext(), p6.getContext().getResources().getIdentifier("qk_game_style_loading", "style", p6.getContext().getPackageName()));
        this.setCancelable(0);
        this.setOnCancelListener(new com.qk.plugin.qkfx.AlertDialog$4(this));
        this.setOnKeyListener(new com.qk.plugin.qkfx.AlertDialog$5(this));
        this.setContentView(p6, p6.getMyLayoutParams());
        this.closeButton = this.findViewById(10004);
        if (this.closeButton != 0) {
            this.closeButton.setOnClickListener(new com.qk.plugin.qkfx.AlertDialog$6(this));
        }
        return;
    }
    public void show()
    {
        super.show();
        return;
    }
}
