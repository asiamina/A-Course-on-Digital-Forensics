package com.qk.js.shell.model3;
final public class R$style {
    final public static int qk_game_style_loading;
    final public static int Animation;
    final public static int SplashTheme;
    public R$style()
    {
        return;
    }
}
