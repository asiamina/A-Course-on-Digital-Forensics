package com.qk.plugin.js.shell.util;
public class Constant {
    final public static String JS_ACTION_UPDATE_ROLE;
    final public static String JS_ACTION_EXIT;
    final public static String JS_ACTION_LOGIN;
    final public static String JS_ACTION_LOGOUT;
    final public static String AES_KEY;
    final public static String JS_ACTION_PAY;
    final public static String JS_ACTION_WEB_LOADED;
    final public static String JS_ACTION_EXTEND;
    public Constant()
    {
        return;
    }
}
