package com.qk.plugin.qkfx;
public class SetGameRolePlugin implements com.qk.plugin.qkfx.CreateTimeNotifier, com.quicksdk.plugin.IPlugin {
    private com.quicksdk.entity.GameRoleInfo roleInfo;
    private com.quicksdk.entity.UserInfo userInfo;
    private com.qk.plugin.qkfx.AlertDialog dialog;
    private android.app.Activity activity;
    public SetGameRolePlugin()
    {
        this.dialog = 0;
        this.roleInfo = 0;
        this.activity = 0;
        this.userInfo = 0;
        return;
    }
    static synthetic android.app.Activity access$0(com.qk.plugin.qkfx.SetGameRolePlugin p1)
    {
        return p1.activity;
    }
    static synthetic void access$1(com.qk.plugin.qkfx.SetGameRolePlugin p0, com.qk.plugin.qkfx.AlertDialog p1)
    {
        p0.dialog = p1;
        return;
    }
    static synthetic com.quicksdk.entity.UserInfo access$2(com.qk.plugin.qkfx.SetGameRolePlugin p1)
    {
        return p1.userInfo;
    }
    static synthetic com.quicksdk.entity.GameRoleInfo access$3(com.qk.plugin.qkfx.SetGameRolePlugin p1)
    {
        return p1.roleInfo;
    }
    static synthetic com.qk.plugin.qkfx.AlertDialog access$4(com.qk.plugin.qkfx.SetGameRolePlugin p1)
    {
        return p1.dialog;
    }
    public varargs void callPlugin(Object[] p3)
    {
        android.util.Log.d("plugin.qkfx", "call SetGameRolePlugin");
        this.userInfo = com.quicksdk.User.getInstance().getUserInfo(0);
        if ((this.userInfo != 0) && ((this.userInfo.isStopCreateRole() != 0) && (this.dialog == 0))) {
            this.activity = p3[0];
            this.roleInfo = p3[1];
            if ((this.activity == 0) || ((this.roleInfo == 0) || (this.roleInfo.getGameRoleID() == 0))) {
                android.util.Log.d("plugin.qkfx", "\u65e0\u6cd5\u83b7\u53d6\u5230roleInfo\u4e2d\u7684\u6570\u636e");
            } else {
                this.activity.runOnUiThread(new com.qk.plugin.qkfx.SetGameRolePlugin$1(this));
            }
        }
        return;
    }
    public void getCreateTimeFailed()
    {
        return;
    }
    public void getCreateTimeSuccess(String p9)
    {
        v1 = ((long) Integer.parseInt(p9));
        v3 = ((long) Integer.parseInt(this.userInfo.getStopCreateTime()));
        android.util.Log.d("plugin.qkfx", new StringBuilder("roleCreateTime:").append(v1).toString());
        android.util.Log.d("plugin.qkfx", new StringBuilder("stopCreateTime:").append(v3).toString());
        if (v1 > v3) {
            this.activity.runOnUiThread(new com.qk.plugin.qkfx.SetGameRolePlugin$2(this));
        }
        return;
    }
}
