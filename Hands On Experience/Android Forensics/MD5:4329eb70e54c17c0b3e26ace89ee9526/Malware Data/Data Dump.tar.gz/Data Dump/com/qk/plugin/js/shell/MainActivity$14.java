package com.qk.plugin.js.shell;
 class MainActivity$14 implements java.lang.Runnable {
    final private synthetic org.json.JSONObject val$orderInfoObj;
    final synthetic com.qk.plugin.js.shell.MainActivity this$0;
     MainActivity$14(com.qk.plugin.js.shell.MainActivity p1, org.json.JSONObject p2)
    {
        this.this$0 = p1;
        this.val$orderInfoObj = p2;
        return;
    }
    public void run()
    {
        android.util.Log.d("jsShell.ma", "do pay");
        com.qk.plugin.js.shell.MainActivity.access$15(this.this$0, this.val$orderInfoObj.optString("serverId"), this.val$orderInfoObj.optString("serverName"), this.val$orderInfoObj.optString("userRoleId"), this.val$orderInfoObj.optString("userRoleName"), this.val$orderInfoObj.optString("userLevel"), this.val$orderInfoObj.optString("vipLevel"), this.val$orderInfoObj.optString("userRoleBalance"), this.val$orderInfoObj.optString("partyName"), this.val$orderInfoObj.optString("cpOrderNo"), this.val$orderInfoObj.optString("goodsId"), this.val$orderInfoObj.optString("productName"), this.val$orderInfoObj.optInt("count"), this.val$orderInfoObj.optDouble("amount"), v16, this.val$orderInfoObj.optString("extrasParams"), this.val$orderInfoObj.optString("callbackUrl"));
        return;
    }
}
