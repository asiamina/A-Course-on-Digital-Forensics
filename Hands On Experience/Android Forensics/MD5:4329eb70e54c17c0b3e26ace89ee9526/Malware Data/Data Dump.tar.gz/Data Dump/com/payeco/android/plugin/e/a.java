package com.payeco.android.plugin.e;
final public class a {
    public static String a;
    public static boolean c;
    public static boolean b;
    private static android.media.MediaPlayer e;
    private static android.media.MediaRecorder d;
    private static com.payeco.android.plugin.e.a f;
    static a()
    {
        com.payeco.android.plugin.e.a.a = "";
        return;
    }
    private a()
    {
        return;
    }
    public static com.payeco.android.plugin.e.a a(String p1)
    {
        com.payeco.android.plugin.e.a.a = p1;
        if (com.payeco.android.plugin.e.a.f == 0) {
            com.payeco.android.plugin.e.a.f = new com.payeco.android.plugin.e.a();
        }
        return com.payeco.android.plugin.e.a.f;
    }
    public static String a()
    {
        if (!com.payeco.android.plugin.e.a.b) {
            com.payeco.android.plugin.c.b.b();
            v0 = new Object[2];
            v0[0] = Integer.valueOf(2);
            v0[1] = "\u6ca1\u6709\u5f55\u97f3\uff0c\u4e0d\u80fd\u505c\u6b62\u5f55\u97f3";
            v0 = com.payeco.android.plugin.e.a.a(v0);
        } else {
            com.payeco.android.plugin.e.a.d.stop();
            com.payeco.android.plugin.e.a.d.release();
            com.payeco.android.plugin.e.a.d = 0;
            com.payeco.android.plugin.e.a.b = 0;
            com.payeco.android.plugin.c.b.b();
            v0 = new Object[3];
            v0[0] = Integer.valueOf(0);
            v0[1] = "\u505c\u6b62\u5f55\u97f3";
            v0[2] = com.payeco.android.plugin.e.a.a;
            v0 = com.payeco.android.plugin.e.a.a(v0);
        }
        return v0;
    }
    public final String a(int p7)
    {
        if (com.payeco.android.plugin.a.c() != 0) {
            if (!com.payeco.android.plugin.e.a.c) {
                if (!com.payeco.android.plugin.e.a.b) {
                    v0 = new android.media.MediaRecorder();
                    com.payeco.android.plugin.e.a.d = v0;
                    v0.setAudioSource(1);
                    com.payeco.android.plugin.e.a.d.setOutputFormat(2);
                    com.payeco.android.plugin.e.a.d.setOutputFile(com.payeco.android.plugin.e.a.a);
                    com.payeco.android.plugin.e.a.d.setAudioEncoder(1);
                    com.payeco.android.plugin.e.a.d.prepare();
                    com.payeco.android.plugin.e.a.d.start();
                    com.payeco.android.plugin.c.b.b();
                    new Thread(new com.payeco.android.plugin.e.b(this, p7)).start();
                    com.payeco.android.plugin.e.a.b = 1;
                    v0 = new Object[2];
                    v0[0] = Integer.valueOf(0);
                    v0[1] = "\u5f00\u59cb\u5f55\u97f3";
                    v0 = com.payeco.android.plugin.e.a.a(v0);
                } else {
                    com.payeco.android.plugin.c.b.b();
                    v0 = new Object[2];
                    v0[0] = Integer.valueOf(2);
                    v0[1] = "\u6b63\u5728\u5f55\u97f3\uff0c\u4e0d\u80fd\u5f00\u59cb\u5f55\u97f3";
                    v0 = com.payeco.android.plugin.e.a.a(v0);
                }
            } else {
                com.payeco.android.plugin.c.b.b();
                v0 = new Object[2];
                v0[0] = Integer.valueOf(3);
                v0[1] = "\u6b63\u5728\u64ad\u653e\uff0c\u4e0d\u80fd\u5f55\u97f3";
                v0 = com.payeco.android.plugin.e.a.a(v0);
            }
        } else {
            v0 = new Object[2];
            v0[0] = Integer.valueOf(4);
            v0[1] = "\u624b\u673a\u6ca1\u7528SD\u5361,\u8bf7\u63d2\u5165\u540e\u518d\u8bd5\uff01";
            v0 = com.payeco.android.plugin.e.a.a(v0);
        }
        return v0;
    }
    private static varargs String a(Object[] p4)
    {
        v1 = new org.json.JSONObject();
        v1.put("errCode", p4[0]);
        v1.put("errMsg", p4[1]);
        if (p4.length > 2) {
            v1.put("fileName", p4[2]);
        }
        return v1.toString();
    }
    public final String b()
    {
        if (!com.payeco.android.plugin.e.a.b) {
            if (!com.payeco.android.plugin.e.a.c) {
                com.payeco.android.plugin.e.a.e = new android.media.MediaPlayer();
                com.payeco.android.plugin.e.a.e.setDataSource(com.payeco.android.plugin.e.a.a);
                com.payeco.android.plugin.e.a.e.prepare();
                com.payeco.android.plugin.e.a.e.start();
                com.payeco.android.plugin.e.a.e.setOnCompletionListener(new com.payeco.android.plugin.e.c(this));
                com.payeco.android.plugin.e.a.c = 1;
                com.payeco.android.plugin.c.b.b();
                v0 = new Object[2];
                v0[0] = Integer.valueOf(0);
                v0[1] = "\u5f00\u59cb\u64ad\u653e";
                v0 = com.payeco.android.plugin.e.a.a(v0);
            } else {
                com.payeco.android.plugin.c.b.b();
                v0 = new Object[2];
                v0[0] = Integer.valueOf(2);
                v0[1] = "\u6b63\u5728\u64ad\u653e\uff0c\u4e0d\u80fd\u7ee7\u7eed\u64ad\u653e";
                v0 = com.payeco.android.plugin.e.a.a(v0);
            }
        } else {
            com.payeco.android.plugin.c.b.b();
            v0 = new Object[2];
            v0[0] = Integer.valueOf(3);
            v0[1] = "\u6b63\u5728\u5f55\u97f3\uff0c\u4e0d\u80fd\u64ad\u653e";
            v0 = com.payeco.android.plugin.e.a.a(v0);
        }
        return v0;
    }
    public static String c()
    {
        if (!com.payeco.android.plugin.e.a.c) {
            com.payeco.android.plugin.c.b.b();
            v0 = new Object[2];
            v0[0] = Integer.valueOf(2);
            v0[1] = "\u6ca1\u6709\u64ad\u653e\uff0c\u4e0d\u80fd\u505c\u6b62\u64ad\u653e";
            v0 = com.payeco.android.plugin.e.a.a(v0);
        } else {
            com.payeco.android.plugin.e.a.e.release();
            com.payeco.android.plugin.e.a.e = 0;
            com.payeco.android.plugin.e.a.c = 0;
            com.payeco.android.plugin.c.b.b();
            v0 = new Object[2];
            v0[0] = Integer.valueOf(0);
            v0[1] = "\u505c\u6b62\u64ad\u653e";
            v0 = com.payeco.android.plugin.e.a.a(v0);
        }
        return v0;
    }
    public static void d()
    {
        com.payeco.android.plugin.e.a.a();
        com.payeco.android.plugin.e.a.c();
        com.payeco.android.plugin.e.a.d = 0;
        com.payeco.android.plugin.e.a.e = 0;
        com.payeco.android.plugin.e.a.f = 0;
        com.payeco.android.plugin.e.a.a = 0;
        com.payeco.android.plugin.e.a.b = 0;
        com.payeco.android.plugin.e.a.c = 0;
        return;
    }
}
