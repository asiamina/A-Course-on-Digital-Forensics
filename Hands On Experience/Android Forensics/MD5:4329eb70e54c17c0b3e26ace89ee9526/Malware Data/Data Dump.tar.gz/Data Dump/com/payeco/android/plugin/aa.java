package com.payeco.android.plugin;
final class aa implements android.view.View$OnClickListener {
    final synthetic com.payeco.android.plugin.PayecoVedioActivity a;
     aa(com.payeco.android.plugin.PayecoVedioActivity p1)
    {
        this.a = p1;
        return;
    }
    public final void onClick(android.view.View p2)
    {
        com.payeco.android.plugin.PayecoVedioActivity.i(this.a);
        return;
    }
}
