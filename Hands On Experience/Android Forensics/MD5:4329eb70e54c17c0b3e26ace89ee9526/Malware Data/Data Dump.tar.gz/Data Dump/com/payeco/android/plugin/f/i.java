package com.payeco.android.plugin.f;
final class i implements android.view.View$OnClickListener {
    final synthetic com.payeco.android.plugin.f.d a;
     i(com.payeco.android.plugin.f.d p1)
    {
        this.a = p1;
        return;
    }
    public final void onClick(android.view.View p3)
    {
        com.payeco.android.plugin.f.d.e(this.a).setHint("");
        return;
    }
}
