package com.payeco.android.plugin.b;
public class a {
    final synthetic static boolean a;
    public static byte[] a(String p5)
    {
        v0 = p5.getBytes();
        v1 = v0.length;
        v3 = new byte[((v1 * 3) / 4)];
        v2 = new com.payeco.android.plugin.b.c(v3);
        if (v2.a(v0, v1) != 0) {
            if (v2.b != v2.a.length) {
                v0 = new byte[v2.b];
                System.arraycopy(v2.a, 0, v0, 0, v2.b);
            } else {
                v0 = v2.a;
            }
            return v0;
        } else {
            throw new IllegalArgumentException("bad base-64");
        }
    }
    static a()
    {
        if (com.payeco.android.plugin.b.a.desiredAssertionStatus() != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        com.payeco.android.plugin.b.a.a = v0;
        return;
    }
    private a()
    {
        return;
    }
    public static String a(byte[] p6)
    {
        v3 = p6.length;
        v4 = new com.payeco.android.plugin.b.d();
        v0 = ((v3 / 3) * 4);
        if (!v4.d) {
            switch ((v3 % 3)) {
                case 0:
                    break;
                case 1:
                    v0 += 2;
                    break;
                case 2:
                    v0 += 3;
                    break;
                default:
                    if (!v4.e) {
                        v1 = new byte[v0];
                        v4.a = v1;
                        v4.a(p6, v3);
                        if ((com.payeco.android.plugin.b.a.a) || (v4.b == v0)) {
                            return new String(v4.a);
                        } else {
                            throw new AssertionError();
                        }
                    } else {
                        if (v3 <= 0) {
                        } else {
                            if (!v4.f) {
                                v1 = 1;
                            } else {
                                v1 = 2;
                            }
                            v0 += (v1 * (((v3 - 1) / 57) + 1));
                        }
                    }
            }
        } else {
            if ((v3 % 3) > 0) {
                v0 += 4;
            }
        }
        }
    }
}
