package com.payeco.android.plugin.util;
final class j extends java.lang.Thread {
    final synthetic com.payeco.android.plugin.util.LBSTool a;
    private j(com.payeco.android.plugin.util.LBSTool p1, byte p2)
    {
        this.a = p1;
        return;
    }
    public final void run()
    {
        android.os.Looper.prepare();
        com.payeco.android.plugin.util.LBSTool.access$0(this.a, android.os.Looper.myLooper());
        this.a.registerLocationListener();
        android.os.Looper.loop();
        return;
    }
    synthetic j(com.payeco.android.plugin.util.LBSTool p2)
    {
        this(p2, 0);
        return;
    }
}
