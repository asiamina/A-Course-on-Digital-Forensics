package com.payeco.android.plugin;
final class p implements android.view.View$OnTouchListener {
    final synthetic com.payeco.android.plugin.PayecoPluginLoadingActivity a;
     p(com.payeco.android.plugin.PayecoPluginLoadingActivity p1)
    {
        this.a = p1;
        return;
    }
    public final boolean onTouch(android.view.View p2, android.view.MotionEvent p3)
    {
        switch (p3.getAction()) {
            case 0:
            case 1:
                if (p2.hasFocus() != 0) {
                } else {
                    p2.requestFocus();
                }
                break;
        }
        return 0;
    }
}
