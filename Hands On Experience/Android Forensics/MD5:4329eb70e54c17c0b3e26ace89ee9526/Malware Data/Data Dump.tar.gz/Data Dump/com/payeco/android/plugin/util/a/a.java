package com.payeco.android.plugin.util.a;
final public class a {
    public static boolean a(String p1)
    {
        if ((p1 == 0) || (p1.trim().length() == 0)) {
            v0 = 1;
        } else {
            v0 = 0;
        }
        return v0;
    }
    public a()
    {
        return;
    }
}
