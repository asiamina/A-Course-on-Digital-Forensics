package com.payeco.android.plugin.f;
final public class b extends android.widget.PopupWindow {
    private int A;
    private com.payeco.android.plugin.bridge.JsBridge B;
    public android.widget.EditText a;
    public android.widget.Button c;
    public android.widget.Button b;
    public android.widget.Button e;
    public android.widget.Button d;
    public android.widget.Button g;
    public android.widget.Button f;
    public android.widget.Button i;
    public android.widget.Button h;
    public android.widget.Button k;
    public android.widget.Button j;
    public android.widget.Button m;
    public android.widget.Button l;
    public android.widget.Button o;
    public android.widget.Button n;
    private static android.content.res.Resources q;
    private String p;
    private boolean s;
    private static String r;
    private String u;
    private boolean t;
    private android.view.View w;
    private String v;
    private String y;
    private android.app.Activity x;
    private int z;
    static synthetic android.app.Activity d(com.payeco.android.plugin.f.b p1)
    {
        return p1.x;
    }
    static synthetic com.payeco.android.plugin.bridge.JsBridge e(com.payeco.android.plugin.f.b p1)
    {
        return p1.B;
    }
    static synthetic String f(com.payeco.android.plugin.f.b p1)
    {
        return p1.p;
    }
    static synthetic int g(com.payeco.android.plugin.f.b p1)
    {
        return p1.z;
    }
    public b(android.app.Activity p7, String p8, int p9, int p10, String p11, boolean p12, boolean p13, String p14, com.payeco.android.plugin.bridge.JsBridge p15)
    {
        this(p7);
        this.s = 0;
        this.t = 0;
        this.u = "";
        this.y = "";
        this.z = 29;
        this.A = 18;
        this.B = p15;
        com.payeco.android.plugin.f.b.q = p7.getResources();
        this.x = p7;
        this.p = p14;
        this.A = p9;
        this.z = p10;
        com.payeco.android.plugin.f.b.r = p7.getPackageName();
        this.v = p8;
        this.s = p12;
        this.t = p13;
        this.u = p11;
        this.w = this.x.getSystemService("layout_inflater").inflate(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_plugin_hxkeyboard", "layout", com.payeco.android.plugin.f.b.r), 0);
        v1 = new com.payeco.android.plugin.f.c(this);
        this.a = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_keyboard_password_hx", "id", com.payeco.android.plugin.f.b.r));
        this.a.setHint(this.v);
        this.a.setMovementMethod(android.text.method.ScrollingMovementMethod.getInstance());
        this.y = this.u;
        this.a.setText(this.y);
        this.a.setSelection(this.y.length());
        this.b = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("keyboard_back", "id", com.payeco.android.plugin.f.b.r));
        this.b.setOnClickListener(v1);
        this.c = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("keyboard_invisable", "id", com.payeco.android.plugin.f.b.r));
        this.c.setOnClickListener(v1);
        this.d = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_1_hx", "id", com.payeco.android.plugin.f.b.r));
        this.d.setOnClickListener(v1);
        this.e = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_2_hx", "id", com.payeco.android.plugin.f.b.r));
        this.e.setOnClickListener(v1);
        this.f = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_3_hx", "id", com.payeco.android.plugin.f.b.r));
        this.f.setOnClickListener(v1);
        this.g = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_4_hx", "id", com.payeco.android.plugin.f.b.r));
        this.g.setOnClickListener(v1);
        this.h = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_5_hx", "id", com.payeco.android.plugin.f.b.r));
        this.h.setOnClickListener(v1);
        this.i = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_6_hx", "id", com.payeco.android.plugin.f.b.r));
        this.i.setOnClickListener(v1);
        this.j = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_7_hx", "id", com.payeco.android.plugin.f.b.r));
        this.j.setOnClickListener(v1);
        this.k = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_8_hx", "id", com.payeco.android.plugin.f.b.r));
        this.k.setOnClickListener(v1);
        this.l = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_9_hx", "id", com.payeco.android.plugin.f.b.r));
        this.l.setOnClickListener(v1);
        this.m = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_0_hx", "id", com.payeco.android.plugin.f.b.r));
        this.m.setOnClickListener(v1);
        this.n = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_x_hx", "id", com.payeco.android.plugin.f.b.r));
        this.n.setOnClickListener(v1);
        if (this.s) {
            this.n.setEnabled(0);
            this.n.setBackgroundResource(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_btnenable", "drawable", com.payeco.android.plugin.f.b.r));
        }
        this.o = this.w.findViewById(com.payeco.android.plugin.f.b.q.getIdentifier("payeco_digit_ok_hx", "id", com.payeco.android.plugin.f.b.r));
        this.o.setOnClickListener(v1);
        this.setBackgroundDrawable(new android.graphics.drawable.BitmapDrawable());
        this.setFocusable(1);
        this.setOutsideTouchable(0);
        this.setContentView(this.w);
        this.setWidth(-1);
        this.setHeight(-1);
        return;
    }
    static synthetic android.content.res.Resources a()
    {
        return com.payeco.android.plugin.f.b.q;
    }
    static synthetic String a(com.payeco.android.plugin.f.b p1)
    {
        return p1.y;
    }
    public final void a(android.view.View p3)
    {
        if (this.isShowing() != 0) {
            this.dismiss();
        } else {
            this.showAtLocation(p3, 80, 0, 0);
        }
        return;
    }
    static synthetic void a(com.payeco.android.plugin.f.b p0, String p1)
    {
        p0.y = p1;
        return;
    }
    static synthetic String b()
    {
        return com.payeco.android.plugin.f.b.r;
    }
    static synthetic boolean b(com.payeco.android.plugin.f.b p1)
    {
        return p1.t;
    }
    static synthetic int c(com.payeco.android.plugin.f.b p1)
    {
        return p1.A;
    }
}
