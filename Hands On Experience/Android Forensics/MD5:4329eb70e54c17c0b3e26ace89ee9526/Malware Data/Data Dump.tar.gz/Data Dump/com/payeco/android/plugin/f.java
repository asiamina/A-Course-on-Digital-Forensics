package com.payeco.android.plugin;
final class f implements android.hardware.Camera$AutoFocusCallback {
    final synthetic com.payeco.android.plugin.e a;
    final private synthetic android.widget.Button b;
     f(com.payeco.android.plugin.e p1, android.widget.Button p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
    public final void onAutoFocus(boolean p5, android.hardware.Camera p6)
    {
        com.payeco.android.plugin.e.a(this.a).camera.takePicture(com.payeco.android.plugin.e.a(this.a).shutterCallback, com.payeco.android.plugin.e.a(this.a).rawCallback, com.payeco.android.plugin.e.a(this.a).jpegCallback);
        this.b.setClickable(1);
        return;
    }
}
