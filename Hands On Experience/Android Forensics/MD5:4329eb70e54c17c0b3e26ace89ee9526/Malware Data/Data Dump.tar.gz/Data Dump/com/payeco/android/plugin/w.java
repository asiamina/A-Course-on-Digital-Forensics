package com.payeco.android.plugin;
final class w extends android.content.BroadcastReceiver {
    final synthetic com.payeco.android.plugin.PayecoPluginLoadingActivity a;
    synthetic w(com.payeco.android.plugin.PayecoPluginLoadingActivity p2)
    {
        this(p2, 0);
        return;
    }
    private w(com.payeco.android.plugin.PayecoPluginLoadingActivity p1, byte p2)
    {
        this.a = p1;
        return;
    }
    public final void onReceive(android.content.Context p8, android.content.Intent p9)
    {
        if (p9.getAction().equals("android.provider.Telephony.SMS_RECEIVED") != 0) {
            v0 = p9.getSerializableExtra("pdus");
            v4 = new byte[][v0.length];
            v3 = 0;
            while (v3 < v0.length) {
                v4[v3] = v0[v3];
                v3++;
            }
            v1 = new byte[][v4.length];
            v3 = v1.length;
            v5 = new android.telephony.gsm.SmsMessage[v3];
            v0 = 0;
            while (v0 < v3) {
                v1[v0] = v4[v0];
                v5[v0] = android.telephony.gsm.SmsMessage.createFromPdu(v1[v0]);
                v0++;
            }
            v1 = v5.length;
            v0 = 0;
            while (v0 < v1) {
                v2 = v5[v0];
                this.a.getApplicationContext();
                if (com.payeco.android.plugin.a.a("SmsNumber").contains(v2.getOriginatingAddress()) != 0) {
                    com.payeco.android.plugin.PayecoPluginLoadingActivity.access$0(this.a, v2.getOriginatingAddress(), v2.getMessageBody());
                }
                v0++;
            }
        }
        return;
    }
}
