package com.payeco.android.plugin.util;
final class c extends android.os.AsyncTask {
    final synthetic com.payeco.android.plugin.util.b a;
    final private synthetic com.payeco.android.plugin.util.l b;
     c(com.payeco.android.plugin.util.b p1, com.payeco.android.plugin.util.l p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
    protected varargs final synthetic Object doInBackground(Object[] p4)
    {
        v0 = 0;
        if ("post".equals(com.payeco.android.plugin.util.b.a(this.a)) != 0) {
            v0 = com.payeco.android.plugin.util.d.a(com.payeco.android.plugin.util.b.b(this.a), com.payeco.android.plugin.util.b.c(this.a), com.payeco.android.plugin.util.b.d(this.a));
        }
        if ("get".equals(com.payeco.android.plugin.util.b.a(this.a)) != 0) {
            v0 = com.payeco.android.plugin.util.d.a(com.payeco.android.plugin.util.b.b(this.a), com.payeco.android.plugin.util.b.d(this.a));
        }
        if ("upfile".equals(com.payeco.android.plugin.util.b.a(this.a)) != 0) {
            v0 = com.payeco.android.plugin.util.d.a(com.payeco.android.plugin.util.b.b(this.a), com.payeco.android.plugin.util.b.c(this.a), com.payeco.android.plugin.util.b.e(this.a));
        }
        return v0;
    }
    protected final synthetic void onPostExecute(Object p2)
    {
        super.onPostExecute(p2);
        if (p2 == 0) {
            this.b.a();
        } else {
            this.b.a(p2);
        }
        return;
    }
}
