package com.payeco.android.plugin.f;
final public class s extends android.widget.PopupWindow {
    private android.app.Activity a;
    private static String c;
    private static android.content.res.Resources b;
    private static String e;
    private android.view.View d;
    private android.widget.Button g;
    private static com.payeco.android.plugin.bridge.JsBridge f;
    private int i;
    private android.widget.Button h;
    private android.os.Handler k;
    private android.widget.TextView j;
    private Runnable m;
    private static int l;
    public static com.payeco.android.plugin.f.s a(android.app.Activity p6, android.view.View p7, String p8, com.payeco.android.plugin.bridge.JsBridge p9, int p10)
    {
        com.payeco.android.plugin.f.s.l = p10;
        com.payeco.android.plugin.f.s.e = p8;
        com.payeco.android.plugin.f.s.f = p9;
        v0 = p6.getSystemService("input_method");
        v1 = p6.getCurrentFocus();
        if ((v1 != 0) && (v0.isActive() != 0)) {
            v0.hideSoftInputFromWindow(v1.getWindowToken(), 2);
        }
        v1 = new com.payeco.android.plugin.f.s(p6, p6.getSystemService("layout_inflater").inflate(p6.getResources().getIdentifier("payeco_plugin_record", "layout", p6.getPackageName()), 0));
        v1.setBackgroundDrawable(new android.graphics.drawable.BitmapDrawable());
        v1.update();
        v1.showAtLocation(p7, 80, 0, 0);
        return v1;
    }
    static synthetic void a(com.payeco.android.plugin.f.s p0, int p1)
    {
        p0.i = p1;
        return;
    }
    static synthetic android.widget.TextView b(com.payeco.android.plugin.f.s p1)
    {
        return p1.j;
    }
    static synthetic com.payeco.android.plugin.bridge.JsBridge b()
    {
        return com.payeco.android.plugin.f.s.f;
    }
    static synthetic android.os.Handler c(com.payeco.android.plugin.f.s p1)
    {
        return p1.k;
    }
    static synthetic String c()
    {
        return com.payeco.android.plugin.f.s.e;
    }
    static synthetic Runnable d(com.payeco.android.plugin.f.s p1)
    {
        return p1.m;
    }
    public final void dismiss()
    {
        this.k.removeCallbacks(this.m);
        super.dismiss();
        return;
    }
    static synthetic android.app.Activity e(com.payeco.android.plugin.f.s p1)
    {
        return p1.a;
    }
    static synthetic android.widget.Button f(com.payeco.android.plugin.f.s p1)
    {
        return p1.h;
    }
    static synthetic android.widget.Button g(com.payeco.android.plugin.f.s p1)
    {
        return p1.g;
    }
    static s()
    {
        com.payeco.android.plugin.f.s.l = 5;
        return;
    }
    private s(android.app.Activity p9, android.view.View p10)
    {
        this(p10, -1, -1, 0);
        this.m = new com.payeco.android.plugin.f.t(this);
        this.a = p9;
        com.payeco.android.plugin.f.s.b = p9.getResources();
        com.payeco.android.plugin.f.s.c = this.a.getPackageName();
        this.d = p10;
        v0 = this.d.findViewById(com.payeco.android.plugin.f.s.b.getIdentifier("btnStart", "id", com.payeco.android.plugin.f.s.c));
        this.g = this.d.findViewById(com.payeco.android.plugin.f.s.b.getIdentifier("btnPlay", "id", com.payeco.android.plugin.f.s.c));
        this.h = this.d.findViewById(com.payeco.android.plugin.f.s.b.getIdentifier("btnFinish", "id", com.payeco.android.plugin.f.s.c));
        v1 = this.d.findViewById(com.payeco.android.plugin.f.s.b.getIdentifier("btnCancel", "id", com.payeco.android.plugin.f.s.c));
        this.j = this.d.findViewById(com.payeco.android.plugin.f.s.b.getIdentifier("time", "id", com.payeco.android.plugin.f.s.c));
        this.h.setEnabled(0);
        this.g.setEnabled(0);
        this.k = new android.os.Handler();
        v0.setOnClickListener(new com.payeco.android.plugin.f.u(this));
        this.g.setOnClickListener(new com.payeco.android.plugin.f.v(this));
        this.h.setOnClickListener(new com.payeco.android.plugin.f.w(this));
        v1.setOnClickListener(new com.payeco.android.plugin.f.x(this));
        return;
    }
    static synthetic int a()
    {
        return com.payeco.android.plugin.f.s.l;
    }
    static synthetic int a(com.payeco.android.plugin.f.s p1)
    {
        return p1.i;
    }
}
