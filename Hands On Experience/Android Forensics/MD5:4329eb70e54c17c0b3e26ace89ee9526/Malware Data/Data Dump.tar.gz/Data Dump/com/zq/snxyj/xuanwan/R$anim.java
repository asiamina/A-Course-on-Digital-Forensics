package com.zq.snxyj.xuanwan;
final public class R$anim {
    final public static int smc_progress;
    static R$anim()
    {
        com.zq.snxyj.xuanwan.R$anim.smc_progress = com.quicksdk.apiadapter.xuanwangame.ActivityAdapter.getResId("smc_progress", "anim");
        return;
    }
    public R$anim()
    {
        return;
    }
}
