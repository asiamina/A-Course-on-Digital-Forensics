package com.snda.youni.dualsim.impl;
final public class SimInfo$SimInfoColumns implements android.provider.BaseColumns {
    final public static int ERROR_GENERAL;
    final public static String NUMBER;
    final public static int DISPLAY_NUMBER_FIRST;
    final public static String ICC_ID;
    final public static String SLOT;
    final public static String DATA_ROAMING;
    final public static String COLOR;
    final public static int ERROR_NAME_EXIST;
    final public static int DATA_ROAMING_DISABLE;
    final public static int DISPALY_NUMBER_NONE;
    final public static String DISPLAY_NAME;
    final public static int DATA_ROAMING_ENABLE;
    final public static android.net.Uri CONTENT_URI;
    final public static int DATA_ROAMING_DEFAULT;
    final public static int DEFAULT_NAME_MIN_INDEX;
    final public static int DISPLAY_NUMBER_LAST;
    final public static int DEFAULT_NAME_MAX_INDEX;
    final public static int SLOT_NONE;
    final public static int COLOR_DEFAULT;
    final public static int COLOR_2;
    final public static int COLOR_1;
    final public static int COLOR_8;
    final public static int COLOR_7;
    final public static int COLOR_6;
    final public static int COLOR_5;
    final public static int COLOR_4;
    final public static int COLOR_3;
    final public static String DEFAULT_SORT_ORDER;
    final public static int DISLPAY_NUMBER_DEFAULT;
    final public static String DISPLAY_NUMBER_FORMAT;
    static SimInfo$SimInfoColumns()
    {
        com.snda.youni.dualsim.impl.SimInfo$SimInfoColumns.CONTENT_URI = android.net.Uri.parse("content://telephony/siminfo");
        return;
    }
    public SimInfo$SimInfoColumns()
    {
        return;
    }
}
