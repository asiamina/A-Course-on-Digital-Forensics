package com.snda.woa;
public class ar {
    private static java.util.HashMap a;
    static ar()
    {
        com.snda.woa.ar.a = new java.util.HashMap();
        com.snda.woa.ar.a.put(String.valueOf(2), "0");
        com.snda.woa.ar.a.put(String.valueOf(1), "1");
        com.snda.woa.ar.a.put(String.valueOf(1), "2");
        com.snda.woa.ar.a.put(String.valueOf(2), "3");
        return;
    }
    public ar()
    {
        return;
    }
    public static String a()
    {
        v0 = new String();
        v3 = new java.io.FileReader("/proc/cpuinfo");
        if (v3 == 0) {
            v2 = 0;
        } else {
            v2 = new java.io.BufferedReader(v3, 1024);
        }
        v0 = new StringBuilder().append(v0).append(v2.readLine()).toString();
        v2.close();
        v3.close();
        if (android.text.TextUtils.isEmpty(v0) != 0) {
            v0 = 0;
        } else {
            v0 = v0.split(":");
            } else {
                v0 = v0[1].trim();
            }
        }
        return v0;
    }
    public static String a(android.content.Context p3)
    {
        if (p3.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", p3.getPackageName()) == 0) {
            v0 = p3.getSystemService("connectivity");
            if (v0 != 0) {
                if (v0.getNetworkInfo(1).getState() != android.net.NetworkInfo$State.CONNECTED) {
                    if (v0.getNetworkInfo(0).getState() != android.net.NetworkInfo$State.CONNECTED) {
                        v0 = "Unknown";
                    } else {
                        v0 = "2G/3G";
                    }
                } else {
                    v0 = "Wi-Fi";
                }
            } else {
                v0 = com.snda.woa.z.am;
            }
        } else {
            v0 = "Unknown";
        }
        return v0;
    }
    public static int b(android.content.Context p3)
    {
        v0 = p3.getResources().getConfiguration();
        if (com.snda.woa.ar.a.containsKey(String.valueOf(v0.orientation)) == 0) {
            v0 = -1;
        } else {
            v0 = Integer.parseInt(com.snda.woa.ar.a.get(String.valueOf(v0.orientation)));
        }
        return v0;
    }
    public static android.location.Location c(android.content.Context p4)
    {
        v0 = p4.getSystemService("location");
        v2 = new android.location.Criteria();
        v2.setAccuracy(1);
        v2.setAltitudeRequired(0);
        v2.setBearingRequired(0);
        v2.setCostAllowed(1);
        v2.setPowerRequirement(1);
        v1 = v0.getLastKnownLocation(v0.getBestProvider(v2, 1));
        v0.setTestProviderEnabled("gps", 0);
        return v1;
    }
    public static boolean d(android.content.Context p5)
    {
        v2 = 0;
        v0 = p5.getSystemService("connectivity");
        if (v0 != 0) {
            if (v0.getNetworkInfo(0).getState() != android.net.NetworkInfo$State.CONNECTED) {
                if (v0.getNetworkInfo(1).getState() != android.net.NetworkInfo$State.CONNECTED) {
                    v0 = 0;
                } else {
                    v0 = 1;
                }
                v2 = v0;
            } else {
                v2 = 1;
            }
        }
        return v2;
    }
}
