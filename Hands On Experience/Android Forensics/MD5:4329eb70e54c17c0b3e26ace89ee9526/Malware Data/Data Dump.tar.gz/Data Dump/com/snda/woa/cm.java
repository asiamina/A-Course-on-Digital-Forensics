package com.snda.woa;
public class cm {
    public static int a;
    public static android.os.Handler c;
    public static String b;
    public static java.util.Date e;
    public static java.util.Date d;
    private static boolean g;
    private static boolean f;
    private static int h;
    static cm()
    {
        com.snda.woa.cm.a = 0;
        com.snda.woa.cm.b = 0;
        com.snda.woa.cm.c = new android.os.Handler(android.os.Looper.getMainLooper());
        com.snda.woa.cm.d = 0;
        com.snda.woa.cm.e = new java.util.Date();
        com.snda.woa.cm.f = 0;
        com.snda.woa.cm.g = 0;
        com.snda.woa.cm.h = 0;
        return;
    }
    public cm()
    {
        return;
    }
    public static void a()
    {
        com.snda.woa.cm.e = new java.util.Date();
        com.snda.woa.d.a();
        return;
    }
    public static boolean a(int p5)
    {
        v0 = 0;
        v2 = com.snda.woa.ce.p;
        v1 = 0;
        while (v1 < v2.length) {
            if (p5 != v2[v1]) {
                v1++;
            } else {
                v0 = 1;
                break;
            }
        }
        return v0;
    }
    public static boolean a(android.content.Context p1)
    {
        if (com.snda.woa.cn.c(com.snda.woa.cf.u(p1)) != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static void b(int p1)
    {
        switch (com.snda.woa.cm.h) {
            case 0:
                com.snda.woa.cm.h = p1;
                break;
            case 10:
                if (p1 != 100) {
                } else {
                    com.snda.woa.cm.h = p1;
                }
            case 100:
            default:
                break;
        }
        return;
    }
    public static boolean b()
    {
        if (!com.snda.woa.cm.f) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static boolean b(android.content.Context p2)
    {
        v0 = 1;
        if ((com.snda.woa.cf.v(p2) == 0) && (com.snda.woa.cf.r(p2) == 0)) {
            v0 = 0;
        }
        return v0;
    }
    public static void c()
    {
        com.snda.woa.cm.f = 1;
        com.snda.woa.cm.g = 1;
        return;
    }
    public static boolean c(android.content.Context p1)
    {
        if (com.snda.woa.cr.c(p1) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static int d(android.content.Context p1)
    {
        if (com.snda.woa.cf.b(p1) == 0) {
            v0 = -2.91353142840318e+38;
        } else {
            v0 = -2.913527371921259e+38;
        }
        return v0;
    }
    public static boolean d()
    {
        return com.snda.woa.cm.g;
    }
    public static void e()
    {
        com.snda.woa.cm.g = 0;
        return;
    }
    public static int f()
    {
        return com.snda.woa.cm.h;
    }
}
