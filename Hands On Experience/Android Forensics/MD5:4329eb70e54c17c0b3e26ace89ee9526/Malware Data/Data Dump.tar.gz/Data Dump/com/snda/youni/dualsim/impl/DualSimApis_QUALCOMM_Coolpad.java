package com.snda.youni.dualsim.impl;
public class DualSimApis_QUALCOMM_Coolpad implements com.snda.youni.dualsim.DualSimApis {
    private android.content.Context context;
    public DualSimApis_QUALCOMM_Coolpad(android.content.Context p1)
    {
        this.context = p1;
        return;
    }
    public String getDeviceId(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualDeviceId", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public int getFirstSlotSimId()
    {
        return 1;
    }
    public String getLine1Number(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualLine1Number", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public String getNetworkOperator(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualNetworkOperator", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public String getNetworkOperatorName(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualNetworkOperatorName", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public int getNetworkType(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualNetworkType", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3).intValue();
    }
    public int getSecondSlotSimId()
    {
        return 2;
    }
    public String getSimFieldName()
    {
        return "network_type";
    }
    public String getSimOperator(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getSimOperator", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public String getSimOperatorName(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getSimOperatorName", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public String getSimSerialNumber(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualSimSerialNumber", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public int getSimState(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualSimState", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3).intValue();
    }
    public String getSubscriberId(int p8)
    {
        v2 = this.context.getSystemService("phone");
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v1 = v0.getDeclaredMethod("getDualSubscriberId", v4);
        v3 = new Object[1];
        v3[0] = Integer.valueOf(p8);
        return v1.invoke(v2, v3);
    }
    public boolean needQuerySimIdSperately()
    {
        return 1;
    }
    public void prepareDualSimApis()
    {
        return;
    }
    public void sendTextMessage(String p9, String p10, String p11, android.app.PendingIntent p12, android.app.PendingIntent p13, int p14)
    {
        v0 = Class.forName("com.yulong.android.telephony.CPSmsManager");
        v5 = new Class[0];
        v2 = v0.getDeclaredMethod("getDefault", v5);
        v2.setAccessible(1);
        v5 = new Class[6];
        v5[0] = String;
        v5[1] = String;
        v5[2] = String;
        v5[3] = android.app.PendingIntent;
        v5[4] = android.app.PendingIntent;
        v5[5] = Integer.TYPE;
        v3 = v0.getDeclaredMethod("sendTextMessage", v5);
        v3.setAccessible(1);
        v4 = new Object[0];
        v1 = v2.invoke(v0, v4);
        v4 = new Object[6];
        v4[0] = p9;
        v4[1] = p10;
        v4[2] = p11;
        v4[3] = p12;
        v4[4] = p13;
        v4[5] = Integer.valueOf(p14);
        v3.invoke(v1, v4);
        return;
    }
    public boolean testDeviceId()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualDeviceId", v4);
        return 1;
    }
    public boolean testDualSimApis()
    {
        v1 = 0;
        if ((this.testPrerequist() != 0) && ((this.testSubscriberId() != 0) && ((this.testSimState() != 0) && ((this.testSimSerialNumber() != 0) && ((this.testNetworkOperator() != 0) && ((this.tstNetworkOperatorName() != 0) && ((this.testNetworkType() != 0) && ((this.testDeviceId() != 0) && ((this.testLine1Number() != 0) && ((this.testSendTextMessage() != 0) && ((((((((((0 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) >= 9))))))))))) {
            this.prepareDualSimApis();
            v1 = 1;
        }
        return v1;
    }
    public boolean testLine1Number()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualLine1Number", v4);
        return 1;
    }
    public boolean testNetworkOperator()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualNetworkOperator", v4);
        return 1;
    }
    public boolean testNetworkType()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualNetworkType", v4);
        return 1;
    }
    public boolean testPrerequist()
    {
        Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        return 1;
    }
    public boolean testSendTextMessage()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPSmsManager");
        v4 = new Class[0];
        v0.getDeclaredMethod("getDefault", v4);
        v4 = new Class[6];
        v4[0] = String;
        v4[1] = String;
        v4[2] = String;
        v4[3] = android.app.PendingIntent;
        v4[4] = android.app.PendingIntent;
        v4[5] = Integer.TYPE;
        v0.getDeclaredMethod("sendDualTextMessage", v4);
        return 1;
    }
    public boolean testSimSerialNumber()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualSimSerialNumber", v4);
        return 1;
    }
    public boolean testSimState()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualSimState", v4);
        return 1;
    }
    public boolean testSubscriberId()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualSubscriberId", v4);
        return 1;
    }
    public boolean tstNetworkOperatorName()
    {
        v0 = Class.forName("com.yulong.android.telephony.CPTelephonyManager");
        v4 = new Class[1];
        v4[0] = Integer.TYPE;
        v0.getDeclaredMethod("getDualNetworkOperatorName", v4);
        return 1;
    }
}
