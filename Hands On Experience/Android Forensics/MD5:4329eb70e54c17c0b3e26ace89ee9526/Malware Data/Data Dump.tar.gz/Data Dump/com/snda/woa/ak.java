package com.snda.woa;
public class ak {
    private Integer a;
    private String c;
    private String b;
    public ak(Integer p1, String p2, String p3)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        return;
    }
    public ak(String p1, String p2)
    {
        this.b = p1;
        this.c = p2;
        return;
    }
    public String a()
    {
        return this.b;
    }
    public String b()
    {
        return this.c;
    }
    public String toString()
    {
        return new StringBuilder().append("id[").append(this.a).append("], device[").append(this.b).append("], osVersion[").append(this.c).append("]").toString();
    }
}
