package com.snda.woa;
public class bv extends android.os.AsyncTask {
    private com.snda.woa.android.callback.ChkSmsInterceptCallback a;
    private int c;
    private android.content.Context b;
    private java.util.Map e;
    private boolean d;
    private String f;
    private java.util.List a(android.content.Context p8)
    {
        v1 = new java.util.ArrayList(0);
        v2 = p8.getPackageManager();
        v3 = v2.getInstalledPackages(0).iterator();
        while (v3.hasNext() != 0) {
            v0 = v3.next();
            v1.add(new com.snda.woa.af(v0.applicationInfo.packageName, v0.applicationInfo.loadLabel(v2).toString(), v0.versionName));
        }
        return v1;
    }
    protected void a(String p7)
    {
        if (this.a != 0) {
            this.a.callBack(this.c, com.snda.woa.android.OpenAPI.getStatusText(this.c), this.d, this.e, this.f);
        }
        return;
    }
    private String b(String p4)
    {
        if (p4 != 0) {
            v0 = p4.replaceAll("\\.", "\\\\.").replaceAll("\\*", ".*");
        } else {
            v0 = "";
        }
        return v0;
    }
    protected synthetic bridge Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
    protected synthetic bridge void onPostExecute(Object p1)
    {
        this.a(p1);
        return;
    }
    public bv(com.snda.woa.android.callback.ChkSmsInterceptCallback p3, android.content.Context p4)
    {
        this.c = 0;
        this.d = 0;
        this.e = new java.util.LinkedHashMap(0);
        this.f = "";
        this.a = p3;
        this.b = p4;
        return;
    }
    protected varargs String a(String[] p10)
    {
        if (this.a != 0) {
            if (this.b != 0) {
                switch (com.snda.woa.cm.f()) {
                    case 0:
                        this.c = -2.9135123629381524e+38;
                        break;
                    case 10:
                        this.f = "timeout";
                        v0 = System.currentTimeMillis();
                        v2 = System.currentTimeMillis();
                        while ((v2 - v0) <= 3000.0) {
                            Thread.sleep(100.0);
                            if (com.snda.woa.cm.f() == 100) {
                                this.f = "";
                                break;
                            }
                        }
                        break;
                    case 100:
                    default:
                        break;
                }
                v0 = com.snda.woa.bi.a(this.b);
                if ((v0 == 0) || (v0.isEmpty() != 0)) {
                    v0 = com.snda.woa.b.a;
                }
                v3 = v0.iterator();
                while (v3.hasNext() != 0) {
                    v0 = v3.next();
                    if (android.os.Build.MODEL.equals(v0.a()) != 0) {
                        this.b(v0.b());
                        if (java.util.regex.Pattern.compile(this).matcher(android.os.Build$VERSION.RELEASE).matches() != 0) {
                            this.d = 1;
                            break;
                        }
                    }
                }
                v0 = com.snda.woa.n.a(this.b);
                if ((v0 != 0) && (v0.isEmpty() == 0)) {
                    v2 = v0;
                } else {
                    v2 = com.snda.woa.b.b;
                }
                this.a(this.b);
                v3 = this.iterator();
                while (v3.hasNext() != 0) {
                    v0 = v3.next();
                    v4 = v2.iterator();
                    while (v4.hasNext() != 0) {
                        v1 = v4.next();
                        if ((v1.a() != 0) && (v1.a().equals(v0.a()) != 0)) {
                            this.b(v1.c());
                            if (java.util.regex.Pattern.compile(this).matcher(v0.c()).matches() != 0) {
                                this.e.put(v0.a(), v0.b());
                                break;
                            }
                        }
                    }
                }
                this.c = 0;
            } else {
                this.c = -2.9135277775694512e+38;
            }
        }
        return 0;
    }
}
