package com.snda.woa;
public class bb {
    public bb()
    {
        return;
    }
    public static String a(java.util.Date p2)
    {
        return new java.text.SimpleDateFormat("yyyyMMddHHmmssSSS").format(p2);
    }
}
