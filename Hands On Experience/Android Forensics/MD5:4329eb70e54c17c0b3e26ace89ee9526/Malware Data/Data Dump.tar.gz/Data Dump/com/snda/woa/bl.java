package com.snda.woa;
public class bl {
    private static long a;
    public bl()
    {
        return;
    }
    public static boolean a()
    {
        v0 = System.currentTimeMillis();
        if ((v0 - com.snda.woa.bl.a) < 60000.0) {
            v0 = 0;
        } else {
            com.snda.woa.bl.a = v0;
            v0 = 1;
        }
        return v0;
    }
    public static void b()
    {
        if (com.snda.woa.cn.d(com.snda.woa.ax.e()) != 0) {
            com.snda.woa.ax.a(com.snda.woa.ax.e());
            com.snda.woa.ax.e("");
        }
        com.snda.woa.bl.a = 0.0;
        return;
    }
    static bl()
    {
        com.snda.woa.bl.a = 0.0;
        return;
    }
}
