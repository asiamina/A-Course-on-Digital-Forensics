package com.snda.woa;
public class be extends com.snda.woa.as {
    private com.snda.woa.android.callback.CallBack a;
    private String c;
    private String b;
    private String e;
    private android.content.Context d;
    final private String g;
    private String f;
    private com.snda.woa.bw i;
    private long h;
    private com.snda.woa.bw j;
    protected void a(Integer p10)
    {
        super.onPostExecute(p10);
        com.snda.woa.bl.b();
        com.snda.woa.au.c("BindAccountTask", new StringBuilder().append("errCode: ").append(p10).toString());
        this.i = new com.snda.woa.bw(this.d, 85, "0", this.h, v5, p10.intValue(), (System.currentTimeMillis() - this.h), v8);
        if (this.i != 0) {
            com.snda.woa.bc.a(this.d, this.i);
        }
        if (this.j != 0) {
            com.snda.woa.bc.a(this.d, this.j);
        }
        com.snda.woa.bc.b(this.d, 0);
        if (p10.intValue() != 0) {
            v0 = com.snda.woa.android.OpenAPI.getStatusText(p10.intValue());
            if (com.snda.woa.cn.d(v0) != 0) {
                this.e = v0;
            }
        } else {
            this.getClass();
            this.e = "\u8d26\u53f7\u548c\u672c\u624b\u673a\u53f7\u7ed1\u5b9a\u6210\u529f";
        }
        this.a.callBack(p10.intValue(), this.e, com.snda.woa.cf.f(this.d));
        if (p10.intValue() != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        com.snda.woa.android.OpenAPI.loginFeedBack(this.d, v0, p10.intValue(), this.f);
        return;
    }
    private int b()
    {
        v0 = com.snda.woa.av.a(this.d, com.snda.woa.ce.o[com.snda.woa.ce.b], new StringBuilder().append(com.snda.woa.ce.e).append("/bind/bindAccount.shtm").toString(), new StringBuilder().append(new StringBuilder().append(new StringBuilder().append("pwdSessionId=").append(this.b).toString()).append("&mobileSessionId=").append(this.c).toString()).append("&extParamIn=").toString(), com.snda.woa.bj.a);
        if (v0.c() != 0) {
            v2 = new org.json.JSONObject(v0.b());
            v0 = v2.getInt("resultCode");
            this.e = v2.optString("resultMsg");
            this.f = v2.optString("token");
        } else {
            this.a(v0.b());
            this.e = com.snda.woa.android.OpenAPI.getStatusText(v0.a());
            v0 = v0.a();
        }
        return v0;
    }
    protected synthetic bridge Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
    protected synthetic bridge void onPostExecute(Object p1)
    {
        this.a(p1);
        return;
    }
    public be(com.snda.woa.android.callback.CallBack p4, String p5, String p6, android.content.Context p7, String p8)
    {
        this.e = "";
        this.f = 0;
        this.g = "\u8d26\u53f7\u548c\u672c\u624b\u673a\u53f7\u7ed1\u5b9a\u6210\u529f";
        this.h = 0.0;
        this.i = 0;
        this.j = 0;
        this.a = p4;
        this.b = p5;
        this.c = p6;
        this.d = p7;
        this.h = System.currentTimeMillis();
        return;
    }
    protected varargs Integer a(String[] p11)
    {
        if (com.snda.woa.bl.a() != 0) {
            if (com.snda.woa.cn.c(com.snda.woa.at.a(this.d)) == 0) {
                v7 = com.snda.woa.k.a().b();
                this.b();
                v7.c();
                this.j = new com.snda.woa.bw(this.d, 85, "120", v7.d(), v5, this, v7.f(), v8, this.a());
                v0 = Integer.valueOf(this);
            } else {
                if (com.snda.woa.at.b(this.d) == 0) {
                    v0 = Integer.valueOf(-2.913470986822561e+38);
                } else {
                    v0 = Integer.valueOf(-2.9134697698779847e+38);
                }
            }
        } else {
            v0 = Integer.valueOf(-2.9135285888658353e+38);
        }
        return v0;
    }
}
