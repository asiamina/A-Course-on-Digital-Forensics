package com.snda.woa;
public class cf {
    public static String a;
    public static String c;
    public static String b;
    private static java.util.Hashtable e;
    public static boolean d;
    private static String g;
    private static java.util.Hashtable f;
    final private static String[][] i;
    private static Object h;
    private static java.util.concurrent.ConcurrentHashMap k;
    private static com.snda.woa.bk j;
    private static boolean l;
    public static void a(android.content.Context p3, String p4, boolean p5, boolean p6)
    {
        com.snda.woa.cf.F(p3);
        com.snda.woa.au.c("StorageUtil", new StringBuilder().append("removeData[db:").append(p5).append("] ").append(p4).append(" sync[").append(p6).append("]").toString());
        if (p6 == 0) {
            v0 = com.snda.woa.cf.g;
            v1 = com.snda.woa.cf.e;
        } else {
            v0 = com.snda.woa.cf.G(p3);
            v1 = com.snda.woa.cf.f;
        }
        v1.remove(p4);
        if (p5 != 0) {
            com.snda.woa.cf.b(p3, v0, p4);
        }
        return;
    }
    public static void a(android.content.Context p13, boolean p14)
    {
        v0 = 0;
        v2 = 2;
        if ((com.snda.woa.cf.l) && (com.snda.woa.bp.a() != 0)) {
            v4 = com.snda.woa.cf.b(com.snda.woa.cf.c());
            com.snda.woa.cf.a(v4);
            v3 = new String[1];
            v3[0] = com.snda.woa.bp.b(p13);
            v3 = com.snda.woa.cf.a(v4, "select user,type from userapp where app=?", v3);
            if (v3.moveToFirst() == 0) {
                v1 = 2;
            } else {
                v5 = v3.getString(0);
                v1 = v3.getInt(1);
                v7 = new String[2];
                v7[0] = v5;
                v7[1] = new StringBuilder().append(v1).append("").toString();
                v0 = com.snda.woa.cf.a(v4, "select token,timestamp,fail from usertoken where user=? and type=?", v7);
                if (v0.moveToFirst() != 0) {
                    if ((v0.getInt(2) != 0) || (p14 != 0)) {
                        v7 = new Object[2];
                        v7[0] = v5;
                        v7[1] = Integer.valueOf(v1);
                        com.snda.woa.cf.a(v4, "delete from usertoken where user=? and type=?", v7);
                        // Both branches of the conditions point to the same code.
                        // if (v1 != 2) {
                        // }
                    } else {
                        v6 = new Object[2];
                        v6[0] = v5;
                        v6[1] = Integer.valueOf(v1);
                        com.snda.woa.cf.a(v4, "update usertoken set fail=fail+1 where user=? and type=?", v6);
                    }
                }
            }
            com.snda.woa.cf.a(v3);
            com.snda.woa.cf.a(v0);
            com.snda.woa.cf.b(v4);
            v2 = v1;
        }
        com.snda.woa.cf.a(p13, new StringBuilder().append("key_app_token").append(v2).toString(), 1, 1);
        com.snda.woa.cf.a(p13, new StringBuilder().append("key_app_token_timestamp").append(v2).toString(), 1, 1);
        com.snda.woa.cf.a(p13, new StringBuilder().append("key_app_token_user").append(v2).toString(), 1, 1);
        com.snda.woa.cf.z(p13);
        return;
    }
    private static void a(android.database.Cursor p3)
    {
        if (p3 != 0) {
            p3.close();
        }
        return;
    }
    private static void a(android.database.sqlite.SQLiteDatabase p1, String p2)
    {
        p1.execSQL(p2);
        com.snda.woa.au.a("DB", p2);
        return;
    }
    private static void a(android.database.sqlite.SQLiteDatabase p5, String p6, Object[] p7)
    {
        p5.execSQL(p6, p7);
        v0 = new StringBuilder().append(p6).append(" ").toString();
        if (p7 != 0) {
            v3 = p7.length;
            v1 = 0;
            while (v1 < v3) {
                v2 = new StringBuilder().append(v0).append(p7[v1]).append(" ").toString();
                v1++;
                v0 = v2;
            }
        }
        com.snda.woa.au.a("DB", v0);
        return;
    }
    public static void a(com.snda.woa.bk p0)
    {
        com.snda.woa.cf.j = p0;
        return;
    }
    public static void a(boolean p0)
    {
        com.snda.woa.cf.l = p0;
        return;
    }
    private static boolean a(android.database.sqlite.SQLiteDatabase p5)
    {
        com.snda.woa.cf.a(com.snda.woa.cf.a(p5, "select user,type,token,timestamp,fail from usertoken", 0));
        com.snda.woa.cf.a(com.snda.woa.cf.a(p5, "select app,user,type from userapp", 0));
        return 0;
    }
    private static boolean a(String p2)
    {
        v0 = 1;
        if ((p2 != 0) && (("pt".equals(p2) != 0) || (("tempt".equals(p2) != 0) || (("locMobile".equals(p2) != 0) || (("loginMobile".equals(p2) != 0) || (("loginMobileTimestamp".equals(p2) != 0) || (("loginMobileSeq".equals(p2) != 0) || ("loginMobileKey".equals(p2) != 0)))))))) {
            v0 = 0;
        }
        return v0;
    }
    private static android.database.sqlite.SQLiteDatabase b(String p6)
    {
        v0 = com.snda.woa.cf.k.get(p6);
        if (v0 != 0) {
            v1 = com.snda.woa.bt.a(v0);
            com.snda.woa.bt.b(v0);
        } else {
            v1 = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(p6, 0);
            v0 = new com.snda.woa.bt(v1);
            com.snda.woa.cf.k.put(p6, v0);
        }
        com.snda.woa.au.a("DB", new StringBuilder().append("GET_DB_").append(p6).append("_COUNT_").append(com.snda.woa.bt.c(v0)).toString());
        com.snda.woa.au.a("DB", new StringBuilder().append("MAP_").append(com.snda.woa.cf.k.toString()).toString());
        return v1;
    }
    private static com.snda.woa.u b(android.content.Context p10, int p11)
    {
        if ((!com.snda.woa.cf.l) || (com.snda.woa.bp.a() == 0)) {
            v6 = 0;
        } else {
            v9 = com.snda.woa.cf.b(com.snda.woa.cf.c());
            com.snda.woa.cf.a(v9);
            v1 = new String[2];
            v1[0] = com.snda.woa.bp.b(p10);
            v4 = "";
            v1[1] = new StringBuilder().append(p11).append("").toString();
            v8 = com.snda.woa.cf.a(v9, "select user from userapp where app=? and type=?", v1);
            if (v8.moveToFirst() == 0) {
                v0 = 0;
                v1 = 0;
            } else {
                v1 = v8.getString(0);
                v2 = new String[2];
                v2[0] = v1;
                v4 = new StringBuilder().append(p11).append("").toString();
                v2[1] = v4;
                v6 = com.snda.woa.cf.a(v9, "select token,timestamp from usertoken where user=? and type=?", v2);
                if (v6.moveToFirst() != 0) {
                    v2 = v6.getString(0);
                    v3 = v6.getLong(1);
                    if ((com.snda.woa.cn.c(v1) == 0) && (com.snda.woa.cn.c(v2) == 0)) {
                        v1 = new com.snda.woa.u(v1, v2, v3, v4, p11);
                        v0 = v6;
                        com.snda.woa.cf.a(v8);
                        com.snda.woa.cf.a(v0);
                        com.snda.woa.cf.b(v9);
                        v6 = v1;
                        v1 = com.snda.woa.cf.b(p10, new StringBuilder().append("key_app_token_user").append(p11).toString(), 1);
                        v2 = com.snda.woa.cf.b(p10, new StringBuilder().append("key_app_token").append(p11).toString(), 1);
                        v3 = com.snda.woa.cf.b(p10, new StringBuilder().append("key_app_token_timestamp").append(p11).toString(), 1);
                        if ((com.snda.woa.cn.c(v1) != 0) || ((com.snda.woa.cn.c(v2) != 0) || (com.snda.woa.cn.c(v3) != 0))) {
                            v0 = 0;
                        } else {
                            v0 = new com.snda.woa.u(v1, v2, Long.parseLong(v3), v4, p11);
                        }
                        if ((v6 != 0) || (v0 != 0)) {
                            if ((v6 == 0) || (v0 == 0)) {
                                if (v0 == 0) {
                                    v0 = v6;
                                }
                            } else {
                                if (v6.b() >= v0.b()) {
                                    v0 = v6;
                                }
                            }
                        } else {
                            v0 = 0;
                        }
                        return v0;
                    }
                }
                v0 = v6;
                v1 = 0;
            }
        }
    }
    public static String b(android.content.Context p5, String p6, boolean p7)
    {
        com.snda.woa.cf.F(p5);
        if (p7 == 0) {
            v2 = com.snda.woa.cf.e;
            v1 = com.snda.woa.cf.g;
        } else {
            v2 = com.snda.woa.cf.f;
            v1 = com.snda.woa.cf.G(p5);
        }
        if (com.snda.woa.cf.a(p6) == 0) {
            v0 = 0;
        } else {
            v0 = v2.get(p6);
        }
        if (v0 == 0) {
            v0 = com.snda.woa.cf.c(p5, v1, p6);
            com.snda.woa.au.c("StorageUtil", new StringBuilder().append(p6).append(" value=").append(v0).toString());
            if (com.snda.woa.cn.c(v0) != 0) {
                v2.put(p6, "");
            } else {
                v2.put(p6, v0);
            }
        }
        return v0;
    }
    public static void b(android.content.Context p2, String p3)
    {
        com.snda.woa.cf.a(p2, "locMobile", p3, 1);
        com.snda.woa.cf.a(p2, "locMobile", p3, 1, 1);
        com.snda.woa.cf.a(p2, 2, p3);
        return;
    }
    private static void b(android.content.Context p4, String p5, String p6)
    {
        v1 = com.snda.woa.cf.b(p5);
        v2 = new Object[1];
        v2[0] = p6;
        com.snda.woa.cf.a(v1, "DELETE FROM data WHERE key=?", v2);
        com.snda.woa.cf.b(v1);
        return;
    }
    private static void b(android.database.sqlite.SQLiteDatabase p6)
    {
        if (p6 != 0) {
            v1 = p6.getPath();
            v0 = com.snda.woa.cf.k.get(v1);
            if (v0 == 0) {
                com.snda.woa.au.e("StorageUtil", new StringBuilder().append(" path ").append(v1).append(" is null ,this is a error").toString());
            }
            com.snda.woa.bt.d(v0);
            if (com.snda.woa.bt.c(v0) == 0) {
                com.snda.woa.bt.a(v0).close();
                com.snda.woa.cf.k.remove(v1);
            }
            com.snda.woa.au.a("DB", new StringBuilder().append("CLOSE_DB_").append(v1).append("_COUNT_").append(com.snda.woa.bt.c(v0)).toString());
            com.snda.woa.au.a("DB", new StringBuilder().append("MAP_").append(com.snda.woa.cf.k.toString()).toString());
        }
        return;
    }
    public static boolean b()
    {
        return com.snda.woa.cf.l;
    }
    public static boolean b(android.content.Context p3)
    {
        v0 = 1;
        v1 = com.snda.woa.cf.b(p3, "key_is_old_user", 1);
        if ((v1 == 0) || ("1".equals(v1) == 0)) {
            v0 = 0;
        }
        return v0;
    }
    private static String c()
    {
        return new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append(com.snda.woa.ce.i).toString();
    }
    private static String c(android.content.Context p6, String p7, String p8)
    {
        v0 = 0;
        v3 = com.snda.woa.cf.b(p7);
        v2 = com.snda.woa.cf.a(v3, new StringBuilder().append("SELECT * FROM data WHERE key=\'").append(p8).append("\'").toString(), 0);
        if (v2.moveToFirst() == 0) {
            com.snda.woa.cf.a(v2);
            com.snda.woa.cf.b(v3);
        } else {
            com.snda.woa.au.c("StorageUtil", new StringBuilder().append("oCursor.getString(oCursor.getColumnIndex()=").append(v2.getString(v2.getColumnIndex("value"))).toString());
            v0 = v2.getString(v2.getColumnIndex("value"));
            com.snda.woa.cf.a(v2);
            com.snda.woa.cf.b(v3);
        }
        return v0;
    }
    public static void c(android.content.Context p2)
    {
        com.snda.woa.cf.a(p2, "pt", 1);
        com.snda.woa.cf.x(p2);
        com.snda.woa.cf.a(p2, "tempt", 1);
        return;
    }
    private static void c(android.content.Context p5, int p6)
    {
        if ((com.snda.woa.cf.l) && (com.snda.woa.bp.a() != 0)) {
            v1 = com.snda.woa.cf.b(com.snda.woa.cf.c());
            com.snda.woa.cf.a(v1);
            v2 = new StringBuilder().append("delete from userapp where app=? ");
            if (p6 >= 0) {
                v0 = " and type =? ";
            } else {
                v0 = "";
            }
            v2 = v2.append(v0).toString();
            if (p6 >= 0) {
                v0 = new Object[2];
                v0[0] = com.snda.woa.bp.b(p5);
                v0[1] = Integer.valueOf(p6);
            } else {
                v0 = new Object[1];
                v0[0] = com.snda.woa.bp.b(p5);
            }
            com.snda.woa.cf.a(v1, v2, v0);
            com.snda.woa.cf.b(v1);
        }
        com.snda.woa.cf.a(p5, new StringBuilder().append("key_app_token").append(p6).toString(), 1, 1);
        com.snda.woa.cf.a(p5, new StringBuilder().append("key_app_token_timestamp").append(p6).toString(), 1, 1);
        com.snda.woa.cf.a(p5, new StringBuilder().append("key_app_token_user").append(p6).toString(), 1, 1);
        return;
    }
    public static void c(android.content.Context p3, String p4)
    {
        v0 = com.snda.woa.ba.b(com.snda.woa.cf.a(p3, "ssnBacklist"), ",");
        if (v0 == 0) {
            v0 = new java.util.HashSet(0);
        }
        v0.add(p4);
        com.snda.woa.cf.a(p3, "ssnBacklist", com.snda.woa.ct.a(v0, ","), 1);
        return;
    }
    public static void d(android.content.Context p0)
    {
        com.snda.woa.cf.y(p0);
        return;
    }
    public static void d(android.content.Context p2, String p3)
    {
        com.snda.woa.cf.a(p2, "key_uuid", p3, 1);
        com.snda.woa.cf.a(p2, "key_uuid", p3, 1, 1);
        com.snda.woa.cf.k(p2);
        return;
    }
    public static String e(android.content.Context p3)
    {
        v0 = p3.getSystemService("phone").getDeviceId();
        if (com.snda.woa.cn.d(v0) != 0) {
            com.snda.woa.cf.a(p3, "imei", v0, 1);
        }
        return v0;
    }
    public static void e(android.content.Context p2, String p3)
    {
        if (("0".equals(p3) != 0) || ("1".equals(p3) != 0)) {
            com.snda.woa.cf.a(p2, "sms_login_status", p3, 1, 1);
        }
        return;
    }
    public static String f(android.content.Context p3)
    {
        v0 = com.snda.woa.cf.a(p3, "locMobile");
        if (com.snda.woa.cn.c(v0) == 0) {
            if (java.util.regex.Pattern.matches("[0-9]{1,}", v0) == 0) {
                v0 = new com.snda.woa.p("w!o2a#r4e%g6i&n8(0)^_-==").b(v0, 0);
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
    public static void f(android.content.Context p2, String p3)
    {
        com.snda.woa.cf.a(p2, "mobile_mark", p3, 1);
        return;
    }
    public static String g(android.content.Context p4)
    {
        v0 = com.snda.woa.cf.b;
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.a(p4, "locMobile");
        }
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.b(p4, "locMobile", 1);
        }
        com.snda.woa.au.b("StorageUtil", new StringBuilder().append(" mobile=").append(v0).toString());
        return v0;
    }
    public static void g(android.content.Context p2, String p3)
    {
        com.snda.woa.cf.a(p2, "key_is_registered", p3, 1);
        com.snda.woa.cf.a(p2, "key_is_registered", p3, 1, 1);
        return;
    }
    public static String h(android.content.Context p5)
    {
        com.snda.woa.cf.F(p5);
        v0 = com.snda.woa.cf.a(p5, "imsi");
        v1 = com.snda.woa.ai.b(p5);
        if ((v1 != 0) && ((v0 == 0) || (v0.equals(v1) == 0))) {
            com.snda.woa.au.c("StorageUtil", "remove local mobile from db");
            com.snda.woa.cf.a(p5, "sms_login_status", 1);
            com.snda.woa.cf.a(p5, "locMobile", 1);
            com.snda.woa.cf.a(p5, "locMobile", 1, 1);
            com.snda.woa.cf.a(p5, "key_is_registered", 1);
            com.snda.woa.cf.a(p5, "key_is_registered", 1, 1);
            com.snda.woa.cf.a(p5, 9, "");
            com.snda.woa.android.OpenAPI.clearMobileLoginData(p5);
            com.snda.woa.cf.a(p5, "imsi", 1);
            com.snda.woa.cf.a(p5, "imsi", v1, 1);
            com.snda.woa.cf.a(p5, "ssn", 0);
            com.snda.woa.cf.a(p5, "ssnBacklist", 0);
            com.snda.woa.cf.a(p5, "backupSsnList", 0);
            com.snda.woa.cf.a(p5, "key_sms_time", 1);
        }
        return v1;
    }
    public static void h(android.content.Context p2, String p3)
    {
        com.snda.woa.cf.a(p2, "key_is_dual_card", p3, 1);
        com.snda.woa.cf.a(p2, "key_is_dual_card", p3, 1, 1);
        return;
    }
    public static String i(android.content.Context p1)
    {
        return com.snda.woa.cf.a(p1, "ssn");
    }
    public static void i(android.content.Context p2, String p3)
    {
        if (("0".equals(p3) != 0) || ("1".equals(p3) != 0)) {
            com.snda.woa.cf.a(p2, "fast_callback", p3, 1, 1);
        }
        return;
    }
    public static String j(android.content.Context p8, String p9)
    {
        v0 = com.snda.woa.cf.a(p8, "loginMobileKey");
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.b(p8, "loginMobileKey", 1);
        }
        if (com.snda.woa.cn.c(v0) != 0) {
            v1 = com.snda.woa.cf.b(p8, "loginMobile", 1);
            if ((v1 != 0) && (v1.length() > 8)) {
                v0 = v1.substring(8);
                com.snda.woa.cf.k(p8, v1);
            }
        }
        v1 = v0;
        v2 = com.snda.woa.cf.a(p8, "loginMobileSeq");
        v0 = "0";
        if (com.snda.woa.cn.c(v2) == 0) {
            v0 = com.snda.woa.cf.b(p8, "loginMobileSeq", 1);
        } else {
            v2 = com.snda.woa.cf.b(p8, "loginMobileSeq", 1);
        }
        if (com.snda.woa.cn.d(v1) == 0) {
            v0 = 0;
        } else {
            v2 = Long.parseLong(v2);
            v4 = Long.parseLong(v0);
            if (v4 > v2) {
                v2 = v4;
            }
            v2++;
            v4 = new StringBuffer(new StringBuilder().append(v2).append("").toString());
            v4.append("|");
            com.snda.woa.cf.a(p8, "loginMobileSeq", new StringBuilder().append(v2).append("").toString(), 1);
            com.snda.woa.cf.a(p8, "loginMobileSeq", new StringBuilder().append(v2).append("").toString(), 1, 1);
            v0 = p8.getSystemService("phone");
            if (v0 != 0) {
                v4.append(v0.getDeviceId());
            }
            v4.append("|");
            v4.append(p9);
            v0 = com.snda.woa.ap.a(v4.toString(), v1);
        }
        return v0;
    }
    public static boolean j(android.content.Context p7)
    {
        v0 = 1;
        v1 = Long.parseLong(com.snda.woa.cf.a(p7, "key_sms_time"));
        if ((v1 != 0.0) && (System.currentTimeMillis() >= v1)) {
            com.snda.woa.au.c("StorageUtil", new StringBuilder().append("smsTime ").append(v1).toString());
            if (System.currentTimeMillis() > (604800000.0 + v1)) {
                com.snda.woa.cf.m(p7);
            }
            if (System.currentTimeMillis() <= (v1 + 100000.0)) {
                v0 = 0;
            }
        }
        return v0;
    }
    public static void k(android.content.Context p4)
    {
        com.snda.woa.cf.a(p4, "key_sms_time", new StringBuilder().append(System.currentTimeMillis()).append("").toString(), 1);
        return;
    }
    public static void k(android.content.Context p4, String p5)
    {
        if (com.snda.woa.cn.c(p5) == 0) {
            com.snda.woa.cf.a(p4, "loginMobileKey", p5.substring(8), 1);
            com.snda.woa.cf.a(p4, "loginMobileKey", p5.substring(8), 1, 1);
            com.snda.woa.cf.a(p4, "loginMobileSeq", "0", 1);
            com.snda.woa.cf.a(p4, "loginMobileSeq", "0", 1, 1);
        }
        return;
    }
    public static String l(android.content.Context p2)
    {
        v0 = com.snda.woa.cf.a;
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.a(p2, "key_uuid");
        }
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.b(p2, "key_uuid", 1);
        }
        return v0;
    }
    public static void m(android.content.Context p2)
    {
        com.snda.woa.cf.a(p2, "key_uuid", 1);
        com.snda.woa.cf.a(p2, "key_uuid", 1, 1);
        com.snda.woa.cf.a(p2, 8, "");
        return;
    }
    public static String n(android.content.Context p4)
    {
        v0 = com.snda.woa.cf.i(p4);
        com.snda.woa.au.c("MobileService", new StringBuilder().append("ssn=").append(v0).toString());
        return v0;
    }
    public static String o(android.content.Context p2)
    {
        v0 = com.snda.woa.cf.a(p2, "key_is_registered");
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.b(p2, "key_is_registered", 1);
        }
        return v0;
    }
    public static boolean p(android.content.Context p5)
    {
        v1 = 0;
        v0 = com.snda.woa.cf.H(p5);
        if ("1".equals(v0) == 0) {
            if ("0".equals(v0) == 0) {
                v3 = android.os.Build.MODEL.toLowerCase();
                v0 = 0;
                while (v0 < com.snda.woa.cf.i.length) {
                    if ((v3.contains(com.snda.woa.cf.i[v0][0].toLowerCase()) == 0) || (v3.contains(com.snda.woa.cf.i[v0][1].toLowerCase()) == 0)) {
                        v0++;
                    } else {
                        com.snda.woa.cf.h(p5, "1");
                        v1 = 1;
                        break;
                    }
                }
            }
        } else {
            v1 = 1;
        }
        return v1;
    }
    public static boolean q(android.content.Context p2)
    {
        return "1".equals(com.snda.woa.cf.b(p2, "fast_callback", 1));
    }
    public static com.snda.woa.u r(android.content.Context p1)
    {
        return com.snda.woa.cf.t(p1);
    }
    public static com.snda.woa.u s(android.content.Context p2)
    {
        v0 = com.snda.woa.cf.a(p2, 3);
        if ((v0 == 0) || (v0.f() == 0)) {
            v0 = 0;
        }
        return v0;
    }
    public static com.snda.woa.u t(android.content.Context p4)
    {
        v0 = com.snda.woa.cf.g(p4);
        v1 = com.snda.woa.cf.A(p4);
        if ((com.snda.woa.cn.c(v0) != 0) || (com.snda.woa.cn.c(v1) != 0)) {
            v0 = 0;
        } else {
            v0 = com.snda.woa.u.c(v0, v1, 0.0);
        }
        return v0;
    }
    public static String u(android.content.Context p2)
    {
        v0 = com.snda.woa.cf.a(p2, 1);
        if ((v0 == 0) || (v0.e() == 0)) {
            v0 = "";
        } else {
            v0 = v0.c();
        }
        return v0;
    }
    public static boolean v(android.content.Context p4)
    {
        v0 = com.snda.woa.cf.a(p4, "loginMobileKey");
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.b(p4, "loginMobileKey", 1);
        }
        v1 = com.snda.woa.cf.a(p4, "loginMobileSeq");
        if (com.snda.woa.cn.c(v1) != 0) {
            v1 = com.snda.woa.cf.b(p4, "loginMobileSeq", 1);
        }
        if ((com.snda.woa.cn.d(v0) == 0) || (com.snda.woa.cn.d(v1) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static void w(android.content.Context p1)
    {
        com.snda.woa.cf.c(p1, -1);
        return;
    }
    public static void x(android.content.Context p1)
    {
        com.snda.woa.cf.c(p1, 1);
        return;
    }
    public static void y(android.content.Context p1)
    {
        com.snda.woa.cf.c(p1, 2);
        return;
    }
    public static void z(android.content.Context p0)
    {
        com.snda.woa.cf.I(p0);
        return;
    }
    static cf()
    {
        com.snda.woa.cf.e = new java.util.Hashtable();
        com.snda.woa.cf.f = new java.util.Hashtable();
        com.snda.woa.cf.g = 0;
        com.snda.woa.cf.a = 0;
        com.snda.woa.cf.b = 0;
        com.snda.woa.cf.c = 0;
        com.snda.woa.cf.h = new Object();
        v0 = new String[][32];
        v1 = new String[2];
        v1[0] = "Galaxy";
        v1[1] = "Nexus";
        v0[0] = v1;
        v1 = new String[2];
        v1[0] = "htc";
        v1[1] = "T328W";
        v0[1] = v1;
        v1 = new String[2];
        v1[0] = "HTC";
        v1[1] = "T328d";
        v0[2] = v1;
        v2 = new String[2];
        v2[0] = "HTC";
        v2[1] = "T328W";
        v0[3] = v2;
        v2 = new String[2];
        v2[0] = "HTC";
        v2[1] = "htcz510d";
        v0[4] = v2;
        v2 = new String[2];
        v2[0] = "HTC";
        v2[1] = "z510d";
        v0[5] = v2;
        v2 = new String[2];
        v2[0] = "ZTE";
        v2[1] = "V889D";
        v0[6] = v2;
        v2 = new String[2];
        v2[0] = "ZTE";
        v2[1] = "U960";
        v0[7] = v2;
        v2 = new String[2];
        v2[0] = "Hisense";
        v2[1] = "eg900";
        v0[8] = v2;
        v2 = new String[2];
        v2[0] = "huawei";
        v2[1] = "S8600";
        v0[9] = v2;
        v2 = new String[2];
        v2[0] = "huawei";
        v2[1] = "s8520";
        v0[10] = v2;
        v2 = new String[2];
        v2[0] = "Coolpad";
        v2[1] = "7260";
        v0[11] = v2;
        v2 = new String[2];
        v2[0] = "Coolpad";
        v2[1] = "5832";
        v0[12] = v2;
        v2 = new String[2];
        v2[0] = "Coolpad";
        v2[1] = "d539";
        v0[13] = v2;
        v2 = new String[2];
        v2[0] = "Lenovo";
        v2[1] = "P70";
        v0[14] = v2;
        v2 = new String[2];
        v2[0] = "Lenovo";
        v2[1] = "A1-32AB0";
        v0[15] = v2;
        v2 = new String[2];
        v2[0] = "moto";
        v2[1] = "xt317";
        v0[16] = v2;
        v2 = new String[2];
        v2[0] = "MOTO";
        v2[1] = "XT800";
        v0[17] = v2;
        v2 = new String[2];
        v2[0] = "Moto";
        v2[1] = "928";
        v0[18] = v2;
        v2 = new String[2];
        v2[0] = "MOTO";
        v2[1] = "XT532";
        v0[19] = v2;
        v2 = new String[2];
        v2[0] = "Philips";
        v2[1] = "W635";
        v0[20] = v2;
        v2 = new String[2];
        v2[0] = "coolpad";
        v2[1] = "5832";
        v0[21] = v2;
        v2 = new String[2];
        v2[0] = "COOLPAD";
        v2[1] = "D539";
        v0[22] = v2;
        v2 = new String[2];
        v2[0] = "SAMSUNG";
        v2[1] = "i909";
        v0[23] = v2;
        v2 = new String[2];
        v2[0] = "SAMSUNG";
        v2[1] = "I589";
        v0[24] = v2;
        v2 = new String[2];
        v2[0] = "SAMSUNG";
        v2[1] = "I929";
        v0[25] = v2;
        v2 = new String[2];
        v2[0] = "SAMSUNG";
        v2[1] = "W899";
        v0[26] = v2;
        v2 = new String[2];
        v2[0] = "Hisense";
        v2[1] = "U8";
        v0[27] = v2;
        v2 = new String[2];
        v2[0] = "SKYWORTH";
        v2[1] = "GEG6188";
        v0[28] = v2;
        v2 = new String[2];
        v2[0] = "CHANGHONG";
        v2[1] = "5018";
        v0[29] = v2;
        v2 = new String[2];
        v2[0] = "K-Touch";
        v2[1] = "E619";
        v0[30] = v2;
        v2 = new String[2];
        v2[0] = "K-Touch";
        v2[1] = "W619";
        v0[31] = v2;
        com.snda.woa.cf.i = v0;
        com.snda.woa.cf.d = 1;
        com.snda.woa.cf.j = 0;
        com.snda.woa.cf.k = new java.util.concurrent.ConcurrentHashMap();
        com.snda.woa.cf.l = 1;
        return;
    }
    public cf()
    {
        return;
    }
    public static String A(android.content.Context p2)
    {
        v0 = com.snda.woa.cf.c;
        if (com.snda.woa.cn.c(v0) != 0) {
            v1 = com.snda.woa.cf.B(p2);
            if (v1 != 0) {
                v0 = v1.c();
            }
        }
        return v0;
    }
    public static com.snda.woa.u B(android.content.Context p10)
    {
        v2 = com.snda.woa.cf.a(p10, "loginMobile");
        v6 = com.snda.woa.cf.b(p10, "loginMobile", 1);
        com.snda.woa.au.c("StorageUtil", new StringBuilder().append("token = ").append(v2).toString());
        com.snda.woa.au.c("StorageUtil", new StringBuilder().append("fileDirToken = ").append(v6).toString());
        if ((com.snda.woa.cn.c(v2) == 0) || (com.snda.woa.cn.c(v6) == 0)) {
            v0 = com.snda.woa.cf.a(p10, "loginMobileTimestamp");
            v7 = com.snda.woa.cf.b(p10, "loginMobileTimestamp", 1);
            v3 = com.snda.woa.cf.a(v0, 0.0);
            v7 = com.snda.woa.cf.a(v7, 0.0);
            if ((com.snda.woa.cn.c(v2) != 0) || (com.snda.woa.cn.c(v6) != 0)) {
                if (com.snda.woa.cn.c(v2) != 0) {
                    v0 = new com.snda.woa.u(0, v6, v7, "fileDirToken = ", 0);
                } else {
                    v0 = new com.snda.woa.u(0, v2, v3, "fileDirToken = ", 0);
                }
            } else {
                if (v3 < v7) {
                    v0 = new com.snda.woa.u(0, v6, v7, "fileDirToken = ", 0);
                } else {
                    v0 = new com.snda.woa.u(0, v2, v3, "fileDirToken = ", 0);
                }
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
    public static boolean C(android.content.Context p4)
    {
        v0 = 0;
        v1 = com.snda.woa.cf.a(p4, "key_cmwap_opt");
        if ((v1 != 0) && ("1".equals(v1) != 0)) {
            v0 = 1;
        }
        return v0;
    }
    public static void D(android.content.Context p3)
    {
        com.snda.woa.cf.a(p3, "key_cmwap_opt", "1", 1);
        return;
    }
    public static void E(android.content.Context p3)
    {
        com.snda.woa.cf.a(p3, "key_cmwap_opt", "0", 1);
        return;
    }
    private static void F(android.content.Context p6)
    {
        if (com.snda.woa.cf.g == 0) {
            if ((!com.snda.woa.cf.l) || (com.snda.woa.bp.a() == 0)) {
                if (p6 != 0) {
                    com.snda.woa.cf.g = com.snda.woa.cf.G(p6);
                }
            } else {
                com.snda.woa.cf.g = new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append(com.snda.woa.ce.i).toString();
            }
            com.snda.woa.au.c("StorageUtil", new StringBuilder().append("StorageUtil.databasePath=").append(com.snda.woa.cf.g).toString());
            v1 = com.snda.woa.cf.b(p6, "publicKey", 1);
            v0 = 0;
            if (v1 != 0) {
                v0 = com.snda.woa.cn.a(v1, "|");
            }
            if ((v0 != 0) && (v0.length > 1)) {
                com.snda.woa.a.a(v0[1], v0[0]);
                com.snda.woa.au.c("StorageUtil", new StringBuilder().append("pubKeys[0] ").append(v0[0]).append(" pubKeys[1] ").append(v0[1]).toString());
            }
            if (com.snda.woa.cn.c(com.snda.woa.cf.l(p6)) != 0) {
                com.snda.woa.cf.a(p6, 5, "");
            }
            if ((android.os.Build.MODEL.contains("Bambook") == 0) || ((android.os.Build.MODEL.contains("S1") == 0) || (Long.parseLong(android.os.Build$VERSION.INCREMENTAL) >= 502.0))) {
                if (com.snda.woa.cn.c(com.snda.woa.cf.g(p6)) != 0) {
                    com.snda.woa.cf.a(p6, 1, "");
                }
                if (com.snda.woa.cn.c(com.snda.woa.cf.A(p6)) != 0) {
                    com.snda.woa.cf.a(p6, 3, "");
                }
            } else {
                com.snda.woa.au.c("StorageUtil", new StringBuilder().append("No CMD_GET_TOKEN - ").append(android.os.Build.MODEL).append(android.os.Build$VERSION.INCREMENTAL).toString());
            }
        }
        return;
    }
    private static String G(android.content.Context p3)
    {
        com.snda.woa.au.b("StorageUtil", new StringBuilder().append("getFileDirDb(Context ").append(p3).toString());
        com.snda.woa.au.b("StorageUtil", new StringBuilder().append("getFileDirDb(Context.getFilesDir() ").append(p3.getFilesDir()).toString());
        com.snda.woa.au.b("StorageUtil", new StringBuilder().append("getFileDirDb(Context.getFilesDir().getPath() ").append(p3.getFilesDir().getPath()).toString());
        com.snda.woa.au.b("StorageUtil", new StringBuilder().append("getFileDirDb(DATABASE_PATH) ").append(p3.getFilesDir().getPath()).append(com.snda.woa.ce.i).toString());
        return new StringBuilder().append(p3.getFilesDir().getPath()).append(com.snda.woa.ce.i).toString();
    }
    private static String H(android.content.Context p2)
    {
        v0 = com.snda.woa.cf.a(p2, "key_is_dual_card");
        if (com.snda.woa.cn.c(v0) != 0) {
            v0 = com.snda.woa.cf.b(p2, "key_is_dual_card", 1);
        }
        return v0;
    }
    private static void I(android.content.Context p2)
    {
        com.snda.woa.cf.a(p2, "loginMobileKey", 1);
        com.snda.woa.cf.a(p2, "loginMobileKey", 1, 1);
        com.snda.woa.cf.a(p2, "loginMobileSeq", 1);
        com.snda.woa.cf.a(p2, "loginMobileSeq", 1, 1);
        com.snda.woa.cf.a(p2, "loginMobile", 1);
        com.snda.woa.cf.a(p2, "loginMobile", 1, 1);
        com.snda.woa.cf.a(p2, "loginMobileTimestamp", 1);
        com.snda.woa.cf.a(p2, "loginMobileTimestamp", 1, 1);
        com.snda.woa.cf.a(p2, 7, "");
        return;
    }
    public static long a(String p1, long p2)
    {
        if (com.snda.woa.cn.c(p1) == 0) {
            p2 = Long.parseLong(p1);
        }
        return p2;
    }
    private static android.database.Cursor a(android.database.sqlite.SQLiteDatabase p5, String p6, String[] p7)
    {
        v0 = new StringBuilder().append(p6).append(" ").toString();
        if (p7 != 0) {
            v3 = p7.length;
            v1 = 0;
            while (v1 < v3) {
                v2 = new StringBuilder().append(v0).append(p7[v1]).append(" ").toString();
                v1++;
                v0 = v2;
            }
        }
        com.snda.woa.au.a("DB", v0);
        return p5.rawQuery(p6, p7);
    }
    public static com.snda.woa.bk a()
    {
        return com.snda.woa.cf.j;
    }
    public static com.snda.woa.u a(android.content.Context p7, int p8)
    {
        v0 = com.snda.woa.cf.b(p7, p8);
        if ((v0 != 0) && (v0.d() == 2)) {
            v1 = com.snda.woa.cf.g(p7);
            v2 = com.snda.woa.cf.B(p7);
            if ((v2 != 0) && ((com.snda.woa.cn.b(v1) == 0) && ((v1.equals(v0.a()) != 0) && (v2.b() >= v0.b())))) {
                v0 = com.snda.woa.u.c(v1, v2.c(), v2.b());
            }
        }
        return v0;
    }
    public static String a(android.content.Context p1)
    {
        com.snda.woa.cf.F(p1);
        return com.snda.woa.cf.g;
    }
    public static String a(android.content.Context p1, String p2)
    {
        return com.snda.woa.cf.b(p1, p2, 0);
    }
    public static void a(android.content.Context p3, int p4, String p5)
    {
        if (!com.snda.woa.cf.d) {
            com.snda.woa.au.c("StorageUtil", new StringBuilder().append("\u53d1\u9001\u5e7f\u64ad: ").append(p4).append(" ").append(p5).toString());
            new com.snda.woa.w(p3).a(p4, p5);
        }
        return;
    }
    public static void a(android.content.Context p4, String p5, long p6)
    {
        if (com.snda.woa.cn.c(p5) == 0) {
            com.snda.woa.cf.a(p4, "loginMobile", p5, 1);
            com.snda.woa.cf.a(p4, "loginMobile", p5, 1, 1);
            com.snda.woa.cf.a(p4, "loginMobileTimestamp", new StringBuilder().append(p6).append("").toString(), 1);
            com.snda.woa.cf.a(p4, "loginMobileTimestamp", new StringBuilder().append(p6).append("").toString(), 1, 1);
            com.snda.woa.cf.a(p4, 4, new StringBuilder().append(p5).append("|").append(p6).toString());
        }
        return;
    }
    public static void a(android.content.Context p9, String p10, com.snda.woa.u p11)
    {
        if (com.snda.woa.cn.c(p10) == 0) {
            if ((com.snda.woa.cf.l) && (com.snda.woa.bp.a() != 0)) {
                v3 = com.snda.woa.cf.b(com.snda.woa.cf.c());
                com.snda.woa.cf.a(v3);
                v2 = new String[2];
                v2[0] = p10;
                v2[1] = new StringBuilder().append(p11.d()).append("").toString();
                v2 = com.snda.woa.cf.a(v3, "select * from usertoken where user=? and type=?", v2);
                if (v2.moveToFirst() == 0) {
                    v4 = new Object[4];
                    v4[0] = p10;
                    v4[1] = Integer.valueOf(p11.d());
                    v4[2] = p11.c();
                    v4[3] = Long.valueOf(p11.b());
                    com.snda.woa.cf.a(v3, "insert into usertoken (user,type,token,timestamp,fail) values (?,?,?,?,0)", v4);
                } else {
                    v4 = new Object[4];
                    v4[0] = p11.c();
                    v4[1] = Long.valueOf(p11.b());
                    v4[2] = p10;
                    v4[3] = Integer.valueOf(p11.d());
                    com.snda.woa.cf.a(v3, "update usertoken set token=?,timestamp=?,fail=0 where user=? and type=?", v4);
                }
                v4 = new String[2];
                v4[0] = com.snda.woa.bp.b(p9);
                v4[1] = new StringBuilder().append(p11.d()).append("").toString();
                v1 = com.snda.woa.cf.a(v3, "select * from userapp where app=? and type=?", v4);
                if (v1.moveToFirst() == 0) {
                    v4 = new Object[3];
                    v4[0] = com.snda.woa.bp.b(p9);
                    v4[1] = p10;
                    v4[2] = Integer.valueOf(p11.d());
                    com.snda.woa.cf.a(v3, "insert into userapp (app,user,type) values (?,?,?)", v4);
                } else {
                    v4 = new Object[3];
                    v4[0] = p10;
                    v4[1] = com.snda.woa.bp.b(p9);
                    v4[2] = Integer.valueOf(p11.d());
                    com.snda.woa.cf.a(v3, "update userapp set user=? where app=? and type=?", v4);
                }
                com.snda.woa.cf.a(v2);
                com.snda.woa.cf.a(v1);
                com.snda.woa.cf.b(v3);
            }
            com.snda.woa.cf.a(p9, new StringBuilder().append("key_app_token").append(p11.d()).toString(), p11.c(), 1, 1);
            com.snda.woa.cf.a(p9, new StringBuilder().append("key_app_token_timestamp").append(p11.d()).toString(), new StringBuilder().append(p11.b()).append("").toString(), 1, 1);
            com.snda.woa.cf.a(p9, new StringBuilder().append("key_app_token_user").append(p11.d()).toString(), p10, 1, 1);
            if (p11.d() == 2) {
                v0 = com.snda.woa.cf.a(p9, "locMobile");
                if ((v0 != 0) && (v0.equals(p10) != 0)) {
                    com.snda.woa.cf.a(p9, p11.c(), p11.b());
                }
            }
        }
        return;
    }
    public static void a(android.content.Context p6, String p7, String p8)
    {
        if (com.snda.woa.cn.c(p7) == 0) {
            com.snda.woa.cf.a(p6, "ssn", p7, 0);
            if (p8 == 0) {
                p8 = "";
            }
            v0 = com.snda.woa.ba.b(com.snda.woa.cf.a(p6, "ssnBacklist"), ",");
            if (v0 != 0) {
                v1 = v0;
            } else {
                v1 = new java.util.HashSet(0);
            }
            com.snda.woa.cf.a(p6, "backupSsnList", p8, 0);
            v0 = com.snda.woa.ba.c(p8, ",");
            if (v0 == 0) {
                v0 = new java.util.ArrayList(0);
            }
            if (v1.contains(p7) == 0) {
                com.snda.woa.cf.a(p6, "ssnBacklist", 1);
            } else {
                v4 = v0.iterator();
                while (v4.hasNext() != 0) {
                    v0 = v4.next();
                    if (v1.contains(v0) == 0) {
                        com.snda.woa.cf.a(p6, "ssn", v0, 1);
                        v0 = 1;
                    }
                    if (v0 == 0) {
                        com.snda.woa.cf.a(p6, "ssnBacklist", 1);
                    }
                }
                v0 = 0;
            }
        }
        return;
    }
    private static void a(android.content.Context p6, String p7, String p8, String p9)
    {
        v2 = com.snda.woa.cf.b(p7);
        com.snda.woa.cf.a(com.snda.woa.cf.a(v2, "SELECT * FROM data", 0));
        v1 = com.snda.woa.cf.a(v2, new StringBuilder().append("SELECT * FROM data WHERE key=\'").append(p8).append("\'").toString(), 0);
        if (v1.getCount() != 0) {
            com.snda.woa.cf.a(v2, new StringBuilder().append("UPDATE data set value=\'").append(p9).append("\' WHERE key=\'").append(p8).append("\'").toString());
        } else {
            com.snda.woa.cf.a(v2, new StringBuilder().append("INSERT INTO data (key, value) VALUES(\'").append(p8).append("\',\'").append(p9).append("\')").toString());
        }
        com.snda.woa.cf.a(v1);
        com.snda.woa.cf.b(v2);
        return;
    }
    public static void a(android.content.Context p1, String p2, String p3, boolean p4)
    {
        com.snda.woa.cf.a(p1, p2, p3, p4, 0);
        return;
    }
    public static void a(android.content.Context p3, String p4, String p5, boolean p6, boolean p7)
    {
        com.snda.woa.cf.F(p3);
        com.snda.woa.au.c("StorageUtil", new StringBuilder().append("saveData[db:").append(p6).append("] ").append(p4).append("=").append(p5).append(" sync[").append(p7).append("]").toString());
        if ((p4 != 0) && (p5 != 0)) {
            if (p7 == 0) {
                v0 = com.snda.woa.cf.g;
                v1 = com.snda.woa.cf.e;
            } else {
                v0 = com.snda.woa.cf.G(p3);
                v1 = com.snda.woa.cf.f;
            }
            v1.put(p4, p5);
            if (p6 != 0) {
                com.snda.woa.cf.a(p3, v0, p4, p5);
            }
        }
        return;
    }
    public static void a(android.content.Context p1, String p2, boolean p3)
    {
        com.snda.woa.cf.a(p1, p2, p3, 0);
        return;
    }
}
