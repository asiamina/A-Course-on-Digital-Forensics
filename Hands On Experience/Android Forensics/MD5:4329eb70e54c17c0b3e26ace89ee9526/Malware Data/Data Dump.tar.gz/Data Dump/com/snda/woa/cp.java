package com.snda.woa;
public class cp {
    public cp()
    {
        return;
    }
    public static int a(android.content.Context p1, String p2)
    {
        if (com.snda.woa.ai.a(p1) != 0) {
            v0 = com.snda.woa.cu.a(p1, com.snda.woa.cf.n(p1), p2);
        } else {
            v0 = -2.9135298058104116e+38;
        }
        return v0;
    }
    public static com.snda.woa.cq a(android.content.Context p11)
    {
        return new com.snda.woa.cq(0, com.snda.woa.cp.a(p11, 0, 6, 0, 0, 0, 0, 0, 1, 1, 0));
    }
    public static com.snda.woa.cq a(android.content.Context p11, String p12, String p13)
    {
        return new com.snda.woa.cq(0, com.snda.woa.cp.a(p11, p12, 3, 0, 0, 0, 0, 0, 1, 1, 0));
    }
    public static com.snda.woa.cq a(android.content.Context p11, String p12, String p13, String p14)
    {
        v4 = com.snda.woa.cf.g(p11);
        if (com.snda.woa.cn.c(v4) == 0) {
            com.snda.woa.au.c("MobileService", new StringBuilder().append("phone=").append(v4).toString());
            v10 = com.snda.woa.cf.j(p11, p14);
            if (com.snda.woa.cn.c(v10) == 0) {
                v1 = com.snda.woa.cp.a(p11, 0, 1, 0, v4, 0, 0, 0, 0, 0, v10);
            } else {
                v1 = com.snda.woa.cp.a(p11, 0, 1, 0, v4, 0, new StringBuilder().append(p13).append("|").append(p14).toString(), 0, 0, 1, 0);
            }
            v0 = new com.snda.woa.cq(0, v1);
        } else {
            v0 = new com.snda.woa.cq(com.snda.woa.cm.d(p11));
        }
        return v0;
    }
    public static com.snda.woa.cq a(android.content.Context p7, String p8, String p9, String p10, boolean p11)
    {
        v0 = com.snda.woa.ce.e;
        if (p11 == 0) {
            v1 = new StringBuilder().append(v0).append("/autologin/verifyClientEx.shtm").toString();
        } else {
            v1 = new StringBuilder().append(v0).append("/autologin/verifyClientExp.shtm").toString();
        }
        v2 = new StringBuffer();
        com.snda.woa.ap.c(com.snda.woa.ay.a(8));
        v2.append("signature=");
        v2.append(com.snda.woa.a.a(com.snda.woa.ap.a()));
        if (p11 == 0) {
            v2.append("&pubKeyVersion=");
            v2.append(com.snda.woa.a.a());
            v2.append("&uuid=");
            v0 = p8.indexOf(124);
            if (v0 > 0) {
                p8 = p8.substring(0, v0);
            }
            v2.append(p8);
        } else {
            v2.append("&sndaId=");
            v2.append(p8);
            v2.append("&hasSDCard=");
            if ((com.snda.woa.cf.b() == 0) || (com.snda.woa.bp.a() == 0)) {
                v0 = "0";
            } else {
                v0 = "1";
            }
            v2.append(v0);
        }
        if (com.snda.woa.cn.c(p9) == 0) {
            v2.append("&smsCode=");
            if (p11 == 0) {
                v2.append(com.snda.woa.ap.a(p9));
            } else {
                v2.append(p9);
            }
        }
        v0 = p7.getSystemService("phone");
        if (v0 != 0) {
            v2.append("&imei=");
            v2.append(com.snda.woa.ap.a(v0.getDeviceId()));
        }
        if (com.snda.woa.cn.c(p10) == 0) {
            v2.append("&extParamIn=");
            v2.append(p10);
        }
        v1 = com.snda.woa.av.a(p7, com.snda.woa.ce.o[com.snda.woa.ce.b], v1, v2.toString(), com.snda.woa.bj.a);
        if (v1.c() != 0) {
            v1 = v1.b();
            if ((v1 == 0) || (v1.length() <= 0)) {
                v0 = new com.snda.woa.cq(com.snda.woa.av.a(p7), "");
            } else {
                v2 = new org.json.JSONObject(v1);
                v3 = v2.optInt("resultCode", -999);
                v4 = v2.optString("resultMsg", "NAN");
                if (v3 == 0) {
                    v0 = "";
                    v3 = v2.optString("phoneNo");
                    com.snda.woa.au.c("MobileService", new StringBuilder().append("key=").append(com.snda.woa.ap.a()).toString());
                    com.snda.woa.au.c("MobileService", new StringBuilder().append("phoneNoDes=").append(v3).toString());
                    if (com.snda.woa.cn.c(v3) == 0) {
                        v0 = com.snda.woa.ap.b(v3);
                        com.snda.woa.au.c("MobileService", new StringBuilder().append("phoneNo=").append(v0).toString());
                        com.snda.woa.cf.b(p7, v0);
                        com.snda.woa.cf.e(p7);
                    }
                    v2 = v2.optString("token");
                    com.snda.woa.au.c("MobileService", new StringBuilder().append("tokenDes=").append(v2).toString());
                    if (com.snda.woa.cn.d(v2) != 0) {
                        v2 = com.snda.woa.ap.b(v2);
                        com.snda.woa.au.c("MobileService", new StringBuilder().append("token=").append(v2).toString());
                        com.snda.woa.cf.a(p7, v0, com.snda.woa.u.c(v0, v2, 0.0));
                        com.snda.woa.cf.k(p7, v2);
                    }
                    v0 = new com.snda.woa.cq(0);
                } else {
                    v0 = new com.snda.woa.cq(v3, v4, v4);
                }
            }
        } else {
            v0 = new com.snda.woa.cq(v1.a(), v1.b(), com.snda.woa.android.OpenAPI.getStatusText(v1.a()));
        }
        return v0;
    }
    public static com.snda.woa.cq a(android.content.Context p11, String p12, String p13, boolean p14)
    {
        v10 = 0;
        if (com.snda.woa.ax.f() > 0) {
            v10 = com.snda.woa.ap.a("1", com.snda.woa.cf.a(), p11);
        }
        return new com.snda.woa.cq(0, com.snda.woa.cp.a(p11, p12, 0, 0, 0, 0, 0, p13, p14, 1, v10));
    }
    public static com.snda.woa.cq a(android.content.Context p5, String p6, String p7, boolean p8, boolean p9)
    {
        v0 = com.snda.woa.cp.a(p5, p7, p8, p9);
        v2 = new StringBuilder().append(com.snda.woa.ce.e).append("/autologin/receiveVerificationSms.shtm").toString();
        v3 = new StringBuilder();
        v3.append("phone=");
        v3.append(com.snda.woa.ap.a(p6, 0, p5));
        v3.append("&msg=");
        v3.append(v0);
        v1 = com.snda.woa.av.a(p5, com.snda.woa.ce.o[com.snda.woa.ce.b], v2, v3.toString(), com.snda.woa.bj.a);
        if (v1.c() != 0) {
            v0 = v1.b();
            if (com.snda.woa.cn.c(v0) != 0) {
                v0 = new com.snda.woa.cq(com.snda.woa.av.a(p5));
            } else {
                v1 = new org.json.JSONObject(v0);
                v2 = v1.optInt("resultCode", -999);
                v1 = v1.optString("resultMsg", "NAN");
                if (v2 != 0) {
                    v0 = new com.snda.woa.cq(v2, v1);
                } else {
                    v0 = new com.snda.woa.cq(v2);
                }
            }
        } else {
            v0 = new com.snda.woa.cq(v1.a(), v1.b());
        }
        return v0;
    }
    public static String a(android.content.Context p8, long p9)
    {
        v3 = ((p9 / 1000.0) * 1000.0);
        v0 = p8.getContentResolver();
        v1 = android.net.Uri.parse("content://sms/inbox");
        v2 = new String[4];
        v2[0] = "_id";
        v2[1] = "address";
        v2[2] = "body";
        v2[3] = "service_center";
        v1 = v0.query(v1, v2, new StringBuilder().append(" date>=").append(v3).toString(), 0, "date desc");
        if (v1 == 0) {
            if (v1 != 0) {
                v1.close();
            }
            v0 = 0;
        } else {
            while (v1.moveToNext() != 0) {
                v0 = v1.getString(2).toLowerCase();
                if (((v0.contains("\u76db\u5927\u7f51\u7edc") != 0) || (v0.contains("snda") != 0)) && (((v0.contains("\u9a8c\u8bc1\u7801") != 0) || (v0.contains("code") != 0)) && (v0.substring(0, v0.indexOf(40)).matches("[0-9]*") != 0))) {
                    v0 = v0.substring(0, v0.indexOf(40));
                    if (v1 != 0) {
                        v1.close();
                    }
                }
            }
        }
        return v0;
    }
    private static String a(android.content.Context p4, String p5, int p6, String p7, String p8, String p9, String p10, String p11, boolean p12, boolean p13, String p14)
    {
        v1 = com.snda.woa.cf.a();
        v2 = new org.json.JSONObject();
        com.snda.woa.ao.a(v2, "optype", p6);
        if ((com.snda.woa.cf.b() == 0) || (com.snda.woa.bp.a() == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        com.snda.woa.ao.a(v2, "hasSDCard", v0);
        if (com.snda.woa.cn.c(p7) == 0) {
            com.snda.woa.ao.a(v2, "sessionId", p7);
        }
        if (com.snda.woa.cn.c(p5) == 0) {
            com.snda.woa.ao.a(v2, "uuid", com.snda.woa.ap.a(p5, v1, p4));
        }
        if (v1 != 0) {
            if (v1 != 0) {
                v0 = v1.a();
            } else {
                v0 = "";
            }
            com.snda.woa.ao.a(v2, "guid", v0);
        }
        if (com.snda.woa.cn.c(p8) == 0) {
            com.snda.woa.ao.a(v2, "phoneNo", com.snda.woa.ap.a(p8, v1, p4));
        }
        if (com.snda.woa.cn.c(p9) == 0) {
            com.snda.woa.ao.a(v2, "sndaId", com.snda.woa.ap.a(p9, v1, p4));
        }
        if (com.snda.woa.cn.c(p10) == 0) {
            com.snda.woa.ao.a(v2, "token", com.snda.woa.ap.a(p10, v1, p4));
        }
        if (com.snda.woa.cn.c(p14) == 0) {
            com.snda.woa.ao.a(v2, "seq", p14);
        }
        com.snda.woa.ao.a(v2, "clientVersion", "2.5.1");
        com.snda.woa.ao.a(v2, "endpointOS", "android");
        if (p12 != 0) {
            com.snda.woa.ao.a(v2, "imsi", com.snda.woa.ap.a(com.snda.woa.cf.h(p4), v1, p4));
        }
        if (p13 != 0) {
            v0 = p4.getSystemService("phone");
            if (v0 != 0) {
                com.snda.woa.ao.a(v2, "imei", com.snda.woa.ap.a(v0.getDeviceId(), v1, p4));
            }
        }
        com.snda.woa.ao.a(v2, "appId", com.snda.woa.ax.c(p4));
        com.snda.woa.ao.a(v2, "areaId", com.snda.woa.ax.d());
        if (com.snda.woa.cn.c(p11) == 0) {
            com.snda.woa.ao.a(v2, "smsCode", p11);
        }
        v0 = v2.toString();
        com.snda.woa.au.c("MobileService", new StringBuilder().append(" sessionid json \uff1a").append(v0).toString());
        v1 = new String(com.snda.woa.q.a(v0.getBytes(), v0.getBytes().length));
        com.snda.woa.au.c("MobileService", new StringBuilder().append(" sessionIdBase64 \uff1a").append(v1).toString());
        return v1;
    }
    public static String a(android.content.Context p1, String p2, boolean p3)
    {
        return com.snda.woa.cp.a(p1, p2, p3, 0);
    }
    public static String a(android.content.Context p3, String p4, boolean p5, boolean p6)
    {
        v0 = new StringBuffer("");
        if (com.snda.woa.ce.o.equals(com.snda.woa.ce.j) == 0) {
            if (com.snda.woa.ce.o.equals(com.snda.woa.ce.l) == 0) {
                if (com.snda.woa.ce.o.equals(com.snda.woa.ce.m) != 0) {
                    v0.append("GREY");
                }
            } else {
                v0.append("PREP");
            }
        } else {
            v0.append("TEST");
        }
        v0.append(com.snda.woa.ce.g);
        if (p6 == 0) {
            v0.append("SL");
        } else {
            v0.append("EM");
        }
        v0.append(p4);
        if (p5 == 0) {
            v0.append("-3");
        } else {
            v0.append("-0");
        }
        v0.append("-");
        v0.append(com.snda.woa.ax.c(p3));
        v0.append("-");
        v0.append(com.snda.woa.ax.d());
        return v0.toString();
    }
    public static com.snda.woa.cq b(android.content.Context p2, String p3)
    {
        return new com.snda.woa.cq(0, p3);
    }
    public static com.snda.woa.cq b(android.content.Context p11, String p12, String p13)
    {
        return new com.snda.woa.cq(0, com.snda.woa.cp.a(p11, 0, 4, 0, 0, p12, p13, 0, 0, 0, 0));
    }
}
