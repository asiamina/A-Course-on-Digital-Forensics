package com.snda.woa;
public class d extends android.os.AsyncTask {
    static java.io.File a;
    private boolean c;
    private android.content.Context b;
    private static String d;
    static d()
    {
        com.snda.woa.d.a = new java.io.File(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append("/woa-log.log").toString());
        return;
    }
    public d(android.content.Context p1, boolean p2)
    {
        this.b = p1;
        this.c = p2;
        return;
    }
    protected varargs String a(com.snda.woa.bw[] p7)
    {
        com.snda.woa.m.a(com.snda.woa.ax.e(this.b));
        com.snda.woa.m.b(com.snda.woa.ax.d(this.b));
        v1 = p7.length;
        v0 = 0;
        while (v0 < v1) {
            v2 = p7[v0];
            if (v2 != 0) {
                v2.b(com.snda.woa.d.d);
                com.snda.woa.au.a("DCLOG", v2.toString());
                com.snda.woa.m.a(this.b, com.snda.woa.ce.r, v2.toString());
                if (com.snda.woa.ce.o != com.snda.woa.ce.k) {
                    this.a(v2);
                }
            }
            v0++;
        }
        if (this.c) {
            com.snda.woa.m.a(this.b);
        }
        return 0;
    }
    public static void a()
    {
        com.snda.woa.d.d = com.snda.woa.ay.b(30);
        return;
    }
    private void a(com.snda.woa.bw p4)
    {
        if (p4 != 0) {
            if (p4.a() == 33) {
                if (p4.b() != "120") {
                    if (p4.b() != "0") {
                        if (p4.b() != "199") {
                            com.snda.woa.au.e("E", new StringBuilder().append("XXXXXXXXXXXXXX ").append(p4.toString()).toString());
                        } else {
                            com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u81ea\u52a8\u767b\u9646 ").append("[\u53cd\u9988 <").append(p4.c()).append(">],").toString());
                        }
                    } else {
                        com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u81ea\u52a8\u767b\u9646 ").append("[\u56de\u8c03 <").append(p4.c()).append(">],").toString());
                    }
                } else {
                    com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u81ea\u52a8\u767b\u9646 ").append("[\u751f\u6210session <").append(p4.c()).append(">],").toString());
                }
            }
            if (p4.a() == 30) {
                if (p4.b() != "110") {
                    if (p4.b() != "120") {
                        if (p4.b() != "150") {
                            if (p4.b() != "0") {
                                if (p4.b() != "199") {
                                    com.snda.woa.au.e("E", new StringBuilder().append("XXXXXXXXXXXXXX ").append(p4.toString()).toString());
                                } else {
                                    com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0a\u884c\u77ed\u4fe1 ").append("[\u53cd\u9988 <").append(p4.c()).append(">],").toString());
                                }
                            } else {
                                com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0a\u884c\u77ed\u4fe1 ").append("[\u56de\u8c03 <").append(p4.c()).append(">],").toString());
                            }
                        } else {
                            com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0a\u884c\u77ed\u4fe1 ").append("[\u6821\u9a8c\u53d1\u9001\u7684\u77ed\u4fe1 <").append(p4.c()).append(">],").toString());
                        }
                    } else {
                        com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0a\u884c\u77ed\u4fe1 ").append("[\u53d1\u9001\u77ed\u4fe1 <").append(p4.c()).append(">],").toString());
                    }
                } else {
                    com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0a\u884c\u77ed\u4fe1 ").append("[\u751f\u6210uuid <").append(p4.c()).append(">],").toString());
                }
            }
            if (p4.a() == 35) {
                if (p4.b() != "105") {
                    if (p4.b() != "110") {
                        if (p4.b() != "130") {
                            if (p4.b() != "120") {
                                if (p4.b() != "0") {
                                    if (p4.b() != "199") {
                                        com.snda.woa.au.e("E", new StringBuilder().append("XXXXXXXXXXXXXX ").append(p4.toString()).toString());
                                    } else {
                                        com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0b\u884c\u77ed\u4fe1 ").append("[\u53cd\u9988 <").append(p4.c()).append(">],").toString());
                                    }
                                } else {
                                    com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0b\u884c\u77ed\u4fe1 ").append("[\u56de\u8c03 <").append(p4.c()).append(">],").toString());
                                }
                            } else {
                                com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0b\u884c\u77ed\u4fe1 ").append("[\u6821\u9a8c\u77ed\u4fe1 <").append(p4.c()).append(">],").toString());
                            }
                        } else {
                            com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0b\u884c\u77ed\u4fe1 ").append("[\u68c0\u67e5\u77ed\u4fe1 <").append(p4.c()).append(">],").toString());
                        }
                    } else {
                        com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0b\u884c\u77ed\u4fe1 ").append("[\u8bf7\u6c42\u77ed\u4fe1 <").append(p4.c()).append(">],").toString());
                    }
                } else {
                    com.snda.woa.d.a(new StringBuilder().append("mobilelogin\u4e0b\u884c\u77ed\u4fe1 ").append("[\u751f\u6210uuid <").append(p4.c()).append(">],").toString());
                }
            }
        }
        return;
    }
    private static synchronized void a(String p5)
    {
        v0 = new StringBuilder().append(com.snda.woa.d.d).append(":").append(p5).append("\n").toString();
        com.snda.woa.au.d("FILE", v0);
        v2 = new java.io.FileWriter(com.snda.woa.d.a, 1);
        v2.append(v0);
        v2.flush();
        v2.close();
        return;
    }
    protected synthetic bridge Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
}
