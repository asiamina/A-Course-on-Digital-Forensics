package com.snda.woa.android.callback;
public interface abstract class PwdLoginCallBack {
    abstract public void eKeyCallBack();
    abstract public void verifyCodeCallBack();
    abstract public void callBack();
    abstract public void eCardCallBack();
}
