package com.snda.woa;
public class u {
    private String a;
    private int c;
    private long b;
    private String d;
    public u(String p1, String p2, long p3, int p5)
    {
        this.d = p1;
        this.a = p2;
        this.b = p3;
        this.c = p5;
        return;
    }
    public static com.snda.woa.u a(String p6, String p7, long p8)
    {
        return new com.snda.woa.u(p6, p7, p8, v4, 3);
    }
    public String a()
    {
        return this.d;
    }
    public long b()
    {
        return this.b;
    }
    public static com.snda.woa.u b(String p6, String p7, long p8)
    {
        return new com.snda.woa.u(p6, p7, p8, v4, 1);
    }
    public static com.snda.woa.u c(String p6, String p7, long p8)
    {
        return new com.snda.woa.u(p6, p7, p8, v4, 2);
    }
    public String c()
    {
        return this.a;
    }
    public int d()
    {
        return this.c;
    }
    public boolean e()
    {
        v0 = 1;
        if (this.c != 1) {
            v0 = 0;
        }
        return v0;
    }
    public boolean f()
    {
        if (this.c != 3) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
}
