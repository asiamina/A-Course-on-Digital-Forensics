package com.snda.woa;
public class n {
    public n()
    {
        return;
    }
    public static java.util.List a(android.content.Context p9)
    {
        com.snda.woa.au.c("SmsInterceptAppUtil", "\u83b7\u53d6\u6240\u6709\u62e6\u622a\u77ed\u4fe1\u7684App\u4fe1\u606f");
        v3 = new java.util.ArrayList(0);
        v2 = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(com.snda.woa.cf.a(p9), 0);
        v4 = new String[0];
        v1 = v2.rawQuery("SELECT * FROM sms_intercept_app ORDER BY ID ", v4);
        while (v1.moveToNext() != 0) {
            v3.add(new com.snda.woa.af(Integer.valueOf(v1.getInt(v1.getColumnIndex("id"))), v1.getString(v1.getColumnIndex("appPackage")), v1.getString(v1.getColumnIndex("appName")), v1.getString(v1.getColumnIndex("appVersion"))));
        }
        com.snda.woa.au.c("SmsInterceptAppUtil", new StringBuilder().append("sql\uff1a").append("SELECT * FROM sms_intercept_app ORDER BY ID ").toString());
        com.snda.woa.au.c("SmsInterceptAppUtil", new StringBuilder().append("\u83b7\u53d6\u6240\u6709\u62e6\u622a\u77ed\u4fe1\u7684App\u4fe1\u606f\u6210\u529f, \u5217\u8868: ").append(v3).toString());
        if (v1 != 0) {
            v1.close();
        }
        if (v2 != 0) {
            v2.close();
        }
        return v3;
    }
    public static void a(android.content.Context p6, com.snda.woa.af p7)
    {
        com.snda.woa.au.c("SmsInterceptAppUtil", new StringBuilder().append("\u4fdd\u5b58\u62e6\u622a\u77ed\u4fe1\u7684App\u4fe1\u606f: ").append(p7).toString());
        v0 = com.snda.woa.cf.a(p6);
        if ((com.snda.woa.cn.c(p7.a()) == 0) && (com.snda.woa.cn.c(p7.c()) == 0)) {
            v1 = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(v0, 0);
            v1.rawQuery("SELECT * FROM sms_intercept_app", 0);
            v3 = new Object[3];
            v3[0] = p7.a();
            v3[1] = p7.b();
            v3[2] = p7.c();
            v1.execSQL("INSERT INTO sms_intercept_app (appPackage, appName, appVersion) VALUES(?, ?, ?)", v3);
            com.snda.woa.au.c("SmsInterceptAppUtil", new StringBuilder().append("sql\uff1a").append("INSERT INTO sms_intercept_app (appPackage, appName, appVersion) VALUES(?, ?, ?)").toString());
            com.snda.woa.au.c("SmsInterceptAppUtil", new StringBuilder().append("\u4fdd\u5b58\u62e6\u622a\u77ed\u4fe1\u7684App\u4fe1\u606f: ").append(p7).append(" \u6210\u529f").toString());
            if (0 != 0) {
                0.close();
            }
            if (v1 != 0) {
                v1.close();
            }
        }
        return;
    }
    public static void b(android.content.Context p5)
    {
        v0 = com.snda.woa.cf.a(p5);
        com.snda.woa.au.c("SmsInterceptAppUtil", "\u5220\u9664\u6240\u6709\u62e6\u622a\u77ed\u4fe1\u7684App\u4fe1\u606f");
        v1 = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(v0, 0);
        v1.rawQuery("SELECT * FROM sms_intercept_app", 0);
        v1.execSQL("DELETE FROM sms_intercept_app");
        com.snda.woa.au.c("SmsInterceptAppUtil", new StringBuilder().append("sql\uff1a").append("DELETE FROM sms_intercept_app").toString());
        com.snda.woa.au.c("SmsInterceptAppUtil", "\u5220\u9664\u6240\u6709\u62e6\u622a\u77ed\u4fe1\u7684App\u4fe1\u606f\u6210\u529f");
        if (v1 != 0) {
            v1.close();
        }
        return;
    }
}
