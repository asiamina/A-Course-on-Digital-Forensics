package com.snda.woa;
public class aa implements com.snda.woa.android.callback.PwdLoginCallBack {
    private com.snda.woa.android.callback.AutoLoginCallBack a;
    public aa(com.snda.woa.android.callback.AutoLoginCallBack p1)
    {
        this.a = p1;
        return;
    }
    public void callBack(int p2, String p3, String p4)
    {
        this.a.callBack(p2, p3, p4);
        return;
    }
    public void eCardCallBack(int p5, String p6, String p7, String[] p8)
    {
        com.snda.woa.au.e("E", "pwd\u81ea\u52a8\u767b\u5f55\u4e0d\u9700\u8981ecard");
        this.a.callBack(-2.913532036875468e+38, com.snda.woa.android.OpenAPI.getStatusText(-2.913532036875468e+38), 0);
        return;
    }
    public void eKeyCallBack(int p5, String p6, String p7, String p8)
    {
        com.snda.woa.au.e("E", "pwd\u81ea\u52a8\u767b\u5f55\u4e0d\u9700\u8981ekey");
        this.a.callBack(-2.913532036875468e+38, com.snda.woa.android.OpenAPI.getStatusText(-2.913532036875468e+38), 0);
        return;
    }
    public void verifyCodeCallBack(int p5, String p6, String p7, String p8)
    {
        com.snda.woa.au.e("E", "pwd\u81ea\u52a8\u767b\u5f55\u4e0d\u9700\u8981verifycode");
        this.a.callBack(-2.913532036875468e+38, com.snda.woa.android.OpenAPI.getStatusText(-2.913532036875468e+38), 0);
        return;
    }
}
