package com.snda.woa;
public class k {
    private long a;
    private long b;
    public com.snda.woa.k b()
    {
        this.a = System.currentTimeMillis();
        return this;
    }
    public com.snda.woa.k c()
    {
        this.b = System.currentTimeMillis();
        return this;
    }
    public long d()
    {
        return this.a;
    }
    public long e()
    {
        return this.b;
    }
    public long f()
    {
        return (this.b - this.a);
    }
    private k()
    {
        return;
    }
    public static com.snda.woa.k a()
    {
        return new com.snda.woa.k();
    }
}
