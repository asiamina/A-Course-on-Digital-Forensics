package com.ta.utdid2.b.a;
 class e {
    public static final Object a(org.xmlpull.v1.XmlPullParser p3, String[] p4)
    {
        v0 = p3.getEventType();
        while (v0 != 2) {
            if (v0 != 3) {
                if (v0 != 4) {
                    v0 = p3.next();
                    if (v0 == 1) {
                        throw new org.xmlpull.v1.XmlPullParserException("Unexpected end of document");
                    }
                } else {
                    throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected text: ").append(p3.getText()).toString());
                }
            } else {
                throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected end tag at: ").append(p3.getName()).toString());
            }
        }
        return com.ta.utdid2.b.a.e.b(p3, p4);
    }
    public static final java.util.ArrayList a(org.xmlpull.v1.XmlPullParser p3, String p4, String[] p5)
    {
        v1 = new java.util.ArrayList();
        v0 = p3.getEventType();
        do {
            if (v0 != 2) {
                if (v0 == 3) {
                    if (p3.getName().equals(p4) == 0) {
                        throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Expected ").append(p4).append(" end tag at: ").append(p3.getName()).toString());
                    } else {
                        return v1;
                    }
                }
            } else {
                v1.add(com.ta.utdid2.b.a.e.b(p3, p5));
            }
            v0 = p3.next();
        } while(v0 != 1);
        throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Document ended before ").append(p4).append(" end tag").toString());
    }
    public static final java.util.HashMap a(java.io.InputStream p2)
    {
        v0 = android.util.Xml.newPullParser();
        v0.setInput(p2, 0);
        v1 = new String[1];
        return com.ta.utdid2.b.a.e.a(v0, v1);
    }
    public static final java.util.HashMap a(org.xmlpull.v1.XmlPullParser p4, String p5, String[] p6)
    {
        v1 = new java.util.HashMap();
        v0 = p4.getEventType();
        do {
            if (v0 != 2) {
                if (v0 == 3) {
                    if (p4.getName().equals(p5) == 0) {
                        throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Expected ").append(p5).append(" end tag at: ").append(p4.getName()).toString());
                    } else {
                        return v1;
                    }
                }
            } else {
                v0 = com.ta.utdid2.b.a.e.b(p4, p6);
                if (p6[0] == 0) {
                    throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Map value without name attribute: ").append(p4.getName()).toString());
                } else {
                    v1.put(p6[0], v0);
                }
            }
            v0 = p4.next();
        } while(v0 != 1);
        throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Document ended before ").append(p5).append(" end tag").toString());
    }
    public static final void a(Object p4, String p5, org.xmlpull.v1.XmlSerializer p6)
    {
        if (p4 != 0) {
            if ((p4 instanceof String) == 0) {
                if ((p4 instanceof Integer) == 0) {
                    if ((p4 instanceof Long) == 0) {
                        if ((p4 instanceof Float) == 0) {
                            if ((p4 instanceof Double) == 0) {
                                if ((p4 instanceof Boolean) == 0) {
                                    if ((p4 instanceof byte[]) == 0) {
                                        if ((p4 instanceof int[]) == 0) {
                                            if ((p4 instanceof java.util.Map) == 0) {
                                                if ((p4 instanceof java.util.List) == 0) {
                                                    if ((p4 instanceof CharSequence) == 0) {
                                                        throw new RuntimeException(new StringBuilder("writeValueXml: unable to write value ").append(p4).toString());
                                                    } else {
                                                        p6.startTag(0, "string");
                                                        if (p5 != 0) {
                                                            p6.attribute(0, "name", p5);
                                                        }
                                                        p6.text(p4.toString());
                                                        p6.endTag(0, "string");
                                                        return;
                                                    }
                                                } else {
                                                    com.ta.utdid2.b.a.e.a(p4, p5, p6);
                                                }
                                            } else {
                                                com.ta.utdid2.b.a.e.a(p4, p5, p6);
                                            }
                                        } else {
                                            com.ta.utdid2.b.a.e.a(p4, p5, p6);
                                        }
                                    } else {
                                        com.ta.utdid2.b.a.e.a(p4, p5, p6);
                                    }
                                } else {
                                    v0 = "boolean";
                                }
                            } else {
                                v0 = "double";
                            }
                        } else {
                            v0 = "float";
                        }
                    } else {
                        v0 = "long";
                    }
                } else {
                    v0 = "int";
                }
                p6.startTag(0, v0);
                if (p5 != 0) {
                    p6.attribute(0, "name", p5);
                }
                p6.attribute(0, "value", p4.toString());
                p6.endTag(0, v0);
            } else {
                p6.startTag(0, "string");
                if (p5 != 0) {
                    p6.attribute(0, "name", p5);
                }
                p6.text(p4.toString());
                p6.endTag(0, "string");
            }
        } else {
            p6.startTag(0, "null");
            if (p5 != 0) {
                p6.attribute(0, "name", p5);
            }
            p6.endTag(0, "null");
        }
    }
    public static final void a(java.util.List p4, String p5, org.xmlpull.v1.XmlSerializer p6)
    {
        if (p4 != 0) {
            p6.startTag(0, "list");
            if (p5 != 0) {
                p6.attribute(0, "name", p5);
            }
            v1 = p4.size();
            v0 = 0;
            while (v0 < v1) {
                com.ta.utdid2.b.a.e.a(p4.get(v0), 0, p6);
                v0++;
            }
            p6.endTag(0, "list");
        } else {
            p6.startTag(0, "null");
            p6.endTag(0, "null");
        }
        return;
    }
    public static final void a(java.util.Map p4, java.io.OutputStream p5)
    {
        v0 = new com.ta.utdid2.b.a.a();
        v0.setOutput(p5, "utf-8");
        v0.startDocument(0, Boolean.valueOf(1));
        v0.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", 1);
        com.ta.utdid2.b.a.e.a(p4, 0, v0);
        v0.endDocument();
        return;
    }
    public static final void a(java.util.Map p4, String p5, org.xmlpull.v1.XmlSerializer p6)
    {
        if (p4 != 0) {
            v1 = p4.entrySet().iterator();
            p6.startTag(0, "map");
            if (p5 != 0) {
                p6.attribute(0, "name", p5);
            }
            while (v1.hasNext() != 0) {
                v0 = v1.next();
                com.ta.utdid2.b.a.e.a(v0.getValue(), v0.getKey(), p6);
            }
            p6.endTag(0, "map");
        } else {
            p6.startTag(0, "null");
            p6.endTag(0, "null");
        }
        return;
    }
    public static final void a(byte[] p7, String p8, org.xmlpull.v1.XmlSerializer p9)
    {
        if (p7 != 0) {
            p9.startTag(0, "byte-array");
            if (p8 != 0) {
                p9.attribute(0, "name", p8);
            }
            v2 = p7.length;
            p9.attribute(0, "num", Integer.toString(v2));
            v3 = new StringBuilder((p7.length * 2));
            v1 = 0;
            while (v1 < v2) {
                v4 = p7[v1];
                v0 = (v4 >> 4);
                if (v0 < 10) {
                    v0 += 48;
                } else {
                    v0 = ((v0 + 97) - 10);
                }
                v3.append(v0);
                v0 = (v4 & 255);
                if (v0 < 10) {
                    v0 += 48;
                } else {
                    v0 = ((v0 + 97) - 10);
                }
                v3.append(v0);
                v1++;
            }
            p9.text(v3.toString());
            p9.endTag(0, "byte-array");
        } else {
            p9.startTag(0, "null");
            p9.endTag(0, "null");
        }
        return;
    }
    public static final void a(int[] p5, String p6, org.xmlpull.v1.XmlSerializer p7)
    {
        if (p5 != 0) {
            p7.startTag(0, "int-array");
            if (p6 != 0) {
                p7.attribute(0, "name", p6);
            }
            v1 = p5.length;
            p7.attribute(0, "num", Integer.toString(v1));
            v0 = 0;
            while (v0 < v1) {
                p7.startTag(0, "item");
                p7.attribute(0, "value", Integer.toString(p5[v0]));
                p7.endTag(0, "item");
                v0++;
            }
            p7.endTag(0, "int-array");
        } else {
            p7.startTag(0, "null");
            p7.endTag(0, "null");
        }
        return;
    }
    public static final int[] a(org.xmlpull.v1.XmlPullParser p5, String p6, String[] p7)
    {
        v2 = new int[Integer.parseInt(p5.getAttributeValue(0, "num"))];
        v0 = 0;
        v1 = p5.getEventType();
        do {
            if (v1 != 2) {
                if (v1 == 3) {
                    if (p5.getName().equals(p6) == 0) {
                        if (p5.getName().equals("item") == 0) {
                            throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Expected ").append(p6).append(" end tag at: ").append(p5.getName()).toString());
                        } else {
                            v0++;
                        }
                    } else {
                        return v2;
                    }
                }
            } else {
                if (p5.getName().equals("item") == 0) {
                    throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Expected item tag at: ").append(p5.getName()).toString());
                } else {
                    v2[v0] = Integer.parseInt(p5.getAttributeValue(0, "value"));
                }
            }
            v1 = p5.next();
        } while(v1 != 1);
        throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Document ended before ").append(p6).append(" end tag").toString());
    }
    private static Object b(org.xmlpull.v1.XmlPullParser p9, String[] p10)
    {
        v0 = 0;
        v1 = p9.getAttributeValue(0, "name");
        v2 = p9.getName();
        if (v2.equals("null") == 0) {
            if (v2.equals("string") == 0) {
                if (v2.equals("int") == 0) {
                    if (v2.equals("long") == 0) {
                        if (v2.equals("float") == 0) {
                            if (v2.equals("double") == 0) {
                                if (v2.equals("boolean") == 0) {
                                    if (v2.equals("int-array") == 0) {
                                        if (v2.equals("map") == 0) {
                                            if (v2.equals("list") == 0) {
                                                throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unknown tag: ").append(v2).toString());
                                            } else {
                                                p9.next();
                                                v0 = com.ta.utdid2.b.a.e.a(p9, "list", p10);
                                                p10[0] = v1;
                                            }
                                        } else {
                                            p9.next();
                                            v0 = com.ta.utdid2.b.a.e.a(p9, "map", p10);
                                            p10[0] = v1;
                                        }
                                    } else {
                                        p9.next();
                                        v0 = com.ta.utdid2.b.a.e.a(p9, "int-array", p10);
                                        p10[0] = v1;
                                    }
                                } else {
                                    v0 = Boolean.valueOf(p9.getAttributeValue(0, "value"));
                                    do {
                                        v3 = p9.next();
                                        if (v3 == 1) {
                                            throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected end of document in <").append(v2).append(">").toString());
                                        } else {
                                            if (v3 != 3) {
                                                if (v3 != 4) {
                                                } else {
                                                    throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected text in <").append(v2).append(">: ").append(p9.getName()).toString());
                                                }
                                            } else {
                                                if (p9.getName().equals(v2) == 0) {
                                                    throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected end tag in <").append(v2).append(">: ").append(p9.getName()).toString());
                                                } else {
                                                    p10[0] = v1;
                                                }
                                            }
                                        }
                                    } while(v3 != 2);
                                    throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected start tag in <").append(v2).append(">: ").append(p9.getName()).toString());
                                }
                            } else {
                                v0 = Double.valueOf(p9.getAttributeValue(0, "value"));
                            }
                        } else {
                            v0 = Float.valueOf(p9.getAttributeValue(0, "value"));
                        }
                    } else {
                        v0 = Long.valueOf(p9.getAttributeValue(0, "value"));
                    }
                } else {
                    v0 = Integer.valueOf(Integer.parseInt(p9.getAttributeValue(0, "value")));
                }
            } else {
                v0 = "";
                do {
                    v2 = p9.next();
                    if (v2 == 1) {
                        throw new org.xmlpull.v1.XmlPullParserException("Unexpected end of document in <string>");
                    } else {
                        if (v2 != 3) {
                            if (v2 != 4) {
                            } else {
                                v0 = new StringBuilder().append(v0).append(p9.getText()).toString();
                            }
                        } else {
                            if (p9.getName().equals("string") == 0) {
                                throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected end tag in <string>: ").append(p9.getName()).toString());
                            } else {
                                p10[0] = v1;
                            }
                        }
                    }
                } while(v2 != 2);
                throw new org.xmlpull.v1.XmlPullParserException(new StringBuilder("Unexpected start tag in <string>: ").append(p9.getName()).toString());
            }
        }
        return v0;
    }
}
