package com.ta.utdid2.a.a;
public class a {
    public static String a(String p3)
    {
        v0 = 0;
        v1 = com.ta.utdid2.a.a.a.a(com.ta.utdid2.a.a.a.a(), p3.getBytes());
        if (v1 != 0) {
            v0 = com.ta.utdid2.a.a.a.a(v1);
        }
        return v0;
    }
    private static String a(byte[] p3)
    {
        if (p3 != 0) {
            v1 = new StringBuffer((p3.length * 2));
            v0 = 0;
            while (v0 < p3.length) {
                com.ta.utdid2.a.a.a.a(v1, p3[v0]);
                v0++;
            }
            v0 = v1.toString();
        } else {
            v0 = "";
        }
        return v0;
    }
    private static void a(StringBuffer p3, byte p4)
    {
        p3.append("0123456789ABCDEF".charAt(((p4 >> 4) & 15))).append("0123456789ABCDEF".charAt((p4 & 15)));
        return;
    }
    private static byte[] a()
    {
        v0 = new byte[16];
        v0 = {33, 83, 206, 167, 172, 142, 80, 99, 10, 63, 22, 191, 245, 30, 101};
        return com.ta.utdid2.a.a.e.a(v0);
    }
    private static byte[] a(String p5)
    {
        v1 = (p5.length() / 2);
        v2 = new byte[v1];
        v0 = 0;
        while (v0 < v1) {
            v2[v0] = Integer.valueOf(p5.substring((v0 * 2), ((v0 * 2) + 2)), 16).byteValue();
            v0++;
        }
        return v2;
    }
    private static byte[] a(byte[] p5, byte[] p6)
    {
        v0 = new javax.crypto.spec.SecretKeySpec(p5, "AES");
        v1 = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
        v4 = new byte[v1.getBlockSize()];
        v1.init(1, v0, new javax.crypto.spec.IvParameterSpec(v4));
        return v1.doFinal(p6);
    }
    public static String b(String p2)
    {
        return new String(com.ta.utdid2.a.a.a.b(v0, com.ta.utdid2.a.a.a.a(p2)));
    }
    private static byte[] b(byte[] p5, byte[] p6)
    {
        v0 = new javax.crypto.spec.SecretKeySpec(p5, "AES");
        v1 = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
        v4 = new byte[v1.getBlockSize()];
        v1.init(2, v0, new javax.crypto.spec.IvParameterSpec(v4));
        return v1.doFinal(p6);
    }
}
