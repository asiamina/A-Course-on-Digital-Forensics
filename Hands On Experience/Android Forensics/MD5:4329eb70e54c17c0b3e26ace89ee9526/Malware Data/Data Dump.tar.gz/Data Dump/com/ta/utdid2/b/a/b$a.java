package com.ta.utdid2.b.a;
public interface abstract class b$a {
    abstract public com.ta.utdid2.b.a.b$a a();
    abstract public com.ta.utdid2.b.a.b$a a();
    abstract public com.ta.utdid2.b.a.b$a a();
    abstract public com.ta.utdid2.b.a.b$a a();
    abstract public com.ta.utdid2.b.a.b$a a();
    abstract public com.ta.utdid2.b.a.b$a a();
    abstract public com.ta.utdid2.b.a.b$a b();
    abstract public boolean commit();
}
