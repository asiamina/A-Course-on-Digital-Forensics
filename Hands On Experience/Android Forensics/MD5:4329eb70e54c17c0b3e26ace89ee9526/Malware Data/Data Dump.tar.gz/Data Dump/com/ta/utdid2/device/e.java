package com.ta.utdid2.device;
public class e {
    public e()
    {
        return;
    }
    public String d(String p2)
    {
        return com.ta.utdid2.a.a.a.b(p2);
    }
    public String e(String p4)
    {
        v0 = com.ta.utdid2.a.a.a.b(p4);
        if (com.ta.utdid2.a.a.f.isEmpty(v0) != 0) {
            v0 = 0;
        } else {
            v0 = new String(com.ta.utdid2.a.a.b.decode(v0, 0));
        }
        return v0;
    }
}
