package com.tencent.connect.share;
final class a$2 implements java.lang.Runnable {
    final synthetic String a;
    final synthetic android.os.Handler b;
     a$2(String p1, android.os.Handler p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
    public void run()
    {
        v0 = com.tencent.connect.share.a.a(this.a, 140);
        if (v0 == 0) {
            v0 = this.b.obtainMessage(102);
            v0.arg1 = 3;
            this.b.sendMessage(v0);
        } else {
            v1 = new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append("/tmp/").toString();
            v2 = new StringBuilder().append("share2qq_temp").append(com.tencent.open.utils.Util.encrypt(this.a)).append(".jpg").toString();
            if (com.tencent.connect.share.a.a(this.a, 140, 140) != 0) {
                com.tencent.open.a.f.b("openSDK_LOG.AsynScaleCompressImage", "out of bound,compress!");
                v0 = com.tencent.connect.share.a.a(v0, v1, v2);
            } else {
                com.tencent.open.a.f.b("openSDK_LOG.AsynScaleCompressImage", "not out of bound,not compress!");
                v0 = this.a;
            }
            com.tencent.open.a.f.b("openSDK_LOG.AsynScaleCompressImage", new StringBuilder().append("-->destFilePath: ").append(v0).toString());
            } else {
                v1 = this.b.obtainMessage(101);
                v1.obj = v0;
                this.b.sendMessage(v1);
            }
        }
        return;
    }
}
