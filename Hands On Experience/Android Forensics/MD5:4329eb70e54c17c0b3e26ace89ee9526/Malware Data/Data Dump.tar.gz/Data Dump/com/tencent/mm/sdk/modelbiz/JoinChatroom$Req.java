package com.tencent.mm.sdk.modelbiz;
public class JoinChatroom$Req extends com.tencent.mm.sdk.modelbase.BaseReq {
    public String extMsg;
    public String groupId;
    public String chatroomNickName;
    public int getType()
    {
        return 15;
    }
    public void toBundle(android.os.Bundle p3)
    {
        super.toBundle(p3);
        p3.putString("_wxapi_join_chatroom_group_id", this.groupId);
        p3.putString("_wxapi_join_chatroom_chatroom_nickname", this.chatroomNickName);
        p3.putString("_wxapi_join_chatroom_ext_msg", this.extMsg);
        return;
    }
    public JoinChatroom$Req()
    {
        return;
    }
    public boolean checkArgs()
    {
        if (com.tencent.mm.sdk.b.h.h(this.groupId) == 0) {
            v0 = 1;
        } else {
            v0 = 0;
        }
        return v0;
    }
}
