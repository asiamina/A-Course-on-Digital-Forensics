package com.tencent.connect.auth;
 class AuthDialog$THandler extends android.os.Handler {
    final synthetic com.tencent.connect.auth.AuthDialog a;
    private com.tencent.connect.auth.AuthDialog$OnTimeListener b;
    public AuthDialog$THandler(com.tencent.connect.auth.AuthDialog p1, com.tencent.connect.auth.AuthDialog$OnTimeListener p2, android.os.Looper p3)
    {
        this.a = p1;
        this(p3);
        this.b = p2;
        return;
    }
    public void handleMessage(android.os.Message p3)
    {
        switch (p3.what) {
            case 1:
                com.tencent.connect.auth.AuthDialog$OnTimeListener.a(this.b, p3.obj);
                break;
            case 2:
                this.b.onCancel();
                break;
            case 3:
                com.tencent.connect.auth.AuthDialog.a(com.tencent.connect.auth.AuthDialog.a(this.a), p3.obj);
                break;
        }
        return;
    }
}
