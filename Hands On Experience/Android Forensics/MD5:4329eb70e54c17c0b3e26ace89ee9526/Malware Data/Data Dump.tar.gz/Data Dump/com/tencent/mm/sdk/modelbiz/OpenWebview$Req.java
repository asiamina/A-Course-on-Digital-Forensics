package com.tencent.mm.sdk.modelbiz;
public class OpenWebview$Req extends com.tencent.mm.sdk.modelbase.BaseReq {
    public String url;
    final private static int MAX_URL_LENGHT;
    public OpenWebview$Req()
    {
        return;
    }
    public boolean checkArgs()
    {
        v0 = 0;
        if ((this.url != 0) && ((this.url.length() >= 0) && (this.url.length() <= 10240))) {
            v0 = 1;
        }
        return v0;
    }
    public int getType()
    {
        return 12;
    }
    public void toBundle(android.os.Bundle p3)
    {
        super.toBundle(p3);
        p3.putString("_wxapi_jump_to_webview_url", java.net.URLEncoder.encode(this.url));
        return;
    }
}
