package com.tencent.connect.auth;
public class AuthMap {
    final synthetic static boolean a;
    public static com.tencent.connect.auth.AuthMap sInstance;
    private static int b;
    final public String KEY_CHAR_LIST;
    public java.util.HashMap authMap;
    static AuthMap()
    {
        if (com.tencent.connect.auth.AuthMap.desiredAssertionStatus() != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        com.tencent.connect.auth.AuthMap.a = v0;
        com.tencent.connect.auth.AuthMap.b = 0;
        return;
    }
    public AuthMap()
    {
        this.authMap = new java.util.HashMap();
        this.KEY_CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        return;
    }
    private String a(String p8, String p9)
    {
        v0 = 0;
        if ((com.tencent.connect.auth.AuthMap.a) || ((p8.length() % 2) == 0)) {
            v2 = new StringBuilder();
            v3 = p9.length();
            v4 = (p8.length() / 2);
            v1 = 0;
            while (v0 < v4) {
                v2.append(((char) (Integer.parseInt(p8.substring((v0 * 2), ((v0 * 2) + 2)), 16) ^ p9.charAt(v1))));
                v1 = ((v1 + 1) % v3);
                v0++;
            }
            return v2.toString();
        } else {
            throw new AssertionError();
        }
    }
    public String decode(String p2, String p3)
    {
        this.a(p2, p3);
        return this;
    }
    public com.tencent.connect.auth.AuthMap$Auth get(String p2)
    {
        return this.authMap.get(p2);
    }
    public static com.tencent.connect.auth.AuthMap getInstance()
    {
        if (com.tencent.connect.auth.AuthMap.sInstance == 0) {
            com.tencent.connect.auth.AuthMap.sInstance = new com.tencent.connect.auth.AuthMap();
        }
        return com.tencent.connect.auth.AuthMap.sInstance;
    }
    public static int getSerial()
    {
        v0 = (com.tencent.connect.auth.AuthMap.b + 1);
        com.tencent.connect.auth.AuthMap.b = v0;
        return v0;
    }
    public String makeKey()
    {
        v2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
        v3 = v2.length;
        v4 = new StringBuffer();
        v0 = 0;
        while (v0 < ((int) Math.ceil(((Math.random() * 20.0) + 3.0)))) {
            v4.append(v2[((int) (Math.random() * ((double) v3)))]);
            v0++;
        }
        return v4.toString();
    }
    public void remove(String p2)
    {
        this.authMap.remove(p2);
        return;
    }
    public String set(com.tencent.connect.auth.AuthMap$Auth p5)
    {
        v1 = com.tencent.connect.auth.AuthMap.getSerial();
        this.authMap.put(new StringBuilder().append("").append(v1).toString(), p5);
        return new StringBuilder().append("").append(v1).toString();
    }
}
