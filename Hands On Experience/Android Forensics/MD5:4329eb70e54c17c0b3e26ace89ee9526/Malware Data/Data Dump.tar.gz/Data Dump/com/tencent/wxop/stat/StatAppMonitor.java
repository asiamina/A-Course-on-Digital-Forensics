package com.tencent.wxop.stat;
public class StatAppMonitor implements java.lang.Cloneable {
    private String a;
    private long c;
    private long b;
    private long e;
    private int d;
    private int g;
    private int f;
    final public static int FAILURE_RESULT_TYPE;
    final public static int SUCCESS_RESULT_TYPE;
    final public static int LOGIC_FAILURE_RESULT_TYPE;
    public StatAppMonitor(String p5)
    {
        this.a = 0;
        this.b = 0.0;
        this.c = 0.0;
        this.d = 0;
        this.e = 0.0;
        this.f = 0;
        this.g = 1;
        this.a = p5;
        return;
    }
    public StatAppMonitor(String p5, int p6, int p7, long p8, long p10, long p12, int p14)
    {
        this.a = 0;
        this.b = 0.0;
        this.c = 0.0;
        this.d = 0;
        this.e = 0.0;
        this.f = 0;
        this.g = 1;
        this.a = p5;
        this.b = p8;
        this.c = p10;
        this.d = p6;
        this.e = p12;
        this.f = p7;
        this.g = p14;
        return;
    }
    public com.tencent.wxop.stat.StatAppMonitor clone()
    {
        return super.clone();
    }
    public synthetic bridge Object clone()
    {
        return this.clone();
    }
    public String getInterfaceName()
    {
        return this.a;
    }
    public long getMillisecondsConsume()
    {
        return this.e;
    }
    public long getReqSize()
    {
        return this.b;
    }
    public long getRespSize()
    {
        return this.c;
    }
    public int getResultType()
    {
        return this.d;
    }
    public int getReturnCode()
    {
        return this.f;
    }
    public int getSampling()
    {
        return this.g;
    }
    public void setInterfaceName(String p1)
    {
        this.a = p1;
        return;
    }
    public void setMillisecondsConsume(long p1)
    {
        this.e = p1;
        return;
    }
    public void setReqSize(long p1)
    {
        this.b = p1;
        return;
    }
    public void setRespSize(long p1)
    {
        this.c = p1;
        return;
    }
    public void setResultType(int p1)
    {
        this.d = p1;
        return;
    }
    public void setReturnCode(int p1)
    {
        this.f = p1;
        return;
    }
    public void setSampling(int p1)
    {
        if (p1 <= 0) {
            p1 = 1;
        }
        this.g = p1;
        return;
    }
}
