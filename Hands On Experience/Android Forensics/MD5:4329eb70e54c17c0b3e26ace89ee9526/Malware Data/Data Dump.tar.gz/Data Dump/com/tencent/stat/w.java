package com.tencent.stat;
 class w extends android.database.sqlite.SQLiteOpenHelper {
    public void onCreate(android.database.sqlite.SQLiteDatabase p2)
    {
        p2.execSQL("create table if not exists events(event_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, content TEXT, status INTEGER, send_count INTEGER, timestamp LONG)");
        p2.execSQL("create table if not exists user(uid TEXT PRIMARY KEY, user_type INTEGER, app_ver TEXT, ts INTEGER)");
        p2.execSQL("create table if not exists config(type INTEGER PRIMARY KEY NOT NULL, content TEXT, md5sum TEXT, version INTEGER)");
        p2.execSQL("create table if not exists keyvalues(key TEXT PRIMARY KEY NOT NULL, value TEXT)");
        return;
    }
    public void onUpgrade(android.database.sqlite.SQLiteDatabase p4, int p5, int p6)
    {
        com.tencent.stat.n.d().debug(new StringBuilder().append("upgrade DB from oldVersion ").append(p5).append(" to newVersion ").append(p6).toString());
        if (p5 == 1) {
            p4.execSQL("create table if not exists keyvalues(key TEXT PRIMARY KEY NOT NULL, value TEXT)");
            this.a(p4);
            this.b(p4);
        }
        if (p5 == 2) {
            this.a(p4);
            this.b(p4);
        }
        return;
    }
    public w(android.content.Context p4)
    {
        this(p4, com.tencent.stat.common.k.v(p4), 0, 3);
        return;
    }
    private void a(android.database.sqlite.SQLiteDatabase p10)
    {
        v8 = 0;
        v1 = p10.query("user", 0, 0, 0, 0, 0, 0);
        v0 = new android.content.ContentValues();
        if (v1.moveToNext() != 0) {
            v8 = v1.getString(0);
            v1.getInt(1);
            v1.getString(2);
            v1.getLong(3);
            v0.put("uid", com.tencent.stat.common.k.c(v8));
        }
        if (v8 != 0) {
            v4 = new String[1];
            v4[0] = v8;
            p10.update("user", v0, "uid=?", v4);
        }
        if (v1 != 0) {
            v1.close();
        }
        return;
    }
    private void b(android.database.sqlite.SQLiteDatabase p11)
    {
        v6 = p11.query("events", 0, 0, 0, 0, 0, 0);
        v7 = new java.util.ArrayList();
        while (v6.moveToNext() != 0) {
            v7.add(new com.tencent.stat.x(v6.getLong(0), 0, v6.getString(1), v6.getInt(2), v6.getInt(3)));
        }
        v1 = new android.content.ContentValues();
        v2 = v7.iterator();
        while (v2.hasNext() != 0) {
            v0 = v2.next();
            v1.put("content", com.tencent.stat.common.k.c(v0.b));
            v5 = new String[1];
            v5[0] = Long.toString(v0.a);
            p11.update("events", v1, "event_id=?", v5);
        }
        if (v6 != 0) {
            v6.close();
        }
        return;
    }
}
