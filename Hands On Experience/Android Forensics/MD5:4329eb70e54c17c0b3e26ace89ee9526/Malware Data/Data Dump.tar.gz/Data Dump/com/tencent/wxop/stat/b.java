package com.tencent.wxop.stat;
 class b extends android.content.BroadcastReceiver {
    final synthetic com.tencent.wxop.stat.a a;
    public void onReceive(android.content.Context p3, android.content.Intent p4)
    {
        if (com.tencent.wxop.stat.a.a(this.a) != 0) {
            com.tencent.wxop.stat.a.a(this.a).a(new com.tencent.wxop.stat.c(this));
        }
        return;
    }
     b(com.tencent.wxop.stat.a p1)
    {
        this.a = p1;
        return;
    }
}
