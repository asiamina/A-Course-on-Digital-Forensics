package com.tencent.open.utils;
public class HttpUtils {
    private HttpUtils()
    {
        return;
    }
    private static int a(android.content.Context p3)
    {
        v0 = -1;
        if (android.os.Build$VERSION.SDK_INT >= 11) {
            v1 = System.getProperty("http.proxyPort");
            if (android.text.TextUtils.isEmpty(v1) == 0) {
                v0 = Integer.parseInt(v1);
            }
        } else {
            if (p3 == 0) {
                v0 = android.net.Proxy.getDefaultPort();
            } else {
                v0 = android.net.Proxy.getPort(p3);
                if (v0 < 0) {
                    v0 = android.net.Proxy.getDefaultPort();
                }
            }
        }
        return v0;
    }
    private static String a(org.apache.http.HttpResponse p6)
    {
        v1 = p6.getEntity().getContent();
        v2 = new java.io.ByteArrayOutputStream();
        v0 = p6.getFirstHeader("Content-Encoding");
        if ((v0 == 0) || (v0.getValue().toLowerCase().indexOf("gzip") <= -1)) {
            v0 = v1;
        } else {
            v0 = new java.util.zip.GZIPInputStream(v1);
        }
        v1 = new byte[512];
        while(true) {
            v3 = v0.read(v1);
            if (v3 == -1) {
                break;
            }
            v2.write(v1, 0, v3);
        }
        v1 = new String(v2.toByteArray(), "UTF-8");
        v0.close();
        return v1;
    }
    private static void a(android.content.Context p3, com.tencent.connect.auth.QQToken p4, String p5)
    {
        if ((p5.indexOf("add_share") > -1) || ((p5.indexOf("upload_pic") > -1) || ((p5.indexOf("add_topic") > -1) || ((p5.indexOf("set_user_face") > -1) || ((p5.indexOf("add_t") > -1) || ((p5.indexOf("add_pic_t") > -1) || ((p5.indexOf("add_pic_url") > -1) || (p5.indexOf("add_video") > -1)))))))) {
            v1 = new String[1];
            v1[0] = p5;
            com.tencent.connect.a.a.a(p3, p4, "requireApi", v1);
        }
        return;
    }
    private static String b(android.content.Context p2)
    {
        if (android.os.Build$VERSION.SDK_INT >= 11) {
            v0 = System.getProperty("http.proxyHost");
        } else {
            if (p2 == 0) {
                v0 = android.net.Proxy.getDefaultHost();
            } else {
                v0 = android.net.Proxy.getHost(p2);
                if (android.text.TextUtils.isEmpty(v0) != 0) {
                    v0 = android.net.Proxy.getDefaultHost();
                }
            }
        }
        return v0;
    }
    public static String encodePostBody(android.os.Bundle p8, String p9)
    {
        if (p8 != 0) {
            v3 = new StringBuilder();
            v4 = p8.size();
            v5 = p8.keySet().iterator();
            v1 = -1;
            while (v5.hasNext() != 0) {
                v0 = v5.next();
                v2 = (v1 + 1);
                v1 = p8.get(v0);
                if ((v1 instanceof String) != 0) {
                    v3.append(new StringBuilder().append("Content-Disposition: form-data; name=\"").append(v0).append("\"").append("\r\n").append("\r\n").append(v1).toString());
                    if (v2 < (v4 - 1)) {
                        v3.append(new StringBuilder().append("\r\n--").append(p9).append("\r\n").toString());
                    }
                    v1 = v2;
                } else {
                    v1 = v2;
                }
            }
            v0 = v3.toString();
        } else {
            v0 = "";
        }
        return v0;
    }
    public static String encodeUrl(android.os.Bundle p8)
    {
        if (p8 != 0) {
            v3 = new StringBuilder();
            v4 = p8.keySet().iterator();
            v1 = 1;
            while (v4.hasNext() != 0) {
                v0 = v4.next();
                v5 = p8.get(v0);
                if (((v5 instanceof String) != 0) || ((v5 instanceof String[]) != 0)) {
                    if ((v5 instanceof String[]) == 0) {
                        if (v1 == 0) {
                            v3.append("&");
                        } else {
                            v1 = 0;
                        }
                        v3.append(new StringBuilder().append(java.net.URLEncoder.encode(v0)).append("=").append(java.net.URLEncoder.encode(p8.getString(v0))).toString());
                        v0 = v1;
                    } else {
                        if (v1 == 0) {
                            v3.append("&");
                        } else {
                            v1 = 0;
                        }
                        v3.append(new StringBuilder().append(java.net.URLEncoder.encode(v0)).append("=").toString());
                        v5 = p8.getStringArray(v0);
                        if (v5 != 0) {
                            v0 = 0;
                            while (v0 < v5.length) {
                                if (v0 != 0) {
                                    v3.append(java.net.URLEncoder.encode(new StringBuilder().append(",").append(v5[v0]).toString()));
                                } else {
                                    v3.append(java.net.URLEncoder.encode(v5[v0]));
                                }
                                v0++;
                            }
                            v0 = v1;
                        }
                    }
                    v1 = v0;
                }
            }
            v0 = v3.toString();
        } else {
            v0 = "";
        }
        return v0;
    }
    public static int getErrorCodeFromException(java.io.IOException p1)
    {
        if ((p1 instanceof java.io.CharConversionException) == 0) {
            if ((p1 instanceof java.nio.charset.MalformedInputException) == 0) {
                if ((p1 instanceof java.nio.charset.UnmappableCharacterException) == 0) {
                    if ((p1 instanceof org.apache.http.client.HttpResponseException) == 0) {
                        if ((p1 instanceof java.nio.channels.ClosedChannelException) == 0) {
                            if ((p1 instanceof org.apache.http.ConnectionClosedException) == 0) {
                                if ((p1 instanceof java.io.EOFException) == 0) {
                                    if ((p1 instanceof java.nio.channels.FileLockInterruptionException) == 0) {
                                        if ((p1 instanceof java.io.FileNotFoundException) == 0) {
                                            if ((p1 instanceof java.net.HttpRetryException) == 0) {
                                                if ((p1 instanceof org.apache.http.conn.ConnectTimeoutException) == 0) {
                                                    if ((p1 instanceof java.net.SocketTimeoutException) == 0) {
                                                        if ((p1 instanceof java.util.InvalidPropertiesFormatException) == 0) {
                                                            if ((p1 instanceof org.apache.http.MalformedChunkCodingException) == 0) {
                                                                if ((p1 instanceof java.net.MalformedURLException) == 0) {
                                                                    if ((p1 instanceof org.apache.http.NoHttpResponseException) == 0) {
                                                                        if ((p1 instanceof java.io.InvalidClassException) == 0) {
                                                                            if ((p1 instanceof java.io.InvalidObjectException) == 0) {
                                                                                if ((p1 instanceof java.io.NotActiveException) == 0) {
                                                                                    if ((p1 instanceof java.io.NotSerializableException) == 0) {
                                                                                        if ((p1 instanceof java.io.OptionalDataException) == 0) {
                                                                                            if ((p1 instanceof java.io.StreamCorruptedException) == 0) {
                                                                                                if ((p1 instanceof java.io.WriteAbortedException) == 0) {
                                                                                                    if ((p1 instanceof java.net.ProtocolException) == 0) {
                                                                                                        if ((p1 instanceof javax.net.ssl.SSLHandshakeException) == 0) {
                                                                                                            if ((p1 instanceof javax.net.ssl.SSLKeyException) == 0) {
                                                                                                                if ((p1 instanceof javax.net.ssl.SSLPeerUnverifiedException) == 0) {
                                                                                                                    if ((p1 instanceof javax.net.ssl.SSLProtocolException) == 0) {
                                                                                                                        if ((p1 instanceof java.net.BindException) == 0) {
                                                                                                                            if ((p1 instanceof java.net.ConnectException) == 0) {
                                                                                                                                if ((p1 instanceof java.net.NoRouteToHostException) == 0) {
                                                                                                                                    if ((p1 instanceof java.net.PortUnreachableException) == 0) {
                                                                                                                                        if ((p1 instanceof java.io.SyncFailedException) == 0) {
                                                                                                                                            if ((p1 instanceof java.io.UTFDataFormatException) == 0) {
                                                                                                                                                if ((p1 instanceof java.net.UnknownHostException) == 0) {
                                                                                                                                                    if ((p1 instanceof java.net.UnknownServiceException) == 0) {
                                                                                                                                                        if ((p1 instanceof java.io.UnsupportedEncodingException) == 0) {
                                                                                                                                                            if ((p1 instanceof java.util.zip.ZipException) == 0) {
                                                                                                                                                                v0 = -2;
                                                                                                                                                            } else {
                                                                                                                                                                v0 = -54;
                                                                                                                                                            }
                                                                                                                                                        } else {
                                                                                                                                                            v0 = -53;
                                                                                                                                                        }
                                                                                                                                                    } else {
                                                                                                                                                        v0 = -52;
                                                                                                                                                    }
                                                                                                                                                } else {
                                                                                                                                                    v0 = -51;
                                                                                                                                                }
                                                                                                                                            } else {
                                                                                                                                                v0 = -50;
                                                                                                                                            }
                                                                                                                                        } else {
                                                                                                                                            v0 = -49;
                                                                                                                                        }
                                                                                                                                    } else {
                                                                                                                                        v0 = -48;
                                                                                                                                    }
                                                                                                                                } else {
                                                                                                                                    v0 = -47;
                                                                                                                                }
                                                                                                                            } else {
                                                                                                                                v0 = -46;
                                                                                                                            }
                                                                                                                        } else {
                                                                                                                            v0 = -45;
                                                                                                                        }
                                                                                                                    } else {
                                                                                                                        v0 = -44;
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    v0 = -43;
                                                                                                                }
                                                                                                            } else {
                                                                                                                v0 = -42;
                                                                                                            }
                                                                                                        } else {
                                                                                                            v0 = -41;
                                                                                                        }
                                                                                                    } else {
                                                                                                        v0 = -40;
                                                                                                    }
                                                                                                } else {
                                                                                                    v0 = -39;
                                                                                                }
                                                                                            } else {
                                                                                                v0 = -38;
                                                                                            }
                                                                                        } else {
                                                                                            v0 = -37;
                                                                                        }
                                                                                    } else {
                                                                                        v0 = -36;
                                                                                    }
                                                                                } else {
                                                                                    v0 = -35;
                                                                                }
                                                                            } else {
                                                                                v0 = -34;
                                                                            }
                                                                        } else {
                                                                            v0 = -33;
                                                                        }
                                                                    } else {
                                                                        v0 = -32;
                                                                    }
                                                                } else {
                                                                    v0 = -3;
                                                                }
                                                            } else {
                                                                v0 = -31;
                                                            }
                                                        } else {
                                                            v0 = -30;
                                                        }
                                                    } else {
                                                        v0 = -8;
                                                    }
                                                } else {
                                                    v0 = -7;
                                                }
                                            } else {
                                                v0 = -29;
                                            }
                                        } else {
                                            v0 = -28;
                                        }
                                    } else {
                                        v0 = -27;
                                    }
                                } else {
                                    v0 = -26;
                                }
                            } else {
                                v0 = -25;
                            }
                        } else {
                            v0 = -24;
                        }
                    } else {
                        v0 = -23;
                    }
                } else {
                    v0 = -22;
                }
            } else {
                v0 = -21;
            }
        } else {
            v0 = -20;
        }
        return v0;
    }
    public static org.apache.http.client.HttpClient getHttpClient(android.content.Context p8, String p9, String p10)
    {
        v0 = 0;
        v3 = new org.apache.http.conn.scheme.SchemeRegistry();
        v3.register(new org.apache.http.conn.scheme.Scheme("http", org.apache.http.conn.scheme.PlainSocketFactory.getSocketFactory(), 80));
        if (android.os.Build$VERSION.SDK_INT >= 16) {
            v3.register(new org.apache.http.conn.scheme.Scheme("https", org.apache.http.conn.ssl.SSLSocketFactory.getSocketFactory(), 443));
        } else {
            v2 = java.security.KeyStore.getInstance(java.security.KeyStore.getDefaultType());
            v2.load(0, 0);
            v4 = new com.tencent.open.utils.HttpUtils$CustomSSLSocketFactory(v2);
            v4.setHostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.STRICT_HOSTNAME_VERIFIER);
            v3.register(new org.apache.http.conn.scheme.Scheme("https", v4, 443));
        }
        v4 = new org.apache.http.params.BasicHttpParams();
        if (p8 == 0) {
            v2 = 0;
        } else {
            v2 = com.tencent.open.utils.OpenConfig.getInstance(p8, p9);
        }
        if (v2 == 0) {
            v1 = 0;
        } else {
            v1 = v2.getInt("Common_HttpConnectionTimeout");
            v0 = v2.getInt("Common_SocketConnectionTimeout");
        }
        if (v1 == 0) {
            v1 = 15000;
        }
        if (v0 == 0) {
            v0 = 30000;
        }
        org.apache.http.params.HttpConnectionParams.setConnectionTimeout(v4, v1);
        org.apache.http.params.HttpConnectionParams.setSoTimeout(v4, v0);
        org.apache.http.params.HttpProtocolParams.setVersion(v4, org.apache.http.HttpVersion.HTTP_1_1);
        org.apache.http.params.HttpProtocolParams.setContentCharset(v4, "UTF-8");
        org.apache.http.params.HttpProtocolParams.setUserAgent(v4, new StringBuilder().append("AndroidSDK_").append(android.os.Build$VERSION.SDK).append("_").append(android.os.Build.DEVICE).append("_").append(android.os.Build$VERSION.RELEASE).toString());
        v1 = new org.apache.http.impl.client.DefaultHttpClient(new org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager(v4, v3), v4);
        v0 = com.tencent.open.utils.HttpUtils.getProxy(p8);
        if (v0 != 0) {
            v1.getParams().setParameter("http.route.default-proxy", new org.apache.http.HttpHost(v0.host, v0.port));
        }
        return v1;
    }
    public static com.tencent.open.utils.HttpUtils$NetworkProxy getProxy(android.content.Context p4)
    {
        if (p4 != 0) {
            v0 = p4.getSystemService("connectivity");
            if (v0 != 0) {
                v0 = v0.getActiveNetworkInfo();
                if (v0 != 0) {
                    if (v0.getType() == 0) {
                        v2 = com.tencent.open.utils.HttpUtils.b(p4);
                        v3 = com.tencent.open.utils.HttpUtils.a(p4);
                        if ((android.text.TextUtils.isEmpty(v2) == 0) && (v3 >= 0)) {
                            v0 = new com.tencent.open.utils.HttpUtils$NetworkProxy(v2, v3, 0);
                            return v0;
                        }
                    }
                    v0 = 0;
                } else {
                    v0 = 0;
                }
            } else {
                v0 = 0;
            }
        } else {
            v0 = 0;
        }
    }
    public static com.tencent.open.utils.Util$Statistic openUrl2(android.content.Context p12, String p13, String p14, android.os.Bundle p15)
    {
        if (p12 != 0) {
            v0 = p12.getSystemService("connectivity");
            if (v0 != 0) {
                v0 = v0.getActiveNetworkInfo();
                if ((v0 == 0) || (v0.isAvailable() == 0)) {
                    throw new com.tencent.open.utils.HttpUtils$NetworkUnavailableException("network unavailable");
                }
            }
        }
        if (p15 == 0) {
            v2 = new android.os.Bundle();
        } else {
            v2 = new android.os.Bundle(p15);
        }
        v0 = v2.getString("appid_for_getting_config");
        v2.remove("appid_for_getting_config");
        v6 = com.tencent.open.utils.HttpUtils.getHttpClient(p12, v0, p13);
        if (p14.equals("GET") == 0) {
            if (p14.equals("POST") == 0) {
                v1 = 0;
                v0 = 0;
            } else {
                v5 = new org.apache.http.client.methods.HttpPost(p13);
                v5.addHeader("Accept-Encoding", "gzip");
                v7 = new android.os.Bundle();
                v8 = v2.keySet().iterator();
                while (v8.hasNext() != 0) {
                    v0 = v8.next();
                    v1 = v2.get(v0);
                    if ((v1 instanceof byte[]) != 0) {
                        v7.putByteArray(v0, v1);
                    }
                }
                if (v2.containsKey("method") == 0) {
                    v2.putString("method", p14);
                }
                v5.setHeader("Content-Type", "multipart/form-data; boundary=3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f");
                v5.setHeader("Connection", "Keep-Alive");
                v8 = new java.io.ByteArrayOutputStream();
                v8.write(com.tencent.open.utils.Util.getBytesUTF8("--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f\r\n"));
                v8.write(com.tencent.open.utils.Util.getBytesUTF8(com.tencent.open.utils.HttpUtils.encodePostBody(v2, "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f")));
                if (v7.isEmpty() == 0) {
                    v2 = v7.size();
                    v8.write(com.tencent.open.utils.Util.getBytesUTF8("\r\n--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f\r\n"));
                    v9 = v7.keySet().iterator();
                    v1 = -1;
                    while (v9.hasNext() != 0) {
                        v0 = v9.next();
                        v1++;
                        v8.write(com.tencent.open.utils.Util.getBytesUTF8(new StringBuilder().append("Content-Disposition: form-data; name=\"").append(v0).append("\"; filename=\"").append(v0).append("\"").append("\r\n").toString()));
                        v8.write(com.tencent.open.utils.Util.getBytesUTF8("Content-Type: content/unknown\r\n\r\n"));
                        v0 = v7.getByteArray(v0);
                        if (v0 != 0) {
                            v8.write(v0);
                        }
                        if (v1 < (v2 - 1)) {
                            v8.write(com.tencent.open.utils.Util.getBytesUTF8("\r\n--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f\r\n"));
                        }
                    }
                }
                v8.write(com.tencent.open.utils.Util.getBytesUTF8("\r\n--3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f--\r\n"));
                v1 = v8.toByteArray();
                v0 = (v1.length + 0);
                v8.close();
                v5.setEntity(new org.apache.http.entity.ByteArrayEntity(v1));
                v1 = v5;
            }
        } else {
            v2 = com.tencent.open.utils.HttpUtils.encodeUrl(v2);
            v1 = (0 + v2.length());
            com.tencent.open.a.f.a("openSDK_LOG.HttpUtils", new StringBuilder().append("-->openUrl2 before url =").append(p13).toString());
            if (p13.indexOf("?") != -1) {
                v0 = new StringBuilder().append(p13).append("&").toString();
            } else {
                v0 = new StringBuilder().append(p13).append("?").toString();
            }
            com.tencent.open.a.f.a("openSDK_LOG.HttpUtils", new StringBuilder().append("-->openUrl2 encodedParam =").append(v2).append(" -- url = ").append(v0).toString());
            v0 = new org.apache.http.client.methods.HttpGet(new StringBuilder().append(v0).append(v2).toString());
            v0.addHeader("Accept-Encoding", "gzip");
            v11 = v1;
            v1 = v0;
            v0 = v11;
        }
        v1 = v6.execute(v1);
        v2 = v1.getStatusLine().getStatusCode();
        if (v2 != 200) {
            throw new com.tencent.open.utils.HttpUtils$HttpStatusException(new StringBuilder().append("http status code error:").append(v2).toString());
        } else {
            return new com.tencent.open.utils.Util$Statistic(com.tencent.open.utils.HttpUtils.a(v1), v0);
        }
    }
    public static org.json.JSONObject request(com.tencent.connect.auth.QQToken p18, android.content.Context p19, String p20, android.os.Bundle p21, String p22)
    {
        com.tencent.open.a.f.a("openSDK_LOG.HttpUtils", "OpenApi request");
        if (p20.toLowerCase().startsWith("http") != 0) {
            v4 = p20;
            v3 = p20;
        } else {
            v3 = new StringBuilder().append(com.tencent.open.utils.ServerSetting.getInstance().getEnvUrl(p19, "https://openmobile.qq.com/")).append(p20).toString();
            v4 = new StringBuilder().append(com.tencent.open.utils.ServerSetting.getInstance().getEnvUrl(p19, "https://openmobile.qq.com/")).append(p20).toString();
        }
        com.tencent.open.utils.HttpUtils.a(p19, p18, p20);
        v7 = android.os.SystemClock.elapsedRealtime();
        v5 = com.tencent.open.utils.OpenConfig.getInstance(p19, p18.getAppId()).getInt("Common_HttpRetryCount");
        com.tencent.open.a.f.a("OpenConfig_test", new StringBuilder().append("config 1:Common_HttpRetryCount            config_value:").append(v5).append("   appid:").append(p18.getAppId()).append("     url:").append(v4).toString());
        if (v5 != 0) {
            v12 = v5;
        } else {
            v12 = 3;
        }
        v10 = new StringBuilder().append("config 1:Common_HttpRetryCount            result_value:").append(v12).append("   appid:").append(p18.getAppId()).append("     url:").append(v4).toString();
        com.tencent.open.a.f.a("OpenConfig_test", v10);
        v5 = v7;
        v9 = com.tencent.open.utils.HttpUtils.openUrl2(p19, v3, p22, p21);
        v14 = com.tencent.open.utils.Util.parseJson(v9.response);
        v12 = v14;
        com.tencent.open.b.g.a().a(v4, v5, 0, v9.reqSize, 0, v9.rspSize, v10, v14.getInt("ret"));
        return v12;
    }
    public static void requestAsync(com.tencent.connect.auth.QQToken p7, android.content.Context p8, String p9, android.os.Bundle p10, String p11, com.tencent.tauth.IRequestListener p12)
    {
        com.tencent.open.a.f.a("openSDK_LOG.HttpUtils", "OpenApi requestAsync");
        new com.tencent.open.utils.HttpUtils$1(p7, p8, p9, p10, p11, p12).start();
        return;
    }
}
