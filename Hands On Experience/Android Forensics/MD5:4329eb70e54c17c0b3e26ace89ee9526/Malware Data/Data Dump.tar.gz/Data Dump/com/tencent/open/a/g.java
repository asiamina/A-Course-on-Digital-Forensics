package com.tencent.open.a;
public class g implements java.lang.Iterable {
    private java.util.concurrent.ConcurrentLinkedQueue a;
    private java.util.concurrent.atomic.AtomicInteger b;
    public g()
    {
        this.a = 0;
        this.b = 0;
        this.a = new java.util.concurrent.ConcurrentLinkedQueue();
        this.b = new java.util.concurrent.atomic.AtomicInteger(0);
        return;
    }
    public int a()
    {
        return this.b.get();
    }
    public int a(String p3)
    {
        v0 = p3.length();
        this.a.add(p3);
        return this.b.addAndGet(v0);
    }
    public void a(java.io.Writer p11, char[] p12)
    {
        if ((p11 != 0) && ((p12 != 0) && (p12.length != 0))) {
            v4 = p12.length;
            v8 = this.iterator();
            v1 = 0;
            v3 = v4;
            while (v8.hasNext() != 0) {
                v0 = v8.next();
                v6 = v0.length();
                v7 = 0;
                while (v6 > 0) {
                    if (v3 <= v6) {
                        v5 = v3;
                    } else {
                        v5 = v6;
                    }
                    v0.getChars(v7, (v7 + v5), p12, v1);
                    v3 -= v5;
                    v1 += v5;
                    v6 -= v5;
                    v5 += v7;
                    if (v3 != 0) {
                        v7 = v5;
                    } else {
                        p11.write(p12, 0, v4);
                        v1 = 0;
                        v3 = v4;
                        v7 = v5;
                    }
                }
            }
            if (v1 > 0) {
                p11.write(p12, 0, v1);
            }
            p11.flush();
        }
        return;
    }
    public void b()
    {
        this.a.clear();
        this.b.set(0);
        return;
    }
    public java.util.Iterator iterator()
    {
        return this.a.iterator();
    }
}
