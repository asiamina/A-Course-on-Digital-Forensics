package com.tencent.mm.sdk.c;
final public class a$b implements android.provider.BaseColumns {
    final public static android.net.Uri CONTENT_URI;
    static a$b()
    {
        com.tencent.mm.sdk.c.a$b.CONTENT_URI = android.net.Uri.parse("content://com.tencent.mm.sdk.plugin.provider/sharedpref");
        return;
    }
}
