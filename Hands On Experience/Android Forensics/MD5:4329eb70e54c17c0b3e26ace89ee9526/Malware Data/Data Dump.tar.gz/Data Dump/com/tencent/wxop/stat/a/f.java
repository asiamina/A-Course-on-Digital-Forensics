package com.tencent.wxop.stat.a;
final public enum class f extends java.lang.Enum {
    final public static enum com.tencent.wxop.stat.a.f a;
    final public static enum com.tencent.wxop.stat.a.f c;
    final public static enum com.tencent.wxop.stat.a.f b;
    final public static enum com.tencent.wxop.stat.a.f e;
    final public static enum com.tencent.wxop.stat.a.f d;
    final public static enum com.tencent.wxop.stat.a.f g;
    final public static enum com.tencent.wxop.stat.a.f f;
    final public static enum com.tencent.wxop.stat.a.f i;
    final public static enum com.tencent.wxop.stat.a.f h;
    final private synthetic static com.tencent.wxop.stat.a.f[] k;
    private int j;
    static f()
    {
        com.tencent.wxop.stat.a.f.a = new com.tencent.wxop.stat.a.f("PAGE_VIEW", 0, 1);
        com.tencent.wxop.stat.a.f.b = new com.tencent.wxop.stat.a.f("SESSION_ENV", 1, 2);
        com.tencent.wxop.stat.a.f.c = new com.tencent.wxop.stat.a.f("ERROR", 2, 3);
        com.tencent.wxop.stat.a.f.d = new com.tencent.wxop.stat.a.f("CUSTOM", 3, 1000);
        com.tencent.wxop.stat.a.f.e = new com.tencent.wxop.stat.a.f("ADDITION", 4, 1001);
        com.tencent.wxop.stat.a.f.f = new com.tencent.wxop.stat.a.f("MONITOR_STAT", 5, 1002);
        com.tencent.wxop.stat.a.f.g = new com.tencent.wxop.stat.a.f("MTA_GAME_USER", 6, 1003);
        com.tencent.wxop.stat.a.f.h = new com.tencent.wxop.stat.a.f("NETWORK_MONITOR", 7, 1004);
        com.tencent.wxop.stat.a.f.i = new com.tencent.wxop.stat.a.f("NETWORK_DETECTOR", 8, 1005);
        v0 = new com.tencent.wxop.stat.a.f[9];
        v0[0] = com.tencent.wxop.stat.a.f.a;
        v0[1] = com.tencent.wxop.stat.a.f.b;
        v0[2] = com.tencent.wxop.stat.a.f.c;
        v0[3] = com.tencent.wxop.stat.a.f.d;
        v0[4] = com.tencent.wxop.stat.a.f.e;
        v0[5] = com.tencent.wxop.stat.a.f.f;
        v0[6] = com.tencent.wxop.stat.a.f.g;
        v0[7] = com.tencent.wxop.stat.a.f.h;
        v0[8] = com.tencent.wxop.stat.a.f.i;
        com.tencent.wxop.stat.a.f.k = v0;
        return;
    }
    private f(String p1, int p2, int p3)
    {
        this(p1, p2);
        this.j = p3;
        return;
    }
    public final int a()
    {
        return this.j;
    }
}
