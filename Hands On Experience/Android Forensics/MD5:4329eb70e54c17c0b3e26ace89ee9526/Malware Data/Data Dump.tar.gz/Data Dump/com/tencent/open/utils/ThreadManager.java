package com.tencent.open.utils;
final public class ThreadManager {
    private static android.os.Handler a;
    final public static java.util.concurrent.Executor NETWORK_EXECUTOR;
    private static Object b;
    private static android.os.Handler e;
    private static android.os.HandlerThread d;
    private static android.os.HandlerThread f;
    private static android.os.Handler c;
    static ThreadManager()
    {
        com.tencent.open.utils.ThreadManager.b = new Object();
        com.tencent.open.utils.ThreadManager.NETWORK_EXECUTOR = com.tencent.open.utils.ThreadManager.a();
        return;
    }
    public ThreadManager()
    {
        return;
    }
    private static java.util.concurrent.Executor a()
    {
        if (android.os.Build$VERSION.SDK_INT < 11) {
            v0 = android.os.AsyncTask.getDeclaredField("sExecutor");
            v0.setAccessible(1);
            v1 = v0.get(0);
        } else {
            v1 = new java.util.concurrent.ThreadPoolExecutor(1, 1, 0.0, v4, java.util.concurrent.TimeUnit.SECONDS, new java.util.concurrent.LinkedBlockingQueue());
        }
        if ((v1 instanceof java.util.concurrent.ThreadPoolExecutor) != 0) {
            v1.setCorePoolSize(3);
        }
        return v1;
    }
    public static void executeOnFileThread(Runnable p1)
    {
        com.tencent.open.utils.ThreadManager.getFileThreadHandler().post(p1);
        return;
    }
    public static void executeOnNetWorkThread(Runnable p1)
    {
        com.tencent.open.utils.ThreadManager.NETWORK_EXECUTOR.execute(p1);
        return;
    }
    public static void executeOnSubThread(Runnable p1)
    {
        com.tencent.open.utils.ThreadManager.getSubThreadHandler().post(p1);
        return;
    }
    public static android.os.Handler getFileThreadHandler()
    {
        if (com.tencent.open.utils.ThreadManager.e == 0) {
            com.tencent.open.utils.ThreadManager.f = new android.os.HandlerThread("SDK_FILE_RW");
            com.tencent.open.utils.ThreadManager.f.start();
            com.tencent.open.utils.ThreadManager.e = new android.os.Handler(com.tencent.open.utils.ThreadManager.f.getLooper());
        }
        return com.tencent.open.utils.ThreadManager.e;
    }
    public static android.os.Looper getFileThreadLooper()
    {
        return com.tencent.open.utils.ThreadManager.getFileThreadHandler().getLooper();
    }
    public static android.os.Handler getMainHandler()
    {
        if ((com.tencent.open.utils.ThreadManager.a == 0) && (com.tencent.open.utils.ThreadManager.a == 0)) {
            com.tencent.open.utils.ThreadManager.a = new android.os.Handler(android.os.Looper.getMainLooper());
        }
        return com.tencent.open.utils.ThreadManager.a;
    }
    public static Thread getSubThread()
    {
        if (com.tencent.open.utils.ThreadManager.d == 0) {
            com.tencent.open.utils.ThreadManager.getSubThreadHandler();
        }
        return com.tencent.open.utils.ThreadManager.d;
    }
    public static android.os.Handler getSubThreadHandler()
    {
        if (com.tencent.open.utils.ThreadManager.c == 0) {
            com.tencent.open.utils.ThreadManager.d = new android.os.HandlerThread("SDK_SUB");
            com.tencent.open.utils.ThreadManager.d.start();
            com.tencent.open.utils.ThreadManager.c = new android.os.Handler(com.tencent.open.utils.ThreadManager.d.getLooper());
        }
        return com.tencent.open.utils.ThreadManager.c;
    }
    public static android.os.Looper getSubThreadLooper()
    {
        return com.tencent.open.utils.ThreadManager.getSubThreadHandler().getLooper();
    }
    public static void init()
    {
        return;
    }
    public static java.util.concurrent.Executor newSerialExecutor()
    {
        return new com.tencent.open.utils.ThreadManager$SerialExecutor(0);
    }
}
