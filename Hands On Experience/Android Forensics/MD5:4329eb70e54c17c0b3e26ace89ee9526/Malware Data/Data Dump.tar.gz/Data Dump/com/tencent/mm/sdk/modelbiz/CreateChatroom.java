package com.tencent.mm.sdk.modelbiz;
public class CreateChatroom {
    private CreateChatroom()
    {
        return;
    }
}
