package com.tencent.mm.sdk.diffdev;
public interface abstract class OAuthListener {
    abstract public void onAuthFinish();
    abstract public void onAuthGotQrcode();
    abstract public void onQrcodeScanned();
}
