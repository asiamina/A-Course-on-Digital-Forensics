package com.tencent.open;
public class a$a {
    protected ref.WeakReference a;
    protected String c;
    protected long b;
    public a$a(android.webkit.WebView p2, long p3, String p5)
    {
        this.a = new ref.WeakReference(p2);
        this.b = p3;
        this.c = p5;
        return;
    }
    public void a()
    {
        v0 = this.a.get();
        if (v0 != 0) {
            v0.loadUrl(new StringBuilder().append("javascript:window.JsBridge&&JsBridge.callback(").append(this.b).append(",{\'r\':1,\'result\':\'no such method\'})").toString());
        }
        return;
    }
    public void a(Object p6)
    {
        v0 = this.a.get();
        if (v0 != 0) {
            v1 = "\'undefined\'";
            if ((p6 instanceof String) == 0) {
                if (((p6 instanceof Number) == 0) && (((p6 instanceof Long) == 0) && (((p6 instanceof Integer) == 0) && (((p6 instanceof Double) == 0) && ((p6 instanceof Float) == 0))))) {
                    if ((p6 instanceof Boolean) != 0) {
                        v1 = p6.toString();
                    }
                } else {
                    v1 = p6.toString();
                }
            } else {
                v1 = new StringBuilder().append("\'").append(p6.replace("\\", "\\\\").replace("\'", "\\\'")).append("\'").toString();
            }
            v0.loadUrl(new StringBuilder().append("javascript:window.JsBridge&&JsBridge.callback(").append(this.b).append(",{\'r\':0,\'result\':").append(v1).append("});").toString());
        }
        return;
    }
    public void a(String p4)
    {
        v0 = this.a.get();
        if (v0 != 0) {
            v0.loadUrl(new StringBuilder().append("javascript:").append(p4).toString());
        }
        return;
    }
}
