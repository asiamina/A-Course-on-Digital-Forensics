package com.tencent.bugly.crashreport.crash;
final class c$2 extends java.lang.Thread {
    private synthetic com.tencent.bugly.crashreport.crash.c a;
    public final void run()
    {
        if (com.tencent.bugly.proguard.z.a(com.tencent.bugly.crashreport.crash.c.b(this.a), "local_crash_lock", 10000.0) != 0) {
            v0 = this.a.o.a();
            if ((v0 != 0) && (v0.size() > 0)) {
                v3 = v0.size();
                if (((long) v3) <= 100.0) {
                    v1 = v0;
                } else {
                    v1 = new java.util.ArrayList();
                    java.util.Collections.sort(v0);
                    v2 = 0;
                    while (((long) v2) < 100.0) {
                        v1.add(v0.get(((v3 - 1) - v2)));
                        v2++;
                    }
                }
                this.a.o.a(v1, 0.0, v3, 0, 0, 0);
            }
            com.tencent.bugly.proguard.z.b(com.tencent.bugly.crashreport.crash.c.b(this.a), "local_crash_lock");
        }
        return;
    }
     c$2(com.tencent.bugly.crashreport.crash.c p1)
    {
        this.a = p1;
        return;
    }
}
