package com.tencent.wxop.stat;
final class l implements java.lang.Runnable {
    final synthetic android.content.Context a;
     l(android.content.Context p1)
    {
        this.a = p1;
        return;
    }
    public final void run()
    {
        com.tencent.wxop.stat.a.a(com.tencent.wxop.stat.StatServiceImpl.e()).h();
        com.tencent.wxop.stat.common.k.a(this.a, 1);
        com.tencent.wxop.stat.au.a(this.a);
        com.tencent.wxop.stat.i.b(this.a);
        com.tencent.wxop.stat.StatServiceImpl.a(Thread.getDefaultUncaughtExceptionHandler());
        Thread.setDefaultUncaughtExceptionHandler(new com.tencent.wxop.stat.ao());
        if (com.tencent.wxop.stat.StatConfig.getStatSendStrategy() == com.tencent.wxop.stat.StatReportStrategy.APP_LAUNCH) {
            com.tencent.wxop.stat.StatServiceImpl.commitEvents(this.a, -1);
        }
        if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
            com.tencent.wxop.stat.StatServiceImpl.f().d("Init MTA StatService success.");
        }
        return;
    }
}
