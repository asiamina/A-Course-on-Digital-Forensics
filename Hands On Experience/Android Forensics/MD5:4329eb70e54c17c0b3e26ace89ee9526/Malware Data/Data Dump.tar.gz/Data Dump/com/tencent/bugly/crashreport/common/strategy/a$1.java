package com.tencent.bugly.crashreport.common.strategy;
final class a$1 extends java.lang.Thread {
    private synthetic com.tencent.bugly.crashreport.common.strategy.a a;
     a$1(com.tencent.bugly.crashreport.common.strategy.a p1)
    {
        this.a = p1;
        return;
    }
    public final void run()
    {
        v1 = com.tencent.bugly.proguard.p.a().a(com.tencent.bugly.crashreport.common.strategy.a.a, 0, 1);
        if (v1 != 0) {
            v0 = v1.get("key_imei");
            v1 = v1.get("key_ip");
            if (v0 != 0) {
                com.tencent.bugly.crashreport.common.info.a.a(com.tencent.bugly.crashreport.common.strategy.a.a(this.a)).e(new String(v0));
            }
            if (v1 != 0) {
                com.tencent.bugly.crashreport.common.info.a.a(com.tencent.bugly.crashreport.common.strategy.a.a(this.a)).d(new String(v1));
            }
        }
        com.tencent.bugly.crashreport.common.strategy.a.a(this.a, com.tencent.bugly.crashreport.common.strategy.a.d());
        if ((com.tencent.bugly.crashreport.common.strategy.a.b(this.a) != 0) && ((com.tencent.bugly.proguard.z.a(com.tencent.bugly.crashreport.common.strategy.a.e()) == 0) && (com.tencent.bugly.proguard.z.c(com.tencent.bugly.crashreport.common.strategy.a.e()) != 0))) {
            com.tencent.bugly.crashreport.common.strategy.a.b(this.a).r = com.tencent.bugly.crashreport.common.strategy.a.e();
            com.tencent.bugly.crashreport.common.strategy.a.b(this.a).s = com.tencent.bugly.crashreport.common.strategy.a.e();
        }
        this.a.a(com.tencent.bugly.crashreport.common.strategy.a.b(this.a), 0);
        return;
    }
}
