package com.tencent.open.wpa;
public class WPA extends com.tencent.connect.common.BaseApi {
    final public static String CHAT_TYPE_GROUP;
    final public static String CHAT_TYPE_WPA;
    public WPA(android.content.Context p1, com.tencent.connect.auth.QQAuth p2, com.tencent.connect.auth.QQToken p3)
    {
        this(p2, p3);
        return;
    }
    public WPA(android.content.Context p1, com.tencent.connect.auth.QQToken p2)
    {
        this(p2);
        return;
    }
    public WPA(com.tencent.connect.auth.QQToken p1)
    {
        this(p1);
        return;
    }
    public void getWPAUserOnlineState(String p9, com.tencent.tauth.IUiListener p10)
    {
        if (p9 != 0) {
            if (p9.length() >= 5) {
                v0 = 0;
                while (v0 < p9.length()) {
                    if (Character.isDigit(p9.charAt(v0)) != 0) {
                        v0++;
                    } else {
                        com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.WPASTATE.XX", "15", "18", "1");
                        throw new Exception("uin not digit");
                    }
                }
                com.tencent.open.utils.HttpUtils.requestAsync(this.mToken, com.tencent.open.utils.Global.getContext(), new StringBuilder().append("http://webpresence.qq.com/getonline?Type=1&").append(p9).append(":").toString(), 0, "GET", new com.tencent.connect.common.BaseApi$TempRequestListener(this, p10));
                com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.WPASTATE.XX", "15", "18", "0");
                return;
            } else {
                com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.WPASTATE.XX", "15", "18", "1");
                throw new Exception("uin length < 5");
            }
        } else {
            com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.WPASTATE.XX", "15", "18", "1");
            throw new Exception("uin null");
        }
    }
    public int startWPAConversation(android.app.Activity p2, String p3, String p4)
    {
        return this.startWPAConversation(p2, "wpa", p3, p4);
    }
    public int startWPAConversation(android.app.Activity p12, String p13, String p14, String p15)
    {
        if ((p13 != 0) && ((p13.equals("wpa") != 0) || (p13.equals("group") != 0))) {
            v4 = "16";
            if (p13.equals("group") != 0) {
                v4 = "17";
            }
            v2 = new android.content.Intent("android.intent.action.VIEW");
            if (android.text.TextUtils.isEmpty(p14) == 0) {
                if (p14.length() >= 5) {
                    v0 = 0;
                    while (v0 < p14.length()) {
                        if (Character.isDigit(p14.charAt(v0)) != 0) {
                            v0++;
                        } else {
                            com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.STARTWPA.XX", v4, "18", "1");
                            v7 = -4;
                        }
                    }
                    v0 = "";
                    if (android.text.TextUtils.isEmpty(p15) == 0) {
                        v0 = android.util.Base64.encodeToString(p15.getBytes("UTF-8"), 2);
                    }
                    v5 = new Object[3];
                    v5[0] = p13;
                    v5[1] = p14;
                    v5[2] = v0;
                    v2.setData(android.net.Uri.parse(String.format("mqqwpa://im/chat?chat_type=%1$s&uin=%2$s&version=1&src_type=app&attach_content=%3$s", v5)));
                    v0 = com.tencent.open.utils.Global.getContext().getPackageManager();
                    if (v0.queryIntentActivities(v2, 9.183549615799121e-41).size() <= 0) {
                        v2.setData(android.net.Uri.parse("http://www.myapp.com/forward/a/45592?g_f=990935"));
                        if (v0.queryIntentActivities(v2, 9.183549615799121e-41).size() <= 0) {
                            com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.STARTWPA.XX", v4, "18", "1");
                            v7 = -2;
                        } else {
                            new com.tencent.open.TDialog(p12, "", this.getCommonDownloadQQUrl(""), 0, this.mToken).show();
                            v7 = 0;
                        }
                    } else {
                        p12.startActivity(v2);
                        v7 = 0;
                    }
                    com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.STARTWPA.XX", v4, "18", "0");
                } else {
                    com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.STARTWPA.XX", v4, "18", "1");
                    v7 = -3;
                }
            } else {
                com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.STARTWPA.XX", v4, "18", "1");
                v7 = -1;
            }
        } else {
            v7 = -5;
        }
        return v7;
    }
}
