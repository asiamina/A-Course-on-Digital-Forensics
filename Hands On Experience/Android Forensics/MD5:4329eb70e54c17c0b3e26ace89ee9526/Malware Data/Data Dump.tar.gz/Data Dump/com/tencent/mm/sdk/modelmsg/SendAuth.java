package com.tencent.mm.sdk.modelmsg;
final public class SendAuth {
    private SendAuth()
    {
        return;
    }
}
