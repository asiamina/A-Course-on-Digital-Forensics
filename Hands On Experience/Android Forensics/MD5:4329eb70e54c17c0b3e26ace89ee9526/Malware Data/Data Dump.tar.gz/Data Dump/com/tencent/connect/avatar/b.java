package com.tencent.connect.avatar;
public class b extends android.view.View {
    private android.graphics.Rect a;
    private android.graphics.Paint b;
    private void b()
    {
        this.b = new android.graphics.Paint();
        return;
    }
    protected void onDraw(android.graphics.Canvas p12)
    {
        super.onDraw(p12);
        v6 = this.a();
        v7 = this.getMeasuredWidth();
        v8 = this.getMeasuredHeight();
        this.b.setStyle(android.graphics.Paint$Style.FILL);
        this.b.setColor(android.graphics.Color.argb(100, 0, 0, 0));
        p12.drawRect(0, 0, ((float) v7), ((float) v6.top), this.b);
        p12.drawRect(0, ((float) v6.bottom), ((float) v7), ((float) v8), this.b);
        p12.drawRect(0, ((float) v6.top), ((float) v6.left), ((float) v6.bottom), this.b);
        p12.drawRect(((float) v6.right), ((float) v6.top), ((float) v7), ((float) v6.bottom), this.b);
        p12.drawColor(android.graphics.Color.argb(100, 0, 0, 0));
        this.b.setStyle(android.graphics.Paint$Style.STROKE);
        this.b.setColor(-1);
        p12.drawRect(((float) v6.left), ((float) v6.top), ((float) (v6.right - 1)), ((float) v6.bottom), this.b);
        return;
    }
    public b(android.content.Context p1)
    {
        this(p1);
        this.b();
        return;
    }
    public android.graphics.Rect a()
    {
        if (this.a == 0) {
            this.a = new android.graphics.Rect();
            v0 = this.getMeasuredWidth();
            v1 = this.getMeasuredHeight();
            v2 = Math.min(Math.min(((v1 - 60) - 80), v0), 640);
            v0 = ((v0 - v2) / 2);
            v1 = ((v1 - v2) / 2);
            this.a.set(v0, v1, (v0 + v2), (v2 + v1));
        }
        return this.a;
    }
}
