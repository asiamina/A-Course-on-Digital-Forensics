package com.tencent.wxop.stat.common;
public class p {
    private static android.content.SharedPreferences a;
    static p()
    {
        com.tencent.wxop.stat.common.p.a = 0;
        return;
    }
    public static int a(android.content.Context p2, String p3, int p4)
    {
        return com.tencent.wxop.stat.common.p.a(p2).getInt(com.tencent.wxop.stat.common.k.a(p2, new StringBuilder("wxop_").append(p3).toString()), p4);
    }
    public static long a(android.content.Context p2, String p3, long p4)
    {
        return com.tencent.wxop.stat.common.p.a(p2).getLong(com.tencent.wxop.stat.common.k.a(p2, new StringBuilder("wxop_").append(p3).toString()), p4, v5);
    }
    static synchronized android.content.SharedPreferences a(android.content.Context p3)
    {
        v0 = p3.getSharedPreferences(".mta-wxop", 0);
        com.tencent.wxop.stat.common.p.a = v0;
        if (v0 == 0) {
            com.tencent.wxop.stat.common.p.a = android.preference.PreferenceManager.getDefaultSharedPreferences(p3);
        }
        return com.tencent.wxop.stat.common.p.a;
    }
    public static String a(android.content.Context p2, String p3, String p4)
    {
        return com.tencent.wxop.stat.common.p.a(p2).getString(com.tencent.wxop.stat.common.k.a(p2, new StringBuilder("wxop_").append(p3).toString()), p4);
    }
    public static void b(android.content.Context p2, String p3, int p4)
    {
        v0 = com.tencent.wxop.stat.common.k.a(p2, new StringBuilder("wxop_").append(p3).toString());
        v1 = com.tencent.wxop.stat.common.p.a(p2).edit();
        v1.putInt(v0, p4);
        v1.commit();
        return;
    }
    public static void b(android.content.Context p2, String p3, long p4)
    {
        v0 = com.tencent.wxop.stat.common.k.a(p2, new StringBuilder("wxop_").append(p3).toString());
        v1 = com.tencent.wxop.stat.common.p.a(p2).edit();
        v1.putLong(v0, p4, v5);
        v1.commit();
        return;
    }
    public static void b(android.content.Context p2, String p3, String p4)
    {
        v0 = com.tencent.wxop.stat.common.k.a(p2, new StringBuilder("wxop_").append(p3).toString());
        v1 = com.tencent.wxop.stat.common.p.a(p2).edit();
        v1.putString(v0, p4);
        v1.commit();
        return;
    }
}
