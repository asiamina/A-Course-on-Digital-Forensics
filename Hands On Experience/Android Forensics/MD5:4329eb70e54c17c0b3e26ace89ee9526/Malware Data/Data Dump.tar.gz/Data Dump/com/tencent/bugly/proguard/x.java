package com.tencent.bugly.proguard;
final public class x {
    public static String a;
    private static String c;
    public static boolean b;
    static x()
    {
        com.tencent.bugly.proguard.x.c = "CrashReportInfo";
        com.tencent.bugly.proguard.x.a = "CrashReport";
        com.tencent.bugly.proguard.x.b = 0;
        return;
    }
    private static varargs boolean a(int p3, String p4, Object[] p5)
    {
        v0 = 0;
        if (com.tencent.bugly.proguard.x.b) {
            if (p4 != 0) {
                if ((p5 != 0) && (p5.length != 0)) {
                    p4 = String.format(java.util.Locale.US, p4, p5);
                }
            } else {
                p4 = "null";
            }
            switch (p3) {
                case 0:
                    android.util.Log.i(com.tencent.bugly.proguard.x.a, p4);
                    v0 = 1;
                    break;
                case 1:
                    android.util.Log.d(com.tencent.bugly.proguard.x.a, p4);
                    v0 = 1;
                    break;
                case 2:
                    android.util.Log.w(com.tencent.bugly.proguard.x.a, p4);
                    v0 = 1;
                    break;
                case 3:
                    android.util.Log.e(com.tencent.bugly.proguard.x.a, p4);
                    v0 = 1;
                case 4:
                default:
                    break;
                case 5:
                    android.util.Log.i(com.tencent.bugly.proguard.x.c, p4);
                    v0 = 1;
                    break;
            }
        }
        return v0;
    }
    public static varargs boolean a(Class p5, String p6, Object[] p7)
    {
        v2 = new Object[2];
        v2[0] = p5.getSimpleName();
        v2[1] = p6;
        return com.tencent.bugly.proguard.x.a(0, String.format(java.util.Locale.US, "[%s] %s", v2), p7);
    }
    public static varargs boolean a(String p1, Object[] p2)
    {
        return com.tencent.bugly.proguard.x.a(0, p1, p2);
    }
    public static boolean a(Throwable p3)
    {
        v0 = 0;
        if (com.tencent.bugly.proguard.x.b) {
            v0 = new Object[0];
            v0 = com.tencent.bugly.proguard.x.a(2, com.tencent.bugly.proguard.z.a(p3), v0);
        }
        return v0;
    }
    public static varargs boolean b(Class p6, String p7, Object[] p8)
    {
        v2 = new Object[2];
        v2[0] = p6.getSimpleName();
        v2[1] = p7;
        return com.tencent.bugly.proguard.x.a(1, String.format(java.util.Locale.US, "[%s] %s", v2), p8);
    }
    public static varargs boolean b(String p1, Object[] p2)
    {
        return com.tencent.bugly.proguard.x.a(5, p1, p2);
    }
    public static boolean b(Throwable p3)
    {
        v0 = 0;
        if (com.tencent.bugly.proguard.x.b) {
            v0 = new Object[0];
            v0 = com.tencent.bugly.proguard.x.a(3, com.tencent.bugly.proguard.z.a(p3), v0);
        }
        return v0;
    }
    public static varargs boolean c(String p1, Object[] p2)
    {
        return com.tencent.bugly.proguard.x.a(1, p1, p2);
    }
    public static varargs boolean d(String p1, Object[] p2)
    {
        return com.tencent.bugly.proguard.x.a(2, p1, p2);
    }
    public static varargs boolean e(String p1, Object[] p2)
    {
        return com.tencent.bugly.proguard.x.a(3, p1, p2);
    }
}
