package com.tencent.wxop.stat;
 class bb implements java.lang.Runnable {
    final synthetic int a;
    final synthetic com.tencent.wxop.stat.au b;
     bb(com.tencent.wxop.stat.au p1, int p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }
    public void run()
    {
        com.tencent.wxop.stat.au.a(this.b, this.a, 1);
        com.tencent.wxop.stat.au.a(this.b, this.a, 0);
        return;
    }
}
