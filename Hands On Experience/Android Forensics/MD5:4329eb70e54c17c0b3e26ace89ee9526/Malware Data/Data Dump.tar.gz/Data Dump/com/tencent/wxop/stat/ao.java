package com.tencent.wxop.stat;
 class ao implements java.lang.Thread$UncaughtExceptionHandler {
     ao()
    {
        return;
    }
    public void uncaughtException(Thread p10, Throwable p11)
    {
        if ((com.tencent.wxop.stat.StatConfig.isEnableStatService() != 0) && (com.tencent.wxop.stat.StatServiceImpl.e() != 0)) {
            if (com.tencent.wxop.stat.StatConfig.isAutoExceptionCaught() != 0) {
                com.tencent.wxop.stat.au.a(com.tencent.wxop.stat.StatServiceImpl.e()).a(new com.tencent.wxop.stat.a.d(com.tencent.wxop.stat.StatServiceImpl.e(), com.tencent.wxop.stat.StatServiceImpl.a(com.tencent.wxop.stat.StatServiceImpl.e(), 0, 0), 2, p11, p10, 0), 0, 0, 1);
                com.tencent.wxop.stat.StatServiceImpl.f().debug("MTA has caught the following uncaught exception:");
                com.tencent.wxop.stat.StatServiceImpl.f().error(p11);
            }
            com.tencent.wxop.stat.StatServiceImpl.flushDataToDB(com.tencent.wxop.stat.StatServiceImpl.e());
            if (com.tencent.wxop.stat.StatServiceImpl.g() != 0) {
                com.tencent.wxop.stat.StatServiceImpl.f().d("Call the original uncaught exception handler.");
                if ((com.tencent.wxop.stat.StatServiceImpl.g() instanceof com.tencent.wxop.stat.ao) == 0) {
                    com.tencent.wxop.stat.StatServiceImpl.g().uncaughtException(p10, p11);
                }
            }
        }
        return;
    }
}
