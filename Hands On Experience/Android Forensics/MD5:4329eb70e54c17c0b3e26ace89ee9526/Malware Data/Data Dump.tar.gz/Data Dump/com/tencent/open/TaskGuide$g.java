package com.tencent.open;
 class TaskGuide$g {
     int a;
     String c;
     String b;
     int e;
     long d;
    public TaskGuide$g(int p1, String p2, String p3, long p4, int p6)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        this.e = p6;
        return;
    }
}
