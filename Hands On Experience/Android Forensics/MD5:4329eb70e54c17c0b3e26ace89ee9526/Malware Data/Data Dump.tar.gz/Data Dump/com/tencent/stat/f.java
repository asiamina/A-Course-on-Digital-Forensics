package com.tencent.stat;
 class f implements java.lang.Runnable {
    final synthetic java.util.List a;
    final synthetic com.tencent.stat.d c;
    final synthetic com.tencent.stat.c b;
     f(com.tencent.stat.d p1, java.util.List p2, com.tencent.stat.c p3)
    {
        this.c = p1;
        this.a = p2;
        this.b = p3;
        return;
    }
    public void run()
    {
        this.c.a(this.a, this.b);
        return;
    }
}
