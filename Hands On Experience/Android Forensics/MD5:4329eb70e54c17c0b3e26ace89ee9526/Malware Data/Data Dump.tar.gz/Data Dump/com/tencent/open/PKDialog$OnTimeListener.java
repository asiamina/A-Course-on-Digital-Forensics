package com.tencent.open;
 class PKDialog$OnTimeListener implements com.tencent.tauth.IUiListener {
    private String mAction;
    private ref.WeakReference mWeakCtx;
     String mAppid;
     String mUrl;
    private com.tencent.tauth.IUiListener mWeakL;
    private void onComplete(String p4)
    {
        this.onComplete(com.tencent.open.utils.Util.parseJson(p4));
        return;
    }
    public void onError(com.tencent.tauth.UiError p12)
    {
        if (p12.errorMessage == 0) {
            v9 = this.mUrl;
        } else {
            v9 = new StringBuilder().append(p12.errorMessage).append(this.mUrl).toString();
        }
        com.tencent.open.b.g.a().a(new StringBuilder().append(this.mAction).append("_H5").toString(), android.os.SystemClock.elapsedRealtime(), v3, 0.0, v5, 0.0, v7, p12.errorCode, v9, 0);
        if (this.mWeakL != 0) {
            this.mWeakL.onError(p12);
            this.mWeakL = 0;
        }
        return;
    }
    public PKDialog$OnTimeListener(android.content.Context p2, String p3, String p4, String p5, com.tencent.tauth.IUiListener p6)
    {
        this.mWeakCtx = new ref.WeakReference(p2);
        this.mAction = p3;
        this.mUrl = p4;
        this.mAppid = p5;
        this.mWeakL = p6;
        return;
    }
    static synthetic void access$600(com.tencent.open.PKDialog$OnTimeListener p0, String p1)
    {
        p0.onComplete(p1);
        return;
    }
    public void onCancel()
    {
        if (this.mWeakL != 0) {
            this.mWeakL.onCancel();
            this.mWeakL = 0;
        }
        return;
    }
    public void onComplete(Object p12)
    {
        com.tencent.open.b.g.a().a(new StringBuilder().append(this.mAction).append("_H5").toString(), android.os.SystemClock.elapsedRealtime(), v3, 0.0, v5, 0.0, -6, p12.optInt("ret", -6), this.mUrl, 0);
        if (this.mWeakL != 0) {
            this.mWeakL.onComplete(p12);
            this.mWeakL = 0;
        }
        return;
    }
}
