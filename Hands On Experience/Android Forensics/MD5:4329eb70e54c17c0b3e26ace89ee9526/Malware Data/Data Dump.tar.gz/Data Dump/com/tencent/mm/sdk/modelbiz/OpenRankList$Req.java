package com.tencent.mm.sdk.modelbiz;
public class OpenRankList$Req extends com.tencent.mm.sdk.modelbase.BaseReq {
    public int getType()
    {
        return 11;
    }
    public OpenRankList$Req()
    {
        return;
    }
    public boolean checkArgs()
    {
        return 1;
    }
}
