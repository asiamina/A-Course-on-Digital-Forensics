package com.tencent.tauth;
public interface abstract class IUiListener {
    abstract public void onComplete();
    abstract public void onError();
    abstract public void onCancel();
}
