package com.tencent.open.utils;
public interface abstract class AsynLoadImgBack {
    final public static int LOAD_IMAGE_COMPLETED;
    final public static int LOAD_IMAGE_IMAGE_FORMAT_ERROR;
    final public static int LOAD_IMAGE_NO_SDCARD;
    final public static int LOAD_IMAGE_PATH_NULL;
    abstract public void batchSaved();
    abstract public void saved();
}
