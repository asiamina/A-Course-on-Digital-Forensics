package com.tencent.open.a;
final public class d$b {
    public static boolean a()
    {
        v0 = android.os.Environment.getExternalStorageState();
        if (("mounted".equals(v0) == 0) && ("mounted_ro".equals(v0) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static com.tencent.open.a.d$c b()
    {
        if (com.tencent.open.a.d$b.a() != 0) {
            v0 = com.tencent.open.a.d$c.b(android.os.Environment.getExternalStorageDirectory());
        } else {
            v0 = 0;
        }
        return v0;
    }
}
