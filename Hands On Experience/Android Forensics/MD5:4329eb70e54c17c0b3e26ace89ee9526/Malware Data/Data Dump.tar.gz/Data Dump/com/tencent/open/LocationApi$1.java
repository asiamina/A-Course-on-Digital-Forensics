package com.tencent.open;
 class LocationApi$1 extends android.os.Handler {
    final synthetic com.tencent.open.LocationApi a;
     LocationApi$1(com.tencent.open.LocationApi p1, android.os.Looper p2)
    {
        this.a = p1;
        this(p2);
        return;
    }
    public void handleMessage(android.os.Message p5)
    {
        switch (p5.what) {
            case 101:
                com.tencent.open.a.f.b("openSDK_LOG.LocationApi", "location: get location timeout.");
                com.tencent.open.LocationApi.a(this.a, -13, "\u5b9a\u4f4d\u8d85\u65f6\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\u6216\u68c0\u67e5\u7f51\u7edc\u72b6\u51b5\uff01");
            case 102:
            default:
                break;
            case 103:
                com.tencent.open.a.f.b("openSDK_LOG.LocationApi", "location: verify sosocode success.");
                com.tencent.open.LocationApi.a(this.a).a(com.tencent.open.utils.Global.getContext(), this.a);
                com.tencent.open.LocationApi.b(this.a).sendEmptyMessageDelayed(101, 10000.0);
                break;
            case 104:
                com.tencent.open.a.f.b("openSDK_LOG.LocationApi", "location: verify sosocode failed.");
                com.tencent.open.LocationApi.a(this.a, -14, "\u5b9a\u4f4d\u5931\u8d25\uff0c\u9a8c\u8bc1\u5b9a\u4f4d\u7801\u9519\u8bef\uff01");
                break;
        }
        super.handleMessage(p5);
        return;
    }
}
