package com.tencent.bugly.proguard;
final public class q extends android.database.sqlite.SQLiteOpenHelper {
    public static String a;
    private android.content.Context c;
    private static int b;
    private java.util.List d;
    static q()
    {
        com.tencent.bugly.proguard.q.a = "bugly_db";
        com.tencent.bugly.proguard.q.b = 13;
        return;
    }
    public q(android.content.Context p4, java.util.List p5)
    {
        v0 = new StringBuilder().append(com.tencent.bugly.proguard.q.a).append("_");
        com.tencent.bugly.crashreport.common.info.a.a(p4).getClass();
        this(p4, v0.toString(), 0, com.tencent.bugly.proguard.q.b);
        this.c = p4;
        this.d = p5;
        return;
    }
    private synchronized boolean a(android.database.sqlite.SQLiteDatabase p9)
    {
        v3 = new String[3];
        v3[0] = "t_lr";
        v3[1] = "t_ui";
        v3[2] = "t_pf";
        v4 = v3.length;
        v2 = 0;
        while (v2 < v4) {
            v6 = new String[0];
            p9.execSQL(new StringBuilder("DROP TABLE IF EXISTS ").append(v3[v2]).toString(), v6);
            v2++;
        }
        return 1;
    }
    public final synchronized android.database.sqlite.SQLiteDatabase getReadableDatabase()
    {
        v0 = 0;
        v1 = 0;
        while ((v1 == 0) && (v0 < 5)) {
            v0++;
            v1 = super.getReadableDatabase();
        }
        return v1;
    }
    public final synchronized android.database.sqlite.SQLiteDatabase getWritableDatabase()
    {
        v0 = 0;
        v1 = 0;
        while ((v1 == 0) && (v0 < 5)) {
            v0++;
            v1 = super.getWritableDatabase();
        }
        if (v1 == 0) {
            v2 = new Object[0];
            com.tencent.bugly.proguard.x.d("[Database] db error delay error record 1min.", v2);
        }
        return v1;
    }
    public final synchronized void onCreate(android.database.sqlite.SQLiteDatabase p4)
    {
        v0 = new StringBuilder();
        v0.setLength(0);
        v0.append(" CREATE TABLE IF NOT EXISTS t_ui").append(" ( _id").append(" INTEGER PRIMARY KEY").append(" , _tm").append(" int").append(" , _ut").append(" int").append(" , _tp").append(" int").append(" , _dt").append(" blob").append(" , _pc").append(" text").append(" ) ");
        v2 = new Object[0];
        com.tencent.bugly.proguard.x.c(v0.toString(), v2);
        v2 = new String[0];
        p4.execSQL(v0.toString(), v2);
        v0.setLength(0);
        v0.append(" CREATE TABLE IF NOT EXISTS t_lr").append(" ( _id").append(" INTEGER PRIMARY KEY").append(" , _tp").append(" int").append(" , _tm").append(" int").append(" , _pc").append(" text").append(" , _th").append(" text").append(" , _dt").append(" blob").append(" ) ");
        v2 = new Object[0];
        com.tencent.bugly.proguard.x.c(v0.toString(), v2);
        v2 = new String[0];
        p4.execSQL(v0.toString(), v2);
        v0.setLength(0);
        v0.append(" CREATE TABLE IF NOT EXISTS t_pf").append(" ( _id").append(" integer").append(" , _tp").append(" text").append(" , _tm").append(" int").append(" , _dt").append(" blob").append(",primary key(_id").append(",_tp").append(" )) ");
        v2 = new Object[0];
        com.tencent.bugly.proguard.x.c(v0.toString(), v2);
        v2 = new String[0];
        p4.execSQL(v0.toString(), v2);
        v0.setLength(0);
        v0.append(" CREATE TABLE IF NOT EXISTS t_cr").append(" ( _id").append(" INTEGER PRIMARY KEY").append(" , _tm").append(" int").append(" , _s1").append(" text").append(" , _up").append(" int").append(" , _me").append(" int").append(" , _uc").append(" int").append(" , _dt").append(" blob").append(" ) ");
        v2 = new Object[0];
        com.tencent.bugly.proguard.x.c(v0.toString(), v2);
        v2 = new String[0];
        p4.execSQL(v0.toString(), v2);
        v0.setLength(0);
        v0.append(" CREATE TABLE IF NOT EXISTS dl_1002").append(" (_id").append(" integer primary key autoincrement, _dUrl").append(" varchar(100), _sFile").append(" varchar(100), _sLen").append(" INTEGER, _tLen").append(" INTEGER, _MD5").append(" varchar(100), _DLTIME").append(" INTEGER)");
        v2 = new Object[0];
        com.tencent.bugly.proguard.x.c(v0.toString(), v2);
        v2 = new String[0];
        p4.execSQL(v0.toString(), v2);
        v0.setLength(0);
        v0.append("CREATE TABLE IF NOT EXISTS ge_1002").append(" (_id").append(" integer primary key autoincrement, _time").append(" INTEGER, _datas").append(" blob)");
        v2 = new Object[0];
        com.tencent.bugly.proguard.x.c(v0.toString(), v2);
        v2 = new String[0];
        p4.execSQL(v0.toString(), v2);
        v0.setLength(0);
        v0.append(" CREATE TABLE IF NOT EXISTS st_1002").append(" ( _id").append(" integer").append(" , _tp").append(" text").append(" , _tm").append(" int").append(" , _dt").append(" blob").append(",primary key(_id").append(",_tp").append(" )) ");
        v2 = new Object[0];
        com.tencent.bugly.proguard.x.c(v0.toString(), v2);
        v1 = new String[0];
        p4.execSQL(v0.toString(), v1);
        if (this.d != 0) {
            v1 = this.d.iterator();
            while (v1.hasNext() != 0) {
                v1.next().onDbCreate(p4);
            }
        }
        return;
    }
    public final synchronized void onDowngrade(android.database.sqlite.SQLiteDatabase p5, int p6, int p7)
    {
        if (com.tencent.bugly.crashreport.common.info.b.c() >= 11) {
            v1 = new Object[2];
            v1[0] = Integer.valueOf(p6);
            v1[1] = Integer.valueOf(p7);
            com.tencent.bugly.proguard.x.d("[Database] Downgrade %d to %d drop tables.", v1);
            if (this.d != 0) {
                v1 = this.d.iterator();
                while (v1.hasNext() != 0) {
                    v1.next().onDbDowngrade(p5, p6, p7);
                }
            }
            this.a(p5);
            if (this == 0) {
                v1 = new Object[0];
                com.tencent.bugly.proguard.x.d("[Database] Failed to drop, delete db.", v1);
                v0 = this.c.getDatabasePath(com.tencent.bugly.proguard.q.a);
                if ((v0 != 0) && (v0.canWrite() != 0)) {
                    v0.delete();
                }
            } else {
                this.onCreate(p5);
            }
        }
        return;
    }
    public final synchronized void onUpgrade(android.database.sqlite.SQLiteDatabase p5, int p6, int p7)
    {
        v1 = new Object[2];
        v1[0] = Integer.valueOf(p6);
        v1[1] = Integer.valueOf(p7);
        com.tencent.bugly.proguard.x.d("[Database] Upgrade %d to %d , drop tables!", v1);
        if (this.d != 0) {
            v1 = this.d.iterator();
            while (v1.hasNext() != 0) {
                v1.next().onDbUpgrade(p5, p6, p7);
            }
        }
        this.a(p5);
        if (this == 0) {
            v1 = new Object[0];
            com.tencent.bugly.proguard.x.d("[Database] Failed to drop, delete db.", v1);
            v0 = this.c.getDatabasePath(com.tencent.bugly.proguard.q.a);
            if ((v0 != 0) && (v0.canWrite() != 0)) {
                v0.delete();
            }
        } else {
            this.onCreate(p5);
        }
        return;
    }
}
