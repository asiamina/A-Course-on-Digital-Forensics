package com.tencent.bugly.crashreport.biz;
final class a$a implements java.lang.Runnable {
    private boolean a;
    private synthetic com.tencent.bugly.crashreport.biz.a c;
    private com.tencent.bugly.crashreport.biz.UserInfoBean b;
    public a$a(com.tencent.bugly.crashreport.biz.a p1, com.tencent.bugly.crashreport.biz.UserInfoBean p2, boolean p3)
    {
        this.c = p1;
        this.b = p2;
        this.a = p3;
        return;
    }
    public final void run()
    {
        if (this.b != 0) {
            v0 = this.b;
            if (v0 != 0) {
                v1 = com.tencent.bugly.crashreport.common.info.a.b();
                if (v1 != 0) {
                    v0.j = v1.e();
                }
            }
            v1 = new Object[0];
            com.tencent.bugly.proguard.x.c("[UserInfo] Record user info.", v1);
            com.tencent.bugly.crashreport.biz.a.a(this.c, this.b, 0);
        }
        if (this.a) {
            v1 = com.tencent.bugly.proguard.w.a();
            if (v1 != 0) {
                v1.a(new com.tencent.bugly.crashreport.biz.a$2(this.c));
            }
        }
        return;
    }
}
