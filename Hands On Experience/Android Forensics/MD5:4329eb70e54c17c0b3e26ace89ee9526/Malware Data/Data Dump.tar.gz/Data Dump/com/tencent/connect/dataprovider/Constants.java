package com.tencent.connect.dataprovider;
final public class Constants {
    final public static String DATA_TYPE;
    final public static String SRC_ACTIVITY_ACTION;
    final public static String REQUEST_TYPE;
    final public static String SRC_PACKAGE_NAME;
    final public static String SRC_ACTIVITY_CLASS_NAME;
    final public static String CONTENT_DATA;
    final public static String APPID;
    public Constants()
    {
        return;
    }
}
