package com.tencent.map.b;
final class f$2 extends android.content.BroadcastReceiver {
    private synthetic com.tencent.map.b.f a;
     f$2(com.tencent.map.b.f p1)
    {
        this.a = p1;
        return;
    }
    public final void onReceive(android.content.Context p3, android.content.Intent p4)
    {
        if ((p4.getBooleanExtra("noConnectivity", 0) == 0) && (com.tencent.map.b.f.d(this.a) != 0)) {
            com.tencent.map.b.f.d(this.a).sendEmptyMessage(256);
        }
        return;
    }
}
