package com.tencent.open;
synthetic class TaskGuide$4 {
    final synthetic static int[] a;
    static TaskGuide$4()
    {
        v0 = new int[com.tencent.open.TaskGuide$k.a().length];
        com.tencent.open.TaskGuide$4.a = v0;
        com.tencent.open.TaskGuide$4.a[com.tencent.open.TaskGuide$k.a.ordinal()] = 1;
        com.tencent.open.TaskGuide$4.a[com.tencent.open.TaskGuide$k.d.ordinal()] = 2;
        com.tencent.open.TaskGuide$4.a[com.tencent.open.TaskGuide$k.c.ordinal()] = 3;
        com.tencent.open.TaskGuide$4.a[com.tencent.open.TaskGuide$k.e.ordinal()] = 4;
        return;
    }
}
