package com.tencent.mm.sdk.diffdev;
public interface abstract class IDiffDevOAuth {
    abstract public void addListener();
    abstract public boolean auth();
    abstract public void detach();
    abstract public void removeAllListeners();
    abstract public void removeListener();
    abstract public boolean stopAuth();
}
