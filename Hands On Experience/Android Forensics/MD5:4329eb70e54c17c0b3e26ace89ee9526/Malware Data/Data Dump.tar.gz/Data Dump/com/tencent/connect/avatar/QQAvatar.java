package com.tencent.connect.avatar;
public class QQAvatar extends com.tencent.connect.common.BaseApi {
    private com.tencent.tauth.IUiListener a;
    private void a(android.app.Activity p4, android.os.Bundle p5, android.content.Intent p6)
    {
        this.a(p5);
        p6.putExtra("key_action", "action_avatar");
        p6.putExtra("key_params", p5);
        com.tencent.connect.common.UIListenerManager.getInstance().setListenerWithRequestcode(11102, this.a);
        this.startAssitActivity(p4, p6, 11102);
        return;
    }
    private void a(android.os.Bundle p4)
    {
        if (this.mToken != 0) {
            p4.putString("appid", this.mToken.getAppId());
            if (this.mToken.isSessionValid() != 0) {
                p4.putString("keystr", this.mToken.getAccessToken());
                p4.putString("keytype", "0x80");
            }
            v0 = this.mToken.getOpenId();
            if (v0 != 0) {
                p4.putString("hopenid", v0);
            }
            p4.putString("platform", "androidqz");
            p4.putString("pf", com.tencent.open.utils.Global.getContext().getSharedPreferences("pfStore", 0).getString("pf", "openmobile_android"));
        }
        p4.putString("sdkv", "3.1.3");
        p4.putString("sdkp", "a");
        return;
    }
    public void setAvatar(android.app.Activity p8, android.net.Uri p9, com.tencent.tauth.IUiListener p10, int p11)
    {
        if (this.a != 0) {
            this.a.onCancel();
        }
        this.a = p10;
        v0 = new android.os.Bundle();
        v0.putString("picture", p9.toString());
        v0.putInt("exitAnim", p11);
        v0.putString("appid", this.mToken.getAppId());
        v0.putString("access_token", this.mToken.getAccessToken());
        v0.putLong("expires_in", this.mToken.getExpireTimeInSecond());
        v0.putString("openid", this.mToken.getOpenId());
        this.a(p8);
        if (this.hasActivityForIntent(this) == 0) {
            com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.SETAVATAR.XX", "12", "18", "1");
        } else {
            this.a(p8, v0, this);
            com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDSDK.SETAVATAR.XX", "12", "18", "0");
        }
        return;
    }
    public QQAvatar(com.tencent.connect.auth.QQToken p1)
    {
        this(p1);
        return;
    }
    private android.content.Intent a(android.app.Activity p3)
    {
        v0 = new android.content.Intent();
        v0.setClass(p3, com.tencent.connect.avatar.ImageActivity);
        return v0;
    }
}
