package com.tencent.bugly.crashreport.crash;
final public class a implements java.lang.Comparable {
    public long a;
    public String c;
    public long b;
    public boolean e;
    public boolean d;
    public int f;
    public a()
    {
        this.a = -1.0;
        this.b = -1.0;
        this.c = 0;
        this.d = 0;
        this.e = 0;
        this.f = 0;
        return;
    }
    public final synthetic bridge int compareTo(Object p7)
    {
        if (p7 == 0) {
            v0 = 1;
        } else {
            v0 = (this.b - p7.b);
            } else {
                if (v0 >= 0.0) {
                    v0 = 0;
                } else {
                    v0 = -1;
                }
            }
        }
        return v0;
    }
}
