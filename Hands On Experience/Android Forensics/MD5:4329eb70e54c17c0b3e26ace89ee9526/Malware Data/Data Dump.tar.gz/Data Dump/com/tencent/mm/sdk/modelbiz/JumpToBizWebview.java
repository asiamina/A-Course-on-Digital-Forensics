package com.tencent.mm.sdk.modelbiz;
final public class JumpToBizWebview {
    public JumpToBizWebview()
    {
        return;
    }
}
