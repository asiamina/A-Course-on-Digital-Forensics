package com.tencent.mm.sdk.modelbiz;
public class OpenBusiLuckyMoney$Req extends com.tencent.mm.sdk.modelbase.BaseReq {
    final private static int MAX_URL_LENGHT;
    public String appId;
    public String timeStamp;
    public String signType;
    public String signature;
    public String nonceStr;
    public String packageExt;
    public OpenBusiLuckyMoney$Req()
    {
        return;
    }
    public boolean checkArgs()
    {
        v0 = 0;
        if ((this.appId != 0) && ((this.appId.length() > 0) && ((this.timeStamp != 0) && ((this.timeStamp.length() > 0) && ((this.nonceStr != 0) && ((this.nonceStr.length() > 0) && ((this.signType != 0) && ((this.signType.length() > 0) && ((this.signature != 0) && (this.signature.length() > 0)))))))))) {
            v0 = 1;
        }
        return v0;
    }
    public int getType()
    {
        return 13;
    }
    public void toBundle(android.os.Bundle p3)
    {
        super.toBundle(p3);
        p3.putString("_wxapi_open_busi_lucky_money_appid", this.appId);
        p3.putString("_wxapi_open_busi_lucky_money_timeStamp", this.timeStamp);
        p3.putString("_wxapi_open_busi_lucky_money_nonceStr", this.nonceStr);
        p3.putString("_wxapi_open_busi_lucky_money_signType", this.signType);
        p3.putString("_wxapi_open_busi_lucky_money_signature", this.signature);
        p3.putString("_wxapi_open_busi_lucky_money_package", this.packageExt);
        return;
    }
}
