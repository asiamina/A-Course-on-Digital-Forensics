package com.tencent.stat;
public class EasyListActivity extends android.app.ListActivity {
    public EasyListActivity()
    {
        return;
    }
    protected void onPause()
    {
        super.onPause();
        com.tencent.stat.StatService.onPause(this);
        return;
    }
    protected void onResume()
    {
        super.onResume();
        com.tencent.stat.StatService.onResume(this);
        return;
    }
}
