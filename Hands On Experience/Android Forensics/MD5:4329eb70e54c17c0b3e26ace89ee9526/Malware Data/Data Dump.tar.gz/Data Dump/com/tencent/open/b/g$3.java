package com.tencent.open.b;
 class g$3 implements java.lang.Runnable {
    final synthetic long a;
    final synthetic String c;
    final synthetic String b;
    final synthetic long e;
    final synthetic int d;
    final synthetic boolean g;
    final synthetic long f;
    final synthetic com.tencent.open.b.g h;
     g$3(com.tencent.open.b.g p1, long p2, String p4, String p5, int p6, long p7, long p9, boolean p11)
    {
        this.h = p1;
        this.a = p2;
        this.b = p4;
        this.c = p5;
        this.d = p6;
        this.e = p7;
        this.f = p9;
        this.g = p11;
        return;
    }
    public void run()
    {
        v0 = 1;
        v3 = (android.os.SystemClock.elapsedRealtime() - this.a);
        v5 = new android.os.Bundle();
        v2 = com.tencent.open.b.a.a(com.tencent.open.utils.Global.getContext());
        v5.putString("apn", v2);
        v5.putString("appid", "1000067");
        v5.putString("commandid", this.b);
        v5.putString("detail", this.c);
        v6 = new StringBuilder();
        v6.append("network=").append(v2).append(38);
        v7 = v6.append("sdcard=");
        if (android.os.Environment.getExternalStorageState().equals("mounted") == 0) {
            v2 = 0;
        } else {
            v2 = 1;
        }
        v7.append(v2).append(38);
        v6.append("wifi=").append(com.tencent.open.b.a.e(com.tencent.open.utils.Global.getContext()));
        v5.putString("deviceInfo", v6.toString());
        v2 = (100 / this.h.a(this.d));
        if (v2 > 0) {
            if (v2 <= 100) {
                v0 = v2;
            } else {
                v0 = 100;
            }
        }
        v5.putString("frequency", new StringBuilder().append(v0).append("").toString());
        v5.putString("reqSize", new StringBuilder().append(this.e).append("").toString());
        v5.putString("resultCode", new StringBuilder().append(this.d).append("").toString());
        v5.putString("rspSize", new StringBuilder().append(this.f).append("").toString());
        v5.putString("timeCost", new StringBuilder().append(v3).append("").toString());
        v5.putString("uin", "1000");
        this.h.c.add(new com.tencent.open.b.b(v5));
        v1 = this.h.c.size();
        v0 = com.tencent.open.utils.OpenConfig.getInstance(com.tencent.open.utils.Global.getContext(), 0).getInt("Agent_ReportTimeInterval");
        if (v0 == 0) {
            v0 = 10000;
        }
        if ((this.h.a("report_cgi", v1) == 0) && (!this.g)) {
            if (this.h.f.hasMessages(1000) == 0) {
                v1 = android.os.Message.obtain();
                v1.what = 1000;
                this.h.f.sendMessageDelayed(v1, ((long) v0));
            }
        } else {
            this.h.b();
            this.h.f.removeMessages(1000);
        }
        return;
    }
}
