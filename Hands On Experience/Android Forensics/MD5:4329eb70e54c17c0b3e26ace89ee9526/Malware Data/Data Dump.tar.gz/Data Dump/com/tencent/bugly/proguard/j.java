package com.tencent.bugly.proguard;
final public class j {
    private java.nio.ByteBuffer a;
    private String b;
    public final void a(byte[] p3, int p4)
    {
        this.a((p3.length + 8));
        this.b(13, p4);
        this.b(0, 0);
        this.a(p3.length, 0);
        this.a.put(p3);
        return;
    }
    private void b(byte p4, int p5)
    {
        if (p5 >= 15) {
            if (p5 >= 256) {
                throw new com.tencent.bugly.proguard.b(new StringBuilder("tag is too large: ").append(p5).toString());
            } else {
                this.a.put(((byte) (p4 | 240)));
                this.a.put(((byte) p5));
            }
        } else {
            this.a.put(((byte) ((p5 << 4) | p4)));
        }
        return;
    }
    public final byte[] b()
    {
        v0 = new byte[this.a.position()];
        System.arraycopy(this.a.array(), 0, v0, 0, this.a.position());
        return v0;
    }
    public j()
    {
        this(128);
        return;
    }
    public j(int p2)
    {
        this.b = "GBK";
        this.a = java.nio.ByteBuffer.allocate(p2);
        return;
    }
    public final int a(String p2)
    {
        this.b = p2;
        return 0;
    }
    public final java.nio.ByteBuffer a()
    {
        return this.a;
    }
    public final void a(byte p2, int p3)
    {
        this.a(3);
        if (p2 != 0) {
            this.b(0, p3);
            this.a.put(p2);
        } else {
            this.b(12, p3);
        }
        return;
    }
    private void a(int p5)
    {
        if (this.a.remaining() < p5) {
            v0 = java.nio.ByteBuffer.allocate(((this.a.capacity() + p5) << 1));
            v0.put(this.a.array(), 0, this.a.position());
            this.a = v0;
        }
        return;
    }
    public final void a(int p2, int p3)
    {
        this.a(6);
        if ((p2 < -32768) || (p2 > 32767)) {
            this.b(2, p3);
            this.a.putInt(p2);
        } else {
            this.a(((short) p2), p3);
        }
        return;
    }
    public final void a(long p3, int p5)
    {
        this.a(10);
        if ((p3 < -2147483648.0) || (p3 > 2147483647.0)) {
            this.b(3, p5);
            this.a.putLong(p3);
        } else {
            this.a(((int) p3), p5);
        }
        return;
    }
    public final void a(com.tencent.bugly.proguard.k p3, int p4)
    {
        this.a(2);
        this.b(10, p4);
        p3.a(this);
        this.a(2);
        this.b(11, 0);
        return;
    }
    public final void a(Object p8, int p9)
    {
        v0 = 1;
        if ((p8 instanceof Byte) == 0) {
            if ((p8 instanceof Boolean) == 0) {
                if ((p8 instanceof Short) == 0) {
                    if ((p8 instanceof Integer) == 0) {
                        if ((p8 instanceof Long) == 0) {
                            if ((p8 instanceof Float) == 0) {
                                if ((p8 instanceof Double) == 0) {
                                    if ((p8 instanceof String) == 0) {
                                        if ((p8 instanceof java.util.Map) == 0) {
                                            if ((p8 instanceof java.util.List) == 0) {
                                                if ((p8 instanceof com.tencent.bugly.proguard.k) == 0) {
                                                    if ((p8 instanceof byte[]) == 0) {
                                                        if ((p8 instanceof boolean[]) == 0) {
                                                            if ((p8 instanceof short[]) == 0) {
                                                                if ((p8 instanceof int[]) == 0) {
                                                                    if ((p8 instanceof long[]) == 0) {
                                                                        if ((p8 instanceof float[]) == 0) {
                                                                            if ((p8 instanceof double[]) == 0) {
                                                                                if (p8.getClass().isArray() == 0) {
                                                                                    if ((p8 instanceof java.util.Collection) == 0) {
                                                                                        throw new com.tencent.bugly.proguard.b(new StringBuilder("write object error: unsupport type. ").append(p8.getClass()).toString());
                                                                                    } else {
                                                                                        this.a(p8, p9);
                                                                                    }
                                                                                } else {
                                                                                    this.a(8);
                                                                                    this.b(9, p9);
                                                                                    this.a(p8.length, 0);
                                                                                    v2 = p8.length;
                                                                                    v0 = 0;
                                                                                    while (v0 < v2) {
                                                                                        this.a(p8[v0], 0);
                                                                                        v0++;
                                                                                    }
                                                                                }
                                                                            } else {
                                                                                this.a(8);
                                                                                this.b(9, p9);
                                                                                this.a(p8.length, 0);
                                                                                v2 = p8.length;
                                                                                v0 = 0;
                                                                                while (v0 < v2) {
                                                                                    v3 = p8[v0];
                                                                                    this.a(10);
                                                                                    this.b(5, 0);
                                                                                    this.a.putDouble(v3);
                                                                                    v0++;
                                                                                }
                                                                            }
                                                                        } else {
                                                                            this.a(8);
                                                                            this.b(9, p9);
                                                                            this.a(p8.length, 0);
                                                                            v2 = p8.length;
                                                                            v0 = 0;
                                                                            while (v0 < v2) {
                                                                                v3 = p8[v0];
                                                                                this.a(6);
                                                                                this.b(4, 0);
                                                                                this.a.putFloat(v3);
                                                                                v0++;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        this.a(8);
                                                                        this.b(9, p9);
                                                                        this.a(p8.length, 0);
                                                                        v2 = p8.length;
                                                                        v0 = 0;
                                                                        while (v0 < v2) {
                                                                            this.a(p8[v0], 0);
                                                                            v0++;
                                                                        }
                                                                    }
                                                                } else {
                                                                    this.a(8);
                                                                    this.b(9, p9);
                                                                    this.a(p8.length, 0);
                                                                    v2 = p8.length;
                                                                    v0 = 0;
                                                                    while (v0 < v2) {
                                                                        this.a(p8[v0], 0);
                                                                        v0++;
                                                                    }
                                                                }
                                                            } else {
                                                                this.a(8);
                                                                this.b(9, p9);
                                                                this.a(p8.length, 0);
                                                                v2 = p8.length;
                                                                v0 = 0;
                                                                while (v0 < v2) {
                                                                    this.a(p8[v0], 0);
                                                                    v0++;
                                                                }
                                                            }
                                                        } else {
                                                            this.a(8);
                                                            this.b(9, p9);
                                                            this.a(p8.length, 0);
                                                            v4 = p8.length;
                                                            v3 = 0;
                                                            while (v3 < v4) {
                                                                if (p8[v3] == 0) {
                                                                    v2 = 0;
                                                                } else {
                                                                    v2 = 1;
                                                                }
                                                                this.a(((byte) v2), 0);
                                                                v3++;
                                                            }
                                                        }
                                                    } else {
                                                        this.a(p8, p9);
                                                    }
                                                } else {
                                                    this.a(2);
                                                    this.b(10, p9);
                                                    p8.a(this);
                                                    this.a(2);
                                                    this.b(11, 0);
                                                }
                                            } else {
                                                this.a(p8, p9);
                                            }
                                        } else {
                                            this.a(p8, p9);
                                        }
                                    } else {
                                        this.a(p8, p9);
                                    }
                                } else {
                                    v0 = p8.doubleValue();
                                    this.a(10);
                                    this.b(5, p9);
                                    this.a.putDouble(v0);
                                }
                            } else {
                                v0 = p8.floatValue();
                                this.a(6);
                                this.b(4, p9);
                                this.a.putFloat(v0);
                            }
                        } else {
                            this.a(p8.longValue(), p9);
                        }
                    } else {
                        this.a(p8.intValue(), p9);
                    }
                } else {
                    this.a(p8.shortValue(), p9);
                }
            } else {
                if (p8.booleanValue() == 0) {
                    v0 = 0;
                }
                this.a(((byte) v0), p9);
            }
        } else {
            this.a(p8.byteValue(), p9);
        }
        return;
    }
    public final void a(String p4, int p5)
    {
        v0 = p4.getBytes(this.b);
        this.a((v0.length + 10));
        if (v0.length <= 255) {
            this.b(6, p5);
            this.a.put(((byte) v0.length));
            this.a.put(v0);
        } else {
            this.b(7, p5);
            this.a.putInt(v0.length);
            this.a.put(v0);
        }
        return;
    }
    public final void a(java.util.Collection p4, int p5)
    {
        this.a(8);
        this.b(9, p5);
        if (p4 != 0) {
            v0 = p4.size();
        } else {
            v0 = 0;
        }
        this.a(v0, 0);
        if (p4 != 0) {
            v0 = p4.iterator();
            while (v0.hasNext() != 0) {
                this.a(v0.next(), 0);
            }
        }
        return;
    }
    public final void a(java.util.Map p5, int p6)
    {
        this.a(8);
        this.b(8, p6);
        if (p5 != 0) {
            v0 = p5.size();
        } else {
            v0 = 0;
        }
        this.a(v0, 0);
        if (p5 != 0) {
            v2 = p5.entrySet().iterator();
            while (v2.hasNext() != 0) {
                v0 = v2.next();
                this.a(v0.getKey(), 0);
                this.a(v0.getValue(), 1);
            }
        }
        return;
    }
    public final void a(short p2, int p3)
    {
        this.a(4);
        if ((p2 < -128) || (p2 > 127)) {
            this.b(1, p3);
            this.a.putShort(p2);
        } else {
            this.a(((byte) p2), p3);
        }
        return;
    }
    public final void a(boolean p2, int p3)
    {
        if (p2 == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        this.a(((byte) v0), p3);
        return;
    }
}
