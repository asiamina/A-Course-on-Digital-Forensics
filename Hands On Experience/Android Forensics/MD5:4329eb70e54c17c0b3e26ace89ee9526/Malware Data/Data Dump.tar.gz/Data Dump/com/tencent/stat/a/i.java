package com.tencent.stat.a;
public class i extends com.tencent.stat.a.e {
    private static String a;
    private String m;
    private String l;
    public i(android.content.Context p2, int p3)
    {
        this(p2, p3);
        this.l = 0;
        this.m = 0;
        this.l = com.tencent.stat.common.k.p(p2);
        if (com.tencent.stat.a.i.a == 0) {
            com.tencent.stat.a.i.a = com.tencent.stat.common.k.m(p2);
        }
        return;
    }
    public com.tencent.stat.a.f a()
    {
        return com.tencent.stat.a.f.h;
    }
    public void a(String p1)
    {
        this.m = p1;
        return;
    }
    public boolean a(org.json.JSONObject p3)
    {
        com.tencent.stat.common.k.a(p3, "op", com.tencent.stat.a.i.a);
        com.tencent.stat.common.k.a(p3, "cn", this.l);
        p3.put("sp", this.m);
        return 1;
    }
    static i()
    {
        com.tencent.stat.a.i.a = 0;
        return;
    }
}
