package com.tencent.bugly.crashreport.crash.anr;
final class b$1 extends android.os.FileObserver {
    private synthetic com.tencent.bugly.crashreport.crash.anr.b a;
     b$1(com.tencent.bugly.crashreport.crash.anr.b p2, String p3, int p4)
    {
        this.a = p2;
        this(p3, 8);
        return;
    }
    public final void onEvent(int p5, String p6)
    {
        if (p6 != 0) {
            v0 = new StringBuilder("/data/anr/").append(p6).toString();
            if (v0.contains("trace") != 0) {
                this.a.a(v0);
            } else {
                v2 = new Object[1];
                v2[0] = v0;
                com.tencent.bugly.proguard.x.d("not anr file %s", v2);
            }
        }
        return;
    }
}
