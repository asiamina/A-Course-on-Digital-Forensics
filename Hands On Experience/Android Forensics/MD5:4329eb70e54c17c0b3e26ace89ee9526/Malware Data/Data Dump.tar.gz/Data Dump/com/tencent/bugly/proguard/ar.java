package com.tencent.bugly.proguard;
final public class ar extends com.tencent.bugly.proguard.k implements java.lang.Cloneable {
    public byte a;
    public String c;
    public String b;
    public java.util.Map e;
    public java.util.ArrayList d;
    private static java.util.Map g;
    private static java.util.ArrayList f;
    public ar()
    {
        this.a = 0;
        this.b = "";
        this.c = "";
        this.d = 0;
        this.e = 0;
        return;
    }
    public final void a(com.tencent.bugly.proguard.i p5)
    {
        this.a = p5.a(this.a, 0, 1);
        this.b = p5.b(1, 0);
        this.c = p5.b(2, 0);
        if (com.tencent.bugly.proguard.ar.f == 0) {
            com.tencent.bugly.proguard.ar.f = new java.util.ArrayList();
            com.tencent.bugly.proguard.ar.f.add(new com.tencent.bugly.proguard.aq());
        }
        this.d = p5.a(com.tencent.bugly.proguard.ar.f, 3, 0);
        if (com.tencent.bugly.proguard.ar.g == 0) {
            com.tencent.bugly.proguard.ar.g = new java.util.HashMap();
            com.tencent.bugly.proguard.ar.g.put("", "");
        }
        this.e = p5.a(com.tencent.bugly.proguard.ar.g, 4, 0);
        return;
    }
    public final void a(com.tencent.bugly.proguard.j p3)
    {
        p3.a(this.a, 0);
        if (this.b != 0) {
            p3.a(this.b, 1);
        }
        if (this.c != 0) {
            p3.a(this.c, 2);
        }
        if (this.d != 0) {
            p3.a(this.d, 3);
        }
        if (this.e != 0) {
            p3.a(this.e, 4);
        }
        return;
    }
    public final void a(StringBuilder p1, int p2)
    {
        return;
    }
}
