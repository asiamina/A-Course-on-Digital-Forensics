package com.tencent.map.b;
public interface abstract class d$c {
    abstract public void a();
}
