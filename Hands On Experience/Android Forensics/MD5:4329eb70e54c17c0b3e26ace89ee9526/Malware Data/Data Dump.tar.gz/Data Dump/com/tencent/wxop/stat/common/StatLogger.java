package com.tencent.wxop.stat.common;
final public class StatLogger {
    private String a;
    private int c;
    private boolean b;
    public final boolean isDebugEnable()
    {
        return this.b;
    }
    public final void setDebugEnable(boolean p1)
    {
        this.b = p1;
        return;
    }
    public final void setLogLevel(int p1)
    {
        this.c = p1;
        return;
    }
    public final void setTag(String p1)
    {
        this.a = p1;
        return;
    }
    public final void v(Object p2)
    {
        if (this.isDebugEnable() != 0) {
            this.verbose(p2);
        }
        return;
    }
    public final void verbose(Object p3)
    {
        if (this.c <= 2) {
            this.a();
            if (this != 0) {
                v0 = new StringBuilder().append(this).append(" - ").append(p3).toString();
            } else {
                v0 = p3.toString();
            }
            android.util.Log.v(this.a, v0);
            v1 = com.tencent.wxop.stat.StatConfig.getCustomLogger();
            if (v1 != 0) {
                v1.b(v0);
            }
        }
        return;
    }
    public final void w(Object p2)
    {
        if (this.isDebugEnable() != 0) {
            this.warn(p2);
        }
        return;
    }
    public final void warn(Object p3)
    {
        if (this.c <= 5) {
            this.a();
            if (this != 0) {
                v0 = new StringBuilder().append(this).append(" - ").append(p3).toString();
            } else {
                v0 = p3.toString();
            }
            android.util.Log.w(this.a, v0);
            v1 = com.tencent.wxop.stat.StatConfig.getCustomLogger();
            if (v1 != 0) {
                v1.c(v0);
            }
        }
        return;
    }
    public StatLogger()
    {
        this.a = "default";
        this.b = 1;
        this.c = 2;
        return;
    }
    public StatLogger(String p2)
    {
        this.a = "default";
        this.b = 1;
        this.c = 2;
        this.a = p2;
        return;
    }
    private String a()
    {
        v0 = 0;
        v2 = Thread.currentThread().getStackTrace();
        if (v2 != 0) {
            v1 = 0;
            while (v1 < v2.length) {
                v4 = v2[v1];
                if ((v4.isNativeMethod() != 0) || ((v4.getClassName().equals(Thread.getName()) != 0) || (v4.getClassName().equals(this.getClass().getName()) != 0))) {
                    v1++;
                } else {
                    v0 = new StringBuilder("[").append(Thread.currentThread().getName()).append("(").append(Thread.currentThread().getId()).append("): ").append(v4.getFileName()).append(":").append(v4.getLineNumber()).append("]").toString();
                    break;
                }
            }
        }
        return v0;
    }
    public final void d(Object p2)
    {
        if (this.isDebugEnable() != 0) {
            this.debug(p2);
        }
        return;
    }
    public final void debug(Object p3)
    {
        if (this.c <= 3) {
            this.a();
            if (this != 0) {
                v0 = new StringBuilder().append(this).append(" - ").append(p3).toString();
            } else {
                v0 = p3.toString();
            }
            android.util.Log.d(this.a, v0);
            v1 = com.tencent.wxop.stat.StatConfig.getCustomLogger();
            if (v1 != 0) {
                v1.e(v0);
            }
        }
        return;
    }
    public final void e(Object p2)
    {
        if (this.isDebugEnable() != 0) {
            this.error(p2);
        }
        return;
    }
    public final void e(Throwable p2)
    {
        if (this.isDebugEnable() != 0) {
            this.error(p2);
        }
        return;
    }
    public final void error(Object p3)
    {
        if (this.c <= 6) {
            this.a();
            if (this != 0) {
                v0 = new StringBuilder().append(this).append(" - ").append(p3).toString();
            } else {
                v0 = p3.toString();
            }
            android.util.Log.e(this.a, v0);
            v1 = com.tencent.wxop.stat.StatConfig.getCustomLogger();
            if (v1 != 0) {
                v1.d(v0);
            }
        }
        return;
    }
    public final void error(Throwable p3)
    {
        if (this.c <= 6) {
            android.util.Log.e(this.a, "", p3);
            v0 = com.tencent.wxop.stat.StatConfig.getCustomLogger();
            if (v0 != 0) {
                v0.d(p3);
            }
        }
        return;
    }
    public final int getLogLevel()
    {
        return this.c;
    }
    public final void i(Object p2)
    {
        if (this.isDebugEnable() != 0) {
            this.info(p2);
        }
        return;
    }
    public final void info(Object p3)
    {
        if (this.c <= 4) {
            this.a();
            if (this != 0) {
                v0 = new StringBuilder().append(this).append(" - ").append(p3).toString();
            } else {
                v0 = p3.toString();
            }
            android.util.Log.i(this.a, v0);
            v1 = com.tencent.wxop.stat.StatConfig.getCustomLogger();
            if (v1 != 0) {
                v1.a(v0);
            }
        }
        return;
    }
}
