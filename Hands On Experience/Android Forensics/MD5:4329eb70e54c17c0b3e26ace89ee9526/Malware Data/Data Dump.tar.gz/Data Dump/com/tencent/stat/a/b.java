package com.tencent.stat.a;
public class b extends com.tencent.stat.a.e {
    protected com.tencent.stat.a.c a;
    private long l;
    public b(android.content.Context p3, int p4, String p5)
    {
        this(p3, p4);
        this.a = new com.tencent.stat.a.c();
        this.l = -1.0;
        this.a.a = p5;
        return;
    }
    public com.tencent.stat.a.f a()
    {
        return com.tencent.stat.a.f.d;
    }
    public void a(long p1)
    {
        this.l = p1;
        return;
    }
    public void a(java.util.Properties p3)
    {
        if (p3 != 0) {
            this.a.c = p3.clone();
        }
        return;
    }
    public void a(String[] p3)
    {
        if (p3 != 0) {
            this.a.b = p3.clone();
        }
        return;
    }
    public boolean a(org.json.JSONObject p6)
    {
        p6.put("ei", this.a.a);
        if (this.l > 0.0) {
            p6.put("du", this.l);
        }
        if ((this.a.c == 0) && (this.a.b == 0)) {
            p6.put("kv", new org.json.JSONObject());
        }
        if (this.a.b != 0) {
            v1 = new org.json.JSONArray();
            v2 = this.a.b;
            v3 = v2.length;
            v0 = 0;
            while (v0 < v3) {
                v1.put(v2[v0]);
                v0++;
            }
            p6.put("ar", v1);
        }
        if (this.a.c != 0) {
            v1 = new org.json.JSONObject();
            v2 = this.a.c.entrySet().iterator();
            while (v2.hasNext() != 0) {
                v0 = v2.next();
                v1.put(v0.getKey().toString(), v0.getValue().toString());
            }
            p6.put(v1, v1);
        }
        return 1;
    }
}
