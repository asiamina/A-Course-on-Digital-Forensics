package com.tencent.bugly;
public class BuglyStrategy {
    private String a;
    private String c;
    private String b;
    private String e;
    private long d;
    private boolean g;
    private String f;
    private boolean i;
    private boolean h;
    private boolean k;
    private Class j;
    private boolean m;
    private boolean l;
    private com.tencent.bugly.BuglyStrategy$a o;
    private boolean n;
    public BuglyStrategy()
    {
        this.g = 1;
        this.h = 1;
        this.i = 1;
        this.j = 0;
        this.k = 1;
        this.l = 1;
        this.m = 1;
        this.n = 0;
        return;
    }
    public synchronized String getAppChannel()
    {
        if (this.b != 0) {
            v0 = this.b;
        } else {
            v0 = com.tencent.bugly.crashreport.common.info.a.b().l;
        }
        return v0;
    }
    public synchronized String getAppPackageName()
    {
        if (this.c != 0) {
            v0 = this.c;
        } else {
            v0 = com.tencent.bugly.crashreport.common.info.a.b().c;
        }
        return v0;
    }
    public synchronized long getAppReportDelay()
    {
        return this.d;
    }
    public synchronized String getAppVersion()
    {
        if (this.a != 0) {
            v0 = this.a;
        } else {
            v0 = com.tencent.bugly.crashreport.common.info.a.b().j;
        }
        return v0;
    }
    public synchronized com.tencent.bugly.BuglyStrategy$a getCrashHandleCallback()
    {
        return this.o;
    }
    public synchronized String getDeviceID()
    {
        return this.f;
    }
    public synchronized String getLibBuglySOFilePath()
    {
        return this.e;
    }
    public synchronized Class getUserInfoActivity()
    {
        return this.j;
    }
    public synchronized boolean isBuglyLogUpload()
    {
        return this.k;
    }
    public synchronized boolean isEnableANRCrashMonitor()
    {
        return this.h;
    }
    public synchronized boolean isEnableNativeCrashMonitor()
    {
        return this.g;
    }
    public synchronized boolean isEnableUserInfo()
    {
        return this.i;
    }
    public boolean isReplaceOldChannel()
    {
        return this.l;
    }
    public synchronized boolean isUploadProcess()
    {
        return this.m;
    }
    public synchronized boolean recordUserInfoOnceADay()
    {
        return this.n;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setAppChannel(String p2)
    {
        this.b = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setAppPackageName(String p2)
    {
        this.c = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setAppReportDelay(long p2)
    {
        this.d = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setAppVersion(String p2)
    {
        this.a = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setBuglyLogUpload(boolean p2)
    {
        this.k = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setCrashHandleCallback(com.tencent.bugly.BuglyStrategy$a p2)
    {
        this.o = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setDeviceID(String p2)
    {
        this.f = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setEnableANRCrashMonitor(boolean p2)
    {
        this.h = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setEnableNativeCrashMonitor(boolean p2)
    {
        this.g = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setEnableUserInfo(boolean p2)
    {
        this.i = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setLibBuglySOFilePath(String p2)
    {
        this.e = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setRecordUserInfoOnceADay(boolean p2)
    {
        this.n = p2;
        return this;
    }
    public void setReplaceOldChannel(boolean p1)
    {
        this.l = p1;
        return;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setUploadProcess(boolean p2)
    {
        this.m = p2;
        return this;
    }
    public synchronized com.tencent.bugly.BuglyStrategy setUserInfoActivity(Class p2)
    {
        this.j = p2;
        return this;
    }
}
