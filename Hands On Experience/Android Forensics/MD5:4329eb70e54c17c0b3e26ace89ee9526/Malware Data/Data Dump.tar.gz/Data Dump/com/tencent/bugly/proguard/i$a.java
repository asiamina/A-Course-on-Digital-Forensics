package com.tencent.bugly.proguard;
final public class i$a {
    public byte a;
    public int b;
    public i$a()
    {
        return;
    }
}
