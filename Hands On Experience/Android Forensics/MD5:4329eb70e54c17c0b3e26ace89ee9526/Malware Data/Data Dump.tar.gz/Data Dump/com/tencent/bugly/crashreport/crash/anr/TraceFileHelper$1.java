package com.tencent.bugly.crashreport.crash.anr;
final class TraceFileHelper$1 implements com.tencent.bugly.crashreport.crash.anr.TraceFileHelper$b {
    private synthetic com.tencent.bugly.crashreport.crash.anr.TraceFileHelper$a a;
    private synthetic boolean b;
    public final boolean a(long p5, long p7, String p9)
    {
        v0 = 1;
        v3 = new Object[1];
        v3[0] = p9;
        com.tencent.bugly.proguard.x.c("new process %s", v3);
        if (p9.equals(p9) != 0) {
            this.a.a = p5;
            this.a.b = p9;
            this.a.c = p7;
            if (this.b) {
                v0 = 0;
            }
        }
        return v0;
    }
    public final boolean a(String p8, int p9, String p10, String p11)
    {
        v1 = new Object[1];
        v1[0] = p8;
        com.tencent.bugly.proguard.x.c("new thread %s", v1);
        if ((this.a.a > 0.0) && ((this.a.c > 0.0) && (this.a.b != 0))) {
            if (this.a.d == 0) {
                this.a.d = new java.util.HashMap();
            }
            v1 = new String[3];
            v1[0] = p10;
            v1[1] = p11;
            v1[2] = new StringBuilder().append(p9).toString();
            this.a.d.put(p8, v1);
        }
        return 1;
    }
     TraceFileHelper$1(com.tencent.bugly.crashreport.crash.anr.TraceFileHelper$a p1, boolean p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
    public final boolean a(long p8)
    {
        v0 = 0;
        v3 = new Object[1];
        v3[0] = Long.valueOf(p8);
        com.tencent.bugly.proguard.x.c("process end %d", v3);
        if ((this.a.a <= 0.0) || ((this.a.c <= 0.0) || (this.a.b == 0))) {
            v0 = 1;
        }
        return v0;
    }
}
