package com.tencent.bugly.proguard;
final public class ak extends com.tencent.bugly.proguard.k {
    private static java.util.ArrayList A;
    private static java.util.Map C;
    private static java.util.Map B;
    public String a;
    public String c;
    public long b;
    public String e;
    public String d;
    public String g;
    public String f;
    public String i;
    public java.util.Map h;
    public int k;
    public com.tencent.bugly.proguard.ai j;
    public String m;
    public String l;
    public java.util.ArrayList o;
    public com.tencent.bugly.proguard.ah n;
    public java.util.ArrayList q;
    public java.util.ArrayList p;
    public java.util.Map s;
    public java.util.Map r;
    private boolean u;
    public String t;
    private static com.tencent.bugly.proguard.ai w;
    private static java.util.Map v;
    private static java.util.ArrayList y;
    private static com.tencent.bugly.proguard.ah x;
    private static java.util.ArrayList z;
    static ak()
    {
        com.tencent.bugly.proguard.ak.v = new java.util.HashMap();
        com.tencent.bugly.proguard.ak.v.put("", "");
        com.tencent.bugly.proguard.ak.w = new com.tencent.bugly.proguard.ai();
        com.tencent.bugly.proguard.ak.x = new com.tencent.bugly.proguard.ah();
        com.tencent.bugly.proguard.ak.y = new java.util.ArrayList();
        com.tencent.bugly.proguard.ak.y.add(new com.tencent.bugly.proguard.ah());
        com.tencent.bugly.proguard.ak.z = new java.util.ArrayList();
        com.tencent.bugly.proguard.ak.z.add(new com.tencent.bugly.proguard.ah());
        com.tencent.bugly.proguard.ak.A = new java.util.ArrayList();
        com.tencent.bugly.proguard.ak.A.add(new com.tencent.bugly.proguard.aj());
        com.tencent.bugly.proguard.ak.B = new java.util.HashMap();
        com.tencent.bugly.proguard.ak.B.put("", "");
        com.tencent.bugly.proguard.ak.C = new java.util.HashMap();
        com.tencent.bugly.proguard.ak.C.put("", "");
        return;
    }
    public ak()
    {
        this.a = "";
        this.b = 0.0;
        this.c = "";
        this.d = "";
        this.e = "";
        this.f = "";
        this.g = "";
        this.h = 0;
        this.i = "";
        this.j = 0;
        this.k = 0;
        this.l = "";
        this.m = "";
        this.n = 0;
        this.o = 0;
        this.p = 0;
        this.q = 0;
        this.r = 0;
        this.s = 0;
        this.t = "";
        this.u = 1;
        return;
    }
    public final void a(com.tencent.bugly.proguard.i p5)
    {
        this.a = p5.b(0, 1);
        this.b = p5.a(this.b, 1, 1);
        this.c = p5.b(2, 1);
        this.d = p5.b(3, 0);
        this.e = p5.b(4, 0);
        this.f = p5.b(5, 0);
        this.g = p5.b(6, 0);
        this.h = p5.a(com.tencent.bugly.proguard.ak.v, 7, 0);
        this.i = p5.b(8, 0);
        this.j = p5.a(com.tencent.bugly.proguard.ak.w, 9, 0);
        this.k = p5.a(this.k, 10, 0);
        this.l = p5.b(11, 0);
        this.m = p5.b(12, 0);
        this.n = p5.a(com.tencent.bugly.proguard.ak.x, 13, 0);
        this.o = p5.a(com.tencent.bugly.proguard.ak.y, 14, 0);
        this.p = p5.a(com.tencent.bugly.proguard.ak.z, 15, 0);
        this.q = p5.a(com.tencent.bugly.proguard.ak.A, 16, 0);
        this.r = p5.a(com.tencent.bugly.proguard.ak.B, 17, 0);
        this.s = p5.a(com.tencent.bugly.proguard.ak.C, 18, 0);
        this.t = p5.b(19, 0);
        this.u = p5.a(20, 0);
        return;
    }
    public final void a(com.tencent.bugly.proguard.j p4)
    {
        p4.a(this.a, 0);
        p4.a(this.b, 1);
        p4.a(this.c, 2);
        if (this.d != 0) {
            p4.a(this.d, 3);
        }
        if (this.e != 0) {
            p4.a(this.e, 4);
        }
        if (this.f != 0) {
            p4.a(this.f, 5);
        }
        if (this.g != 0) {
            p4.a(this.g, 6);
        }
        if (this.h != 0) {
            p4.a(this.h, 7);
        }
        if (this.i != 0) {
            p4.a(this.i, 8);
        }
        if (this.j != 0) {
            p4.a(this.j, 9);
        }
        p4.a(this.k, 10);
        if (this.l != 0) {
            p4.a(this.l, 11);
        }
        if (this.m != 0) {
            p4.a(this.m, 12);
        }
        if (this.n != 0) {
            p4.a(this.n, 13);
        }
        if (this.o != 0) {
            p4.a(this.o, 14);
        }
        if (this.p != 0) {
            p4.a(this.p, 15);
        }
        if (this.q != 0) {
            p4.a(this.q, 16);
        }
        if (this.r != 0) {
            p4.a(this.r, 17);
        }
        if (this.s != 0) {
            p4.a(this.s, 18);
        }
        if (this.t != 0) {
            p4.a(this.t, 19);
        }
        p4.a(this.u, 20);
        return;
    }
}
