package com.tencent.wxop.stat.a;
public class i extends com.tencent.wxop.stat.a.e {
    final public static com.tencent.wxop.stat.StatSpecifyReportedInfo a;
    static i()
    {
        v0 = new com.tencent.wxop.stat.StatSpecifyReportedInfo();
        com.tencent.wxop.stat.a.i.a = v0;
        v0.setAppKey("A9VH9B8L4GX4");
        return;
    }
    public i(android.content.Context p3)
    {
        this(p3, 0, com.tencent.wxop.stat.a.i.a);
        return;
    }
    public com.tencent.wxop.stat.a.f a()
    {
        return com.tencent.wxop.stat.a.f.i;
    }
    public boolean a(org.json.JSONObject p3)
    {
        com.tencent.wxop.stat.common.q.a(p3, "actky", com.tencent.wxop.stat.StatConfig.getAppKey(this.l));
        return 1;
    }
}
