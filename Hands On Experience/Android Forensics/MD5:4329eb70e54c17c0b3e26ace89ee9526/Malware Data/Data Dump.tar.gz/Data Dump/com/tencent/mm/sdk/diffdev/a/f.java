package com.tencent.mm.sdk.diffdev.a;
final class f extends android.os.AsyncTask {
    private String aq;
    private String url;
    private int aw;
    private com.tencent.mm.sdk.diffdev.OAuthListener an;
    public f(String p4, com.tencent.mm.sdk.diffdev.OAuthListener p5)
    {
        this.aq = p4;
        this.an = p5;
        v1 = new Object[1];
        v1[0] = p4;
        this.url = String.format("https://long.open.weixin.qq.com/connect/l/qrconnect?f=json&uuid=%s", v1);
        return;
    }
    protected final synthetic Object doInBackground(Object[] p13)
    {
        if ((this.aq != 0) && (this.aq.length() != 0)) {
            while (this.isCancelled() == 0) {
                v1 = new StringBuilder().append(this.url);
                if (this.aw != 0) {
                    v0 = new StringBuilder("&last=").append(this.aw).toString();
                } else {
                    v0 = "";
                }
                v1 = v1.append(v0).toString();
                v2 = System.currentTimeMillis();
                v0 = com.tencent.mm.sdk.diffdev.a.e.b(v1, 8.407790785948902e-41);
                v4 = System.currentTimeMillis();
                v0 = com.tencent.mm.sdk.diffdev.a.f$a.e(v0);
                v8 = new Object[4];
                v8[0] = v1;
                v8[1] = v0.ap.toString();
                v8[2] = Integer.valueOf(v0.ay);
                v8[3] = Long.valueOf((v4 - v2));
                android.util.Log.d("MicroMsg.SDK.NoopingTask", String.format("nooping, url = %s, errCode = %s, uuidStatusCode = %d, time consumed = %d(ms)", v8));
                if (v0.ap != com.tencent.mm.sdk.diffdev.OAuthErrCode.WechatAuth_Err_OK) {
                    v3 = new Object[2];
                    v3[0] = v0.ap.toString();
                    v3[1] = Integer.valueOf(v0.ay);
                    android.util.Log.e("MicroMsg.SDK.NoopingTask", String.format("nooping fail, errCode = %s, uuidStatusCode = %d", v3));
                } else {
                    this.aw = v0.ay;
                    if (v0.ay != com.tencent.mm.sdk.diffdev.a.g.aB.getCode()) {
                        if ((v0.ay != com.tencent.mm.sdk.diffdev.a.g.aD.getCode()) && (v0.ay == com.tencent.mm.sdk.diffdev.a.g.aC.getCode())) {
                            if ((v0.ax == 0) || (v0.ax.length() == 0)) {
                                android.util.Log.e("MicroMsg.SDK.NoopingTask", "nooping fail, confirm with an empty code!!!");
                                v0.ap = com.tencent.mm.sdk.diffdev.OAuthErrCode.WechatAuth_Err_NormalErr;
                            }
                        }
                    } else {
                        this.an.onQrcodeScanned();
                    }
                }
            }
            android.util.Log.i("MicroMsg.SDK.NoopingTask", "IDiffDevOAuth.stopAuth / detach invoked");
            v0 = new com.tencent.mm.sdk.diffdev.a.f$a();
            v0.ap = com.tencent.mm.sdk.diffdev.OAuthErrCode.WechatAuth_Err_Auth_Stopped;
        } else {
            android.util.Log.e("MicroMsg.SDK.NoopingTask", "run fail, uuid is null");
            v0 = new com.tencent.mm.sdk.diffdev.a.f$a();
            v0.ap = com.tencent.mm.sdk.diffdev.OAuthErrCode.WechatAuth_Err_NormalErr;
        }
        return v0;
    }
    protected final synthetic void onPostExecute(Object p4)
    {
        this.an.onAuthFinish(p4.ap, p4.ax);
        return;
    }
}
