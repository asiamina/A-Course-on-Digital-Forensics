package com.tencent.bugly.proguard;
final public class aa {
    public static com.tencent.bugly.proguard.ab a(int p2)
    {
        v0 = 0;
        if (p2 != 1) {
            if (p2 == 2) {
                v0 = new com.tencent.bugly.proguard.ac();
            }
        } else {
            v0 = new com.tencent.bugly.proguard.ad();
        }
        return v0;
    }
}
