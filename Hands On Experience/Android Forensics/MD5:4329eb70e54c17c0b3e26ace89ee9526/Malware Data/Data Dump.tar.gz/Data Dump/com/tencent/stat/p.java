package com.tencent.stat;
 class p implements java.lang.Runnable {
    final synthetic java.util.List a;
    final synthetic com.tencent.stat.n c;
    final synthetic int b;
     p(com.tencent.stat.n p1, java.util.List p2, int p3)
    {
        this.c = p1;
        this.a = p2;
        this.b = p3;
        return;
    }
    public void run()
    {
        com.tencent.stat.n.a(this.c, this.a, this.b);
        return;
    }
}
