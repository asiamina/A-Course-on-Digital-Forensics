package com.tencent.open;
 class TaskGuide$1 implements java.lang.Runnable {
    final synthetic int a;
    final synthetic com.tencent.open.TaskGuide b;
     TaskGuide$1(com.tencent.open.TaskGuide p1, int p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }
    public void run()
    {
        if (com.tencent.open.TaskGuide.a(this.b) != 0) {
            if (this.a != 0) {
                if (this.a != 1) {
                    if (this.a == 2) {
                        com.tencent.open.TaskGuide.b(this.b).findViewById(1).a(com.tencent.open.TaskGuide.c(this.b));
                        if (com.tencent.open.TaskGuide.b(this.b).getChildCount() > 1) {
                            com.tencent.open.TaskGuide.b(this.b).findViewById(2).a(com.tencent.open.TaskGuide.d(this.b));
                        }
                    }
                } else {
                    com.tencent.open.TaskGuide.b(this.b).findViewById(2).a(com.tencent.open.TaskGuide.d(this.b));
                }
            } else {
                com.tencent.open.TaskGuide.b(this.b).findViewById(1).a(com.tencent.open.TaskGuide.c(this.b));
            }
        }
        return;
    }
}
