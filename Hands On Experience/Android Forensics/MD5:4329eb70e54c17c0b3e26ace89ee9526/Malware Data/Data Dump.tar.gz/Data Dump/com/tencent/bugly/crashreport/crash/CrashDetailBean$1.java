package com.tencent.bugly.crashreport.crash;
final class CrashDetailBean$1 implements android.os.Parcelable$Creator {
     CrashDetailBean$1()
    {
        return;
    }
    public final synthetic Object createFromParcel(android.os.Parcel p2)
    {
        return new com.tencent.bugly.crashreport.crash.CrashDetailBean(p2);
    }
    public final synthetic bridge Object[] newArray(int p2)
    {
        v0 = new com.tencent.bugly.crashreport.crash.CrashDetailBean[p2];
        return v0;
    }
}
