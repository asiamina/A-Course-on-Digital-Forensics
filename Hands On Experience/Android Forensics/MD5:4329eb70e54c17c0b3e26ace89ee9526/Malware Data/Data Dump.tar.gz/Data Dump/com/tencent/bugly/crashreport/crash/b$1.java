package com.tencent.bugly.crashreport.crash;
final class b$1 implements com.tencent.bugly.proguard.t {
    private synthetic java.util.List a;
    private synthetic com.tencent.bugly.crashreport.crash.b b;
     b$1(com.tencent.bugly.crashreport.crash.b p1, java.util.List p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }
    public final void a(boolean p2)
    {
        com.tencent.bugly.crashreport.crash.b.a(p2, this.a);
        return;
    }
}
