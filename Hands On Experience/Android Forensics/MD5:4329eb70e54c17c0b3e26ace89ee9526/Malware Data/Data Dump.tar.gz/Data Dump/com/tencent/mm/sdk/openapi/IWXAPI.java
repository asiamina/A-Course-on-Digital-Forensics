package com.tencent.mm.sdk.openapi;
public interface abstract class IWXAPI {
    abstract public void detach();
    abstract public int getWXAppSupportAPI();
    abstract public boolean handleIntent();
    abstract public boolean isWXAppInstalled();
    abstract public boolean isWXAppSupportAPI();
    abstract public boolean openWXApp();
    abstract public boolean registerApp();
    abstract public boolean sendReq();
    abstract public boolean sendResp();
    abstract public void unregisterApp();
}
