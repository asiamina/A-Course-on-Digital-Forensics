package com.tencent.mm.sdk.b;
final public class g implements java.lang.Runnable {
     long bd;
     float be;
    final private static String bf;
    final private static String bg;
     long ba;
     long bb;
     long bc;
     boolean started;
    final android.os.Handler handler;
    final Runnable aQ;
    final Object aS;
    final String aR;
     String aU;
    final Thread aT;
    final com.tencent.mm.sdk.b.g$a aW;
     long aV;
     long aY;
     long aX;
     long aZ;
     int priority;
    static g()
    {
        v0 = new StringBuilder();
        v0.append("taskName = %s");
        v0.append("|token = %s");
        v0.append("|handler = %s");
        v0.append("|threadName = %s");
        v0.append("|threadId = %d");
        v0.append("|priority = %d");
        v0.append("|addTime = %d");
        v0.append("|delayTime = %d");
        v0.append("|usedTime = %d");
        v0.append("|cpuTime = %d");
        v0.append("|started = %b");
        com.tencent.mm.sdk.b.g.bf = v0.toString();
        v0 = new StringBuilder();
        v0.append("taskName = %s");
        v0.append(" | addTime = %s");
        v0.append(" | endTime = %s");
        v0.append(" | usedTime = %d");
        v0.append(" | cpuTime = %d");
        v0.append(" | threadCpuTime = %d");
        v0.append(" | totalCpuTime = %d");
        v0.append(" | threadCpuRate = %.1f");
        com.tencent.mm.sdk.b.g.bg = v0.toString();
        return;
    }
     g(Thread p5, android.os.Handler p6, Runnable p7, Object p8, com.tencent.mm.sdk.b.g$a p9)
    {
        this.started = 0;
        this.be = -1.0;
        this.aT = p5;
        if (p5 != 0) {
            this.aU = p5.getName();
            this.aV = p5.getId();
            this.priority = p5.getPriority();
        }
        this.handler = p6;
        this.aQ = p7;
        v0 = p7.getClass().getName();
        v1 = p7.toString();
        if (com.tencent.mm.sdk.b.h.h(v1) == 0) {
            v2 = v1.indexOf(124);
            if (v2 > 0) {
                v0 = new StringBuilder().append(v0).append("_").append(v1.substring((v2 + 1))).toString();
            }
        }
        this.aR = v0;
        this.aS = p8;
        this.aW = p9;
        this.aX = System.currentTimeMillis();
        return;
    }
    public final void run()
    {
        new StringBuilder("/proc/self/task/").append(android.os.Process.myTid()).append("/stat");
        this.ba = System.currentTimeMillis();
        this.bb = android.os.Debug.threadCpuTimeNanos();
        this.bc = -1.0;
        this.bd = -1.0;
        this.started = 1;
        this.aQ.run();
        this.bc = (-1.0 - this.bc);
        this.bd = (-1.0 - this.bd);
        this.aZ = System.currentTimeMillis();
        this.ba = (this.aZ - this.ba);
        this.bb = ((android.os.Debug.threadCpuTimeNanos() - this.bb) / 1000000.0);
        if (this.bd != 0.0) {
            this.be = (((float) (100.0 * this.bc)) / ((float) this.bd));
        }
        if (this.aW != 0) {
            this.aW.c(this.aQ, this);
        }
        return;
    }
}
