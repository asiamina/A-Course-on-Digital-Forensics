package com.tencent.connect.avatar;
 class ImageActivity$4 implements java.lang.Runnable {
    final synthetic String a;
    final synthetic com.tencent.connect.avatar.ImageActivity c;
    final synthetic int b;
     ImageActivity$4(com.tencent.connect.avatar.ImageActivity p1, String p2, int p3)
    {
        this.c = p1;
        this.a = p2;
        this.b = p3;
        return;
    }
    public void run()
    {
        com.tencent.connect.avatar.ImageActivity.a(this.c, this.a, this.b);
        return;
    }
}
