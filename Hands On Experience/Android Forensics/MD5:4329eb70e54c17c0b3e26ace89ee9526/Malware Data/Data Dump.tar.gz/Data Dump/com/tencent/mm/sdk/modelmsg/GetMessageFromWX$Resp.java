package com.tencent.mm.sdk.modelmsg;
public class GetMessageFromWX$Resp extends com.tencent.mm.sdk.modelbase.BaseResp {
    public com.tencent.mm.sdk.modelmsg.WXMediaMessage message;
    final private static String TAG;
    public GetMessageFromWX$Resp()
    {
        return;
    }
    public GetMessageFromWX$Resp(android.os.Bundle p1)
    {
        this.fromBundle(p1);
        return;
    }
    public boolean checkArgs()
    {
        if (this.message != 0) {
            v0 = this.message.checkArgs();
        } else {
            com.tencent.mm.sdk.b.b.b("MicroMsg.SDK.GetMessageFromWX.Resp", "checkArgs fail, message is null");
            v0 = 0;
        }
        return v0;
    }
    public void fromBundle(android.os.Bundle p2)
    {
        super.fromBundle(p2);
        this.message = com.tencent.mm.sdk.modelmsg.WXMediaMessage$Builder.fromBundle(p2);
        return;
    }
    public int getType()
    {
        return 3;
    }
    public void toBundle(android.os.Bundle p2)
    {
        super.toBundle(p2);
        p2.putAll(com.tencent.mm.sdk.modelmsg.WXMediaMessage$Builder.toBundle(this.message));
        return;
    }
}
