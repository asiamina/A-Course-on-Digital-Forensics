package com.tencent.wxop.stat;
final class s implements java.lang.Runnable {
    final synthetic android.content.Context a;
    final synthetic com.tencent.wxop.stat.a.c c;
    final synthetic com.tencent.wxop.stat.StatSpecifyReportedInfo b;
     s(android.content.Context p1, com.tencent.wxop.stat.StatSpecifyReportedInfo p2, com.tencent.wxop.stat.a.c p3)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        return;
    }
    public final void run()
    {
        v0 = new com.tencent.wxop.stat.a.b(this.a, com.tencent.wxop.stat.StatServiceImpl.a(this.a, 0, this.b), this.c.a, this.b);
        v0.b().b = this.c.b;
        new com.tencent.wxop.stat.aq(v0).a();
        return;
    }
}
