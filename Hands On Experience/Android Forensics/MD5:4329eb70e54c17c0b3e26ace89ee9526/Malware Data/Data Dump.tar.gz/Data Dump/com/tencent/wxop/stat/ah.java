package com.tencent.wxop.stat;
final class ah implements java.lang.Runnable {
    final synthetic android.content.Context a;
    final synthetic com.tencent.wxop.stat.StatSpecifyReportedInfo c;
    final synthetic String b;
     ah(android.content.Context p1, String p2, com.tencent.wxop.stat.StatSpecifyReportedInfo p3)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        return;
    }
    public final void run()
    {
        com.tencent.wxop.stat.StatServiceImpl.flushDataToDB(this.a);
        com.tencent.wxop.stat.StatServiceImpl.h();
        v0 = com.tencent.wxop.stat.StatServiceImpl.h().remove(this.b);
        if (v0 == 0) {
            com.tencent.wxop.stat.StatServiceImpl.f().e(new StringBuilder("Starttime for PageID:").append(this.b).append(" not found, lost onResume()?").toString());
        } else {
            v5 = Long.valueOf(((System.currentTimeMillis() - v0.longValue()) / 1000.0));
            if (v5.longValue() <= 0.0) {
                v5 = Long.valueOf(1.0);
            }
            v2 = com.tencent.wxop.stat.StatServiceImpl.j();
            if ((v2 != 0) && (v2.equals(this.b) == 1)) {
                v2 = "-";
            }
            v0 = new com.tencent.wxop.stat.a.k(this.a, v2, this.b, com.tencent.wxop.stat.StatServiceImpl.a(this.a, 0, this.c), v5, this.c);
            if (this.b.equals(com.tencent.wxop.stat.StatServiceImpl.i()) == 0) {
                com.tencent.wxop.stat.StatServiceImpl.f().warn("Invalid invocation since previous onResume on diff page.");
            }
            new com.tencent.wxop.stat.aq(v0).a();
            com.tencent.wxop.stat.StatServiceImpl.c(this.b);
        }
        return;
    }
}
