package com.tencent.connect.share;
public class QzonePublish extends com.tencent.connect.common.BaseApi {
    final public static String PUBLISH_TO_QZONE_KEY_TYPE;
    final public static String PUBLISH_TO_QZONE_VIDEO_SIZE;
    final public static String PUBLISH_TO_QZONE_IMAGE_URL;
    final public static int PUBLISH_TO_QZONE_TYPE_PUBLISHMOOD;
    final public static String PUBLISH_TO_QZONE_VIDEO_DURATION;
    final public static String PUBLISH_TO_QZONE_SUMMARY;
    final public static String PUBLISH_TO_QZONE_APP_NAME;
    final public static String PUBLISH_TO_QZONE_VIDEO_PATH;
    final public static int PUBLISH_TO_QZONE_TYPE_PUBLISHVIDEO;
    public QzonePublish(android.content.Context p1, com.tencent.connect.auth.QQToken p2)
    {
        this(p2);
        return;
    }
    private void a(android.app.Activity p19, android.os.Bundle p20, com.tencent.tauth.IUiListener p21)
    {
        com.tencent.open.a.f.c("openSDK_LOG.QzonePublish", "doPublishToQzone() --start");
        v5 = new StringBuffer("mqqapi://qzone/publish?src_type=app&version=1&file_type=news");
        v6 = p20.getStringArrayList("imageUrl");
        v7 = p20.getString("summary");
        v8 = p20.getInt("req_type", 3);
        v9 = p20.getString("appName");
        v10 = p20.getString("videoPath");
        v11 = p20.getInt("videoDuration");
        v12 = p20.getLong("videoSize");
        v14 = this.mToken.getAppId();
        v15 = this.mToken.getOpenId();
        com.tencent.open.a.f.a("openSDK_LOG.QzonePublish", new StringBuilder().append("openId:").append(v15).toString());
        v2 = "";
        if ((3 == v8) && (v6 != 0)) {
            v16 = new StringBuffer();
            v17 = v6.size();
            v4 = 0;
            while (v4 < v17) {
                v16.append(java.net.URLEncoder.encode(v6.get(v4)));
                if (v4 != (v17 - 1)) {
                    v16.append(";");
                }
                v4++;
            }
            v5.append(new StringBuilder().append("&image_url=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(v16.toString()), 2)).toString());
            v2 = "7";
        }
        if (4 == v8) {
            v2 = "8";
            v5.append(new StringBuilder().append("&videoPath=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(v10), 2)).toString());
            v5.append(new StringBuilder().append("&videoDuration=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(String.valueOf(v11)), 2)).toString());
            v5.append(new StringBuilder().append("&videoSize=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(String.valueOf(v12)), 2)).toString());
        }
        v13 = v2;
        if (android.text.TextUtils.isEmpty(v7) == 0) {
            v5.append(new StringBuilder().append("&description=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(v7), 2)).toString());
        }
        if (android.text.TextUtils.isEmpty(v14) == 0) {
            v5.append(new StringBuilder().append("&share_id=").append(v14).toString());
        }
        if (android.text.TextUtils.isEmpty(v9) == 0) {
            v5.append(new StringBuilder().append("&app_name=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(v9), 2)).toString());
        }
        if (com.tencent.open.utils.Util.isEmpty(v15) == 0) {
            v5.append(new StringBuilder().append("&open_id=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(v15), 2)).toString());
        }
        v5.append(new StringBuilder().append("&req_type=").append(android.util.Base64.encodeToString(com.tencent.open.utils.Util.getBytesUTF8(String.valueOf(v8)), 2)).toString());
        com.tencent.open.a.f.a("openSDK_LOG.QzonePublish", new StringBuilder().append("doPublishToQzone, url: ").append(v5.toString()).toString());
        v2 = com.tencent.open.utils.Global.getContext();
        v6 = new String[1];
        v6[0] = "shareToNativeQQ";
        com.tencent.connect.a.a.a(v2, this.mToken, "requireApi", v6);
        v2 = new android.content.Intent("android.intent.action.VIEW");
        v2.setData(android.net.Uri.parse(v5.toString()));
        v2.putExtra("pkg_name", p19.getPackageName());
        if (this.hasActivityForIntent(v2) == 0) {
            com.tencent.open.a.f.e("openSDK_LOG.QzonePublish", "doPublishToQzone() target activity not found");
            com.tencent.open.b.d.a().a(1, "SHARE_CHECK_SDK", "1000", this.mToken.getAppId(), String.valueOf(4), Long.valueOf(android.os.SystemClock.elapsedRealtime()), 0, 1, "hasActivityForIntent fail");
            com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDQQ.SHARETOQZ.XX", "11", "3", "1", v13, "0", "1", "0");
        } else {
            this.startAssistActivity(p19, 10104, v2, 0);
            com.tencent.open.b.d.a().a(0, "SHARE_CHECK_SDK", "1000", this.mToken.getAppId(), String.valueOf(4), Long.valueOf(android.os.SystemClock.elapsedRealtime()), 0, 1, "hasActivityForIntent success");
            com.tencent.open.b.d.a().a(this.mToken.getOpenId(), this.mToken.getAppId(), "ANDROIDQQ.SHARETOQZ.XX", "11", "3", "1", v13, "0", "1", "0");
        }
        com.tencent.open.a.f.c("openSDK_LOG", "doPublishToQzone() --end");
        return;
    }
    static synthetic void a(com.tencent.connect.share.QzonePublish p0, android.app.Activity p1, android.os.Bundle p2, com.tencent.tauth.IUiListener p3)
    {
        p0.a(p1, p2, p3);
        return;
    }
    public void publishToQzone(android.app.Activity p12, android.os.Bundle p13, com.tencent.tauth.IUiListener p14)
    {
        v7 = 0;
        com.tencent.open.a.f.c("openSDK_LOG.QzonePublish", "publishToQzone() -- start");
        if (p13 != 0) {
            if (com.tencent.open.utils.Util.isSupportPushToQZone(p12) != 0) {
                v2 = p13.getString("summary");
                v3 = p13.getStringArrayList("imageUrl");
                v0 = com.tencent.open.utils.Util.getApplicationLable(p12);
                if (v0 != 0) {
                    if (v0.length() > 20) {
                        v0 = new StringBuilder().append(v0.substring(0, 20)).append("...").toString();
                    }
                } else {
                    v0 = p13.getString("appName");
                }
                if (android.text.TextUtils.isEmpty(v0) == 0) {
                    p13.putString("appName", v0);
                }
                p13.putString("summary", v2);
                v0 = p13.getInt("req_type");
                if (v0 != 3) {
                    if (v0 != 4) {
                        p14.onError(new com.tencent.tauth.UiError(-5, "\u8bf7\u9009\u62e9\u652f\u6301\u7684\u5206\u4eab\u7c7b\u578b", 0));
                        com.tencent.open.a.f.e("openSDK_LOG.QzonePublish", "publishToQzone() error--end\u8bf7\u9009\u62e9\u652f\u6301\u7684\u5206\u4eab\u7c7b\u578b");
                        com.tencent.open.b.d.a().a(1, "SHARE_CHECK_SDK", "1000", this.mToken.getAppId(), String.valueOf(4), Long.valueOf(android.os.SystemClock.elapsedRealtime()), 0, 1, "publishToQzone() \u8bf7\u9009\u62e9\u652f\u6301\u7684\u5206\u4eab\u7c7b\u578b");
                    } else {
                        v2 = p13.getString("videoPath");
                        if (com.tencent.open.utils.Util.fileExists(v2) != 0) {
                            v6 = new android.media.MediaPlayer();
                            v6.setOnPreparedListener(new com.tencent.connect.share.QzonePublish$1(this, v2, p13, p12, p14));
                            v6.setOnErrorListener(new com.tencent.connect.share.QzonePublish$2(this, p14));
                            v6.setDataSource(v2);
                            v6.prepareAsync();
                        } else {
                            com.tencent.open.a.f.e("openSDK_LOG.QzonePublish", "publishToQzone() video url invalid");
                            p14.onError(new com.tencent.tauth.UiError(-5, "\u8bf7\u9009\u62e9\u6709\u6548\u7684\u89c6\u9891\u6587\u4ef6", 0));
                        }
                    }
                } else {
                    if ((v3 != 0) && (v3.size() > 0)) {
                        while (v7 < v3.size()) {
                            if (com.tencent.open.utils.Util.fileExists(v3.get(v7)) == 0) {
                                v3.remove(v7);
                            }
                            v7++;
                        }
                        p13.putStringArrayList("imageUrl", v3);
                    }
                    this.a(p12, p13, p14);
                    com.tencent.open.a.f.c("openSDK_LOG.QzonePublish", "publishToQzone() --end");
                }
            } else {
                p14.onError(new com.tencent.tauth.UiError(-15, "\u624bQ\u7248\u672c\u8fc7\u4f4e\uff0c\u8bf7\u4e0b\u8f7d\u5b89\u88c5\u6700\u65b0\u7248\u624bQ", 0));
                com.tencent.open.a.f.e("openSDK_LOG.QzonePublish", "-->publishToQzone, this is not support below qq 5.9.5");
                com.tencent.open.b.d.a().a(1, "SHARE_CHECK_SDK", "1000", this.mToken.getAppId(), String.valueOf(4), Long.valueOf(android.os.SystemClock.elapsedRealtime()), 0, 1, "publicToQzone, this is not support below qq 5.9.5");
                new com.tencent.open.TDialog(p12, "", this.getCommonDownloadQQUrl(""), 0, this.mToken).show();
            }
        } else {
            p14.onError(new com.tencent.tauth.UiError(-6, "\u4f20\u5165\u53c2\u6570\u4e0d\u53ef\u4ee5\u4e3a\u7a7a", 0));
            com.tencent.open.a.f.e("openSDK_LOG.QzonePublish", "-->publishToQzone, params is null");
            com.tencent.open.b.d.a().a(1, "SHARE_CHECK_SDK", "1000", this.mToken.getAppId(), String.valueOf(4), Long.valueOf(android.os.SystemClock.elapsedRealtime()), 0, 1, "\u4f20\u5165\u53c2\u6570\u4e0d\u53ef\u4ee5\u4e3a\u7a7a");
        }
        return;
    }
}
