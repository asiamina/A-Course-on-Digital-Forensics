package com.tencent.map.b;
final public class j {
    public static String a(String p6)
    {
        v0 = java.security.MessageDigest.getInstance("MD5");
        v0.update(p6.getBytes());
        v1 = v0.digest();
        v3 = new StringBuilder();
        v4 = v1.length;
        v0 = 0;
        while (v0 < v4) {
            v3.append(Integer.toHexString((v1[v0] & 255))).append("");
            v0++;
        }
        return v3.toString();
    }
    public static byte[] a(byte[] p5)
    {
        v0 = 0;
        if (p5 != 0) {
            v1 = new java.io.ByteArrayOutputStream();
            v2 = new java.util.zip.DeflaterOutputStream(v1);
            v2.write(p5, 0, p5.length);
            v2.finish();
            v2.flush();
            v2.close();
            v0 = v1.toByteArray();
        }
        return v0;
    }
    public static byte[] b(byte[] p11)
    {
        v0 = 0;
        if (p11 != 0) {
            v4 = new java.io.ByteArrayInputStream(p11);
            v5 = new java.util.zip.InflaterInputStream(v4);
            v2 = new byte[0];
            v6 = new byte[1024];
            while(true) {
                v7 = v5.read(v6);
                if (v7 <= 0) {
                    v1 = v2;
                } else {
                    v0 += v7;
                    v1 = new byte[v0];
                    System.arraycopy(v2, 0, v1, 0, v2.length);
                    System.arraycopy(v6, 0, v1, v2.length, v7);
                }
                if (v7 <= 0) {
                    break;
                }
                v2 = v1;
            }
            v4.close();
            v5.close();
        } else {
            v1 = 0;
        }
        return v1;
    }
}
