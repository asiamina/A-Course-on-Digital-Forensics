package com.tencent.stat.common;
 class m implements java.io.FileFilter {
     m()
    {
        return;
    }
    public boolean accept(java.io.File p3)
    {
        if (java.util.regex.Pattern.matches("cpu[0-9]", p3.getName()) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
}
