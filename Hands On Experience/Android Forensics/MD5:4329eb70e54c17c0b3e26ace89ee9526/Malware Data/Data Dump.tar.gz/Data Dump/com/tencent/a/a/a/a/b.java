package com.tencent.a.a.a.a;
final class b extends com.tencent.a.a.a.a.f {
    protected final void a(String p4)
    {
        android.util.Log.i("MID", "write mid to InternalStorage");
        com.tencent.a.a.a.a.a.d(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append("/").append(com.tencent.a.a.a.a.h.f("6X8Y4XdM2Vhvn0I=")).toString());
        v0 = new java.io.BufferedWriter(new java.io.FileWriter(v0));
        v0.write(new StringBuilder().append(com.tencent.a.a.a.a.h.f("4kU71lN96TJUomD1vOU9lgj9Tw==")).append(",").append(p4).toString());
        v0.write("\n");
        v0.close();
        return;
    }
    protected final boolean a()
    {
        if ((com.tencent.a.a.a.a.h.a(this.a, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) || (android.os.Environment.getExternalStorageState().equals("mounted") == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    protected final String b()
    {
        android.util.Log.i("MID", "read mid from InternalStorage");
        v2 = com.tencent.a.a.a.a.a.a(new java.io.File(android.os.Environment.getExternalStorageDirectory(), com.tencent.a.a.a.a.h.f("6X8Y4XdM2Vhvn0KfzcEatGnWaNU="))).iterator();
        while (v2.hasNext() != 0) {
            v0 = v2.next().split(",");
            if ((v0.length == 2) && (v0[0].equals(com.tencent.a.a.a.a.h.f("4kU71lN96TJUomD1vOU9lgj9Tw==")) != 0)) {
                android.util.Log.i("MID", new StringBuilder("read mid from InternalStorage:").append(v0[1]).toString());
                v0 = v0[1];
            }
            return v0;
        }
        v0 = 0;
    }
     b(android.content.Context p1)
    {
        this(p1);
        return;
    }
}
