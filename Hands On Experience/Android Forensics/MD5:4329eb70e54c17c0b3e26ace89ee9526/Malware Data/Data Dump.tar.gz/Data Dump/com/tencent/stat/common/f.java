package com.tencent.stat.common;
public class f {
    static long a;
    static long a(android.content.Context p2, String p3)
    {
        return com.tencent.stat.common.p.a(p2, p3, com.tencent.stat.common.f.a);
    }
    static void a(android.content.Context p0, String p1, long p2)
    {
        com.tencent.stat.common.p.b(p0, p1, p2);
        return;
    }
    public static synchronized boolean a(android.content.Context p8)
    {
        v2 = com.tencent.stat.common.f.a(p8, "1.6.2_begin_protection");
        v4 = com.tencent.stat.common.f.a(p8, "1.6.2_end__protection");
        if ((v2 <= 0.0) || (v4 != com.tencent.stat.common.f.a)) {
            if (v2 == com.tencent.stat.common.f.a) {
                com.tencent.stat.common.f.a(p8, "1.6.2_begin_protection", System.currentTimeMillis());
            }
            v0 = 1;
        } else {
            v0 = 0;
        }
        return v0;
    }
    public static synchronized void b(android.content.Context p6)
    {
        if (com.tencent.stat.common.f.a(p6, "1.6.2_end__protection") == com.tencent.stat.common.f.a) {
            com.tencent.stat.common.f.a(p6, "1.6.2_end__protection", System.currentTimeMillis());
        }
        return;
    }
    static f()
    {
        com.tencent.stat.common.f.a = -1.0;
        return;
    }
}
