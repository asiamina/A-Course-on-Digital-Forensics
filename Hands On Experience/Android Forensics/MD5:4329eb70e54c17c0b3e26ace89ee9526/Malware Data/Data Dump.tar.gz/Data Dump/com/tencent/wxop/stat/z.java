package com.tencent.wxop.stat;
final class z implements java.lang.Runnable {
    final synthetic String a;
    final synthetic android.content.Context c;
    final synthetic com.tencent.wxop.stat.a.c b;
    final synthetic com.tencent.wxop.stat.StatSpecifyReportedInfo d;
     z(String p1, com.tencent.wxop.stat.a.c p2, android.content.Context p3, com.tencent.wxop.stat.StatSpecifyReportedInfo p4)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        return;
    }
    public final void run()
    {
        if (com.tencent.wxop.stat.StatServiceImpl.a(this.a) == 0) {
            v0 = com.tencent.wxop.stat.StatServiceImpl.k().remove(this.b);
            if (v0 == 0) {
                com.tencent.wxop.stat.StatServiceImpl.f().warn(new StringBuilder("No start time found for custom event: ").append(this.b.toString()).append(", lost trackCustomBeginKVEvent()?").toString());
            } else {
                v2 = new com.tencent.wxop.stat.a.b(this.c, com.tencent.wxop.stat.StatServiceImpl.a(this.c, 0, this.d), this.b.a, this.d);
                v2.b().c = this.b.c;
                v0 = Long.valueOf(((System.currentTimeMillis() - v0.longValue()) / 1000.0));
                if (v0.longValue() > 0.0) {
                    v0 = v0.longValue();
                } else {
                    v0 = 1.0;
                }
                v2.a(Long.valueOf(v0).longValue());
                new com.tencent.wxop.stat.aq(v2).a();
            }
        } else {
            com.tencent.wxop.stat.StatServiceImpl.f().error("The event_id of StatService.trackCustomEndEvent() can not be null or empty.");
        }
        return;
    }
}
