package com.tencent.wxop.stat.common;
public class f {
    static byte[] a()
    {
        return android.util.Base64.decode("MDNhOTc2NTExZTJjYmUzYTdmMjY4MDhmYjdhZjNjMDU=", 0);
    }
    public static byte[] a(byte[] p1)
    {
        return com.tencent.wxop.stat.common.f.a(p1, com.tencent.wxop.stat.common.f.a());
    }
    static byte[] a(byte[] p8, byte[] p9)
    {
        v0 = 0;
        v3 = new int[256];
        v4 = new int[256];
        v2 = p9.length;
        if ((v2 > 0) && (v2 <= 256)) {
            v1 = 0;
            while (v1 < 256) {
                v3[v1] = v1;
                v4[v1] = p9[(v1 % v2)];
                v1++;
            }
            v1 = 0;
            v2 = 0;
            while (v2 < 256) {
                v1 = (((v1 + v3[v2]) + v4[v2]) & 255);
                v5 = v3[v2];
                v3[v2] = v3[v1];
                v3[v1] = v5;
                v2++;
            }
            v4 = new byte[p8.length];
            v1 = 0;
            v2 = 0;
            while (v0 < p8.length) {
                v1 = ((v1 + 1) & 255);
                v2 = ((v2 + v3[v1]) & 255);
                v5 = v3[v1];
                v3[v1] = v3[v2];
                v3[v2] = v5;
                v4[v0] = ((byte) (v3[((v3[v1] + v3[v2]) & 255)] ^ p8[v0]));
                v0++;
            }
            return v4;
        } else {
            throw new IllegalArgumentException("key must be between 1 and 256 bytes");
        }
    }
    public static byte[] b(byte[] p1)
    {
        return com.tencent.wxop.stat.common.f.b(p1, com.tencent.wxop.stat.common.f.a());
    }
    static byte[] b(byte[] p1, byte[] p2)
    {
        return com.tencent.wxop.stat.common.f.a(p1, p2);
    }
}
