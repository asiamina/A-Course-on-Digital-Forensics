package com.tencent.bugly.proguard;
final class u$1 implements java.lang.Runnable {
    private synthetic Runnable a;
    private synthetic com.tencent.bugly.proguard.u b;
     u$1(com.tencent.bugly.proguard.u p1, Runnable p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }
    public final void run()
    {
        this.a.run();
        com.tencent.bugly.proguard.u.a(this.b);
        com.tencent.bugly.proguard.u.b(this.b);
        return;
    }
}
