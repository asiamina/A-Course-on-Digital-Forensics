package com.tencent.bugly.crashreport;
public interface abstract class a {
    abstract public boolean appendLogToNative();
    abstract public boolean setNativeIsAppForeground();
}
