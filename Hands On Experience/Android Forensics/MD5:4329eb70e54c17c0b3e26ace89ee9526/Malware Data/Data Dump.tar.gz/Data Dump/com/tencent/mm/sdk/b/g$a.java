package com.tencent.mm.sdk.b;
public interface abstract class g$a {
    abstract public void c();
}
