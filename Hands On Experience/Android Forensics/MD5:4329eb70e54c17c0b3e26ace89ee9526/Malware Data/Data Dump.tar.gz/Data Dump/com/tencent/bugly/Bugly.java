package com.tencent.bugly;
public class Bugly {
    private static boolean a;
    final public static String SDK_IS_DEV;
    private static String[] c;
    private static String[] b;
    public static android.content.Context applicationContext;
    public static boolean enable;
    public static Boolean isDev;
    static Bugly()
    {
        com.tencent.bugly.Bugly.enable = 1;
        com.tencent.bugly.Bugly.applicationContext = 0;
        v0 = new String[3];
        v0[0] = "BuglyCrashModule";
        v0[1] = "BuglyRqdModule";
        v0[2] = "BuglyBetaModule";
        com.tencent.bugly.Bugly.b = v0;
        v0 = new String[3];
        v0[0] = "BuglyRqdModule";
        v0[1] = "BuglyCrashModule";
        v0[2] = "BuglyBetaModule";
        com.tencent.bugly.Bugly.c = v0;
        return;
    }
    public Bugly()
    {
        return;
    }
    public static synchronized String getAppChannel()
    {
        v0 = 0;
        v1 = com.tencent.bugly.crashreport.common.info.a.b();
        if (v1 != 0) {
            if (android.text.TextUtils.isEmpty(v1.l) != 0) {
                v0 = com.tencent.bugly.proguard.p.a();
                if (v0 != 0) {
                    v0 = v0.a(556, 0, 1);
                    if (v0 != 0) {
                        v0 = v0.get("app_channel");
                        if (v0 != 0) {
                            v0 = new String(v0);
                            return v0;
                        }
                    }
                } else {
                    v0 = v1.l;
                }
            }
            v0 = v1.l;
        }
    }
    public static void init(android.content.Context p1, String p2, boolean p3)
    {
        com.tencent.bugly.Bugly.init(p1, p2, p3, 0);
        return;
    }
    public static synchronized void init(android.content.Context p6, String p7, boolean p8, com.tencent.bugly.BuglyStrategy p9)
    {
        if (!com.tencent.bugly.Bugly.a) {
            com.tencent.bugly.Bugly.a = 1;
            v0 = com.tencent.bugly.proguard.z.a(p6);
            com.tencent.bugly.Bugly.applicationContext = v0;
            if (v0 != 0) {
                if (com.tencent.bugly.Bugly.isDev() != 0) {
                    com.tencent.bugly.Bugly.b = com.tencent.bugly.Bugly.c;
                }
                v3 = com.tencent.bugly.Bugly.b;
                v4 = v3.length;
                v1 = 0;
                while (v1 < v4) {
                    v0 = v3[v1];
                    if (v0.equals("BuglyCrashModule") == 0) {
                        if ((v0.equals("BuglyBetaModule") == 0) && (v0.equals("BuglyRqdModule") == 0)) {
                            v0.equals("BuglyFeedbackModule");
                        }
                    } else {
                        com.tencent.bugly.b.a(com.tencent.bugly.CrashModule.getInstance());
                    }
                    v1++;
                }
                com.tencent.bugly.b.a = com.tencent.bugly.Bugly.enable;
                com.tencent.bugly.b.a(com.tencent.bugly.Bugly.applicationContext, p7, p8, p9);
            } else {
                android.util.Log.e(com.tencent.bugly.proguard.x.a, "init arg \'context\' should not be null!");
            }
        }
        return;
    }
    public static boolean isDev()
    {
        if (com.tencent.bugly.Bugly.isDev == 0) {
            com.tencent.bugly.Bugly.isDev = Boolean.valueOf(Boolean.parseBoolean("false".replace("@", "")));
        }
        return com.tencent.bugly.Bugly.isDev.booleanValue();
    }
}
