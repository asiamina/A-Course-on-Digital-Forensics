package com.tencent.open.utils;
public class ServerSetting {
    final public static String DEFAULT_LOCAL_STORAGE_URI;
    final public static String DEFAULT_URL_REACTIVE;
    final public static String DEFAULT_URL_VOICE;
    final public static String DEFAULT_REDIRECT_URI;
    final public static String DEFAULT_URL_GRAPH_BASE;
    final public static String URL_PRIZE_GET_ACTIVITY_STATE;
    final public static String KEY_HOST_FUSION;
    final public static String DEFAULT_CGI_AUTHORIZE;
    final public static String NEED_QQ_VERSION_TIPS_URL;
    final public static String URL_FUSION_BASE;
    final public static String KEY_HOST_QZS_QQ;
    final public static String APP_DETAIL_PAGE;
    final public static String DEFAULT_URL_REPORT;
    final public static String DOWNLOAD_QQ_URL_COMMON;
    final public static String DEFAULT_URL_BRAG;
    final public static String KEY_OPEN_SETTING;
    final public static int ENVIRONMENT_NORMOL;
    final public static String KEY_OPEN_ENV;
    final public static String DOWNLOAD_QQ_URL;
    final public static String URL_FUSION_CGI_BASE;
    final public static String KEY_HOST_I_GTIMG;
    final public static String KEY_HOST_APPIC;
    final public static String KEY_HOST_ANALY;
    final public static String KEY_HOST_OPEN_MOBILE;
    final public static String DEFAULT_URL_ASK;
    final public static String URL_PRIZE_MAKE_SHARE_URL;
    final public static String KEY_HOST_QZAPP_QLOGO;
    private static com.tencent.open.utils.ServerSetting a;
    private volatile ref.WeakReference b;
    final public static String URL_PRIZE_EXCHANGE;
    final public static String KEY_HOST_MAPP_QZONE;
    final public static String DEFAULT_URL_SEND_STORY;
    final public static String DEFAULT_URL_INVITE;
    final public static String DEFAULT_URL_GIFT;
    final public static String URL_PRIZE_QUERY_UNEXCHANGE;
    final public static int ENVIRONMENT_EXPERIENCE;
    final public static String KEY_HOST_APP_SUPPORT;
    final public static String CGI_FETCH_QQ_URL;
    static ServerSetting()
    {
        com.tencent.open.utils.ServerSetting.a = 0;
        return;
    }
    public ServerSetting()
    {
        this.b = 0;
        return;
    }
    public void changeServer()
    {
        this.b = 0;
        return;
    }
    public String getEnvUrl(android.content.Context p6, String p7)
    {
        if ((this.b == 0) || (this.b.get() == 0)) {
            this.b = new ref.WeakReference(p6.getSharedPreferences("ServerPrefs", 0));
        }
        v1 = new java.net.URL(p7).getHost();
        if (v1 != 0) {
            v0 = this.b.get().getString(v1, 0);
            if ((v0 != 0) && (v1.equals(v0) == 0)) {
                p7 = p7.replace(v1, v0);
                com.tencent.open.a.f.a("openSDK_LOG.ServerSetting", new StringBuilder().append("return environment url : ").append(p7).toString());
            } else {
                com.tencent.open.a.f.a("openSDK_LOG.ServerSetting", new StringBuilder().append("host=").append(v1).append(", envHost=").append(v0).toString());
            }
        } else {
            com.tencent.open.a.f.e("openSDK_LOG.ServerSetting", new StringBuilder().append("Get host error. url=").append(p7).toString());
        }
        return p7;
    }
    public static synchronized com.tencent.open.utils.ServerSetting getInstance()
    {
        if (com.tencent.open.utils.ServerSetting.a == 0) {
            com.tencent.open.utils.ServerSetting.a = new com.tencent.open.utils.ServerSetting();
        }
        return com.tencent.open.utils.ServerSetting.a;
    }
    public void setEnvironment(android.content.Context p5, int p6)
    {
        if ((p5 != 0) && ((this.b == 0) || (this.b.get() == 0))) {
            this.b = new ref.WeakReference(p5.getSharedPreferences("ServerPrefs", 0));
        }
        if ((p6 == 0) || (p6 == 1)) {
            switch (p6) {
                case 0:
                    v0 = this.b.get().edit();
                    if (v0 != 0) {
                        v0.putInt("ServerType", 0);
                        v0.putString("OpenEnvironment", "formal");
                        v0.putString("qzs.qq.com", "qzs.qq.com");
                        v0.putString("openmobile.qq.com", "openmobile.qq.com");
                        v0.commit();
                        this.changeServer();
                        android.widget.Toast.makeText(p5, "\u5df2\u5207\u6362\u5230\u6b63\u5f0f\u73af\u5883", 0).show();
                    }
                    break;
                case 1:
                    v0 = this.b.get().edit();
                    if (v0 != 0) {
                        v0.putInt("ServerType", 1);
                        v0.putString("OpenEnvironment", "exp");
                        v0.putString("qzs.qq.com", "testmobile.qq.com");
                        v0.putString("openmobile.qq.com", "test.openmobile.qq.com");
                        v0.commit();
                        this.changeServer();
                        android.widget.Toast.makeText(p5, "\u5df2\u5207\u6362\u5230\u4f53\u9a8c\u73af\u5883", 0).show();
                    }
                    break;
            }
        } else {
            com.tencent.open.a.f.e("openSDK_LOG.ServerSetting", "\u5207\u6362\u73af\u5883\u53c2\u6570\u9519\u8bef\uff0c\u6b63\u5f0f\u73af\u5883\u4e3a0\uff0c\u4f53\u9a8c\u73af\u5883\u4e3a1");
        }
        return;
    }
}
