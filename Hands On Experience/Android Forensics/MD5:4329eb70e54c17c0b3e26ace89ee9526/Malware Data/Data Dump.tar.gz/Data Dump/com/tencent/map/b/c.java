package com.tencent.map.b;
final public class c {
    private static com.tencent.map.b.c a;
    private java.util.List c;
    private long b;
    private String e;
    private java.util.List d;
    public c()
    {
        this.b = 0.0;
        this.c = new java.util.ArrayList();
        this.d = new java.util.ArrayList();
        return;
    }
    public static com.tencent.map.b.c a()
    {
        if (com.tencent.map.b.c.a == 0) {
            com.tencent.map.b.c.a = new com.tencent.map.b.c();
        }
        return com.tencent.map.b.c.a;
    }
    public final void a(int p5, int p6, int p7, int p8, java.util.List p9)
    {
        this.b = System.currentTimeMillis();
        this.e = 0;
        this.c.clear();
        v0 = new com.tencent.map.b.c$a(0);
        v0.a = p5;
        v0.b = p6;
        v0.c = p7;
        v0.d = p8;
        this.c.add(v0);
        if (p9 != 0) {
            this.d.clear();
            v1 = 0;
            while (v1 < p9.size()) {
                v3 = new com.tencent.map.b.c$b(0);
                v3.a = p9.get(v1).BSSID;
                p9.get(v1);
                this.d.add(v3);
                v1++;
            }
        }
        return;
    }
    public final void a(String p1)
    {
        this.e = p1;
        return;
    }
    private static boolean a(StringBuffer p5)
    {
        v0 = 0;
        if (new org.json.JSONObject(p5.toString()).getJSONObject("location").getDouble("accuracy") < 5000.0) {
            v0 = 1;
        }
        return v0;
    }
    private boolean a(java.util.List p10)
    {
        v2 = 0;
        if (p10 != 0) {
            if (this.d == 0) {
                v3 = 0;
            } else {
                v1 = 0;
                v3 = 0;
                while (v1 < this.d.size()) {
                    v6 = this.d.get(v1).a;
                    v5 = 0;
                    while ((v6 != 0) && (v5 < p10.size())) {
                        if (v6.equals(p10.get(v5).BSSID) == 0) {
                            v5++;
                        } else {
                            v3++;
                            break;
                        }
                    }
                    v1++;
                }
            }
            v0 = p10.size();
            if ((v0 < 6) || (v3 < ((v0 / 2) + 1))) {
                if ((v0 >= 6) || (v3 < 2)) {
                    if ((this.d.size() <= 2) && ((p10.size() <= 2) && (Math.abs((System.currentTimeMillis() - this.b)) <= 30000.0))) {
                        v2 = 1;
                    }
                } else {
                    v2 = 1;
                }
            } else {
                v2 = 1;
            }
        }
        return v2;
    }
    public final String b(int p8, int p9, int p10, int p11, java.util.List p12)
    {
        v1 = 0;
        if ((this.e != 0) && (this.e.length() >= 10)) {
            v0 = this.e;
            if ((v0 != 0) && (p12 != 0)) {
                v2 = Math.abs((System.currentTimeMillis() - this.b));
                if (((v2 > 30000.0) && (p12.size() > 2)) || (((v2 > 45000.0) && (p12.size() <= 2)) || (com.tencent.map.b.c.a(new StringBuffer(v0)) == 0))) {
                    v0 = 0;
                }
            } else {
                v0 = 0;
            }
            this.e = v0;
            if (this.e != 0) {
                if ((this.c != 0) && (this.c.size() > 0)) {
                    v0 = this.c.get(0);
                    if ((v0.a != p8) || ((v0.b != p9) || ((v0.c != p10) || (v0.d != p11)))) {
                        return v1;
                    } else {
                        if (((this.d != 0) && (this.d.size() != 0)) || ((p12 != 0) && (p12.size() != 0))) {
                            this.a(p12);
                            if (this != 0) {
                                v1 = this.e;
                            }
                        } else {
                            v1 = this.e;
                        }
                    }
                }
                this.a(p12);
                if (this != 0) {
                    v1 = this.e;
                }
            }
        }
    }
    public final void b()
    {
        this.e = 0;
        return;
    }
}
