package com.tencent.bugly.proguard;
final public class g extends java.lang.RuntimeException {
    public g(String p1)
    {
        this(p1);
        return;
    }
}
