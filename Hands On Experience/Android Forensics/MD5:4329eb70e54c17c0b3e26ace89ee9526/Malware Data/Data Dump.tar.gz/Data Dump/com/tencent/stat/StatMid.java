package com.tencent.stat;
public class StatMid {
    private static com.tencent.stat.common.StatLogger a;
    private static com.tencent.stat.DeviceInfo b;
    private static com.tencent.stat.DeviceInfo a(String p1)
    {
        if (p1 == 0) {
            v0 = 0;
        } else {
            v0 = com.tencent.stat.DeviceInfo.a(com.tencent.stat.common.k.d(p1));
        }
        return v0;
    }
    public static com.tencent.stat.DeviceInfo getDeviceInfo(android.content.Context p2)
    {
        if (p2 != 0) {
            if (com.tencent.stat.StatMid.b == 0) {
                com.tencent.stat.StatMid.a(p2);
            }
            v0 = com.tencent.stat.StatMid.b;
        } else {
            com.tencent.stat.StatMid.a.error("Context for StatConfig.getDeviceInfo is null.");
            v0 = 0;
        }
        return v0;
    }
    public static String getMid(android.content.Context p1)
    {
        if (com.tencent.stat.StatMid.b == 0) {
            com.tencent.stat.StatMid.getDeviceInfo(p1);
        }
        return com.tencent.stat.StatMid.b.getMid();
    }
    public static void updateDeviceInfo(android.content.Context p4, String p5)
    {
        com.tencent.stat.StatMid.getDeviceInfo(p4);
        com.tencent.stat.StatMid.b.c(p5);
        com.tencent.stat.StatMid.b.a((com.tencent.stat.StatMid.b.a() + 1));
        com.tencent.stat.StatMid.b.a(System.currentTimeMillis());
        v0 = com.tencent.stat.StatMid.b.c().toString();
        com.tencent.stat.StatMid.a.d(new StringBuilder().append("save DeviceInfo:").append(v0).toString());
        v0 = com.tencent.stat.common.k.c(v0).replace("\n", "");
        v1 = com.tencent.stat.a.a(p4);
        v1.c("__MTA_DEVICE_INFO__", v0);
        v1.e("__MTA_DEVICE_INFO__", v0);
        v1.a("__MTA_DEVICE_INFO__", v0);
        return;
    }
    static StatMid()
    {
        com.tencent.stat.StatMid.a = com.tencent.stat.common.k.b();
        com.tencent.stat.StatMid.b = 0;
        return;
    }
    public StatMid()
    {
        return;
    }
    static synchronized com.tencent.stat.DeviceInfo a(android.content.Context p7)
    {
        v0 = com.tencent.stat.a.a(p7);
        v2 = com.tencent.stat.StatMid.a(v0.d("__MTA_DEVICE_INFO__", 0));
        com.tencent.stat.StatMid.a.d(new StringBuilder().append("get device info from internal storage:").append(v2).toString());
        v3 = com.tencent.stat.StatMid.a(v0.f("__MTA_DEVICE_INFO__", 0));
        com.tencent.stat.StatMid.a.d(new StringBuilder().append("get device info from setting.system:").append(v3).toString());
        v0 = com.tencent.stat.StatMid.a(v0.b("__MTA_DEVICE_INFO__", 0));
        com.tencent.stat.StatMid.a.d(new StringBuilder().append("get device info from SharedPreference:").append(v0).toString());
        com.tencent.stat.StatMid.b = com.tencent.stat.StatMid.a(v0, v3, v2);
        if (com.tencent.stat.StatMid.b == 0) {
            com.tencent.stat.StatMid.b = new com.tencent.stat.DeviceInfo();
        }
        v0 = com.tencent.stat.n.a(p7).b(p7);
        if (v0 != 0) {
            com.tencent.stat.StatMid.b.d(v0.getImei());
            com.tencent.stat.StatMid.b.e(v0.getMac());
            com.tencent.stat.StatMid.b.b(v0.getUserType());
        }
        return com.tencent.stat.StatMid.b;
    }
    static com.tencent.stat.DeviceInfo a(com.tencent.stat.DeviceInfo p1, com.tencent.stat.DeviceInfo p2)
    {
        if ((p1 == 0) || (p2 == 0)) {
            if (p1 == 0) {
                if (p2 == 0) {
                    p1 = 0;
                } else {
                    p1 = p2;
                }
            }
        } else {
            if (p1.a(p2) < 0) {
                p1 = p2;
            }
        }
        return p1;
    }
    static com.tencent.stat.DeviceInfo a(com.tencent.stat.DeviceInfo p2, com.tencent.stat.DeviceInfo p3, com.tencent.stat.DeviceInfo p4)
    {
        return com.tencent.stat.StatMid.a(com.tencent.stat.StatMid.a(p2, p3), com.tencent.stat.StatMid.a(p3, p4));
    }
}
