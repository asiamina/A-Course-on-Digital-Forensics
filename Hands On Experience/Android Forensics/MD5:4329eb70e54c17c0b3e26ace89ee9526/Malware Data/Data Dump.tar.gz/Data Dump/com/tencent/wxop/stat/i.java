package com.tencent.wxop.stat;
 class i {
     org.apache.http.impl.client.DefaultHttpClient a;
     StringBuilder c;
     com.tencent.wxop.stat.common.e b;
    private static com.tencent.wxop.stat.i e;
    private static com.tencent.wxop.stat.common.StatLogger d;
    private long g;
    private static android.content.Context f;
    static i()
    {
        com.tencent.wxop.stat.i.d = com.tencent.wxop.stat.common.k.b();
        com.tencent.wxop.stat.i.e = 0;
        com.tencent.wxop.stat.i.f = 0;
        return;
    }
    private i(android.content.Context p5)
    {
        this.a = 0;
        this.b = 0;
        this.c = new StringBuilder(4096);
        this.g = 0.0;
        com.tencent.wxop.stat.i.f = p5.getApplicationContext();
        this.g = (System.currentTimeMillis() / 1000.0);
        this.b = new com.tencent.wxop.stat.common.e();
        if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
            java.util.logging.Logger.getLogger("org.apache.http.wire").setLevel(java.util.logging.Level.FINER);
            java.util.logging.Logger.getLogger("org.apache.http.headers").setLevel(java.util.logging.Level.FINER);
            System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
            System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
            System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "debug");
            System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "debug");
            System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "debug");
        }
        v0 = new org.apache.http.params.BasicHttpParams();
        org.apache.http.params.HttpConnectionParams.setStaleCheckingEnabled(v0, 0);
        org.apache.http.params.HttpConnectionParams.setConnectionTimeout(v0, 10000);
        org.apache.http.params.HttpConnectionParams.setSoTimeout(v0, 10000);
        this.a = new org.apache.http.impl.client.DefaultHttpClient(v0);
        this.a.setKeepAliveStrategy(new com.tencent.wxop.stat.j(this));
        return;
    }
    static android.content.Context a()
    {
        return com.tencent.wxop.stat.i.f;
    }
    static void a(android.content.Context p1)
    {
        com.tencent.wxop.stat.i.f = p1.getApplicationContext();
        return;
    }
     void a(com.tencent.wxop.stat.a.e p4, com.tencent.wxop.stat.h p5)
    {
        v0 = new String[1];
        v0[0] = p4.g();
        this.b(java.util.Arrays.asList(v0), p5);
        return;
    }
     void a(java.util.List p13, com.tencent.wxop.stat.h p14)
    {
        v2 = 0;
        if ((p13 != 0) && (p13.isEmpty() == 0)) {
            v3 = p13.size();
            p13.get(0);
            this.c.delete(0, this.c.length());
            this.c.append("[");
            v0 = 0;
            while (v0 < v3) {
                this.c.append(p13.get(v0).toString());
                if (v0 != (v3 - 1)) {
                    this.c.append(",");
                }
                v0++;
            }
            this.c.append("]");
            v0 = this.c.toString();
            v3 = v0.length();
            v5 = new StringBuilder().append(com.tencent.wxop.stat.StatConfig.getStatReportUrl()).append("/?index=").append(this.g).toString();
            this.g = (this.g + 1.0);
            if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
                com.tencent.wxop.stat.i.d.i(new StringBuilder("[").append(v5).append("]Send request(").append(v3).append("bytes), content:").append(v0).toString());
            }
            v6 = new org.apache.http.client.methods.HttpPost(v5);
            v6.addHeader("Accept-Encoding", "gzip");
            v6.setHeader("Connection", "Keep-Alive");
            v6.removeHeaders("Cache-Control");
            v5 = com.tencent.wxop.stat.a.a(com.tencent.wxop.stat.i.f).a();
            v6.addHeader("Content-Encoding", "rc4");
            if (v5 != 0) {
                if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
                    com.tencent.wxop.stat.i.d.d(new StringBuilder("proxy:").append(v5.toHostString()).toString());
                }
                v6.addHeader("X-Content-Encoding", "rc4");
                this.a.getParams().setParameter("http.route.default-proxy", v5);
                v6.addHeader("X-Online-Host", com.tencent.wxop.stat.StatConfig.k);
                v6.addHeader("Accept", "*/*");
                v6.addHeader("Content-Type", "json");
            } else {
                this.a.getParams().removeParameter("http.route.default-proxy");
            }
            v7 = new java.io.ByteArrayOutputStream(v3);
            v0 = v0.getBytes("UTF-8");
            v8 = v0.length;
            if (v3 > com.tencent.wxop.stat.StatConfig.o) {
                v2 = 1;
            }
            if (v2 != 0) {
                v6.removeHeaders("Content-Encoding");
                v2 = new StringBuilder().append("rc4").append(",gzip").toString();
                v6.addHeader("Content-Encoding", v2);
                if (v5 != 0) {
                    v6.removeHeaders("X-Content-Encoding");
                    v6.addHeader("X-Content-Encoding", v2);
                }
                v2 = new byte[4];
                v7.write(v2);
                v2 = new java.util.zip.GZIPOutputStream(v7);
                v2.write(v0);
                v2.close();
                v0 = v7.toByteArray();
                java.nio.ByteBuffer.wrap(v0, 0, 4).putInt(v8);
                if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
                    com.tencent.wxop.stat.i.d.d(new StringBuilder("before Gzip:").append(v8).append(" bytes, after Gzip:").append(v0.length).append(" bytes").toString());
                }
            }
            v6.setEntity(new org.apache.http.entity.ByteArrayEntity(com.tencent.wxop.stat.common.f.a(v0)));
            v2 = this.a.execute(v6);
            v0 = v2.getEntity();
            v3 = v2.getStatusLine().getStatusCode();
            v4 = v0.getContentLength();
            if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
                com.tencent.wxop.stat.i.d.i(new StringBuilder("http recv response status code:").append(v3).append(", content length:").append(v4).toString());
            }
            if (v4 > 0.0) {
                if (v4 <= 0.0) {
                    org.apache.http.util.EntityUtils.toString(v0);
                } else {
                    v4 = v0.getContent();
                    v5 = new java.io.DataInputStream(v4);
                    v0 = new byte[((int) v0.getContentLength())];
                    v5.readFully(v0);
                    v4.close();
                    v5.close();
                    v2 = v2.getFirstHeader("Content-Encoding");
                    if (v2 != 0) {
                        if (v2.getValue().equalsIgnoreCase("gzip,rc4") == 0) {
                            if (v2.getValue().equalsIgnoreCase("rc4,gzip") == 0) {
                                if (v2.getValue().equalsIgnoreCase("gzip") == 0) {
                                    if (v2.getValue().equalsIgnoreCase("rc4") != 0) {
                                        v0 = com.tencent.wxop.stat.common.f.b(v0);
                                    }
                                } else {
                                    v0 = com.tencent.wxop.stat.common.k.a(v0);
                                }
                            } else {
                                v0 = com.tencent.wxop.stat.common.k.a(com.tencent.wxop.stat.common.f.b(v0));
                            }
                        } else {
                            v0 = com.tencent.wxop.stat.common.f.b(com.tencent.wxop.stat.common.k.a(v0));
                        }
                    }
                    v2 = new String(v0, "UTF-8");
                    if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
                        com.tencent.wxop.stat.i.d.i(new StringBuilder("http get response data:").append(v2).toString());
                    }
                    v5 = new org.json.JSONObject(v2);
                    if (v3 != 200) {
                        com.tencent.wxop.stat.i.d.error(new StringBuilder("Server response error code:").append(v3).append(", error:").append(new String(v0, "UTF-8")).toString());
                        if (p14 != 0) {
                            p14.b();
                        }
                    } else {
                        this.a(v5);
                        if (p14 != 0) {
                            if (v5.optInt("ret") != 0) {
                                com.tencent.wxop.stat.i.d.error("response error data.");
                                p14.b();
                            } else {
                                p14.a();
                            }
                        }
                    }
                    v4.close();
                }
                v7.close();
                if (0 != 0) {
                    com.tencent.wxop.stat.i.d.error(0);
                    if (p14 != 0) {
                        p14.b();
                    }
                    if ((0 instanceof OutOfMemoryError) != 0) {
                        System.gc();
                        this.c = 0;
                        this.c = new StringBuilder(2048);
                    }
                    com.tencent.wxop.stat.a.a(com.tencent.wxop.stat.i.f).d();
                }
            } else {
                com.tencent.wxop.stat.i.d.e("Server response no data.");
                if (p14 != 0) {
                    p14.b();
                }
                org.apache.http.util.EntityUtils.toString(v0);
            }
        }
        return;
    }
    private void a(org.json.JSONObject p8)
    {
        v0 = p8.optString("mid");
        if (com.tencent.a.a.a.a.h.c(v0) != 0) {
            if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
                com.tencent.wxop.stat.i.d.i(new StringBuilder("update mid:").append(v0).toString());
            }
            com.tencent.a.a.a.a.g.E(com.tencent.wxop.stat.i.f).a(v0);
        }
        if (p8.isNull("cfg") == 0) {
            com.tencent.wxop.stat.StatConfig.a(com.tencent.wxop.stat.i.f, p8.getJSONObject("cfg"));
        }
        if (p8.isNull("ncts") == 0) {
            v0 = p8.getInt("ncts");
            v1 = ((int) (((long) v0) - (System.currentTimeMillis() / 1000.0)));
            if (com.tencent.wxop.stat.StatConfig.isDebugEnable() != 0) {
                com.tencent.wxop.stat.i.d.i(new StringBuilder("server time:").append(v0).append(", diff time:").append(v1).toString());
            }
            com.tencent.wxop.stat.common.k.z(com.tencent.wxop.stat.i.f);
            com.tencent.wxop.stat.common.k.a(com.tencent.wxop.stat.i.f, v1);
        }
        return;
    }
    static com.tencent.wxop.stat.i b(android.content.Context p2)
    {
        if ((com.tencent.wxop.stat.i.e == 0) && (com.tencent.wxop.stat.i.e == 0)) {
            com.tencent.wxop.stat.i.e = new com.tencent.wxop.stat.i(p2);
        }
        return com.tencent.wxop.stat.i.e;
    }
     void b(java.util.List p3, com.tencent.wxop.stat.h p4)
    {
        if (this.b != 0) {
            this.b.a(new com.tencent.wxop.stat.k(this, p3, p4));
        }
        return;
    }
}
