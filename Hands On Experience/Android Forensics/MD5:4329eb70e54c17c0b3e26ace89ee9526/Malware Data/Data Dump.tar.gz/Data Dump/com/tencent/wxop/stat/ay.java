package com.tencent.wxop.stat;
 class ay implements java.lang.Runnable {
    final synthetic com.tencent.wxop.stat.a.e a;
    final synthetic boolean c;
    final synthetic com.tencent.wxop.stat.h b;
    final synthetic com.tencent.wxop.stat.au e;
    final synthetic boolean d;
     ay(com.tencent.wxop.stat.au p1, com.tencent.wxop.stat.a.e p2, com.tencent.wxop.stat.h p3, boolean p4, boolean p5)
    {
        this.e = p1;
        this.a = p2;
        this.b = p3;
        this.c = p4;
        this.d = p5;
        return;
    }
    public void run()
    {
        com.tencent.wxop.stat.au.a(this.e, this.a, this.b, this.c, this.d);
        return;
    }
}
