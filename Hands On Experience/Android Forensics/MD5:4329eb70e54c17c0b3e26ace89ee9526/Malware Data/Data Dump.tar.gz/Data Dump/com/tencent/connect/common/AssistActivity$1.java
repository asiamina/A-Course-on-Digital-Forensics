package com.tencent.connect.common;
 class AssistActivity$1 extends android.os.Handler {
    final synthetic com.tencent.connect.common.AssistActivity this$0;
     AssistActivity$1(com.tencent.connect.common.AssistActivity p1)
    {
        this.this$0 = p1;
        return;
    }
    public void handleMessage(android.os.Message p3)
    {
        switch (p3.what) {
            case 0:
                if (this.this$0.isFinishing() != 0) {
                } else {
                    com.tencent.open.a.f.d("openSDK_LOG.AssistActivity", "-->finish by timeout");
                    this.this$0.finish();
                }
                break;
        }
        return;
    }
}
