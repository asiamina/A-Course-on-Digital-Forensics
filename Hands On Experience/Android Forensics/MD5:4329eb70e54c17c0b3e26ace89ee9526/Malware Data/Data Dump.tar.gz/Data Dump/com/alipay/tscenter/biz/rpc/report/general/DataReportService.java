package com.alipay.tscenter.biz.rpc.report.general;
public interface abstract class DataReportService {
    abstract public com.alipay.tscenter.biz.rpc.report.general.model.DataReportResult reportData();
}
