package com.alipay.android.phone.mrpc.core;
final public class k {
    final private static java.util.regex.Pattern a;
    final private static java.util.regex.Pattern b;
    static k()
    {
        com.alipay.android.phone.mrpc.core.k.a = java.util.regex.Pattern.compile("([0-9]{1,2})[- ]([A-Za-z]{3,9})[- ]([0-9]{2,4})[ ]([0-9]{1,2}:[0-9][0-9]:[0-9][0-9])");
        com.alipay.android.phone.mrpc.core.k.b = java.util.regex.Pattern.compile("[ ]([A-Za-z]{3,9})[ ]+([0-9]{1,2})[ ]([0-9]{1,2}:[0-9][0-9]:[0-9][0-9])[ ]([0-9]{2,4})");
        return;
    }
    public static long a(String p9)
    {
        v4 = 1;
        v0 = com.alipay.android.phone.mrpc.core.k.a.matcher(p9);
        if (v0.find() == 0) {
            v2 = com.alipay.android.phone.mrpc.core.k.b.matcher(p9);
            if (v2.find() == 0) {
                throw new IllegalArgumentException();
            } else {
                v5 = com.alipay.android.phone.mrpc.core.k.c(v2.group(1));
                v1 = com.alipay.android.phone.mrpc.core.k.b(v2.group(2));
                v0 = com.alipay.android.phone.mrpc.core.k.e(v2.group(3));
                v6 = com.alipay.android.phone.mrpc.core.k.d(v2.group(4));
                v3 = v0;
                v0 = v1;
            }
        } else {
            v1 = com.alipay.android.phone.mrpc.core.k.b(v0.group(1));
            v5 = com.alipay.android.phone.mrpc.core.k.c(v0.group(2));
            v6 = com.alipay.android.phone.mrpc.core.k.d(v0.group(3));
            v3 = com.alipay.android.phone.mrpc.core.k.e(v0.group(4));
            v0 = v1;
        }
        if (v6 < 2038) {
            v4 = v0;
        } else {
            v6 = 2038;
            v5 = 0;
        }
        v0 = new android.text.format.Time("UTC");
        v0.set(v3.c, v3.b, v3.a, v4, v5, v6);
        return v0.toMillis(0);
    }
    private static int b(String p3)
    {
        if (p3.length() != 2) {
            v0 = (p3.charAt(0) - 48);
        } else {
            v0 = (((p3.charAt(0) - 48) * 10) + (p3.charAt(1) - 48));
        }
        return v0;
    }
    private static int c(String p5)
    {
        v0 = 0;
        switch ((((Character.toLowerCase(p5.charAt(0)) + Character.toLowerCase(p5.charAt(1))) + Character.toLowerCase(p5.charAt(2))) + -291)) {
            case 9:
                v0 = 11;
                break;
            case 10:
                v0 = 1;
            case 22:
                break;
            case 26:
                v0 = 7;
                break;
            case 29:
                v0 = 2;
                break;
            case 32:
                v0 = 3;
                break;
            case 35:
                v0 = 9;
                break;
            case 36:
                v0 = 4;
                break;
            case 37:
                v0 = 8;
                break;
            case 40:
                v0 = 6;
                break;
            case 42:
                v0 = 5;
                break;
            case 48:
                v0 = 10;
                break;
            default:
                throw new IllegalArgumentException();
        }
        return v0;
    }
    private static int d(String p6)
    {
        if (p6.length() != 2) {
            if (p6.length() != 3) {
                if (p6.length() != 4) {
                    v0 = 1970;
                } else {
                    v0 = (((((p6.charAt(0) - 48) * 1000) + ((p6.charAt(1) - 48) * 100)) + ((p6.charAt(2) - 48) * 10)) + (p6.charAt(3) - 48));
                }
            } else {
                v0 = (((((p6.charAt(0) - 48) * 100) + ((p6.charAt(1) - 48) * 10)) + (p6.charAt(2) - 48)) + 1900);
            }
        } else {
            v0 = (((p6.charAt(0) - 48) * 10) + (p6.charAt(1) - 48));
            if (v0 < 70) {
                v0 += 2000;
            } else {
                v0 += 1900;
            }
        }
        return v0;
    }
    private static com.alipay.android.phone.mrpc.core.k$a e(String p4)
    {
        v0 = (p4.charAt(0) - 48);
        if (p4.charAt(1) == 58) {
            v1 = 1;
        } else {
            v1 = 2;
            v0 = ((v0 * 10) + (p4.charAt(1) - 48));
        }
        v1++;
        v2 = (v1 + 1);
        v3 = (v2 + 1);
        v1 = (((p4.charAt(v1) - 48) * 10) + (p4.charAt(v2) - 48));
        v2 = (v3 + 1);
        return new com.alipay.android.phone.mrpc.core.k$a(v0, v1, (((p4.charAt(v2) - 48) * 10) + (p4.charAt((v2 + 1)) - 48)));
    }
}
