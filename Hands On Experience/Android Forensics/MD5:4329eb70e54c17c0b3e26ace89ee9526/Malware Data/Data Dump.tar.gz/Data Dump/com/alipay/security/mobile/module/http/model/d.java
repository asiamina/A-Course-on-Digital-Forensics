package com.alipay.security.mobile.module.http.model;
final public class d {
    public String a;
    public String c;
    public String b;
    public String e;
    public String d;
    public String g;
    public java.util.Map f;
    public String i;
    public String h;
    public String j;
    public d()
    {
        return;
    }
    private String a()
    {
        return this.j;
    }
    private void a(String p1)
    {
        this.j = p1;
        return;
    }
    private void a(java.util.Map p1)
    {
        this.f = p1;
        return;
    }
    private String b()
    {
        return com.alipay.security.mobile.module.a.a.d(this.a);
    }
    private void b(String p1)
    {
        this.a = p1;
        return;
    }
    private String c()
    {
        return com.alipay.security.mobile.module.a.a.d(this.b);
    }
    private void c(String p1)
    {
        this.b = p1;
        return;
    }
    private String d()
    {
        return com.alipay.security.mobile.module.a.a.d(this.c);
    }
    private void d(String p1)
    {
        this.c = p1;
        return;
    }
    private String e()
    {
        return com.alipay.security.mobile.module.a.a.d(this.d);
    }
    private void e(String p1)
    {
        this.d = p1;
        return;
    }
    private java.util.Map f()
    {
        if (this.f != 0) {
            v0 = this.f;
        } else {
            v0 = new java.util.HashMap();
        }
        return v0;
    }
    private void f(String p1)
    {
        this.e = p1;
        return;
    }
    private String g()
    {
        return this.e;
    }
    private void g(String p1)
    {
        this.g = p1;
        return;
    }
    private String h()
    {
        return this.g;
    }
    private void h(String p1)
    {
        this.h = p1;
        return;
    }
    private String i()
    {
        return this.h;
    }
    private void i(String p1)
    {
        this.i = p1;
        return;
    }
    private String j()
    {
        return this.i;
    }
}
