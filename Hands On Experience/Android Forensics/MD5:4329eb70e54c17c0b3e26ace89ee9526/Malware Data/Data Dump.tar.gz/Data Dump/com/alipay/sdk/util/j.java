package com.alipay.sdk.util;
final public class j {
    final public static String a;
    final public static String c;
    final public static String b;
    public static java.util.Map a(String p4)
    {
        v1 = com.alipay.sdk.app.j.a(com.alipay.sdk.app.j.c.h);
        v0 = new java.util.HashMap();
        v0.put("resultStatus", Integer.toString(v1.h));
        v0.put("memo", v1.i);
        v0.put("result", "");
        return com.alipay.sdk.util.j.b(p4);
    }
    private static java.util.Map b(String p9)
    {
        v2 = p9.split(";");
        v3 = new java.util.HashMap();
        v4 = v2.length;
        v0 = 0;
        while (v0 < v4) {
            v5 = v2[v0];
            v6 = v5.substring(0, v5.indexOf("={"));
            v7 = new StringBuilder().append(v6).append("={").toString();
            v3.put(v6, v5.substring((v7.length() + v8), v5.lastIndexOf(v5.indexOf(v7))));
            v0++;
        }
        return v3;
    }
    public j()
    {
        return;
    }
    private static String a(String p2, String p3)
    {
        v0 = new StringBuilder().append(p3).append("={").toString();
        return p2.substring((v0.length() + p2.indexOf(v0)), p2.lastIndexOf("}"));
    }
    private static java.util.Map a()
    {
        v0 = com.alipay.sdk.app.j.a(com.alipay.sdk.app.j.c.h);
        v1 = new java.util.HashMap();
        v1.put("resultStatus", Integer.toString(v0.h));
        v1.put("memo", v0.i);
        v1.put("result", "");
        return v1;
    }
}
