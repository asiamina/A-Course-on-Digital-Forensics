package com.alipay.apmobilesecuritysdk.common;
final class RushTimeUtil$1 extends java.util.ArrayList {
     RushTimeUtil$1()
    {
        this.add("2018-06-17&2018-06-18");
        this.add("2018-09-08&2018-09-09");
        this.add("2018-11-10&2018-11-11");
        this.add("2018-12-11&2018-12-12");
        this.add("2019-06-17&2019-06-18");
        this.add("2019-09-08&2019-09-09");
        this.add("2019-11-10&2019-11-11");
        this.add("2019-12-11&2019-12-12");
        this.add("2020-06-17&2020-06-18");
        this.add("2020-09-08&2020-09-09");
        this.add("2020-11-10&2020-11-11");
        this.add("2020-12-11&2020-12-12");
        this.add("2021-06-17&2021-06-18");
        this.add("2021-09-08&2021-09-09");
        this.add("2021-11-10&2021-11-11");
        this.add("2021-12-11&2021-12-12");
        this.add("2022-06-17&2022-06-18");
        this.add("2022-09-08&2022-09-09");
        this.add("2022-11-10&2022-11-11");
        this.add("2022-12-11&2022-12-12");
        return;
    }
}
