package com.alipay.android.phone.mrpc.core;
final public class r {
    public static void a(java.io.Closeable p1)
    {
        if (p1 != 0) {
            p1.close();
        }
        return;
    }
}
