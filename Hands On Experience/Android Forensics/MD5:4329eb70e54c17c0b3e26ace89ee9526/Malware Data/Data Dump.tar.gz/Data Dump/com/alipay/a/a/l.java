package com.alipay.a.a;
final public class l implements com.alipay.a.a.i, com.alipay.a.a.j {
    public final Object a(Object p1)
    {
        return p1;
    }
    public final Object a(Object p1, reflect.Type p2)
    {
        return p1;
    }
    public final boolean a(Class p2)
    {
        return com.alipay.a.b.a.a(p2);
    }
    public l()
    {
        return;
    }
}
