package com.alipay.sdk.data;
final class b implements java.lang.Runnable {
    final synthetic android.content.Context a;
    final synthetic com.alipay.sdk.data.a b;
     b(com.alipay.sdk.data.a p1, android.content.Context p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }
    public final void run()
    {
        v1 = this.a;
        v0 = new com.alipay.sdk.packet.impl.b().a(v1, "", com.alipay.sdk.util.k.a(v1), 1);
        if (v0 != 0) {
            v1 = this.b;
            v0 = v0.b;
            if (android.text.TextUtils.isEmpty(v0) == 0) {
                v0 = new org.json.JSONObject(v0).optJSONObject("st_sdk_config");
                v1.i = v0.optInt("timeout", 3500);
                v1.j = v0.optString("tbreturl", "http://h5.m.taobao.com/trade/paySuccess.html?bizOrderId=$OrderId$&").trim();
            }
            v0 = this.b;
            v1 = new org.json.JSONObject();
            v1.put("timeout", v0.a());
            v1.put("tbreturl", v0.j);
            com.alipay.sdk.util.i.a(com.alipay.sdk.sys.b.a().a, "alipay_cashier_dynamic_config", v1.toString());
        }
        return;
    }
}
