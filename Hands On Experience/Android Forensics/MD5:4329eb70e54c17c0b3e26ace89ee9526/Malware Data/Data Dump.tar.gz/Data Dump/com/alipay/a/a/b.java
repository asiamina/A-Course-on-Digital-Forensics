package com.alipay.a.a;
final public class b implements com.alipay.a.a.i, com.alipay.a.a.j {
    public final boolean a(Class p2)
    {
        return java.util.Collection.isAssignableFrom(p2);
    }
    public b()
    {
        return;
    }
    public final Object a(Object p4)
    {
        v0 = new java.util.ArrayList();
        v1 = p4.iterator();
        while (v1.hasNext() != 0) {
            v0.add(com.alipay.a.a.f.b(v1.next()));
        }
        return v0;
    }
    public final Object a(Object p5, reflect.Type p6)
    {
        v0 = 0;
        if (p5.getClass().equals(org.json.alipay.a) != 0) {
            v1 = com.alipay.a.a.b.a(com.alipay.a.b.a.a(p6), p6);
            if ((p6 instanceof reflect.ParameterizedType) == 0) {
                throw new IllegalArgumentException("Does not support the implement for generics.");
            }
            while (v0 < p5.a()) {
                v1.add(com.alipay.a.a.e.a(p5.a(v0), p6.getActualTypeArguments()[0]));
                v0++;
            }
            v0 = v1;
        } else {
            v0 = 0;
        }
        return v0;
    }
    private static java.util.Collection a(Class p3, reflect.Type p4)
    {
        if (p3 != java.util.AbstractCollection) {
            if (p3.isAssignableFrom(java.util.HashSet) == 0) {
                if (p3.isAssignableFrom(java.util.LinkedHashSet) == 0) {
                    if (p3.isAssignableFrom(java.util.TreeSet) == 0) {
                        if (p3.isAssignableFrom(java.util.ArrayList) == 0) {
                            if (p3.isAssignableFrom(java.util.EnumSet) == 0) {
                                v0 = p3.newInstance();
                            } else {
                                if ((p4 instanceof reflect.ParameterizedType) == 0) {
                                    v0 = Object;
                                } else {
                                    v0 = p4.getActualTypeArguments()[0];
                                }
                                v0 = java.util.EnumSet.noneOf(v0);
                            }
                        } else {
                            v0 = new java.util.ArrayList();
                        }
                    } else {
                        v0 = new java.util.TreeSet();
                    }
                } else {
                    v0 = new java.util.LinkedHashSet();
                }
            } else {
                v0 = new java.util.HashSet();
            }
        } else {
            v0 = new java.util.ArrayList();
        }
        return v0;
    }
}
