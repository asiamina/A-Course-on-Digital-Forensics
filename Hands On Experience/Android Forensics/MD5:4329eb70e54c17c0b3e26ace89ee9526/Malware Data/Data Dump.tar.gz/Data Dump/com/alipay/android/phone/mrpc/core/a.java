package com.alipay.android.phone.mrpc.core;
public abstract class a implements com.alipay.android.phone.mrpc.core.v {
    protected reflect.Method a;
    protected String c;
    protected byte[] b;
    protected String e;
    protected int d;
    protected boolean f;
    public a(reflect.Method p1, int p2, String p3, byte[] p4, String p5, boolean p6)
    {
        this.a = p1;
        this.d = p2;
        this.c = p3;
        this.b = p4;
        this.e = p5;
        this.f = p6;
        return;
    }
}
