package com.alipay.sdk.widget;
final class b implements java.lang.Runnable {
    final synthetic com.alipay.sdk.widget.a a;
     b(com.alipay.sdk.widget.a p1)
    {
        this.a = p1;
        return;
    }
    public final void run()
    {
        if (com.alipay.sdk.widget.a.c(this.a) == 0) {
            com.alipay.sdk.widget.a.a(this.a, new com.alipay.sdk.widget.a$a(this.a, com.alipay.sdk.widget.a.a(this.a)));
            com.alipay.sdk.widget.a.c(this.a).setCancelable(com.alipay.sdk.widget.a.d(this.a));
        }
        if (com.alipay.sdk.widget.a.c(this.a).isShowing() == 0) {
            com.alipay.sdk.widget.a.c(this.a).show();
        }
        return;
    }
}
