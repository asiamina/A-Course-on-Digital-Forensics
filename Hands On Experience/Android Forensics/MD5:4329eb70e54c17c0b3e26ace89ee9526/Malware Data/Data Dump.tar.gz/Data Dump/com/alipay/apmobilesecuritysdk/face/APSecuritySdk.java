package com.alipay.apmobilesecuritysdk.face;
public class APSecuritySdk {
    private static com.alipay.apmobilesecuritysdk.face.APSecuritySdk a;
    private static Object c;
    private android.content.Context b;
    static APSecuritySdk()
    {
        com.alipay.apmobilesecuritysdk.face.APSecuritySdk.c = new Object();
        return;
    }
    private APSecuritySdk(android.content.Context p1)
    {
        this.b = p1;
        return;
    }
    static synthetic android.content.Context a(com.alipay.apmobilesecuritysdk.face.APSecuritySdk p1)
    {
        return p1.b;
    }
    public String getApdidToken()
    {
        v0 = com.alipay.apmobilesecuritysdk.a.a.a(this.b, "");
        if (com.alipay.security.mobile.module.a.a.a(v0) != 0) {
            this.initToken(0, new java.util.HashMap(), 0);
        }
        return v0;
    }
    public static com.alipay.apmobilesecuritysdk.face.APSecuritySdk getInstance(android.content.Context p2)
    {
        if ((com.alipay.apmobilesecuritysdk.face.APSecuritySdk.a == 0) && (com.alipay.apmobilesecuritysdk.face.APSecuritySdk.a == 0)) {
            com.alipay.apmobilesecuritysdk.face.APSecuritySdk.a = new com.alipay.apmobilesecuritysdk.face.APSecuritySdk(p2);
        }
        return com.alipay.apmobilesecuritysdk.face.APSecuritySdk.a;
    }
    public String getSdkName()
    {
        return "APPSecuritySDK-ALIPAY";
    }
    public String getSdkVersion()
    {
        return "3.2.2-20180403";
    }
    public synchronized com.alipay.apmobilesecuritysdk.face.APSecuritySdk$TokenResult getTokenResult()
    {
        v0 = 0;
        v1 = new com.alipay.apmobilesecuritysdk.face.APSecuritySdk$TokenResult(this);
        v1.apdidToken = com.alipay.apmobilesecuritysdk.a.a.a(this.b, "");
        v1.clientKey = com.alipay.apmobilesecuritysdk.e.h.f(this.b);
        v1.apdid = com.alipay.apmobilesecuritysdk.a.a.a(this.b);
        v1.umidToken = com.alipay.apmobilesecuritysdk.otherid.UmidSdkWrapper.getSecurityToken(this.b);
        if (com.alipay.security.mobile.module.a.a.a(v1.apdid) != 0) {
            v0 = 1;
        }
        if ((v0 != 0) || ((com.alipay.security.mobile.module.a.a.a(v1.apdidToken) != 0) || (com.alipay.security.mobile.module.a.a.a(v1.clientKey) != 0))) {
            this.initToken(0, new java.util.HashMap(), 0);
        }
        return v1;
    }
    public static String getUtdid(android.content.Context p1)
    {
        return com.alipay.apmobilesecuritysdk.otherid.UtdidWrapper.getUtdid(p1);
    }
    public void initToken(int p6, java.util.Map p7, com.alipay.apmobilesecuritysdk.face.APSecuritySdk$InitResultListener p8)
    {
        com.alipay.apmobilesecuritysdk.b.a.a().a(p6);
        v0 = com.alipay.apmobilesecuritysdk.e.h.b(this.b);
        v1 = com.alipay.apmobilesecuritysdk.b.a.a().c();
        if ((com.alipay.security.mobile.module.a.a.b(v0) != 0) && (com.alipay.security.mobile.module.a.a.a(v0, v1) == 0)) {
            com.alipay.apmobilesecuritysdk.e.a.b(this.b);
            com.alipay.apmobilesecuritysdk.e.d.a(this.b);
            com.alipay.apmobilesecuritysdk.e.g.a(this.b);
            com.alipay.apmobilesecuritysdk.e.i.h();
        }
        if (com.alipay.security.mobile.module.a.a.a(v0, v1) == 0) {
            com.alipay.apmobilesecuritysdk.e.h.c(this.b, v1);
        }
        v0 = com.alipay.security.mobile.module.a.a.a(p7, "utdid", "");
        v1 = com.alipay.security.mobile.module.a.a.a(p7, "tid", "");
        v2 = com.alipay.security.mobile.module.a.a.a(p7, "userId", "");
        if (com.alipay.security.mobile.module.a.a.a(v0) != 0) {
            v0 = com.alipay.apmobilesecuritysdk.otherid.UtdidWrapper.getUtdid(this.b);
        }
        v3 = new java.util.HashMap();
        v3.put("utdid", v0);
        v3.put("tid", v1);
        v3.put("userId", v2);
        v3.put("appName", "");
        v3.put("appKeyClient", "");
        v3.put("appchannel", "");
        v3.put("rpcVersion", "8");
        com.alipay.apmobilesecuritysdk.f.b.a().a(new com.alipay.apmobilesecuritysdk.face.APSecuritySdk$1(this, v3, p8));
        return;
    }
}
