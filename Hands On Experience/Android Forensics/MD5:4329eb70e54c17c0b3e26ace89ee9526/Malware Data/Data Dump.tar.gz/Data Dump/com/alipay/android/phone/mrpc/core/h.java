package com.alipay.android.phone.mrpc.core;
final public class h extends com.alipay.android.phone.mrpc.core.w {
    private android.content.Context a;
    public h(android.content.Context p1)
    {
        this.a = p1;
        return;
    }
    static synthetic android.content.Context a(com.alipay.android.phone.mrpc.core.h p1)
    {
        return p1.a;
    }
    public final Object a(Class p3, com.alipay.android.phone.mrpc.core.aa p4)
    {
        return new com.alipay.android.phone.mrpc.core.x(new com.alipay.android.phone.mrpc.core.i(this, p4)).a(p3);
    }
}
