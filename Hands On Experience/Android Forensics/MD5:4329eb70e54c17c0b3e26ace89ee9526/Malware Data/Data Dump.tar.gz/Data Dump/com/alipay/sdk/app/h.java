package com.alipay.sdk.app;
final class h implements com.alipay.sdk.util.e$a {
    final synthetic com.alipay.sdk.app.PayTask a;
     h(com.alipay.sdk.app.PayTask p1)
    {
        this.a = p1;
        return;
    }
    public final void a()
    {
        com.alipay.sdk.app.PayTask.a(this.a);
        return;
    }
}
