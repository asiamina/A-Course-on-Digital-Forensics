package com.alipay.android.app;
public interface abstract class IAlixPay implements android.os.IInterface {
    abstract public String prePay();
    abstract public void registerCallback();
    abstract public String test();
    abstract public void unregisterCallback();
    abstract public String Pay();
}
