package com.alipay.android.phone.mrpc.core;
final class k$a {
     int a;
     int c;
     int b;
     k$a(int p1, int p2, int p3)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        return;
    }
}
