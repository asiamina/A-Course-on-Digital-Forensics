package com.alipay.apmobilesecuritysdk.e;
final public class c {
    private String a;
    private String c;
    private String b;
    private String e;
    private String d;
    public c(String p2, String p3, String p4, String p5, String p6)
    {
        this.a = "";
        this.b = "";
        this.c = "";
        this.d = "";
        this.e = "";
        this.a = p2;
        this.b = p3;
        this.c = p4;
        this.d = p5;
        this.e = p6;
        return;
    }
    public final String a()
    {
        return this.a;
    }
    public final String b()
    {
        return this.b;
    }
    public final String c()
    {
        return this.c;
    }
    public final String d()
    {
        return this.d;
    }
    public final String e()
    {
        return this.e;
    }
}
