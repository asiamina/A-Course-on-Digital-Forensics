package com.alipay.apmobilesecuritysdk.d;
final public class b {
    public static synchronized java.util.Map a(android.content.Context p11, java.util.Map p12)
    {
        v0 = new java.util.HashMap();
        v2 = com.alipay.security.mobile.module.a.a.a(p12, "tid", "");
        v3 = com.alipay.security.mobile.module.a.a.a(p12, "utdid", "");
        v4 = com.alipay.security.mobile.module.a.a.a(p12, "userId", "");
        v5 = com.alipay.security.mobile.module.a.a.a(p12, "appName", "");
        v6 = com.alipay.security.mobile.module.a.a.a(p12, "appKeyClient", "");
        v7 = com.alipay.security.mobile.module.a.a.a(p12, "tmxSessionId", "");
        v8 = com.alipay.apmobilesecuritysdk.e.h.f(p11);
        v9 = com.alipay.security.mobile.module.a.a.a(p12, "sessionId", "");
        v0.put("AC1", v2);
        v0.put("AC2", v3);
        v0.put("AC3", "");
        v0.put("AC4", v8);
        v0.put("AC5", v4);
        v0.put("AC6", v7);
        v0.put("AC7", "");
        v0.put("AC8", v5);
        v0.put("AC9", v6);
        if (com.alipay.security.mobile.module.a.a.b(v9) != 0) {
            v0.put("AC10", v9);
        }
        return v0;
    }
}
