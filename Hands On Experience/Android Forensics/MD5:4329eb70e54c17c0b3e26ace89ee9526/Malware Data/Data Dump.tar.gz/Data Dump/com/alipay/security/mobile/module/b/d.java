package com.alipay.security.mobile.module.b;
final public class d {
    private static com.alipay.security.mobile.module.b.d a;
    static d()
    {
        com.alipay.security.mobile.module.b.d.a = new com.alipay.security.mobile.module.b.d();
        return;
    }
    private d()
    {
        return;
    }
    public static com.alipay.security.mobile.module.b.d a()
    {
        return com.alipay.security.mobile.module.b.d.a;
    }
    private static String a(String p5, String p6)
    {
        v0 = Class.forName("android.os.SystemProperties");
        v2 = new Class[2];
        v2[0] = String;
        v2[1] = String;
        v0 = v0.getMethod("get", v2);
        v2 = new Object[2];
        v2[0] = p5;
        v2[1] = p6;
        return v0.invoke(0, v2);
    }
    public static boolean a(android.content.Context p7)
    {
        if ((android.os.Build.HARDWARE.contains("goldfish") == 0) && ((android.os.Build.PRODUCT.contains("sdk") == 0) && (android.os.Build.FINGERPRINT.contains("generic") == 0))) {
            v0 = p7.getSystemService("phone");
            if (v0 != 0) {
                v3 = v0.getDeviceId();
                if (v3 == 0) {
                    v0 = 1;
                } else {
                    v4 = v3.length();
                    if (v4 != 0) {
                        v0 = 0;
                        while (v0 < v4) {
                            if ((Character.isWhitespace(v3.charAt(v0)) != 0) || (v3.charAt(v0) == 48)) {
                                v0++;
                            } else {
                                v0 = 0;
                            }
                        }
                        v0 = 1;
                    }
                }
                if (v0 != 0) {
                    v0 = 1;
                    return v0;
                }
            }
            v0 = com.alipay.security.mobile.module.a.a.a(android.provider.Settings$Secure.getString(p7.getContentResolver(), "android_id"));
        } else {
            v0 = 1;
        }
    }
    public static String b()
    {
        return "android";
    }
    public static boolean c()
    {
        v0 = 1;
        v3 = new String[5];
        v3[0] = "/system/bin/";
        v3[1] = "/system/xbin/";
        v3[2] = "/system/sbin/";
        v3[3] = "/sbin/";
        v3[4] = "/vendor/bin/";
        v2 = 0;
        while (v2 < 5) {
            if (new java.io.File(new StringBuilder().append(v3[v2]).append("su").toString()).exists() == 0) {
                v2++;
            }
            return v0;
        }
        v0 = 0;
    }
    public static String d()
    {
        return android.os.Build.BOARD;
    }
    public static String e()
    {
        return android.os.Build.BRAND;
    }
    public static String f()
    {
        return android.os.Build.DEVICE;
    }
    public static String g()
    {
        return android.os.Build.DISPLAY;
    }
    public static String h()
    {
        return android.os.Build$VERSION.INCREMENTAL;
    }
    public static String i()
    {
        return android.os.Build.MANUFACTURER;
    }
    public static String j()
    {
        return android.os.Build.MODEL;
    }
    public static String k()
    {
        return android.os.Build.PRODUCT;
    }
    public static String l()
    {
        return android.os.Build$VERSION.RELEASE;
    }
    public static String m()
    {
        return android.os.Build$VERSION.SDK;
    }
    public static String n()
    {
        return android.os.Build.TAGS;
    }
    public static String o()
    {
        return com.alipay.security.mobile.module.b.d.a("ro.kernel.qemu", "0");
    }
}
