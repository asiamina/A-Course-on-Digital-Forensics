package com.alipay.apmobilesecuritysdk.c;
final public class a {
    public static synchronized void a(android.content.Context p6, String p7, String p8, String p9)
    {
        com.alipay.security.mobile.module.d.d.a(new StringBuilder().append(p6.getFilesDir().getAbsolutePath()).append("/log/ap").toString(), new StringBuilder().append(new java.text.SimpleDateFormat("yyyyMMdd").format(java.util.Calendar.getInstance().getTime())).append(".log").toString(), com.alipay.apmobilesecuritysdk.c.a.b(p6, p7, p8, p9).toString());
        return;
    }
    public static synchronized void a(String p2)
    {
        com.alipay.security.mobile.module.d.d.a(p2);
        return;
    }
    public static synchronized void a(Throwable p2)
    {
        com.alipay.security.mobile.module.d.d.a(p2);
        return;
    }
    private static com.alipay.security.mobile.module.d.a b(android.content.Context p8, String p9, String p10, String p11)
    {
        return new com.alipay.security.mobile.module.d.a(android.os.Build.MODEL, p8.getPackageName(), "APPSecuritySDK-ALIPAY", "3.2.2-20180403", p9, p10, p11);
    }
}
