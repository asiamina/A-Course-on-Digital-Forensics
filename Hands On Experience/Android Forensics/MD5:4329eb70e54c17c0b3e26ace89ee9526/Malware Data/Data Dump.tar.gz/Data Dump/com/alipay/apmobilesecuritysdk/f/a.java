package com.alipay.apmobilesecuritysdk.f;
public class a {
    public a()
    {
        return;
    }
    public static String a(android.content.Context p3, String p4, String p5)
    {
        v0 = 0;
        if ((p3 != 0) && ((com.alipay.security.mobile.module.a.a.a(p4) == 0) && (com.alipay.security.mobile.module.a.a.a(p5) == 0))) {
            v1 = com.alipay.security.mobile.module.c.e.a(p3, p4, p5, "");
            if (com.alipay.security.mobile.module.a.a.a(v1) == 0) {
                v0 = com.alipay.security.mobile.module.a.a.c.b(com.alipay.security.mobile.module.a.a.c.a(), v1);
            }
        }
        return v0;
    }
    public static String a(String p4, String p5)
    {
        v0 = 0;
        if ((com.alipay.security.mobile.module.a.a.a(p4) == 0) && (com.alipay.security.mobile.module.a.a.a(p5) == 0)) {
            v2 = com.alipay.security.mobile.module.c.b.a(p4);
            if (com.alipay.security.mobile.module.a.a.a(v2) == 0) {
                v2 = new org.json.JSONObject(v2).getString(p5);
                if (com.alipay.security.mobile.module.a.a.a(v2) == 0) {
                    v0 = com.alipay.security.mobile.module.a.a.c.b(com.alipay.security.mobile.module.a.a.c.a(), v2);
                }
            }
        }
        return v0;
    }
    public static void a(android.content.Context p2, String p3, String p4, String p5)
    {
        if ((com.alipay.security.mobile.module.a.a.a(p3) == 0) && ((com.alipay.security.mobile.module.a.a.a(p4) == 0) && (p2 != 0))) {
            v0 = com.alipay.security.mobile.module.a.a.c.a(com.alipay.security.mobile.module.a.a.c.a(), p5);
            v1 = new java.util.HashMap();
            v1.put(p4, v0);
            com.alipay.security.mobile.module.c.e.a(p2, p3, v1);
        }
        return;
    }
    public static void a(String p4, String p5, String p6)
    {
        if ((com.alipay.security.mobile.module.a.a.a(p4) == 0) && (com.alipay.security.mobile.module.a.a.a(p5) == 0)) {
            v2 = com.alipay.security.mobile.module.c.b.a(p4);
            v0 = new org.json.JSONObject();
            if (com.alipay.security.mobile.module.a.a.b(v2) != 0) {
                v0 = new org.json.JSONObject(v2);
            }
            v0.put(p5, com.alipay.security.mobile.module.a.a.c.a(com.alipay.security.mobile.module.a.a.c.a(), p6));
            v0.toString();
            System.clearProperty(p4);
            if (com.alipay.security.mobile.module.c.c.a() != 0) {
                v0 = new StringBuilder(".SystemConfig").append(java.io.File.separator).append(p4).toString();
                if (com.alipay.security.mobile.module.c.c.a() != 0) {
                    v2 = new java.io.File(android.os.Environment.getExternalStorageDirectory(), v0);
                    if ((v2.exists() != 0) && (v2.isFile() != 0)) {
                        v2.delete();
                    }
                }
            }
        }
        return;
    }
}
