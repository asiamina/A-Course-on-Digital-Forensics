package com.alipay.android.phone.mrpc.core.a;
public interface abstract class c {
    abstract public Object a();
}
