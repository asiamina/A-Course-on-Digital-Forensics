package com.alipay.sdk.auth;
final public class h {
    final private static String a;
    private static com.alipay.sdk.widget.a c;
    final private static int b;
    private static String d;
    static h()
    {
        com.alipay.sdk.auth.h.c = 0;
        com.alipay.sdk.auth.h.d = 0;
        return;
    }
    public h()
    {
        return;
    }
    static synthetic com.alipay.sdk.widget.a a()
    {
        return com.alipay.sdk.auth.h.c;
    }
    static synthetic String a(String p0)
    {
        com.alipay.sdk.auth.h.d = p0;
        return p0;
    }
    public static void a(android.app.Activity p3, com.alipay.sdk.auth.APAuthInfo p4)
    {
        v0 = com.alipay.sdk.sys.b.a();
        com.alipay.sdk.data.c.a();
        v0.a(p3);
        if (com.alipay.sdk.auth.h.a(p3) == 0) {
            if ((p3 != 0) && (p3.isFinishing() == 0)) {
                v0 = new com.alipay.sdk.widget.a(p3, "\u6b63\u5728\u52a0\u8f7d");
                com.alipay.sdk.auth.h.c = v0;
                v0.a();
            }
            v0 = new StringBuilder();
            v0.append("app_id=");
            v0.append(p4.getAppId());
            v0.append("&partner=");
            v0.append(p4.getPid());
            v0.append("&scope=kuaijie");
            v0.append("&login_goal=auth");
            v0.append("&redirect_url=");
            v0.append(p4.getRedirectUri());
            v0.append("&view=wap");
            v0.append("&prod_code=");
            v0.append(p4.getProductId());
            new Thread(new com.alipay.sdk.auth.i(p3, v0, p4)).start();
        } else {
            v0 = new StringBuilder();
            v0.append("alipayauth://platformapi/startapp");
            v0.append("?appId=20000122");
            v0.append("&approveType=005");
            v0.append("&scope=kuaijie");
            v0.append("&productId=");
            v0.append(p4.getProductId());
            v0.append("&thirdpartyId=");
            v0.append(p4.getAppId());
            v0.append("&redirectUri=");
            v0.append(p4.getRedirectUri());
            com.alipay.sdk.auth.h.a(p3, v0.toString());
        }
        return;
    }
    public static void a(android.app.Activity p2, String p3)
    {
        v0 = new android.content.Intent("android.intent.action.VIEW");
        v0.setData(android.net.Uri.parse(p3));
        p2.startActivity(v0);
        return;
    }
    private static boolean a(android.content.Context p4)
    {
        v0 = 0;
        v1 = p4.getPackageManager().getPackageInfo("com.eg.android.AlipayGphone", 128);
        if ((v1 != 0) && (v1.versionCode >= 65)) {
            v0 = 1;
        }
        return v0;
    }
    static synthetic com.alipay.sdk.widget.a b()
    {
        com.alipay.sdk.auth.h.c = 0;
        return 0;
    }
    private static void b(android.app.Activity p2, com.alipay.sdk.auth.APAuthInfo p3)
    {
        v0 = new StringBuilder();
        v0.append("alipayauth://platformapi/startapp");
        v0.append("?appId=20000122");
        v0.append("&approveType=005");
        v0.append("&scope=kuaijie");
        v0.append("&productId=");
        v0.append(p3.getProductId());
        v0.append("&thirdpartyId=");
        v0.append(p3.getAppId());
        v0.append("&redirectUri=");
        v0.append(p3.getRedirectUri());
        com.alipay.sdk.auth.h.a(p2, v0.toString());
        return;
    }
    static synthetic String c()
    {
        return com.alipay.sdk.auth.h.d;
    }
    private static void c(android.app.Activity p3, com.alipay.sdk.auth.APAuthInfo p4)
    {
        if ((p3 != 0) && (p3.isFinishing() == 0)) {
            v0 = new com.alipay.sdk.widget.a(p3, "\u6b63\u5728\u52a0\u8f7d");
            com.alipay.sdk.auth.h.c = v0;
            v0.a();
        }
        v0 = new StringBuilder();
        v0.append("app_id=");
        v0.append(p4.getAppId());
        v0.append("&partner=");
        v0.append(p4.getPid());
        v0.append("&scope=kuaijie");
        v0.append("&login_goal=auth");
        v0.append("&redirect_url=");
        v0.append(p4.getRedirectUri());
        v0.append("&view=wap");
        v0.append("&prod_code=");
        v0.append(p4.getProductId());
        new Thread(new com.alipay.sdk.auth.i(p3, v0, p4)).start();
        return;
    }
}
