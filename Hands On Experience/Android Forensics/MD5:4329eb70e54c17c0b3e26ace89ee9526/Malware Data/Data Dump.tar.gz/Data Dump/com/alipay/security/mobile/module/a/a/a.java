package com.alipay.security.mobile.module.a.a;
final public class a {
    private static char[] a;
    private static byte[] b;
    static a()
    {
        v0 = new char[64];
        v0 = {65, 0, 66, 0, 67, 0, 68, 0, 69, 0, 70, 0, 71, 0, 72, 0, 73, 0, 74, 0, 75, 0, 76, 0, 77, 0, 78, 0, 79, 0, 80, 0, 81, 0, 82, 0, 83, 0, 84, 0, 85, 0, 86, 0, 87, 0, 88, 0, 89, 0, 90, 0, 97, 0, 98, 0, 99, 0, 100, 0, 101, 0, 102, 0, 103, 0, 104, 0, 105, 0, 106, 0, 107, 0, 108, 0, 109, 0, 110, 0, 111, 0, 112, 0, 113, 0, 114, 0, 115, 0, 116, 0, 117, 0, 118, 0, 119, 0, 120, 0, 121, 0, 122, 0, 48, 0, 49, 0, 50, 0, 51, 0, 52, 0, 53, 0, 54, 0, 55, 0, 56, 0, 57, 0, 43, 0, 47, 0};
        com.alipay.security.mobile.module.a.a.a.a = v0;
        v0 = new byte[128];
        v0 = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 62, 255, 255, 255, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 255, 255, 255, 255, 255, 255, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 255, 255, 255, 255};
        com.alipay.security.mobile.module.a.a.a.b = v0;
        return;
    }
    public static byte[] a(String p9)
    {
        v2 = new StringBuffer();
        v3 = p9.getBytes("US-ASCII");
        v4 = v3.length;
        v0 = 0;
        while (v0 < v4) {
            while(true) {
                v1 = (v0 + 1);
                v5 = com.alipay.security.mobile.module.a.a.a.b[v3[v0]];
                if ((v1 >= v4) || (v5 != -1)) {
                    break;
                }
                v0 = v1;
            }
            if (v5 == -1) {
                break;
            }
            while(true) {
                v0 = (v1 + 1);
                v6 = com.alipay.security.mobile.module.a.a.a.b[v3[v1]];
                if ((v0 >= v4) || (v6 != -1)) {
                    break;
                }
                v1 = v0;
            }
            if (v6 == -1) {
                break;
            }
            v2.append(((char) ((v5 << 2) | ((v6 & 48) >> 4))));
            while(true) {
                v1 = (v0 + 1);
                v0 = v3[v0];
                if (v0 != 61) {
                    v5 = com.alipay.security.mobile.module.a.a.a.b[v0];
                    if ((v1 >= v4) || (v5 != -1)) {
                        break;
                    }
                    v0 = v1;
                } else {
                    v0 = v2.toString().getBytes("iso8859-1");
                }
                return v0;
            }
            if (v5 == -1) {
                break;
            }
            v2.append(((char) (((v6 & 15) << 4) | ((v5 & 60) >> 2))));
            while(true) {
                v0 = (v1 + 1);
                v1 = v3[v1];
                if (v1 != 61) {
                    v1 = com.alipay.security.mobile.module.a.a.a.b[v1];
                    if ((v0 >= v4) || (v1 != -1)) {
                        break;
                    }
                    v1 = v0;
                } else {
                    v0 = v2.toString().getBytes("iso8859-1");
                }
            }
            if (v1 == -1) {
                break;
            }
            v2.append(((char) (v1 | ((v5 & 3) << 6))));
        }
        v0 = v2.toString().getBytes("iso8859-1");
    }
}
