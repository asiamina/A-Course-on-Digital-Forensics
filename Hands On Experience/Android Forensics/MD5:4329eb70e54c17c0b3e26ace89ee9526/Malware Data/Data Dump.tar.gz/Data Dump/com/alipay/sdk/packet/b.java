package com.alipay.sdk.packet;
final public class b {
     String a;
    public String b;
    public b(String p1, String p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
    public final org.json.JSONObject a()
    {
        v1 = 0;
        if (android.text.TextUtils.isEmpty(this.b) == 0) {
            v1 = new org.json.JSONObject(this.b);
        }
        return v1;
    }
    private void a(String p1)
    {
        this.a = p1;
        return;
    }
    private String b()
    {
        return this.a;
    }
    private void b(String p1)
    {
        this.b = p1;
        return;
    }
    private String c()
    {
        return this.b;
    }
    public final String toString()
    {
        return new StringBuilder("\nenvelop:").append(this.a).append("\nbody:").append(this.b).toString();
    }
}
