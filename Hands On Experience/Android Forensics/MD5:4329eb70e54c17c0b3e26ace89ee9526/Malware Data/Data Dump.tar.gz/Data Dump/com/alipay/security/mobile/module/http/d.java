package com.alipay.security.mobile.module.http;
final public class d {
    public d()
    {
        return;
    }
    public static com.alipay.security.mobile.module.http.v2.a a(android.content.Context p1, String p2)
    {
        if (p1 != 0) {
            v0 = com.alipay.security.mobile.module.http.v2.b.a(p1, p2);
        } else {
            v0 = 0;
        }
        return v0;
    }
    private static String a()
    {
        return 0;
    }
    private static com.alipay.security.mobile.module.http.a b(android.content.Context p1, String p2)
    {
        if (p1 != 0) {
            v0 = com.alipay.security.mobile.module.http.b.a(p1, p2);
        } else {
            v0 = 0;
        }
        return v0;
    }
}
