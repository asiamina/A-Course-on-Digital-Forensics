package com.alipay.sdk.packet.impl;
final public class b extends com.alipay.sdk.packet.d {
    public b()
    {
        return;
    }
    protected final org.json.JSONObject a()
    {
        return com.alipay.sdk.packet.d.a("sdkConfig", "obtain");
    }
    protected final String b()
    {
        return "5.0.0";
    }
}
