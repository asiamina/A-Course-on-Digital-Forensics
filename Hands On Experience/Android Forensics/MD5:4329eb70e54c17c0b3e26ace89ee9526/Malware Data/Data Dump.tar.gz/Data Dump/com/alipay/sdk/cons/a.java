package com.alipay.sdk.cons;
final public class a {
    public static String a;
    public static String c;
    final public static String b;
    final public static String e;
    final public static String d;
    final public static String g;
    final public static String f;
    final public static String i;
    final public static String h;
    final public static String k;
    final public static String j;
    final public static String m;
    final public static String l;
    final public static String o;
    final public static String n;
    final public static String q;
    final public static String p;
    final public static String s;
    public static boolean r;
    final public static String t;
    static a()
    {
        com.alipay.sdk.cons.a.a = "https://mobilegw.alipay.com/mgw.htm";
        com.alipay.sdk.cons.a.c = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDENksAVqDoz5SMCZq0bsZwE+I3NjrANyTTwUVSf1+ec1PfPB4tiocEpYJFCYju9MIbawR8ivECbUWjpffZq5QllJg+19CB7V5rYGcEnb/M7CS3lFF2sNcRFJUtXUUAqyR3/l7PmpxTwObZ4DLG258dhE2vFlVGXjnuLs+FI2hg4QIDAQAB";
        com.alipay.sdk.cons.a.r = 0;
        return;
    }
    public a()
    {
        return;
    }
}
