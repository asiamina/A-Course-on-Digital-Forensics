package com.alipay.android.phone.mrpc.core;
final public class aa {
    private String a;
    private boolean c;
    private java.util.List b;
    public aa()
    {
        return;
    }
    public final String a()
    {
        return this.a;
    }
    public final void a(String p1)
    {
        this.a = p1;
        return;
    }
    public final java.util.List b()
    {
        return this.b;
    }
    public final boolean c()
    {
        return this.c;
    }
}
