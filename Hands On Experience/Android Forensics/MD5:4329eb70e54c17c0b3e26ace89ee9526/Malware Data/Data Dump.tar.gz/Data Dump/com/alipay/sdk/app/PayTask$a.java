package com.alipay.sdk.app;
final class PayTask$a {
     String a;
    final synthetic com.alipay.sdk.app.PayTask c;
     String b;
    private PayTask$a(com.alipay.sdk.app.PayTask p2)
    {
        this.c = p2;
        this.a = "";
        this.b = "";
        return;
    }
    synthetic PayTask$a(com.alipay.sdk.app.PayTask p1, byte p2)
    {
        this(p1);
        return;
    }
    private String a()
    {
        return this.a;
    }
    private void a(String p1)
    {
        this.a = p1;
        return;
    }
    private String b()
    {
        return this.b;
    }
    private void b(String p1)
    {
        this.b = p1;
        return;
    }
}
