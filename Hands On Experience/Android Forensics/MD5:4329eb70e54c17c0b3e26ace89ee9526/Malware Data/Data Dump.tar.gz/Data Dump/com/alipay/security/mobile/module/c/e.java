package com.alipay.security.mobile.module.c;
final public class e {
    public static String a(android.content.Context p1, String p2, String p3, String p4)
    {
        return p1.getSharedPreferences(p2, 0).getString(p3, p4);
    }
    public static void a(android.content.Context p4, String p5, java.util.Map p6)
    {
        v2 = p4.getSharedPreferences(p5, 0).edit();
        if (v2 != 0) {
            v3 = p6.keySet().iterator();
            while (v3.hasNext() != 0) {
                v0 = v3.next();
                v2.putString(v0, p6.get(v0));
            }
            v2.commit();
        }
        return;
    }
}
