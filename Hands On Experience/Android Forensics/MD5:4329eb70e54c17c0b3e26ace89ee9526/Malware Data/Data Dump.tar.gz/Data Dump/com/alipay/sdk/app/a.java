package com.alipay.sdk.app;
final class a implements com.alipay.sdk.util.e$a {
    final synthetic com.alipay.sdk.app.AuthTask a;
     a(com.alipay.sdk.app.AuthTask p1)
    {
        this.a = p1;
        return;
    }
    public final void a()
    {
        com.alipay.sdk.app.AuthTask.a(this.a);
        return;
    }
}
