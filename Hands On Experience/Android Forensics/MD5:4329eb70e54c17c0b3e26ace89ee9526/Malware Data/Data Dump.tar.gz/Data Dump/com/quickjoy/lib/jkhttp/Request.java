package com.quickjoy.lib.jkhttp;
public class Request {
    private String a;
    private com.quickjoy.lib.jkhttp.Parameter c;
    private String b;
    private com.quickjoy.lib.jkhttp.Headers d;
     Request(com.quickjoy.lib.jkhttp.Request$Builder p2)
    {
        this.a = p2.a;
        this.b = p2.b;
        this.c = p2.c;
        this.d = p2.d;
        return;
    }
    public com.quickjoy.lib.jkhttp.Headers getHeader()
    {
        return this.d;
    }
    public String getMethod()
    {
        return this.b;
    }
    public com.quickjoy.lib.jkhttp.Parameter getParameter()
    {
        return this.c;
    }
    public String getUrl()
    {
        return this.a;
    }
    public void setHeader(com.quickjoy.lib.jkhttp.Headers p1)
    {
        this.d = p1;
        return;
    }
    public void setMethod(String p1)
    {
        this.b = p1;
        return;
    }
    public void setParameter(com.quickjoy.lib.jkhttp.Parameter p1)
    {
        this.c = p1;
        return;
    }
    public void setUrl(String p1)
    {
        this.a = p1;
        return;
    }
}
