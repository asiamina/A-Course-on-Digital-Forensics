package com.google.gson;
final enum class FieldNamingPolicy$1 extends com.google.gson.FieldNamingPolicy {
     FieldNamingPolicy$1(String p2, int p3)
    {
        this(p2, p3, 0);
        return;
    }
    public String translateName(reflect.Field p2)
    {
        return p2.getName();
    }
}
