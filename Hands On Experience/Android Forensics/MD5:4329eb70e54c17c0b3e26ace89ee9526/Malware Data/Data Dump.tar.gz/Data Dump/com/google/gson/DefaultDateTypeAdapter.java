package com.google.gson;
final class DefaultDateTypeAdapter implements com.google.gson.JsonDeserializer, com.google.gson.JsonSerializer {
    final private java.text.DateFormat iso8601Format;
    final private java.text.DateFormat enUsFormat;
    final private java.text.DateFormat localFormat;
     DefaultDateTypeAdapter()
    {
        this(java.text.DateFormat.getDateTimeInstance(2, 2, java.util.Locale.US), java.text.DateFormat.getDateTimeInstance(2, 2));
        return;
    }
     DefaultDateTypeAdapter(int p3)
    {
        this(java.text.DateFormat.getDateInstance(p3, java.util.Locale.US), java.text.DateFormat.getDateInstance(p3));
        return;
    }
    public DefaultDateTypeAdapter(int p3, int p4)
    {
        this(java.text.DateFormat.getDateTimeInstance(p3, p4, java.util.Locale.US), java.text.DateFormat.getDateTimeInstance(p3, p4));
        return;
    }
     DefaultDateTypeAdapter(String p3)
    {
        this(new java.text.SimpleDateFormat(p3, java.util.Locale.US), new java.text.SimpleDateFormat(p3));
        return;
    }
     DefaultDateTypeAdapter(java.text.DateFormat p4, java.text.DateFormat p5)
    {
        this.enUsFormat = p4;
        this.localFormat = p5;
        this.iso8601Format = new java.text.SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ss\'Z\'", java.util.Locale.US);
        this.iso8601Format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return;
    }
    public synthetic bridge Object deserialize(com.google.gson.JsonElement p2, reflect.Type p3, com.google.gson.JsonDeserializationContext p4)
    {
        return this.deserialize(p2, p3, p4);
    }
    public java.util.Date deserialize(com.google.gson.JsonElement p5, reflect.Type p6, com.google.gson.JsonDeserializationContext p7)
    {
        if ((p5 instanceof com.google.gson.JsonPrimitive) != 0) {
            this.deserializeToDate(p5);
            v0 = this;
            if (p6 != java.util.Date) {
                if (p6 != java.sql.Timestamp) {
                    if (p6 != java.sql.Date) {
                        throw new IllegalArgumentException(new StringBuilder().append(this.getClass()).append(" cannot deserialize to ").append(p6).toString());
                    } else {
                        v0 = new java.sql.Date(this.getTime());
                    }
                } else {
                    v0 = new java.sql.Timestamp(this.getTime());
                }
            }
            return v0;
        } else {
            throw new com.google.gson.JsonParseException("The date should be a string value");
        }
    }
    private java.util.Date deserializeToDate(com.google.gson.JsonElement p5)
    {
        return this.localFormat.parse(p5.getAsString());
    }
    public synthetic bridge com.google.gson.JsonElement serialize(Object p2, reflect.Type p3, com.google.gson.JsonSerializationContext p4)
    {
        return this.serialize(p2, p3, p4);
    }
    public com.google.gson.JsonElement serialize(java.util.Date p4, reflect.Type p5, com.google.gson.JsonSerializationContext p6)
    {
        return new com.google.gson.JsonPrimitive(this.enUsFormat.format(p4));
    }
    public String toString()
    {
        v0 = new StringBuilder();
        v0.append(com.google.gson.DefaultDateTypeAdapter.getSimpleName());
        v0.append(40).append(this.localFormat.getClass().getSimpleName()).append(41);
        return v0.toString();
    }
}
