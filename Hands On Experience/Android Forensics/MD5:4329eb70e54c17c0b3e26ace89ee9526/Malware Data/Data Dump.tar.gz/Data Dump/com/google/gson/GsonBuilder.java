package com.google.gson;
final public class GsonBuilder {
    private com.google.gson.internal.Excluder excluder;
    private boolean generateNonExecutableJson;
    private com.google.gson.LongSerializationPolicy longSerializationPolicy;
    private boolean prettyPrinting;
    private int timeStyle;
    private int dateStyle;
    private boolean complexMapKeySerialization;
    private boolean escapeHtmlChars;
    final private java.util.List hierarchyFactories;
    final private java.util.Map instanceCreators;
    private String datePattern;
    private boolean serializeNulls;
    final private java.util.List factories;
    private boolean serializeSpecialFloatingPointValues;
    private com.google.gson.FieldNamingStrategy fieldNamingPolicy;
    public GsonBuilder()
    {
        this.excluder = com.google.gson.internal.Excluder.DEFAULT;
        this.longSerializationPolicy = com.google.gson.LongSerializationPolicy.DEFAULT;
        this.fieldNamingPolicy = com.google.gson.FieldNamingPolicy.IDENTITY;
        this.instanceCreators = new java.util.HashMap();
        this.factories = new java.util.ArrayList();
        this.hierarchyFactories = new java.util.ArrayList();
        this.dateStyle = 2;
        this.timeStyle = 2;
        this.escapeHtmlChars = 1;
        return;
    }
    public com.google.gson.GsonBuilder addDeserializationExclusionStrategy(com.google.gson.ExclusionStrategy p4)
    {
        this.excluder = this.excluder.withExclusionStrategy(p4, 0, 1);
        return this;
    }
    public com.google.gson.GsonBuilder addSerializationExclusionStrategy(com.google.gson.ExclusionStrategy p4)
    {
        this.excluder = this.excluder.withExclusionStrategy(p4, 1, 0);
        return this;
    }
    private void addTypeAdaptersForDate(String p5, int p6, int p7, java.util.List p8)
    {
        if ((p5 == 0) || ("".equals(p5.trim()) != 0)) {
            if ((p6 != 2) && (p7 != 2)) {
                v0 = new com.google.gson.DefaultDateTypeAdapter(p6, p7);
                p8.add(com.google.gson.TreeTypeAdapter.newFactory(com.google.gson.reflect.TypeToken.get(java.util.Date), v0));
                p8.add(com.google.gson.TreeTypeAdapter.newFactory(com.google.gson.reflect.TypeToken.get(java.sql.Timestamp), v0));
                p8.add(com.google.gson.TreeTypeAdapter.newFactory(com.google.gson.reflect.TypeToken.get(java.sql.Date), v0));
            }
        } else {
            v0 = new com.google.gson.DefaultDateTypeAdapter(p5);
        }
        return;
    }
    public com.google.gson.Gson create()
    {
        v11 = new java.util.ArrayList();
        v11.addAll(this.factories);
        java.util.Collections.reverse(v11);
        v11.addAll(this.hierarchyFactories);
        this.addTypeAdaptersForDate(this.datePattern, this.dateStyle, this.timeStyle, v11);
        return new com.google.gson.Gson(this.excluder, this.fieldNamingPolicy, this.instanceCreators, this.serializeNulls, this.complexMapKeySerialization, this.generateNonExecutableJson, this.escapeHtmlChars, this.prettyPrinting, this.serializeSpecialFloatingPointValues, this.longSerializationPolicy, v11);
    }
    public com.google.gson.GsonBuilder disableHtmlEscaping()
    {
        this.escapeHtmlChars = 0;
        return this;
    }
    public com.google.gson.GsonBuilder disableInnerClassSerialization()
    {
        this.excluder = this.excluder.disableInnerClassSerialization();
        return this;
    }
    public com.google.gson.GsonBuilder enableComplexMapKeySerialization()
    {
        this.complexMapKeySerialization = 1;
        return this;
    }
    public varargs com.google.gson.GsonBuilder excludeFieldsWithModifiers(int[] p2)
    {
        this.excluder = this.excluder.withModifiers(p2);
        return this;
    }
    public com.google.gson.GsonBuilder excludeFieldsWithoutExposeAnnotation()
    {
        this.excluder = this.excluder.excludeFieldsWithoutExposeAnnotation();
        return this;
    }
    public com.google.gson.GsonBuilder generateNonExecutableJson()
    {
        this.generateNonExecutableJson = 1;
        return this;
    }
    public com.google.gson.GsonBuilder registerTypeAdapter(reflect.Type p4, Object p5)
    {
        if (((p5 instanceof com.google.gson.JsonSerializer) == 0) && (((p5 instanceof com.google.gson.JsonDeserializer) == 0) && (((p5 instanceof com.google.gson.InstanceCreator) == 0) && ((p5 instanceof com.google.gson.TypeAdapter) == 0)))) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        com.google.gson.internal.$Gson$Preconditions.checkArgument(v1);
        if ((p5 instanceof com.google.gson.InstanceCreator) != 0) {
            this.instanceCreators.put(p4, p5);
        }
        if (((p5 instanceof com.google.gson.JsonSerializer) != 0) || ((p5 instanceof com.google.gson.JsonDeserializer) != 0)) {
            this.factories.add(com.google.gson.TreeTypeAdapter.newFactoryWithMatchRawType(com.google.gson.reflect.TypeToken.get(p4), p5));
        }
        if ((p5 instanceof com.google.gson.TypeAdapter) != 0) {
            this.factories.add(com.google.gson.internal.bind.TypeAdapters.newFactory(com.google.gson.reflect.TypeToken.get(p4), p5));
        }
        return this;
    }
    public com.google.gson.GsonBuilder registerTypeAdapterFactory(com.google.gson.TypeAdapterFactory p2)
    {
        this.factories.add(p2);
        return this;
    }
    public com.google.gson.GsonBuilder registerTypeHierarchyAdapter(Class p4, Object p5)
    {
        if (((p5 instanceof com.google.gson.JsonSerializer) == 0) && (((p5 instanceof com.google.gson.JsonDeserializer) == 0) && ((p5 instanceof com.google.gson.TypeAdapter) == 0))) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        com.google.gson.internal.$Gson$Preconditions.checkArgument(v0);
        if (((p5 instanceof com.google.gson.JsonDeserializer) != 0) || ((p5 instanceof com.google.gson.JsonSerializer) != 0)) {
            this.hierarchyFactories.add(0, com.google.gson.TreeTypeAdapter.newTypeHierarchyFactory(p4, p5));
        }
        if ((p5 instanceof com.google.gson.TypeAdapter) != 0) {
            this.factories.add(com.google.gson.internal.bind.TypeAdapters.newTypeHierarchyFactory(p4, p5));
        }
        return this;
    }
    public com.google.gson.GsonBuilder serializeNulls()
    {
        this.serializeNulls = 1;
        return this;
    }
    public com.google.gson.GsonBuilder serializeSpecialFloatingPointValues()
    {
        this.serializeSpecialFloatingPointValues = 1;
        return this;
    }
    public com.google.gson.GsonBuilder setDateFormat(int p2)
    {
        this.dateStyle = p2;
        this.datePattern = 0;
        return this;
    }
    public com.google.gson.GsonBuilder setDateFormat(int p2, int p3)
    {
        this.dateStyle = p2;
        this.timeStyle = p3;
        this.datePattern = 0;
        return this;
    }
    public com.google.gson.GsonBuilder setDateFormat(String p1)
    {
        this.datePattern = p1;
        return this;
    }
    public varargs com.google.gson.GsonBuilder setExclusionStrategies(com.google.gson.ExclusionStrategy[] p7)
    {
        v0 = p7;
        v2 = v0.length;
        v1 = 0;
        while (v1 < v2) {
            this.excluder = this.excluder.withExclusionStrategy(v0[v1], 1, 1);
            v1++;
        }
        return this;
    }
    public com.google.gson.GsonBuilder setFieldNamingPolicy(com.google.gson.FieldNamingPolicy p1)
    {
        this.fieldNamingPolicy = p1;
        return this;
    }
    public com.google.gson.GsonBuilder setFieldNamingStrategy(com.google.gson.FieldNamingStrategy p1)
    {
        this.fieldNamingPolicy = p1;
        return this;
    }
    public com.google.gson.GsonBuilder setLongSerializationPolicy(com.google.gson.LongSerializationPolicy p1)
    {
        this.longSerializationPolicy = p1;
        return this;
    }
    public com.google.gson.GsonBuilder setPrettyPrinting()
    {
        this.prettyPrinting = 1;
        return this;
    }
    public com.google.gson.GsonBuilder setVersion(double p2)
    {
        this.excluder = this.excluder.withVersion(p2);
        return this;
    }
}
