package com.google.gson.internal.bind;
final class TypeAdapterRuntimeTypeWrapper extends com.google.gson.TypeAdapter {
    final private reflect.Type type;
    final private com.google.gson.TypeAdapter delegate;
    final private com.google.gson.Gson context;
    private reflect.Type getRuntimeTypeIfMoreSpecific(reflect.Type p2, Object p3)
    {
        if ((p3 != 0) && ((p2 == Object) || (((p2 instanceof reflect.TypeVariable) != 0) || ((p2 instanceof Class) != 0)))) {
            p2 = p3.getClass();
        }
        return p2;
    }
    public Object read(com.google.gson.stream.JsonReader p2)
    {
        return this.delegate.read(p2);
    }
    public void write(com.google.gson.stream.JsonWriter p6, Object p7)
    {
        v0 = this.delegate;
        this.getRuntimeTypeIfMoreSpecific(this.type, p7);
        if (this != this.type) {
            v2 = this.context.getAdapter(com.google.gson.reflect.TypeToken.get(this));
            if ((v2 instanceof com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$Adapter) != 0) {
                if ((this.delegate instanceof com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$Adapter) != 0) {
                    v0 = v2;
                } else {
                    v0 = this.delegate;
                }
            } else {
                v0 = v2;
            }
        }
        v0.write(p6, p7);
        return;
    }
     TypeAdapterRuntimeTypeWrapper(com.google.gson.Gson p1, com.google.gson.TypeAdapter p2, reflect.Type p3)
    {
        this.context = p1;
        this.delegate = p2;
        this.type = p3;
        return;
    }
}
