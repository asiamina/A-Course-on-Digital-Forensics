package com.google.gson.internal.bind;
final class TypeAdapters$22 implements com.google.gson.TypeAdapterFactory {
     TypeAdapters$22()
    {
        return;
    }
    public com.google.gson.TypeAdapter create(com.google.gson.Gson p4, com.google.gson.reflect.TypeToken p5)
    {
        if (p5.getRawType() == java.sql.Timestamp) {
            v1 = new com.google.gson.internal.bind.TypeAdapters$22$1(this, p4.getAdapter(java.util.Date));
        } else {
            v1 = 0;
        }
        return v1;
    }
}
