package com.google.gson.stream;
final class JsonReader$1 extends com.google.gson.internal.JsonReaderInternalAccess {
     JsonReader$1()
    {
        return;
    }
    public void promoteNameToValue(com.google.gson.stream.JsonReader p5)
    {
        if ((p5 instanceof com.google.gson.internal.bind.JsonTreeReader) == 0) {
            v0 = com.google.gson.stream.JsonReader.access$000(p5);
            if (v0 == 0) {
                v0 = com.google.gson.stream.JsonReader.access$100(p5);
            }
            if (v0 != 13) {
                if (v0 != 12) {
                    if (v0 != 14) {
                        throw new IllegalStateException(new StringBuilder().append("Expected a name but was ").append(p5.peek()).append(" ").append(" at line ").append(com.google.gson.stream.JsonReader.access$200(p5)).append(" column ").append(com.google.gson.stream.JsonReader.access$300(p5)).toString());
                    } else {
                        com.google.gson.stream.JsonReader.access$002(p5, 10);
                    }
                } else {
                    com.google.gson.stream.JsonReader.access$002(p5, 8);
                }
            } else {
                com.google.gson.stream.JsonReader.access$002(p5, 9);
            }
        } else {
            p5.promoteNameToValue();
        }
        return;
    }
}
