package com.google.gson.internal.bind;
final public class ObjectTypeAdapter extends com.google.gson.TypeAdapter {
    final public static com.google.gson.TypeAdapterFactory FACTORY;
    final private com.google.gson.Gson gson;
    static ObjectTypeAdapter()
    {
        com.google.gson.internal.bind.ObjectTypeAdapter.FACTORY = new com.google.gson.internal.bind.ObjectTypeAdapter$1();
        return;
    }
    private ObjectTypeAdapter(com.google.gson.Gson p1)
    {
        this.gson = p1;
        return;
    }
    synthetic ObjectTypeAdapter(com.google.gson.Gson p1, com.google.gson.internal.bind.ObjectTypeAdapter$1 p2)
    {
        this(p1);
        return;
    }
    public Object read(com.google.gson.stream.JsonReader p6)
    {
        switch (com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken[p6.peek().ordinal()]) {
            case 1:
                v0 = new java.util.ArrayList();
                p6.beginArray();
                while (p6.hasNext() != 0) {
                    v0.add(this.read(p6));
                }
                p6.endArray();
                break;
            case 2:
                v1 = new com.google.gson.internal.LinkedTreeMap();
                p6.beginObject();
                while (p6.hasNext() != 0) {
                    v1.put(p6.nextName(), this.read(p6));
                }
                p6.endObject();
                v0 = v1;
                break;
            case 3:
                v0 = p6.nextString();
                break;
            case 4:
                v0 = Double.valueOf(p6.nextDouble());
                break;
            case 5:
                v0 = Boolean.valueOf(p6.nextBoolean());
                break;
            case 6:
                p6.nextNull();
                v0 = 0;
                break;
            default:
                throw new IllegalStateException();
        }
        return v0;
    }
    public void write(com.google.gson.stream.JsonWriter p4, Object p5)
    {
        if (p5 != 0) {
            v0 = this.gson.getAdapter(p5.getClass());
            if ((v0 instanceof com.google.gson.internal.bind.ObjectTypeAdapter) == 0) {
                v0.write(p4, p5);
            } else {
                p4.beginObject();
                p4.endObject();
            }
        } else {
            p4.nullValue();
        }
        return;
    }
}
