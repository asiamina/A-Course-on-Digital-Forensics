package com.google.gson.internal;
final public class LazilyParsedNumber extends java.lang.Number {
    final private String value;
    public LazilyParsedNumber(String p1)
    {
        this.value = p1;
        return;
    }
    public double doubleValue()
    {
        return Double.parseDouble(this.value);
    }
    public float floatValue()
    {
        return Float.parseFloat(this.value);
    }
    public int intValue()
    {
        return Integer.parseInt(this.value);
    }
    public long longValue()
    {
        return Long.parseLong(this.value);
    }
    public String toString()
    {
        return this.value;
    }
    private Object writeReplace()
    {
        return new java.math.BigDecimal(this.value);
    }
}
