package com.google.gson.internal;
final class $Gson$Types$WildcardTypeImpl implements java.io.Serializable, java.lang.reflect.WildcardType {
    final private reflect.Type lowerBound;
    final private reflect.Type upperBound;
    final private static long serialVersionUID;
    public String toString()
    {
        if (this.lowerBound == 0) {
            if (this.upperBound != Object) {
                v0 = new StringBuilder().append("? extends ").append(com.google.gson.internal.$Gson$Types.typeToString(this.upperBound)).toString();
            } else {
                v0 = "?";
            }
        } else {
            v0 = new StringBuilder().append("? super ").append(com.google.gson.internal.$Gson$Types.typeToString(this.lowerBound)).toString();
        }
        return v0;
    }
    public $Gson$Types$WildcardTypeImpl(reflect.Type[] p5, reflect.Type[] p6)
    {
        v1 = 1;
        if (p6.length > 1) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        com.google.gson.internal.$Gson$Preconditions.checkArgument(v0);
        if (p5.length != 1) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        com.google.gson.internal.$Gson$Preconditions.checkArgument(v0);
        if (p6.length != 1) {
            com.google.gson.internal.$Gson$Preconditions.checkNotNull(p5[0]);
            com.google.gson.internal.$Gson$Types.access$000(p5[0]);
            this.lowerBound = 0;
            this.upperBound = com.google.gson.internal.$Gson$Types.canonicalize(p5[0]);
        } else {
            com.google.gson.internal.$Gson$Preconditions.checkNotNull(p6[0]);
            com.google.gson.internal.$Gson$Types.access$000(p6[0]);
            if (p5[0] != Object) {
                v1 = 0;
            }
            com.google.gson.internal.$Gson$Preconditions.checkArgument(v1);
            this.lowerBound = com.google.gson.internal.$Gson$Types.canonicalize(p6[0]);
            this.upperBound = Object;
        }
        return;
    }
    public boolean equals(Object p2)
    {
        if (((p2 instanceof reflect.WildcardType) == 0) || (com.google.gson.internal.$Gson$Types.equals(this, p2) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public reflect.Type[] getLowerBounds()
    {
        if (this.lowerBound == 0) {
            v0 = com.google.gson.internal.$Gson$Types.EMPTY_TYPE_ARRAY;
        } else {
            v0 = new reflect.Type[1];
            v0[0] = this.lowerBound;
        }
        return v0;
    }
    public reflect.Type[] getUpperBounds()
    {
        v0 = new reflect.Type[1];
        v0[0] = this.upperBound;
        return v0;
    }
    public int hashCode()
    {
        if (this.lowerBound == 0) {
            v0 = 1;
        } else {
            v0 = (this.lowerBound.hashCode() + 31);
        }
        return (v0 ^ (this.upperBound.hashCode() + 31));
    }
}
