package com.google.gson.internal;
 class ConstructorConstructor$4 implements com.google.gson.internal.ObjectConstructor {
    final synthetic com.google.gson.internal.ConstructorConstructor this$0;
     ConstructorConstructor$4(com.google.gson.internal.ConstructorConstructor p1)
    {
        this.this$0 = p1;
        return;
    }
    public Object construct()
    {
        return new java.util.TreeSet();
    }
}
