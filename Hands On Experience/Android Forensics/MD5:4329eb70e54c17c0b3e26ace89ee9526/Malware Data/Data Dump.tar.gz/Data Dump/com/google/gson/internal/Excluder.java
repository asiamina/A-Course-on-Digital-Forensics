package com.google.gson.internal;
final public class Excluder implements com.google.gson.TypeAdapterFactory, java.lang.Cloneable {
    private int modifiers;
    final private static double IGNORE_VERSIONS;
    final public static com.google.gson.internal.Excluder DEFAULT;
    private java.util.List serializationStrategies;
    private boolean requireExpose;
    private double version;
    private java.util.List deserializationStrategies;
    private boolean serializeInnerClasses;
    public com.google.gson.internal.Excluder disableInnerClassSerialization()
    {
        v0 = this.clone();
        v0.serializeInnerClasses = 0;
        return v0;
    }
    public boolean excludeClass(Class p9, boolean p10)
    {
        if (this.version == -1.0) {
            if (this.serializeInnerClasses) {
                this.isInnerClass(p9);
                if (this != 0) {
                    v3 = 1;
                    return v3;
                }
            }
            this.isAnonymousOrLocal(p9);
            if (this == 0) {
                if (p10 == 0) {
                    v2 = this.deserializationStrategies;
                } else {
                    v2 = this.serializationStrategies;
                }
                v1 = v2.iterator();
                while (v1.hasNext() != 0) {
                    if (v1.next().shouldSkipClass(p9) != 0) {
                        v3 = 1;
                    }
                }
                v3 = 0;
            } else {
                v3 = 1;
            }
        } else {
            this.isValidVersion(p9.getAnnotation(com.google.gson.annotations.Since), p9.getAnnotation(com.google.gson.annotations.Until));
            } else {
                v3 = 1;
            }
        }
    }
    public boolean excludeField(reflect.Field p11, boolean p12)
    {
        if ((this.modifiers & p11.getModifiers()) == 0) {
            if (this.version != -1.0) {
                this.isValidVersion(p11.getAnnotation(com.google.gson.annotations.Since), p11.getAnnotation(com.google.gson.annotations.Until));
                if (this == 0) {
                    v5 = 1;
                    return v5;
                }
            }
            if (p11.isSynthetic() == 0) {
                if (this.requireExpose) {
                    v0 = p11.getAnnotation(com.google.gson.annotations.Expose);
                    if (v0 != 0) {
                        if (p12 == 0) {
                            if (v0.deserialize() != 0) {
                                if (this.serializeInnerClasses) {
                                    this.isInnerClass(p11.getType());
                                    if (this != 0) {
                                        v5 = 1;
                                    }
                                }
                                this.isAnonymousOrLocal(p11.getType());
                                if (this == 0) {
                                    if (p12 == 0) {
                                        v4 = this.deserializationStrategies;
                                    } else {
                                        v4 = this.serializationStrategies;
                                    }
                                    if (v4.isEmpty() == 0) {
                                        v2 = new com.google.gson.FieldAttributes(p11);
                                        v3 = v4.iterator();
                                        while (v3.hasNext() != 0) {
                                            if (v3.next().shouldSkipField(v2) != 0) {
                                                v5 = 1;
                                            }
                                        }
                                    }
                                    v5 = 0;
                                } else {
                                    v5 = 1;
                                }
                            }
                        } else {
                            }
                        }
                    }
                    v5 = 1;
                }
            } else {
                v5 = 1;
            }
        } else {
            v5 = 1;
        }
    }
    public com.google.gson.internal.Excluder excludeFieldsWithoutExposeAnnotation()
    {
        v0 = this.clone();
        v0.requireExpose = 1;
        return v0;
    }
    private boolean isAnonymousOrLocal(Class p2)
    {
        if ((Enum.isAssignableFrom(p2) != 0) || ((p2.isAnonymousClass() == 0) && (p2.isLocalClass() == 0))) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    private boolean isInnerClass(Class p2)
    {
        if (p2.isMemberClass() == 0) {
            v0 = 0;
        } else {
            this.isStatic(p2);
            } else {
                v0 = 1;
            }
        }
        return v0;
    }
    private boolean isStatic(Class p2)
    {
        if ((p2.getModifiers() & 8) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    private boolean isValidSince(com.google.gson.annotations.Since p5)
    {
        if ((p5 == 0) || (p5.value() <= this.version)) {
            v2 = 1;
        } else {
            v2 = 0;
        }
        return v2;
    }
    private boolean isValidUntil(com.google.gson.annotations.Until p5)
    {
        if ((p5 == 0) || (p5.value() > this.version)) {
            v2 = 1;
        } else {
            v2 = 0;
        }
        return v2;
    }
    private boolean isValidVersion(com.google.gson.annotations.Since p2, com.google.gson.annotations.Until p3)
    {
        this.isValidSince(p2);
        if (this == 0) {
            v0 = 0;
        } else {
            this.isValidUntil(p3);
            } else {
                v0 = 1;
            }
        }
        return v0;
    }
    public com.google.gson.internal.Excluder withExclusionStrategy(com.google.gson.ExclusionStrategy p4, boolean p5, boolean p6)
    {
        v0 = this.clone();
        if (p5 != 0) {
            v0.serializationStrategies = new java.util.ArrayList(this.serializationStrategies);
            v0.serializationStrategies.add(p4);
        }
        if (p6 != 0) {
            v0.deserializationStrategies = new java.util.ArrayList(this.deserializationStrategies);
            v0.deserializationStrategies.add(p4);
        }
        return v0;
    }
    public varargs com.google.gson.internal.Excluder withModifiers(int[] p7)
    {
        v4 = this.clone();
        v4.modifiers = 0;
        v0 = p7;
        v2 = v0.length;
        v1 = 0;
        while (v1 < v2) {
            v4.modifiers = (v4.modifiers | v0[v1]);
            v1++;
        }
        return v4;
    }
    public com.google.gson.internal.Excluder withVersion(double p2)
    {
        v0 = this.clone();
        v0.version = p2;
        return v0;
    }
    static Excluder()
    {
        com.google.gson.internal.Excluder.DEFAULT = new com.google.gson.internal.Excluder();
        return;
    }
    public Excluder()
    {
        this.version = -1.0;
        this.modifiers = 136;
        this.serializeInnerClasses = 1;
        this.serializationStrategies = java.util.Collections.emptyList();
        this.deserializationStrategies = java.util.Collections.emptyList();
        return;
    }
    protected com.google.gson.internal.Excluder clone()
    {
        return super.clone();
    }
    protected synthetic bridge Object clone()
    {
        return this.clone();
    }
    public com.google.gson.TypeAdapter create(com.google.gson.Gson p8, com.google.gson.reflect.TypeToken p9)
    {
        v6 = p9.getRawType();
        v3 = this.excludeClass(v6, 1);
        v2 = this.excludeClass(v6, 0);
        if ((v3 != 0) || (v2 != 0)) {
            v0 = new com.google.gson.internal.Excluder$1(this, v2, v3, p8, p9);
        } else {
            v0 = 0;
        }
        return v0;
    }
}
