package com.google.gson.internal.bind;
final class TypeAdapters$18 extends com.google.gson.TypeAdapter {
     TypeAdapters$18()
    {
        return;
    }
    public synthetic bridge Object read(com.google.gson.stream.JsonReader p2)
    {
        return this.read(p2);
    }
    public java.net.URL read(com.google.gson.stream.JsonReader p5)
    {
        v1 = 0;
        if (p5.peek() != com.google.gson.stream.JsonToken.NULL) {
            v0 = p5.nextString();
            if ("null".equals(v0) == 0) {
                v1 = new java.net.URL(v0);
            }
        } else {
            p5.nextNull();
        }
        return v1;
    }
    public synthetic bridge void write(com.google.gson.stream.JsonWriter p1, Object p2)
    {
        this.write(p1, p2);
        return;
    }
    public void write(com.google.gson.stream.JsonWriter p2, java.net.URL p3)
    {
        if (p3 != 0) {
            v0 = p3.toExternalForm();
        } else {
            v0 = 0;
        }
        p2.value(v0);
        return;
    }
}
