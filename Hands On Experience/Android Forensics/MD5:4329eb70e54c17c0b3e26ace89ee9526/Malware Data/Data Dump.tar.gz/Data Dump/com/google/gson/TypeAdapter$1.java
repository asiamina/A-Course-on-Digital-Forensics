package com.google.gson;
 class TypeAdapter$1 extends com.google.gson.TypeAdapter {
    final synthetic com.google.gson.TypeAdapter this$0;
     TypeAdapter$1(com.google.gson.TypeAdapter p1)
    {
        this.this$0 = p1;
        return;
    }
    public Object read(com.google.gson.stream.JsonReader p3)
    {
        if (p3.peek() != com.google.gson.stream.JsonToken.NULL) {
            v0 = this.this$0.read(p3);
        } else {
            p3.nextNull();
            v0 = 0;
        }
        return v0;
    }
    public void write(com.google.gson.stream.JsonWriter p2, Object p3)
    {
        if (p3 != 0) {
            this.this$0.write(p2, p3);
        } else {
            p2.nullValue();
        }
        return;
    }
}
