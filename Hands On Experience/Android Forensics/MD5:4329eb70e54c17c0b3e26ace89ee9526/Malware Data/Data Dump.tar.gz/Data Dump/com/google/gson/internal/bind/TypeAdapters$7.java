package com.google.gson.internal.bind;
final class TypeAdapters$7 extends com.google.gson.TypeAdapter {
    public synthetic bridge void write(com.google.gson.stream.JsonWriter p1, Object p2)
    {
        this.write(p1, p2);
        return;
    }
     TypeAdapters$7()
    {
        return;
    }
    public Number read(com.google.gson.stream.JsonReader p4)
    {
        if (p4.peek() != com.google.gson.stream.JsonToken.NULL) {
            v1 = Integer.valueOf(p4.nextInt());
        } else {
            p4.nextNull();
            v1 = 0;
        }
        return v1;
    }
    public synthetic bridge Object read(com.google.gson.stream.JsonReader p2)
    {
        return this.read(p2);
    }
    public void write(com.google.gson.stream.JsonWriter p1, Number p2)
    {
        p1.value(p2);
        return;
    }
}
