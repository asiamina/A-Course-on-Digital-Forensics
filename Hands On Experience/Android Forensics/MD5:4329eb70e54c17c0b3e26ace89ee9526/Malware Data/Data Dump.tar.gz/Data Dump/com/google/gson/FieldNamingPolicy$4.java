package com.google.gson;
final enum class FieldNamingPolicy$4 extends com.google.gson.FieldNamingPolicy {
     FieldNamingPolicy$4(String p2, int p3)
    {
        this(p2, p3, 0);
        return;
    }
    public String translateName(reflect.Field p3)
    {
        return com.google.gson.FieldNamingPolicy.access$200(p3.getName(), "_").toLowerCase();
    }
}
