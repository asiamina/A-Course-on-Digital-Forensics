package com.google.gson;
public abstract class TypeAdapter {
    public final com.google.gson.TypeAdapter nullSafe()
    {
        return new com.google.gson.TypeAdapter$1(this);
    }
    abstract public Object read();
    public final String toJson(Object p3)
    {
        v0 = new java.io.StringWriter();
        this.toJson(v0, p3);
        return v0.toString();
    }
    public final void toJson(java.io.Writer p2, Object p3)
    {
        this.write(new com.google.gson.stream.JsonWriter(p2), p3);
        return;
    }
    public final com.google.gson.JsonElement toJsonTree(Object p4)
    {
        v1 = new com.google.gson.internal.bind.JsonTreeWriter();
        this.write(v1, p4);
        return v1.get();
    }
    abstract public void write();
    public TypeAdapter()
    {
        return;
    }
    public final Object fromJson(java.io.Reader p3)
    {
        return this.read(new com.google.gson.stream.JsonReader(p3));
    }
    public final Object fromJson(String p2)
    {
        return this.fromJson(new java.io.StringReader(p2));
    }
    public final Object fromJsonTree(com.google.gson.JsonElement p4)
    {
        return this.read(new com.google.gson.internal.bind.JsonTreeReader(p4));
    }
}
