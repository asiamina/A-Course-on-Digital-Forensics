package com.google.gson.internal.bind;
synthetic class ObjectTypeAdapter$2 {
    final synthetic static int[] $SwitchMap$com$google$gson$stream$JsonToken;
    static ObjectTypeAdapter$2()
    {
        v0 = new int[com.google.gson.stream.JsonToken.values().length];
        com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken = v0;
        com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken[com.google.gson.stream.JsonToken.BEGIN_ARRAY.ordinal()] = 1;
        com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken[com.google.gson.stream.JsonToken.BEGIN_OBJECT.ordinal()] = 2;
        com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken[com.google.gson.stream.JsonToken.STRING.ordinal()] = 3;
        com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken[com.google.gson.stream.JsonToken.NUMBER.ordinal()] = 4;
        com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken[com.google.gson.stream.JsonToken.BOOLEAN.ordinal()] = 5;
        com.google.gson.internal.bind.ObjectTypeAdapter$2.$SwitchMap$com$google$gson$stream$JsonToken[com.google.gson.stream.JsonToken.NULL.ordinal()] = 6;
        return;
    }
}
