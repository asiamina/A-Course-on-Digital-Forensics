package com.google.gson.annotations;
public interface annotation abstract class Expose implements java.lang.annotation.Annotation {
    abstract public boolean serialize();
    abstract public boolean deserialize();
}
