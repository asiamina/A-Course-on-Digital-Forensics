package com.google.gson.internal.bind;
final class TypeAdapters$4 extends com.google.gson.TypeAdapter {
    public void write(com.google.gson.stream.JsonWriter p2, Boolean p3)
    {
        if (p3 != 0) {
            v0 = p3.toString();
        } else {
            v0 = "null";
        }
        p2.value(v0);
        return;
    }
    public synthetic bridge void write(com.google.gson.stream.JsonWriter p1, Object p2)
    {
        this.write(p1, p2);
        return;
    }
     TypeAdapters$4()
    {
        return;
    }
    public Boolean read(com.google.gson.stream.JsonReader p3)
    {
        if (p3.peek() != com.google.gson.stream.JsonToken.NULL) {
            v0 = Boolean.valueOf(p3.nextString());
        } else {
            p3.nextNull();
            v0 = 0;
        }
        return v0;
    }
    public synthetic bridge Object read(com.google.gson.stream.JsonReader p2)
    {
        return this.read(p2);
    }
}
