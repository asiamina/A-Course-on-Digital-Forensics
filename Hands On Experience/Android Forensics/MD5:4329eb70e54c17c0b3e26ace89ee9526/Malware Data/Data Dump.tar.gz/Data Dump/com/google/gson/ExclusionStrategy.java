package com.google.gson;
public interface abstract class ExclusionStrategy {
    abstract public boolean shouldSkipField();
    abstract public boolean shouldSkipClass();
}
