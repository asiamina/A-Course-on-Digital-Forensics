package com.google.gson.internal;
final class LinkedTreeMap$1 implements java.util.Comparator {
    public synthetic bridge int compare(Object p2, Object p3)
    {
        return this.compare(p2, p3);
    }
     LinkedTreeMap$1()
    {
        return;
    }
    public int compare(Comparable p2, Comparable p3)
    {
        return p2.compareTo(p3);
    }
}
