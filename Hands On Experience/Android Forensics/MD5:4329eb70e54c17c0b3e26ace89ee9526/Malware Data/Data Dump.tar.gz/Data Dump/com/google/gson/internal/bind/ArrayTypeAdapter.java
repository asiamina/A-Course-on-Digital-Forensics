package com.google.gson.internal.bind;
final public class ArrayTypeAdapter extends com.google.gson.TypeAdapter {
    final private Class componentType;
    final public static com.google.gson.TypeAdapterFactory FACTORY;
    final private com.google.gson.TypeAdapter componentTypeAdapter;
    public Object read(com.google.gson.stream.JsonReader p7)
    {
        if (p7.peek() != com.google.gson.stream.JsonToken.NULL) {
            v3 = new java.util.ArrayList();
            p7.beginArray();
            while (p7.hasNext() != 0) {
                v3.add(this.componentTypeAdapter.read(p7));
            }
            p7.endArray();
            v0 = reflect.Array.newInstance(this.componentType, v3.size());
            v1 = 0;
            while (v1 < v3.size()) {
                reflect.Array.set(v0, v1, v3.get(v1));
                v1++;
            }
        } else {
            p7.nextNull();
            v0 = 0;
        }
        return v0;
    }
    public void write(com.google.gson.stream.JsonWriter p5, Object p6)
    {
        if (p6 != 0) {
            p5.beginArray();
            v0 = 0;
            v1 = reflect.Array.getLength(p6);
            while (v0 < v1) {
                this.componentTypeAdapter.write(p5, reflect.Array.get(p6, v0));
                v0++;
            }
            p5.endArray();
        } else {
            p5.nullValue();
        }
        return;
    }
    static ArrayTypeAdapter()
    {
        com.google.gson.internal.bind.ArrayTypeAdapter.FACTORY = new com.google.gson.internal.bind.ArrayTypeAdapter$1();
        return;
    }
    public ArrayTypeAdapter(com.google.gson.Gson p2, com.google.gson.TypeAdapter p3, Class p4)
    {
        this.componentTypeAdapter = new com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper(p2, p3, p4);
        this.componentType = p4;
        return;
    }
}
