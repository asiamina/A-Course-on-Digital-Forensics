package com.google.gson.internal.bind;
final public class DateTypeAdapter extends com.google.gson.TypeAdapter {
    final private java.text.DateFormat iso8601Format;
    final public static com.google.gson.TypeAdapterFactory FACTORY;
    final private java.text.DateFormat enUsFormat;
    final private java.text.DateFormat localFormat;
    static DateTypeAdapter()
    {
        com.google.gson.internal.bind.DateTypeAdapter.FACTORY = new com.google.gson.internal.bind.DateTypeAdapter$1();
        return;
    }
    public DateTypeAdapter()
    {
        this.enUsFormat = java.text.DateFormat.getDateTimeInstance(2, 2, java.util.Locale.US);
        this.localFormat = java.text.DateFormat.getDateTimeInstance(2, 2);
        this.iso8601Format = com.google.gson.internal.bind.DateTypeAdapter.buildIso8601Format();
        return;
    }
    private static java.text.DateFormat buildIso8601Format()
    {
        v0 = new java.text.SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ss\'Z\'", java.util.Locale.US);
        v0.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return v0;
    }
    private synchronized java.util.Date deserializeToDate(String p3)
    {
        return this.localFormat.parse(p3);
    }
    public synthetic bridge Object read(com.google.gson.stream.JsonReader p2)
    {
        return this.read(p2);
    }
    public java.util.Date read(com.google.gson.stream.JsonReader p3)
    {
        if (p3.peek() != com.google.gson.stream.JsonToken.NULL) {
            this.deserializeToDate(p3.nextString());
            v0 = this;
        } else {
            p3.nextNull();
            v0 = 0;
        }
        return v0;
    }
    public synthetic bridge void write(com.google.gson.stream.JsonWriter p1, Object p2)
    {
        this.write(p1, p2);
        return;
    }
    public synchronized void write(com.google.gson.stream.JsonWriter p3, java.util.Date p4)
    {
        if (p4 != 0) {
            p3.value(this.enUsFormat.format(p4));
        } else {
            p3.nullValue();
        }
        return;
    }
}
