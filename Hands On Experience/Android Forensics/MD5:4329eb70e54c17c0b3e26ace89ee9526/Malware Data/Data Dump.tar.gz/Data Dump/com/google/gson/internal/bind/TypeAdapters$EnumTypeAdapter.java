package com.google.gson.internal.bind;
final class TypeAdapters$EnumTypeAdapter extends com.google.gson.TypeAdapter {
    final private java.util.Map nameToConstant;
    final private java.util.Map constantToName;
    public TypeAdapters$EnumTypeAdapter(Class p10)
    {
        this.nameToConstant = new java.util.HashMap();
        this.constantToName = new java.util.HashMap();
        v1 = p10.getEnumConstants();
        v5 = v1.length;
        v4 = 0;
        while (v4 < v5) {
            v2 = v1[v4];
            v6 = v2.name();
            v0 = p10.getField(v6).getAnnotation(com.google.gson.annotations.SerializedName);
            if (v0 != 0) {
                v6 = v0.value();
            }
            this.nameToConstant.put(v6, v2);
            this.constantToName.put(v2, v6);
            v4++;
        }
        return;
    }
    public Enum read(com.google.gson.stream.JsonReader p3)
    {
        if (p3.peek() != com.google.gson.stream.JsonToken.NULL) {
            v0 = this.nameToConstant.get(p3.nextString());
        } else {
            p3.nextNull();
            v0 = 0;
        }
        return v0;
    }
    public synthetic bridge Object read(com.google.gson.stream.JsonReader p2)
    {
        return this.read(p2);
    }
    public void write(com.google.gson.stream.JsonWriter p2, Enum p3)
    {
        if (p3 != 0) {
            v0 = this.constantToName.get(p3);
        } else {
            v0 = 0;
        }
        p2.value(v0);
        return;
    }
    public synthetic bridge void write(com.google.gson.stream.JsonWriter p1, Object p2)
    {
        this.write(p1, p2);
        return;
    }
}
