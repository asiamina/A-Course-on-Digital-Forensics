package com.google.gson.internal;
 class LinkedTreeMap$KeySet extends java.util.AbstractSet {
    final synthetic com.google.gson.internal.LinkedTreeMap this$0;
     LinkedTreeMap$KeySet(com.google.gson.internal.LinkedTreeMap p1)
    {
        this.this$0 = p1;
        return;
    }
    public void clear()
    {
        this.this$0.clear();
        return;
    }
    public boolean contains(Object p2)
    {
        return this.this$0.containsKey(p2);
    }
    public java.util.Iterator iterator()
    {
        return new com.google.gson.internal.LinkedTreeMap$KeySet$1(this);
    }
    public boolean remove(Object p2)
    {
        if (this.this$0.removeInternalByKey(p2) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public int size()
    {
        return this.this$0.size;
    }
}
