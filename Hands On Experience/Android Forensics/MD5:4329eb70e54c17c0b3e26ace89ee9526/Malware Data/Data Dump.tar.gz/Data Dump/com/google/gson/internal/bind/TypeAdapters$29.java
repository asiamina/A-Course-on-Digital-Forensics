package com.google.gson.internal.bind;
final class TypeAdapters$29 implements com.google.gson.TypeAdapterFactory {
    final synthetic Class val$boxed;
    final synthetic Class val$unboxed;
    final synthetic com.google.gson.TypeAdapter val$typeAdapter;
     TypeAdapters$29(Class p1, Class p2, com.google.gson.TypeAdapter p3)
    {
        this.val$unboxed = p1;
        this.val$boxed = p2;
        this.val$typeAdapter = p3;
        return;
    }
    public com.google.gson.TypeAdapter create(com.google.gson.Gson p3, com.google.gson.reflect.TypeToken p4)
    {
        v0 = p4.getRawType();
        if ((v0 != this.val$unboxed) && (v0 != this.val$boxed)) {
            v1 = 0;
        } else {
            v1 = this.val$typeAdapter;
        }
        return v1;
    }
    public String toString()
    {
        return new StringBuilder().append("Factory[type=").append(this.val$boxed.getName()).append("+").append(this.val$unboxed.getName()).append(",adapter=").append(this.val$typeAdapter).append("]").toString();
    }
}
