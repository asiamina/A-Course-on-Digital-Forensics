package com.google.gson;
final public class FieldAttributes {
    final private reflect.Field field;
    public String getName()
    {
        return this.field.getName();
    }
    public boolean hasModifier(int p2)
    {
        if ((this.field.getModifiers() & p2) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
     boolean isSynthetic()
    {
        return this.field.isSynthetic();
    }
    public FieldAttributes(reflect.Field p1)
    {
        com.google.gson.internal.$Gson$Preconditions.checkNotNull(p1);
        this.field = p1;
        return;
    }
     Object get(Object p2)
    {
        return this.field.get(p2);
    }
    public otation.Annotation getAnnotation(Class p2)
    {
        return this.field.getAnnotation(p2);
    }
    public java.util.Collection getAnnotations()
    {
        return java.util.Arrays.asList(this.field.getAnnotations());
    }
    public Class getDeclaredClass()
    {
        return this.field.getType();
    }
    public reflect.Type getDeclaredType()
    {
        return this.field.getGenericType();
    }
    public Class getDeclaringClass()
    {
        return this.field.getDeclaringClass();
    }
}
