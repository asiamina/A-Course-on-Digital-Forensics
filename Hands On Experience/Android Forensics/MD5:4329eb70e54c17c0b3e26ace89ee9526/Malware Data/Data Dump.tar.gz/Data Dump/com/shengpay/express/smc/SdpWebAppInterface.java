package com.shengpay.express.smc;
public class SdpWebAppInterface {
    private String merchantName;
    private static com.shengpay.express.smc.SdpWebAppInterface webAppInterface;
    private String walletPcgName;
    private String TAG;
    private android.content.Context context;
    private android.webkit.WebView webView;
    public SdpWebAppInterface(android.webkit.WebView p2, android.content.Context p3, String p4)
    {
        this.TAG = "SdpWebAppInterface";
        this.walletPcgName = "com.shengpay.mobile.wallet";
        this.webView = p2;
        this.context = p3;
        this.merchantName = p4;
        return;
    }
    public void callWallet(String p7)
    {
        android.util.Log.d(this.TAG, new StringBuilder("callWallet.data=").append(p7).toString());
        v2 = new org.json.JSONObject(p7);
        v1 = new android.content.Intent();
        v1.setAction("sdp.intent.action.PAY");
        v1.setData(android.net.Uri.parse("sdp:"));
        v1.putExtra("sdp_pkgName", this.context.getPackageName());
        v1.putExtra("sdp_orderNo", v2.getString("orderNo"));
        v1.putExtra("sdp_merchantNo", v2.getString("merchantNo"));
        v1.putExtra("sdp_merchantName", v2.getString("merchantName"));
        v1.putExtra("sdp_sessionToken", v2.getString("sessionToken"));
        v1.putExtra("sdp_goodsInfo", v2.getString("goodsInfo"));
        v1.putExtra("sdp_riskExt", v2.getString("riskExt"));
        v1.putExtra("sdp_appId", v2.getString("appId"));
        v1.putExtra("sdp_acquireInstOrderNo", v2.getString("acquireInstOrderNo"));
        v1.putExtra("sdp_amount", v2.getString("amount"));
        v1.putExtra("sdp_acquireInstType", v2.getString("acquireInstType"));
        v1.putExtra("sdp_sign", v2.getString("sign"));
        android.util.Log.d(this.TAG, new StringBuilder("intent.bundle=").append(v1.getExtras().toString()).toString());
        this.context.startActivity(v1);
        return;
    }
    public String getMerchantName()
    {
        if ((this.merchantName != 0) && (("".equalsIgnoreCase(this.merchantName) == 0) && (this.merchantName.length() != 0))) {
            v0 = this.merchantName;
        } else {
            v0 = "\u65b0\u5feb\u6377\u6536\u94f6\u53f0";
        }
        return v0;
    }
    public static void init(android.webkit.WebView p3, android.content.Context p4, String p5)
    {
        com.shengpay.express.smc.SdpWebAppInterface.webAppInterface = new com.shengpay.express.smc.SdpWebAppInterface(p3, p4, p5);
        p3.addJavascriptInterface(com.shengpay.express.smc.SdpWebAppInterface.webAppInterface, "walletHelper");
        p3.getSettings().setJavaScriptEnabled(1);
        return;
    }
    public String isInstalled()
    {
        this.context.getPackageManager().getApplicationInfo(this.walletPcgName, 8192);
        android.util.Log.d(this.TAG, "isInstalled,true.");
        return "true";
    }
}
