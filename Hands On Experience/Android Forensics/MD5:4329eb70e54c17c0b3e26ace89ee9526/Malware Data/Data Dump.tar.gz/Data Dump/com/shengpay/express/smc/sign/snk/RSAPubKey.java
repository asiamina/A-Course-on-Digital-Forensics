package com.shengpay.express.smc.sign.snk;
public class RSAPubKey {
    public int bitlen;
    public int pubexp;
    public int magic;
    public RSAPubKey()
    {
        return;
    }
}
