package com.wancms.sdk.floatwindow;
interface abstract class l {
    abstract public void a();
}
