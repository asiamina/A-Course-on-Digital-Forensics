package com.wancms.sdk.util;
 class c extends java.lang.Thread {
    final synthetic com.wancms.sdk.util.b a;
     c(com.wancms.sdk.util.b p1)
    {
        this.a = p1;
        return;
    }
    public void run()
    {
        android.os.Looper.prepare();
        android.widget.Toast.makeText(com.wancms.sdk.util.b.a(this.a), "\u5f88\u62b1\u6b49\uff0c\u7a0b\u5e8f\u5f02\u5e38", 1).show();
        android.os.Looper.loop();
        return;
    }
}
