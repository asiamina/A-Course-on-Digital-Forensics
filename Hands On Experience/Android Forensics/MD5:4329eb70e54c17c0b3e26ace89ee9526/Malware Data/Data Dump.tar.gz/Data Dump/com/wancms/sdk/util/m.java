package com.wancms.sdk.util;
public class m {
    public static String a;
    public static String c;
    public static String b;
    public static String e;
    public static boolean d;
    public static String g;
    public static String f;
    public static String h;
    static m()
    {
        com.wancms.sdk.util.m.a = "";
        com.wancms.sdk.util.m.b = "";
        com.wancms.sdk.util.m.c = "";
        com.wancms.sdk.util.m.d = 1;
        com.wancms.sdk.util.m.e = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code";
        com.wancms.sdk.util.m.f = "https://api.weixin.qq.com/sns/userinfo?access_token=ACCESS_TOKEN&openid=OPENID";
        com.wancms.sdk.util.m.g = "https://graph.qq.com/oauth2.0/me?access_token=ACCESSTOKEN&unionid=1";
        com.wancms.sdk.util.m.h = "http://www.85sy.com/Sdkapixx/sdk/alipay/notify_url.php";
        return;
    }
}
