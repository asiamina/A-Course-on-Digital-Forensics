package com.wancms.sdk.view;
public class au extends android.os.AsyncTask {
    final synthetic com.wancms.sdk.view.ap a;
    private boolean b;
    protected synthetic void onPostExecute(Object p1)
    {
        this.a(p1);
        return;
    }
    public au(com.wancms.sdk.view.ap p1, boolean p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
    protected varargs com.wancms.sdk.domain.f a(Void[] p3)
    {
        return com.wancms.sdk.util.g.a(com.wancms.sdk.view.ap.c).e(com.wancms.sdk.view.ap.a(this.a).a(com.wancms.sdk.view.ap.c).toString());
    }
    protected void a(com.wancms.sdk.domain.f p7)
    {
        if ((this.b) && (com.wancms.sdk.util.d.c() != 0)) {
            super.onPostExecute(p7);
            com.wancms.sdk.util.d.a();
            new com.wancms.sdk.domain.LogincallBack();
            if ((p7 == 0) || (p7.a != 1)) {
                if (p7 == 0) {
                    v1 = 0;
                } else {
                    v1 = p7.a;
                }
                if (p7 == 0) {
                    v0 = "\u670d\u52a1\u5668\u5185\u90e8\u9519\u8bef\uff0c\u8bf7\u60a8\u8054\u7cfb\u5ba2\u670d";
                } else {
                    v0 = p7.h;
                }
                com.wancms.sdk.view.ap.b().loginError(new com.wancms.sdk.domain.LoginErrorMsg(v1, v0));
                android.widget.Toast.makeText(com.wancms.sdk.view.ap.c, v0, 0).show();
            } else {
                if (com.wancms.sdk.a.b.a(com.wancms.sdk.view.ap.c).a(p7.d) != 0) {
                    com.wancms.sdk.a.b.a(com.wancms.sdk.view.ap.c).b(p7.d);
                    com.wancms.sdk.a.b.a(com.wancms.sdk.view.ap.c).a(p7.d, p7.e);
                } else {
                    com.wancms.sdk.a.b.a(com.wancms.sdk.view.ap.c).a(p7.d, p7.e);
                }
                com.wancms.sdk.WancmsSDKAppService.a = com.wancms.sdk.view.ap.a(this.a);
                if (com.wancms.sdk.view.ap.e) {
                    com.wancms.sdk.view.ap.c.finish();
                    com.wancms.sdk.ui.TrumpetActivity.a(com.wancms.sdk.view.ap.b());
                    com.wancms.sdk.ui.TrumpetActivity.a(com.wancms.sdk.view.ap.c);
                } else {
                    if (com.wancms.sdk.util.k.a(com.wancms.sdk.view.ap.c).b("IsShowDialog").equals("\u4e0d\u518d\u63d0\u793a") != 0) {
                        com.wancms.sdk.view.ap.c.finish();
                        com.wancms.sdk.ui.TrumpetActivity.a(com.wancms.sdk.view.ap.b());
                        com.wancms.sdk.ui.TrumpetActivity.a(com.wancms.sdk.view.ap.c);
                    } else {
                        v0 = new com.wancms.sdk.view.al(com.wancms.sdk.view.ap.c, p7.d, p7.e, 1);
                        v0.setCanceledOnTouchOutside(0);
                        v0.show();
                        v0.a(new com.wancms.sdk.view.av(this, v0));
                    }
                }
            }
        }
        return;
    }
    protected synthetic Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
}
