package com.wancms.sdk.ui;
 class aw extends android.os.Handler {
    final synthetic com.wancms.sdk.ui.YYWebPayActivity a;
     aw(com.wancms.sdk.ui.YYWebPayActivity p1)
    {
        this.a = p1;
        return;
    }
    public void handleMessage(android.os.Message p4)
    {
        if (p4.what != 10000) {
            com.wancms.sdk.view.d.c = 0;
            v0 = new com.wancms.sdk.domain.PaymentErrorMsg();
            v0.code = -1;
            v0.msg = "\u652f\u4ed8\u5931\u8d25";
            v0.money = Double.valueOf(com.wancms.sdk.ui.YYWebPayActivity.a(this.a)).doubleValue();
            com.wancms.sdk.ui.ChargeActivity.b.paymentError(v0);
        } else {
            com.wancms.sdk.view.d.c = 1;
            v0 = new com.wancms.sdk.domain.PaymentCallbackInfo();
            v0.money = Double.valueOf(com.wancms.sdk.ui.YYWebPayActivity.a(this.a)).doubleValue();
            v0.msg = "\u652f\u4ed8\u6210\u529f";
            com.wancms.sdk.ui.ChargeActivity.b.paymentSuccess(v0);
        }
        this.a.setResult(600);
        this.a.finish();
        return;
    }
}
