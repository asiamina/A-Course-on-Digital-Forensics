package com.wancms.sdk.domain;
public interface abstract class e {
    abstract public void a();
    abstract public void a();
}
