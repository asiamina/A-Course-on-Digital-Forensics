package com.wancms.sdk;
 class d extends android.os.AsyncTask {
    final synthetic android.content.Context a;
    final synthetic String c;
    final synthetic String b;
    final synthetic String e;
    final synthetic String d;
    final synthetic org.json.JSONObject g;
    final synthetic String f;
    final synthetic com.wancms.sdk.WancmsSDKManager h;
     d(com.wancms.sdk.WancmsSDKManager p1, android.content.Context p2, String p3, String p4, String p5, String p6, String p7, org.json.JSONObject p8)
    {
        this.h = p1;
        this.a = p2;
        this.b = p3;
        this.c = p4;
        this.d = p5;
        this.e = p6;
        this.f = p7;
        this.g = p8;
        return;
    }
    protected varargs org.json.JSONObject a(Void[] p8)
    {
        return com.wancms.sdk.util.g.a(this.a).a(this.b, this.c, this.d, this.e, this.f, this.g);
    }
    protected void a(org.json.JSONObject p3)
    {
        com.wancms.sdk.util.Logger.msg(new StringBuilder().append("\u8bbe\u7f6e\u89d2\u8272\u4fe1\u606f\u8fd4\u56deonPostExecute:::").append(p3.toString()).toString());
        if (p3.getInt("code") == 1) {
            com.wancms.sdk.util.Logger.msg("\u89d2\u8272\u4fe1\u606f\u8bbe\u7f6e\u6210\u529f!");
        }
        return;
    }
    protected synthetic Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
    protected synthetic void onPostExecute(Object p1)
    {
        this.a(p1);
        return;
    }
}
