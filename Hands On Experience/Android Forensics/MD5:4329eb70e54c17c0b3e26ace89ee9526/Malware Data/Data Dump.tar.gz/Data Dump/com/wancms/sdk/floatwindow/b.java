package com.wancms.sdk.floatwindow;
 class b implements android.view.View$OnTouchListener {
    final synthetic com.wancms.sdk.floatwindow.a a;
     b(com.wancms.sdk.floatwindow.a p1)
    {
        this.a = p1;
        return;
    }
    public boolean onTouch(android.view.View p8, android.view.MotionEvent p9)
    {
        com.wancms.sdk.floatwindow.a.d().alpha = 10.0;
        com.wancms.sdk.floatwindow.a.d().x = (((int) p9.getRawX()) - (com.wancms.sdk.floatwindow.a.a(this.a).getMeasuredWidth() / 2));
        com.wancms.sdk.floatwindow.a.d().y = ((((int) p9.getRawY()) - (com.wancms.sdk.floatwindow.a.a(this.a).getMeasuredHeight() / 2)) - 25);
        com.wancms.sdk.floatwindow.a.f().updateViewLayout(com.wancms.sdk.floatwindow.a.e(), com.wancms.sdk.floatwindow.a.d());
        v0 = ((double) (((float) com.wancms.sdk.util.e.a(com.wancms.sdk.floatwindow.a.b(this.a))) - p9.getRawX()));
        v2 = ((double) (((float) com.wancms.sdk.util.e.b(com.wancms.sdk.floatwindow.a.b(this.a))) - p9.getRawY()));
        com.wancms.sdk.util.Logger.msg(new StringBuilder().append("dx=").append(p9.getRawX()).toString());
        com.wancms.sdk.util.Logger.msg(new StringBuilder().append("dy=").append(v2).toString());
        com.wancms.sdk.floatwindow.a.a(this.a, "other");
        if (v0 < ((double) (com.wancms.sdk.util.e.a(com.wancms.sdk.floatwindow.a.b(this.a)) / 6))) {
            com.wancms.sdk.floatwindow.a.a(this.a, "RIGHT");
        }
        if (p9.getRawX() < ((float) (com.wancms.sdk.util.e.a(com.wancms.sdk.floatwindow.a.b(this.a)) / 6))) {
            com.wancms.sdk.floatwindow.a.a(this.a, "LEFT");
        }
        switch (p9.getAction()) {
            case 0:
                com.wancms.sdk.floatwindow.a.a(this.a).setImageResource(com.wancms.sdk.util.MResource.getIdByName(com.wancms.sdk.floatwindow.a.b(this.a), "drawable", "wancms_fload"));
                break;
            case 1:
                com.wancms.sdk.floatwindow.a.a(this.a).setImageResource(com.wancms.sdk.util.MResource.getIdByName(com.wancms.sdk.floatwindow.a.b(this.a), "drawable", "wancms_fload"));
                if (com.wancms.sdk.floatwindow.a.c(this.a).equals("LEFT") == 0) {
                    if (com.wancms.sdk.floatwindow.a.c(this.a).equals("RIGHT") == 0) {
                    } else {
                        com.wancms.sdk.floatwindow.a.d().x = com.wancms.sdk.util.e.a(com.wancms.sdk.floatwindow.a.b(this.a));
                        com.wancms.sdk.floatwindow.a.d().y = ((((int) p9.getRawY()) - (com.wancms.sdk.floatwindow.a.a(this.a).getMeasuredHeight() / 2)) - 25);
                        com.wancms.sdk.floatwindow.a.d(this.a).setVisibility(8);
                        com.wancms.sdk.floatwindow.a.f().updateViewLayout(com.wancms.sdk.floatwindow.a.e(), com.wancms.sdk.floatwindow.a.d());
                        com.wancms.sdk.floatwindow.a.a(this.a).setImageResource(com.wancms.sdk.util.MResource.getIdByName(com.wancms.sdk.floatwindow.a.b(this.a), "drawable", "wancms_fload_right"));
                    }
                } else {
                    com.wancms.sdk.floatwindow.a.d().x = -25;
                    com.wancms.sdk.floatwindow.a.d().y = ((((int) p9.getRawY()) - (com.wancms.sdk.floatwindow.a.a(this.a).getMeasuredHeight() / 2)) - 25);
                    com.wancms.sdk.floatwindow.a.d(this.a).setVisibility(8);
                    com.wancms.sdk.floatwindow.a.f().updateViewLayout(com.wancms.sdk.floatwindow.a.e(), com.wancms.sdk.floatwindow.a.d());
                    com.wancms.sdk.floatwindow.a.a(this.a).setImageResource(com.wancms.sdk.util.MResource.getIdByName(com.wancms.sdk.floatwindow.a.b(this.a), "drawable", "wancms_fload_left"));
                }
                break;
        }
        return 0;
    }
}
