package com.wancms.sdk.ui;
public class YIJIWebPayActivity extends android.app.Activity implements android.view.View$OnClickListener {
    private android.webkit.WebView a;
    private String c;
    private String b;
    private String e;
    private String d;
    private String g;
    private String f;
    private String i;
    private String h;
    private String k;
    private String j;
    private double m;
    private double l;
    private android.widget.TextView o;
    private double n;
    private android.widget.ImageView q;
    private android.widget.TextView p;
    private com.wancms.sdk.domain.PaymentCallbackInfo r;
    static synthetic String f(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.i;
    }
    static synthetic String g(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.j;
    }
    static synthetic double h(com.wancms.sdk.ui.YIJIWebPayActivity p2)
    {
        return p2.m;
    }
    static synthetic double i(com.wancms.sdk.ui.YIJIWebPayActivity p2)
    {
        return p2.n;
    }
    static synthetic String j(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.d;
    }
    static synthetic String k(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.e;
    }
    static synthetic String l(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.f;
    }
    static synthetic String m(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.g;
    }
    static synthetic String n(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.h;
    }
    public void onBackPressed()
    {
        super.onBackPressed();
        this.setResult(300);
        this.finish();
        return;
    }
    public void onClick(android.view.View p4)
    {
        if (p4.getId() == this.o.getId()) {
            this.setResult(300);
            com.wancms.sdk.ui.ChargeActivity.c.finish();
            com.wancms.sdk.ui.ChargeActivity.b.paymentSuccess(this.r);
            this.finish();
        }
        if (p4.getId() == this.q.getId()) {
            this.setResult(300);
            com.wancms.sdk.ui.ChargeActivity.c.finish();
            com.wancms.sdk.ui.ChargeActivity.b.paymentSuccess(this.r);
            this.finish();
        }
        return;
    }
    protected void onCreate(android.os.Bundle p7)
    {
        super.onCreate(p7);
        this.setContentView(com.wancms.sdk.util.MResource.getIdByName(this.getApplication(), "layout", "wancms_sdk_float_web"));
        v0 = this.getIntent();
        this.l = v0.getDoubleExtra("price", 1.0);
        this.m = v0.getDoubleExtra("discount", 1.0);
        this.n = v0.getDoubleExtra("cost_price", 1.0);
        this.c = v0.getStringExtra("payid");
        this.b = v0.getStringExtra("username");
        this.e = v0.getStringExtra("username");
        this.f = v0.getStringExtra("productdesc");
        this.g = v0.getStringExtra("fcallbackurl");
        this.i = v0.getStringExtra("roleid");
        this.j = v0.getStringExtra("serverid");
        this.h = v0.getStringExtra("attach");
        this.a();
        this.d = this;
        if (this.c.equals("15") == 0) {
            this.k = "wx";
        } else {
            this.k = "zfb";
        }
        this.r.msg = "\u8fd9\u4e0d\u662f\u51c6\u786e\u56de\u8c03";
        this.r.money = 0.0;
        this.a = this.findViewById(com.wancms.sdk.util.MResource.getIdByName(this.getApplication(), "id", "wv_content"));
        this.o = this.findViewById(com.wancms.sdk.util.MResource.getIdByName(this.getApplication(), "id", "tv_back"));
        this.q = this.findViewById(com.wancms.sdk.util.MResource.getIdByName(this.getApplication(), "id", "iv_cancel"));
        this.p = this.findViewById(com.wancms.sdk.util.MResource.getIdByName(this.getApplication(), "id", "tv_charge_title"));
        this.p.setText("\u5145\u503c");
        this.a.getSettings().setJavaScriptEnabled(1);
        this.a.getSettings().setLoadsImagesAutomatically(1);
        this.a.getSettings().setAppCacheEnabled(0);
        this.a.getSettings().setDomStorageEnabled(1);
        this.a.setWebViewClient(new com.wancms.sdk.ui.au(this));
        this.b();
        this.o.setOnClickListener(this);
        this.q.setOnClickListener(this);
        return;
    }
    protected void onDestroy()
    {
        super.onDestroy();
        this.setResult(300);
        this.finish();
        return;
    }
    public boolean onKeyUp(int p3, android.view.KeyEvent p4)
    {
        if ((p3 != 4) || (this.a.canGoBack() == 0)) {
            this.setResult(300);
            com.wancms.sdk.ui.ChargeActivity.c.finish();
            com.wancms.sdk.ui.ChargeActivity.b.paymentSuccess(this.r);
            this.finish();
            v0 = 0;
        } else {
            this.setResult(300);
            com.wancms.sdk.ui.ChargeActivity.c.finish();
            com.wancms.sdk.ui.ChargeActivity.b.paymentSuccess(this.r);
            this.finish();
            v0 = 1;
        }
        return v0;
    }
    public YIJIWebPayActivity()
    {
        this.r = new com.wancms.sdk.domain.PaymentCallbackInfo();
        return;
    }
    static synthetic android.webkit.WebView a(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.a;
    }
    private String a()
    {
        System.currentTimeMillis();
        return new StringBuilder().append("").append(System.currentTimeMillis()).append(((new java.util.Random().nextInt(9999) % 9000) + 1000)).toString();
    }
    static synthetic com.wancms.sdk.domain.PaymentCallbackInfo b(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.r;
    }
    private void b()
    {
        v1 = new Void[0];
        new com.wancms.sdk.ui.av(this).execute(v1);
        return;
    }
    static synthetic String c(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.k;
    }
    static synthetic double d(com.wancms.sdk.ui.YIJIWebPayActivity p2)
    {
        return p2.l;
    }
    static synthetic String e(com.wancms.sdk.ui.YIJIWebPayActivity p1)
    {
        return p1.b;
    }
}
