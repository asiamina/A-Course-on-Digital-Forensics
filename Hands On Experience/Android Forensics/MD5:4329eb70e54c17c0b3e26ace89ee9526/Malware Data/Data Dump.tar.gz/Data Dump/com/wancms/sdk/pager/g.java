package com.wancms.sdk.pager;
interface abstract class g {
    abstract public void a();
}
