package com.wancms.sdk.domain;
public interface abstract class OnLogoutListener {
    abstract public void logoutError();
    abstract public void logoutSuccess();
}
