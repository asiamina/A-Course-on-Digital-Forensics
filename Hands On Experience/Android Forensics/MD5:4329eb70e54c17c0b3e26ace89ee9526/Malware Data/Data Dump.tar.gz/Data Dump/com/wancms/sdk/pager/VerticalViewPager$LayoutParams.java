package com.wancms.sdk.pager;
public class VerticalViewPager$LayoutParams extends android.view.ViewGroup$LayoutParams {
    public boolean a;
    public int b;
    public VerticalViewPager$LayoutParams()
    {
        this(-1, -1);
        return;
    }
    public VerticalViewPager$LayoutParams(android.content.Context p3, android.util.AttributeSet p4)
    {
        this(p3, p4);
        v0 = p3.obtainStyledAttributes(p4, com.wancms.sdk.pager.VerticalViewPager.access$100());
        this.b = v0.getInteger(0, 0);
        v0.recycle();
        return;
    }
}
