package com.wancms.sdk.view;
public class ax extends com.wancms.sdk.view.a {
    public static android.content.Context c;
    private android.widget.TextView e;
    private android.widget.ImageView d;
    private android.webkit.WebView g;
    private android.widget.TextView f;
    public ax(android.content.Context p4)
    {
        com.wancms.sdk.view.ax.c = p4;
        this.b = p4.getSystemService("layout_inflater");
        this.a = this.b.inflate(com.wancms.sdk.util.MResource.getIdByName(p4, "layout", "ttw_user_agreement"), 0);
        this.e = this.a.findViewById(com.wancms.sdk.util.MResource.getIdByName(p4, "id", "tv_charge_title"));
        this.f = this.a.findViewById(com.wancms.sdk.util.MResource.getIdByName(p4, "id", "tv_back"));
        this.d = this.a.findViewById(com.wancms.sdk.util.MResource.getIdByName(p4, "id", "iv_ingame"));
        this.g = this.a.findViewById(com.wancms.sdk.util.MResource.getIdByName(p4, "id", "wv_content"));
        this.e.setText("\u7528\u6237\u534f\u8bae");
        this.d.setVisibility(8);
        this.g.setWebViewClient(new com.wancms.sdk.view.ay(this));
        this.g.loadUrl("http://www.85sy.com/Sdkapixx/Agreement/xieyi");
        return;
    }
    public android.view.View a()
    {
        return this.a;
    }
    public void a(android.view.View$OnClickListener p2)
    {
        this.f.setOnClickListener(p2);
        return;
    }
    public void onClick(android.view.View p1)
    {
        return;
    }
}
