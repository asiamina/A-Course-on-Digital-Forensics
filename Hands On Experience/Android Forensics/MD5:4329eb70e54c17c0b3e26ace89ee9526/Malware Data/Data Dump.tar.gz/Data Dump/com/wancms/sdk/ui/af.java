package com.wancms.sdk.ui;
 class af extends android.os.AsyncTask {
    final synthetic com.wancms.sdk.ui.ad a;
     af(com.wancms.sdk.ui.ad p1)
    {
        this.a = p1;
        return;
    }
    protected varargs com.wancms.sdk.domain.f a(Void[] p4)
    {
        v1 = new org.json.JSONObject();
        v1.put("z", com.wancms.sdk.WancmsSDKAppService.d);
        v1.put("b", com.wancms.sdk.WancmsSDKAppService.a.a);
        return com.wancms.sdk.util.g.a(this.a.a).o(v1.toString());
    }
    protected void a(com.wancms.sdk.domain.f p5)
    {
        if (p5 != 0) {
            if (p5.a == 1) {
                com.wancms.sdk.WancmsSDKAppService.j = com.wancms.sdk.ui.ad.a(this.a, p5.b);
            }
            if (p5.a == -2) {
                com.wancms.sdk.WancmsSDKAppService.j = 0;
            }
            if (p5.h != 0) {
                v0 = p5.h;
            } else {
                v0 = "\u5e73\u53f0\u5e01\u5237\u65b0\u5931\u8d25";
            }
            android.widget.Toast.makeText(this.a.a, v0, 0).show();
            com.wancms.sdk.ui.ad.i(this.a).setText(String.valueOf(com.wancms.sdk.WancmsSDKAppService.j));
            com.wancms.sdk.ui.ad.a(this.a, System.currentTimeMillis());
            com.wancms.sdk.ui.ad.a(this.a, 1);
        }
        return;
    }
    protected synthetic Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
    protected synthetic void onPostExecute(Object p1)
    {
        this.a(p1);
        return;
    }
}
