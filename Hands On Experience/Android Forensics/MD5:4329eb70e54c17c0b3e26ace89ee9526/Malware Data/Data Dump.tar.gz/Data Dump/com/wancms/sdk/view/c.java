package com.wancms.sdk.view;
 class c extends android.webkit.WebViewClient {
    final synthetic com.wancms.sdk.view.b a;
    public void onPageFinished(android.webkit.WebView p2, String p3)
    {
        super.onPageFinished(p2, p3);
        com.wancms.sdk.util.d.a();
        return;
    }
    public void onPageStarted(android.webkit.WebView p3, String p4, android.graphics.Bitmap p5)
    {
        super.onPageStarted(p3, p4, p5);
        if (com.wancms.sdk.util.d.c() == 0) {
            com.wancms.sdk.util.d.a(com.wancms.sdk.view.b.c, "\u6b63\u5728\u52a0\u8f7d...");
        }
        return;
    }
     c(com.wancms.sdk.view.b p1)
    {
        this.a = p1;
        return;
    }
}
