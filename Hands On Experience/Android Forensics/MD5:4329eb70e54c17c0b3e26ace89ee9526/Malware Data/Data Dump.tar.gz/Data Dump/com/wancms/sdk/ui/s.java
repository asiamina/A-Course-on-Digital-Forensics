package com.wancms.sdk.ui;
 class s implements android.view.View$OnClickListener {
    final synthetic com.wancms.sdk.ui.LoginActivity a;
     s(com.wancms.sdk.ui.LoginActivity p1)
    {
        this.a = p1;
        return;
    }
    public void onClick(android.view.View p6)
    {
        if (p6.getId() != com.wancms.sdk.util.MResource.getIdByName(this.a, "id", "tv_register")) {
            if (p6.getId() != com.wancms.sdk.util.MResource.getIdByName(this.a, "id", "tv_cut")) {
                if (p6.getId() != com.wancms.sdk.util.MResource.getIdByName(this.a, "id", "tv_back")) {
                    if (p6.getId() != com.wancms.sdk.util.MResource.getIdByName(this.a, "id", "tv_user_aggrement")) {
                        if (p6.getId() != com.wancms.sdk.util.MResource.getIdByName(this.a, "id", "iv_login_wechat")) {
                            if (p6.getId() == com.wancms.sdk.util.MResource.getIdByName(this.a, "id", "iv_login_qq")) {
                                if (this.a.a(this.a) != 0) {
                                    com.wancms.sdk.util.BaseApplication.j = "qq";
                                    com.wancms.sdk.ui.LoginActivity.a(this.a, com.tencent.tauth.Tencent.createInstance(com.wancms.sdk.util.m.a, this.a));
                                    com.wancms.sdk.ui.LoginActivity.f(this.a).login(this.a, "all", com.wancms.sdk.ui.LoginActivity.e(this.a));
                                } else {
                                    android.widget.Toast.makeText(this.a, "\u8bf7\u5b89\u88c5qq\u540e\u518d\u8fdb\u884c\u6388\u6743\u767b\u5f55", 0).show();
                                }
                            }
                        } else {
                            if (com.wancms.sdk.ui.LoginActivity.d(this.a) == 0) {
                                com.wancms.sdk.ui.LoginActivity.a(this.a, com.tencent.mm.sdk.openapi.WXAPIFactory.createWXAPI(this.a, com.wancms.sdk.util.m.b, 1));
                            }
                            if (com.wancms.sdk.ui.LoginActivity.d(this.a).isWXAppInstalled() != 0) {
                                com.wancms.sdk.util.BaseApplication.j = "weixin";
                                com.wancms.sdk.ui.LoginActivity.d(this.a).registerApp(com.wancms.sdk.util.m.b);
                                v0 = new com.tencent.mm.sdk.modelmsg.SendAuth$Req();
                                v0.scope = "snsapi_userinfo";
                                v0.state = "wechat_sdk_demo_test";
                                com.wancms.sdk.ui.LoginActivity.d(this.a).sendReq(v0);
                            } else {
                                android.widget.Toast.makeText(this.a, "\u8bf7\u5b89\u88c5\u5fae\u4fe1\u540e\u518d\u8fdb\u884c\u6388\u6743\u767b\u5f55\uff01", 0).show();
                            }
                        }
                    } else {
                        v0 = new com.wancms.sdk.view.ax(this.a);
                        this.a.pushView2Stack(v0.a());
                        v0.a(com.wancms.sdk.ui.LoginActivity.a(this.a));
                    }
                } else {
                    this.a.popViewFromStack();
                }
            } else {
                this.a.popViewFromStack();
            }
        } else {
            com.wancms.sdk.ui.LoginActivity.a(this.a, new com.wancms.sdk.view.ap(this.a, com.wancms.sdk.ui.LoginActivity.a));
            com.wancms.sdk.ui.LoginActivity.c(this.a).h = 0;
            com.wancms.sdk.ui.LoginActivity.c(this.a);
            com.wancms.sdk.view.ap.e = 0;
            com.wancms.sdk.ui.LoginActivity.c(this.a).a(new com.wancms.sdk.ui.t(this));
            com.wancms.sdk.ui.LoginActivity.c(this.a).a(com.wancms.sdk.ui.LoginActivity.a(this.a));
        }
        return;
    }
}
