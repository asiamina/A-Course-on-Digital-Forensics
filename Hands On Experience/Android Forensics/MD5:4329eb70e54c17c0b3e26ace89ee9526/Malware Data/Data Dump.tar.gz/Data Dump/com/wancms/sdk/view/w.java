package com.wancms.sdk.view;
 class w implements android.view.View$OnClickListener {
    final synthetic int a;
    final synthetic com.wancms.sdk.view.v b;
     w(com.wancms.sdk.view.v p1, int p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }
    public void onClick(android.view.View p4)
    {
        if (com.wancms.sdk.view.o.a(this.b.a).getText().toString().trim().equals(com.wancms.sdk.view.o.m(this.b.a).get(this.a).a) != 0) {
            com.wancms.sdk.view.o.a(this.b.a).setText("");
            com.wancms.sdk.view.o.b(this.b.a).setText("");
        }
        com.wancms.sdk.a.b.a(com.wancms.sdk.view.o.c).b(com.wancms.sdk.view.o.m(this.b.a).get(this.a).a);
        com.wancms.sdk.view.o.m(this.b.a).remove(this.a);
        if (com.wancms.sdk.view.o.o(this.b.a) != 0) {
            com.wancms.sdk.view.o.o(this.b.a).notifyDataSetChanged();
        }
        return;
    }
}
