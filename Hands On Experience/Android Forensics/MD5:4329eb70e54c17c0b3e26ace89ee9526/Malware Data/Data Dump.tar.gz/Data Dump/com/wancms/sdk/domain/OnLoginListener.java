package com.wancms.sdk.domain;
public interface abstract class OnLoginListener {
    abstract public void loginError();
    abstract public void loginSuccess();
}
