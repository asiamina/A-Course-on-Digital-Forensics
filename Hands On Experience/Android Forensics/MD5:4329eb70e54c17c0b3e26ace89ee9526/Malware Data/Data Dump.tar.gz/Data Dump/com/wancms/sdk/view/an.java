package com.wancms.sdk.view;
public interface abstract class an {
    abstract public void a();
    abstract public void b();
    abstract public void c();
}
