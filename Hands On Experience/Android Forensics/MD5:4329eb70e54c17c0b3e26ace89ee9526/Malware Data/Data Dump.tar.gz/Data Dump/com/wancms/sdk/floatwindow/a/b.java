package com.wancms.sdk.floatwindow.a;
public class b {
    public static boolean b()
    {
        v0 = 0;
        v1 = com.wancms.sdk.floatwindow.a.b.a("ro.build.display.id");
        if ((android.text.TextUtils.isEmpty(v1) == 0) && ((v1.contains("flyme") != 0) || (v1.toLowerCase().contains("flyme") != 0))) {
            v0 = 1;
        }
        return v0;
    }
    public static String a(String p6)
    {
        v2 = new java.io.BufferedReader(new java.io.InputStreamReader(v0.exec(new StringBuilder().append("getprop ").append(p6).toString()).getInputStream()), Runtime.getRuntime());
        v0 = v2.readLine();
        v2.close();
        if (v2 != 0) {
            v2.close();
        }
        return v0;
    }
    public static boolean a()
    {
        if (android.text.TextUtils.isEmpty(com.wancms.sdk.floatwindow.a.b.a("ro.miui.ui.version.name")) != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
}
