package com.wancms.sdk.view;
 class ag implements android.support.v4.view.ViewPager$OnPageChangeListener {
    final synthetic com.wancms.sdk.view.ae a;
    public void onPageScrolled(int p4, float p5, int p6)
    {
        com.wancms.sdk.util.Logger.msg(new StringBuilder().append("position:").append(p4).append("  positionoffset:").append(p5).append("  positionoffsetPixels:").append(p6).toString());
        v0 = com.wancms.sdk.view.ae.v(this.a).getLayoutParams();
        v0.leftMargin = ((int) (((float) (com.wancms.sdk.view.ae.v(this.a).getWidth() * p4)) + (((float) v0.width) * p5)));
        com.wancms.sdk.view.ae.v(this.a).setLayoutParams(v0);
        return;
    }
    public void onPageSelected(int p5)
    {
        switch (p5) {
            case 0:
                com.wancms.sdk.view.ae.b(this.a, 0);
                com.wancms.sdk.view.ae.a(this.a, 1);
                com.wancms.sdk.view.ae.b(this.a, "\u652f\u4ed8\u6210\u529f!");
                this.a.a();
                com.wancms.sdk.view.ae.p(this.a).setTextColor(-1);
                this.a.a(com.wancms.sdk.view.ae.c(), com.wancms.sdk.view.ae.q(this.a), com.wancms.sdk.view.ae.j(this.a));
                break;
            case 1:
                com.wancms.sdk.view.ae.b(this.a, 0);
                com.wancms.sdk.view.ae.a(this.a, 1);
                com.wancms.sdk.view.ae.b(this.a, "\u672a\u652f\u4ed8\uff01");
                this.a.a();
                com.wancms.sdk.view.ae.r(this.a).setTextColor(-1);
                this.a.a(com.wancms.sdk.view.ae.d(), com.wancms.sdk.view.ae.s(this.a), com.wancms.sdk.view.ae.l(this.a));
                break;
            case 2:
                com.wancms.sdk.view.ae.b(this.a, 0);
                com.wancms.sdk.view.ae.a(this.a, 1);
                com.wancms.sdk.view.ae.b(this.a, "\u652f\u4ed8\u5931\u8d25!");
                this.a.a();
                com.wancms.sdk.view.ae.t(this.a).setTextColor(-1);
                this.a.a(com.wancms.sdk.view.ae.e(), com.wancms.sdk.view.ae.u(this.a), com.wancms.sdk.view.ae.n(this.a));
                break;
        }
        return;
    }
    private ag(com.wancms.sdk.view.ae p1)
    {
        this.a = p1;
        return;
    }
    synthetic ag(com.wancms.sdk.view.ae p1, com.wancms.sdk.view.af p2)
    {
        this(p1);
        return;
    }
    public void onPageScrollStateChanged(int p4)
    {
        com.wancms.sdk.view.ae.w(this.a).hideSoftInputFromWindow(this.a.a.getApplicationWindowToken(), 2);
        return;
    }
}
