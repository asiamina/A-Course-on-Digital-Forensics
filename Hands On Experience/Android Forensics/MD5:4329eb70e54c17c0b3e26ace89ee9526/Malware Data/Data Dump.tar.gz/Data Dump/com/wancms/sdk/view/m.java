package com.wancms.sdk.view;
public interface abstract class m {
    abstract public void a();
    abstract public void a();
}
