package com.wancms.sdk;
 class a implements java.lang.Runnable {
    final synthetic com.wancms.sdk.WancmsSDKAppService a;
    public void run()
    {
        v0 = new org.json.JSONObject();
        v0.put("z", com.wancms.sdk.WancmsSDKAppService.d);
        v0.put("b", com.wancms.sdk.WancmsSDKAppService.a.a);
        com.wancms.sdk.WancmsSDKAppService.j = com.wancms.sdk.util.g.a(this.a).n(v0.toString());
        return;
    }
     a(com.wancms.sdk.WancmsSDKAppService p1)
    {
        this.a = p1;
        return;
    }
}
