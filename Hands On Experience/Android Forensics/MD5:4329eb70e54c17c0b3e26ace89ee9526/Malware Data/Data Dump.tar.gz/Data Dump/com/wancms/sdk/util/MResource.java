package com.wancms.sdk.util;
public class MResource {
    public MResource()
    {
        return;
    }
    public static int getIdByName(android.content.Context p2, String p3, String p4)
    {
        if (p2.getResources().getIdentifier(p4, p3, p2.getPackageName()) != 0) {
            return p2.getResources().getIdentifier(p4, p3, p2.getPackageName());
        } else {
            throw new Exception("can not find resources id");
        }
    }
    public static int[] getIdsByName(android.content.Context p5, String p6, String p7)
    {
        v2 = Class.forName(new StringBuilder().append(p5.getPackageName()).append(".R").toString()).getClasses();
        v0 = 0;
        while (v0 < v2.length) {
            if (v2[v0].getName().split("\\$")[1].equals(p6) == 0) {
                v0++;
            } else {
                v0 = v2[v0];
            }
            if ((v0 == 0) || ((v0.getField(p7).get(v0) == 0) || (v0.getField(p7).get(v0).getClass().isArray() == 0))) {
                v0 = 0;
            } else {
                v0 = v0.getField(p7).get(v0);
            }
            return v0;
        }
        v0 = 0;
    }
}
