package com.wancms.sdk.pager;
public class VerticalViewPager extends android.view.ViewGroup {
    private boolean mPopulatePending;
    final private static String TAG;
    private android.view.VelocityTracker mVelocityTracker;
    private boolean mScrollingCacheEnabled;
    private com.wancms.sdk.pager.h mInternalPageChangeListener;
    final public static int SCROLL_STATE_SETTLING;
    final private static int DEFAULT_OFFSCREEN_PAGES;
    private float mInitialMotionY;
    private android.os.Parcelable mRestoredAdapterState;
    private android.support.v4.widget.EdgeEffectCompat mBottomEdge;
    final public static int SCROLL_STATE_IDLE;
    final private static int INVALID_POINTER;
    private int mFlingDistance;
    final private static int[] LAYOUT_ATTRS;
    private ClassLoader mRestoredClassLoader;
    private com.wancms.sdk.pager.h mOnPageChangeListener;
    final private static java.util.Comparator COMPARATOR;
    private int mDecorChildCount;
    private int mOffscreenPageLimit;
    private android.graphics.drawable.Drawable mMarginDrawable;
    private float mLastMotionX;
    final private static int MAX_SETTLE_DURATION;
    private android.support.v4.widget.EdgeEffectCompat mTopEdge;
    private int mRestoredCurItem;
    private boolean mFirstLayout;
    private int mTouchSlop;
    private int mRightPageBounds;
    private com.wancms.sdk.pager.g mAdapterChangeListener;
    final private java.util.ArrayList mItems;
    private int mChildHeightMeasureSpec;
    private float mLastMotionY;
    private int mActivePointerId;
    final private static int MIN_DISTANCE_FOR_FLING;
    final private static android.view.animation.Interpolator sInterpolator;
    private int mPageMargin;
    private int mMaximumVelocity;
    private int mChildWidthMeasureSpec;
    private boolean mFakeDragging;
    final public static int SCROLL_STATE_DRAGGING;
    private int mLeftPageBounds;
    final private static boolean DEBUG;
    private long mFakeDragBeginTime;
    private int mScrollState;
    private android.widget.Scroller mScroller;
    final private static boolean USE_CACHE;
    private boolean mIsUnableToDrag;
    private int mMinimumVelocity;
    private boolean mIsBeingDragged;
    private com.wancms.sdk.pager.a mAdapter;
    private boolean mCalledSuper;
    private boolean mScrolling;
    private com.wancms.sdk.pager.i mObserver;
    private boolean mInLayout;
    private int mCurItem;
    public int getOffscreenPageLimit()
    {
        return this.mOffscreenPageLimit;
    }
    public int getPageMargin()
    {
        return this.mPageMargin;
    }
     com.wancms.sdk.pager.f infoForAnyChild(android.view.View p3)
    {
        while(true) {
            v0 = p3.getParent();
            if (v0 == this) {
                v0 = this.infoForChild(p3);
            } else {
                if ((v0 == 0) || ((v0 instanceof android.view.View) == 0)) {
                    break;
                }
                p3 = v0;
            }
            return v0;
        }
        v0 = 0;
    }
     com.wancms.sdk.pager.f infoForChild(android.view.View p5)
    {
        v1 = 0;
        while (v1 < this.mItems.size()) {
            v0 = this.mItems.get(v1);
            if (this.mAdapter.isViewFromObject(p5, v0.a) == 0) {
                v1++;
            }
            return v0;
        }
        v0 = 0;
    }
     void initViewPager()
    {
        this.setWillNotDraw(0);
        this.setDescendantFocusability(3.6734198463196485e-40);
        this.setFocusable(1);
        v0 = this.getContext();
        this.mScroller = new android.widget.Scroller(v0, com.wancms.sdk.pager.VerticalViewPager.sInterpolator);
        v1 = android.view.ViewConfiguration.get(v0);
        this.mTouchSlop = android.support.v4.view.ViewConfigurationCompat.getScaledPagingTouchSlop(v1);
        this.mMinimumVelocity = v1.getScaledMinimumFlingVelocity();
        this.mMaximumVelocity = v1.getScaledMaximumFlingVelocity();
        this.mTopEdge = new android.support.v4.widget.EdgeEffectCompat(v0);
        this.mBottomEdge = new android.support.v4.widget.EdgeEffectCompat(v0);
        this.mFlingDistance = ((int) (v0.getResources().getDisplayMetrics().density * 25.0));
        return;
    }
    public boolean isFakeDragging()
    {
        return this.mFakeDragging;
    }
    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        this.mFirstLayout = 1;
        return;
    }
    protected void onDraw(android.graphics.Canvas p6)
    {
        super.onDraw(p6);
        if ((this.mPageMargin > 0) && (this.mMarginDrawable != 0)) {
            v0 = this.getScrollY();
            v1 = this.getHeight();
            v2 = (v0 % (this.mPageMargin + v1));
            if (v2 != 0) {
                v0 = ((v0 - v2) + v1);
                this.mMarginDrawable.setBounds(this.mLeftPageBounds, v0, this.mRightPageBounds, (this.mPageMargin + v0));
                this.mMarginDrawable.draw(p6);
            }
        }
        return;
    }
    public boolean onInterceptTouchEvent(android.view.MotionEvent p12)
    {
        v2 = 0;
        v0 = (p12.getAction() & 255);
        if ((v0 != 3) && (v0 != 1)) {
            if (v0 != 0) {
                if (!this.mIsBeingDragged) {
                    if (this.mIsUnableToDrag) {
                        return v2;
                    }
                } else {
                    v2 = 1;
                }
            }
            switch (v0) {
                case 0:
                    this.mLastMotionX = p12.getX();
                    v0 = p12.getY();
                    this.mInitialMotionY = v0;
                    this.mLastMotionY = v0;
                    this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p12, 0);
                    if (this.mScrollState != 2) {
                        this.completeScroll();
                        this.mIsBeingDragged = 0;
                        this.mIsUnableToDrag = 0;
                    } else {
                        this.mIsBeingDragged = 1;
                        this.mIsUnableToDrag = 0;
                        this.setScrollState(1);
                    }
                case 2:
                    v0 = this.mActivePointerId;
                    if (v0 == -1) {
                    } else {
                        v0 = android.support.v4.view.MotionEventCompat.findPointerIndex(p12, v0);
                        v7 = android.support.v4.view.MotionEventCompat.getX(p12, v0);
                        v8 = Math.abs((v7 - this.mLastMotionX));
                        v9 = android.support.v4.view.MotionEventCompat.getY(p12, v0);
                        v0 = (v9 - this.mLastMotionY);
                        v10 = Math.abs(v0);
                        if (this.canScroll(this, 0, ((int) v0), ((int) v7), ((int) v9)) == 0) {
                            if ((v10 <= ((float) this.mTouchSlop)) || (v10 <= v8)) {
                                if (v8 <= ((float) this.mTouchSlop)) {
                                } else {
                                    this.mIsUnableToDrag = 1;
                                }
                            } else {
                                this.mIsBeingDragged = 1;
                                this.setScrollState(1);
                                this.mLastMotionY = v9;
                                this.setScrollingCacheEnabled(1);
                            }
                        } else {
                            this.mLastMotionY = v9;
                            this.mInitialMotionY = v9;
                            this.mLastMotionX = v7;
                        }
                    }
                    break;
                case 6:
                    this.onSecondaryPointerUp(p12);
                    break;
            }
            if (this.mIsBeingDragged) {
                if (this.mVelocityTracker == 0) {
                    this.mVelocityTracker = android.view.VelocityTracker.obtain();
                }
                this.mVelocityTracker.addMovement(p12);
            }
            v2 = this.mIsBeingDragged;
        } else {
            this.mIsBeingDragged = 0;
            this.mIsUnableToDrag = 0;
            this.mActivePointerId = -1;
            if (this.mVelocityTracker != 0) {
                this.mVelocityTracker.recycle();
                this.mVelocityTracker = 0;
            }
        }
    }
    protected void onLayout(boolean p18, int p19, int p20, int p21, int p22)
    {
        this.mInLayout = 1;
        this.populate();
        this.mInLayout = 0;
        v9 = this.getChildCount();
        v10 = (p21 - p19);
        v11 = (p22 - p20);
        v6 = this.getPaddingLeft();
        v2 = this.getPaddingTop();
        v5 = this.getPaddingRight();
        v3 = this.getPaddingBottom();
        v12 = this.getScrollY();
        v4 = 0;
        v8 = 0;
        while (v8 < v9) {
            v13 = this.getChildAt(v8);
            if (v13.getVisibility() == 8) {
                v1 = v4;
                v4 = v2;
                v2 = v5;
                v5 = v6;
            } else {
                v1 = v13.getLayoutParams();
                if (!v1.a) {
                    v1 = this.infoForChild(v13);
                    } else {
                        v1 = ((v1.b * (this.mPageMargin + v11)) + v2);
                        v13.layout(v6, v1, (v13.getMeasuredWidth() + v6), (v13.getMeasuredHeight() + v1));
                    }
                } else {
                    v14 = (v1.b & 112);
                    switch ((v1.b & 7)) {
                        case 1:
                            v7 = Math.max(((v10 - v13.getMeasuredWidth()) / 2), v6);
                            break;
                        case 2:
                        case 4:
                        default:
                            v7 = v6;
                            break;
                        case 3:
                            v7 = v6;
                            v6 = (v13.getMeasuredWidth() + v6);
                            break;
                        case 5:
                            v1 = ((v10 - v5) - v13.getMeasuredWidth());
                            v5 += v13.getMeasuredWidth();
                            v7 = v1;
                            break;
                    }
                    switch (v14) {
                        case 16:
                            v1 = Math.max(((v11 - v13.getMeasuredHeight()) / 2), v2);
                            v16 = v3;
                            v3 = v2;
                            v2 = v16;
                            break;
                        case 48:
                            v1 = (v13.getMeasuredHeight() + v2);
                            v16 = v2;
                            v2 = v3;
                            v3 = v1;
                            v1 = v16;
                            break;
                        case 80:
                            v1 = ((v11 - v3) - v13.getMeasuredHeight());
                            v16 = (v3 + v13.getMeasuredHeight());
                            v3 = v2;
                            v2 = v16;
                            break;
                        default:
                            v1 = v2;
                            v16 = v3;
                            v3 = v2;
                            v2 = v16;
                    }
                    v14 = (v1 + v12);
                    v1 = (v4 + 1);
                    v13.layout(v7, v14, (v13.getMeasuredWidth() + v7), (v13.getMeasuredHeight() + v14));
                    v4 = v3;
                    v3 = v2;
                    v2 = v5;
                    v5 = v6;
                }
            }
            v8++;
            v6 = v5;
            v5 = v2;
            v2 = v4;
            v4 = v1;
        }
        this.mLeftPageBounds = v6;
        this.mRightPageBounds = (v10 - v5);
        this.mDecorChildCount = v4;
        this.mFirstLayout = 0;
        return;
    }
    protected void onMeasure(int p12, int p13)
    {
        this.setMeasuredDimension(com.wancms.sdk.pager.VerticalViewPager.getDefaultSize(0, p12), com.wancms.sdk.pager.VerticalViewPager.getDefaultSize(0, p13));
        v3 = ((this.getMeasuredWidth() - this.getPaddingLeft()) - this.getPaddingRight());
        v2 = ((this.getMeasuredHeight() - this.getPaddingTop()) - this.getPaddingBottom());
        v7 = this.getChildCount();
        v6 = 0;
        while (v6 < v7) {
            v8 = this.getChildAt(v6);
            if (v8.getVisibility() == 8) {
                v0 = v2;
                v1 = v3;
            } else {
                v0 = v8.getLayoutParams();
                } else {
                    v9 = (v0.b & 7);
                    v4 = (v0.b & 112);
                    android.util.Log.d("VerticalViewPager", new StringBuilder().append("gravity: ").append(v0.b).append(" hgrav: ").append(v9).append(" vgrav: ").append(v4).toString());
                    v1 = -0.0;
                    v0 = -0.0;
                    if ((v4 != 48) && (v4 != 80)) {
                        v5 = 0;
                    } else {
                        v5 = 1;
                    }
                    if ((v9 != 3) && (v9 != 5)) {
                        v4 = 0;
                    } else {
                        v4 = 1;
                    }
                    if (v5 == 0) {
                        if (v4 != 0) {
                            v0 = 2.0;
                        }
                    } else {
                        v1 = 2.0;
                    }
                    v8.measure(android.view.View$MeasureSpec.makeMeasureSpec(v3, v1), android.view.View$MeasureSpec.makeMeasureSpec(v2, v0));
                    if (v5 == 0) {
                        } else {
                            v1 = (v3 - v8.getMeasuredWidth());
                            v0 = v2;
                        }
                    } else {
                        v0 = (v2 - v8.getMeasuredHeight());
                        v1 = v3;
                    }
                }
            }
            v6++;
            v3 = v1;
            v2 = v0;
        }
        this.mChildWidthMeasureSpec = android.view.View$MeasureSpec.makeMeasureSpec(v3, 2.0);
        this.mChildHeightMeasureSpec = android.view.View$MeasureSpec.makeMeasureSpec(v2, 2.0);
        this.mInLayout = 1;
        this.populate();
        this.mInLayout = 0;
        v2 = this.getChildCount();
        v1 = 0;
        while (v1 < v2) {
            v3 = this.getChildAt(v1);
            if (v3.getVisibility() != 8) {
                v0 = v3.getLayoutParams();
                if ((v0 == 0) || (v0.a)) {
                    v3.measure(this.mChildWidthMeasureSpec, this.mChildHeightMeasureSpec);
                }
            }
            v1++;
        }
        return;
    }
    protected void onPageScrolled(int p11, float p12, int p13)
    {
        if (this.mDecorChildCount > 0) {
            v4 = this.getScrollY();
            v1 = this.getPaddingTop();
            v2 = this.getPaddingBottom();
            v5 = this.getHeight();
            v6 = this.getChildCount();
            v3 = 0;
            while (v3 < v6) {
                v7 = this.getChildAt(v3);
                v0 = v7.getLayoutParams();
                if (v0.a) {
                    switch ((v0.b & 112)) {
                        case 1:
                            v0 = Math.max(((v5 - v7.getMeasuredHeight()) / 2), v1);
                            v9 = v2;
                            v2 = v1;
                            v1 = v9;
                            break;
                        case 48:
                            v0 = (v7.getHeight() + v1);
                            v9 = v1;
                            v1 = v2;
                            v2 = v0;
                            v0 = v9;
                            break;
                        case 80:
                            v0 = ((v5 - v2) - v7.getMeasuredHeight());
                            v9 = (v2 + v7.getMeasuredHeight());
                            v2 = v1;
                            v1 = v9;
                            break;
                        default:
                            v0 = v1;
                            v9 = v2;
                            v2 = v1;
                            v1 = v9;
                    }
                    v0 = ((v0 + v4) - v7.getTop());
                    if (v0 != 0) {
                        v7.offsetTopAndBottom(v0);
                    }
                } else {
                    v9 = v2;
                    v2 = v1;
                    v1 = v9;
                }
                v3++;
                v9 = v1;
                v1 = v2;
                v2 = v9;
            }
        }
        if (this.mOnPageChangeListener != 0) {
            this.mOnPageChangeListener.a(p11, p12, p13);
        }
        if (this.mInternalPageChangeListener != 0) {
            this.mInternalPageChangeListener.a(p11, p12, p13);
        }
        this.mCalledSuper = 1;
        return;
    }
    protected boolean onRequestFocusInDescendants(int p9, android.graphics.Rect p10)
    {
        v2 = 1;
        v1 = -1;
        v0 = this.getChildCount();
        if ((p9 & 2) == 0) {
            v3 = (v0 - 1);
            v0 = -1;
        } else {
            v1 = 1;
            v3 = 0;
        }
        while (v3 != v0) {
            v5 = this.getChildAt(v3);
            if (v5.getVisibility() == 0) {
                v6 = this.infoForChild(v5);
                if ((v6 != 0) && ((v6.b == this.mCurItem) && (v5.requestFocus(p9, p10) != 0))) {
                    return v2;
                }
            }
            v3 += v1;
        }
        v2 = 0;
    }
    public void onRestoreInstanceState(android.os.Parcelable p4)
    {
        if ((p4 instanceof com.wancms.sdk.pager.j) != 0) {
            super.onRestoreInstanceState(p4.getSuperState());
            if (this.mAdapter == 0) {
                this.mRestoredCurItem = p4.a;
                this.mRestoredAdapterState = p4.b;
                this.mRestoredClassLoader = p4.c;
            } else {
                this.mAdapter.restoreState(p4.b, p4.c);
                this.setCurrentItemInternal(p4.a, 0, 1);
            }
        } else {
            super.onRestoreInstanceState(p4);
        }
        return;
    }
    public android.os.Parcelable onSaveInstanceState()
    {
        v1 = new com.wancms.sdk.pager.j(super.onSaveInstanceState());
        v1.a = this.mCurItem;
        if (this.mAdapter != 0) {
            v1.b = this.mAdapter.saveState();
        }
        return v1;
    }
    private void onSecondaryPointerUp(android.view.MotionEvent p4)
    {
        v0 = android.support.v4.view.MotionEventCompat.getActionIndex(p4);
        if (android.support.v4.view.MotionEventCompat.getPointerId(p4, v0) == this.mActivePointerId) {
            if (v0 != 0) {
                v0 = 0;
            } else {
                v0 = 1;
            }
            this.mLastMotionY = android.support.v4.view.MotionEventCompat.getY(p4, v0);
            this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p4, v0);
            if (this.mVelocityTracker != 0) {
                this.mVelocityTracker.clear();
            }
        }
        return;
    }
    protected void onSizeChanged(int p3, int p4, int p5, int p6)
    {
        super.onSizeChanged(p3, p4, p5, p6);
        if (p4 != p6) {
            this.recomputeScrollPosition(p4, p6, this.mPageMargin, this.mPageMargin);
        }
        return;
    }
    public boolean onTouchEvent(android.view.MotionEvent p11)
    {
        v0 = 0;
        if (!this.mFakeDragging) {
            if (((p11.getAction() != 0) || (p11.getEdgeFlags() == 0)) && ((this.mAdapter != 0) && (this.mAdapter.getCount() != 0))) {
                if (this.mVelocityTracker == 0) {
                    this.mVelocityTracker = android.view.VelocityTracker.obtain();
                }
                this.mVelocityTracker.addMovement(p11);
                switch ((p11.getAction() & 255)) {
                    case 0:
                        this.completeScroll();
                        v1 = p11.getY();
                        this.mInitialMotionY = v1;
                        this.mLastMotionY = v1;
                        this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p11, 0);
                        break;
                    case 1:
                        if (!this.mIsBeingDragged) {
                        } else {
                            v0 = this.mVelocityTracker;
                            v0.computeCurrentVelocity(1000, ((float) this.mMaximumVelocity));
                            v0 = ((int) android.support.v4.view.VelocityTrackerCompat.getYVelocity(v0, this.mActivePointerId));
                            this.mPopulatePending = 1;
                            v1 = (this.getHeight() + this.mPageMargin);
                            v2 = this.getScrollY();
                            this.determineTargetPage((v2 / v1), (((float) (v2 % v1)) / ((float) v1)), v0, ((int) (android.support.v4.view.MotionEventCompat.getY(p11, android.support.v4.view.MotionEventCompat.findPointerIndex(p11, this.mActivePointerId)) - this.mInitialMotionY)));
                            this.setCurrentItemInternal(this, 1, 1, v0);
                            this.mActivePointerId = -1;
                            this.endDrag();
                            v0 = (this.mTopEdge.onRelease() | this.mBottomEdge.onRelease());
                        }
                        break;
                    case 2:
                        if (this.mIsBeingDragged) {
                            v1 = android.support.v4.view.MotionEventCompat.findPointerIndex(p11, this.mActivePointerId);
                            v2 = Math.abs((android.support.v4.view.MotionEventCompat.getX(p11, v1) - this.mLastMotionX));
                            v1 = android.support.v4.view.MotionEventCompat.getY(p11, v1);
                            v3 = Math.abs((v1 - this.mLastMotionY));
                            if ((v3 > ((float) this.mTouchSlop)) && (v3 > v2)) {
                                this.mIsBeingDragged = 1;
                                this.mLastMotionY = v1;
                                this.setScrollState(1);
                                this.setScrollingCacheEnabled(1);
                            }
                        }
                        if (!this.mIsBeingDragged) {
                        } else {
                            v1 = android.support.v4.view.MotionEventCompat.getY(p11, android.support.v4.view.MotionEventCompat.findPointerIndex(p11, this.mActivePointerId));
                            v2 = (this.mLastMotionY - v1);
                            this.mLastMotionY = v1;
                            v3 = (((float) this.getScrollY()) + v2);
                            v5 = this.getHeight();
                            v6 = (v5 + this.mPageMargin);
                            v7 = (this.mAdapter.getCount() - 1);
                            v1 = ((float) Math.max(0, ((this.mCurItem - 1) * v6)));
                            v2 = ((float) (Math.min((this.mCurItem + 1), v7) * v6));
                            if (v3 >= v1) {
                                if (v3 <= v2) {
                                    v1 = 0;
                                    v0 = v3;
                                } else {
                                    if (v2 == ((float) (v7 * v6))) {
                                        v0 = this.mBottomEdge.onPull(((v3 - v2) / ((float) v5)));
                                    }
                                    v1 = v0;
                                    v0 = v2;
                                }
                            } else {
                                if (v1 == 0) {
                                    v0 = this.mTopEdge.onPull(((- v3) / ((float) v5)));
                                }
                                v9 = v1;
                                v1 = v0;
                                v0 = v9;
                            }
                            this.mLastMotionY = (this.mLastMotionY + (v0 - ((float) ((int) v0))));
                            this.scrollTo(this.getScrollX(), ((int) v0));
                            this.pageScrolled(((int) v0));
                            v0 = v1;
                        }
                        break;
                    case 3:
                        if (this.mIsBeingDragged) {
                            this.setCurrentItemInternal(this.mCurItem, 1, 1);
                            this.mActivePointerId = -1;
                            this.endDrag();
                            v0 = (this.mTopEdge.onRelease() | this.mBottomEdge.onRelease());
                        } else {
                        }
                    case 4:
                    default:
                        break;
                    case 5:
                        v1 = android.support.v4.view.MotionEventCompat.getActionIndex(p11);
                        this.mLastMotionY = android.support.v4.view.MotionEventCompat.getY(p11, v1);
                        this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p11, v1);
                        break;
                    case 6:
                        this.onSecondaryPointerUp(p11);
                        this.mLastMotionY = android.support.v4.view.MotionEventCompat.getY(p11, android.support.v4.view.MotionEventCompat.findPointerIndex(p11, this.mActivePointerId));
                        break;
                }
                if (v0 != 0) {
                    this.invalidate();
                }
                v0 = 1;
            }
        } else {
            v0 = 1;
        }
        return v0;
    }
     boolean pageDown()
    {
        v0 = 1;
        if ((this.mAdapter == 0) || (this.mCurItem >= (this.mAdapter.getCount() - 1))) {
            v0 = 0;
        } else {
            this.setCurrentItem((this.mCurItem + 1), 1);
        }
        return v0;
    }
    private void pageScrolled(int p5)
    {
        v0 = (this.getHeight() + this.mPageMargin);
        v1 = (p5 / v0);
        v2 = (p5 % v0);
        v0 = (((float) v2) / ((float) v0));
        this.mCalledSuper = 0;
        this.onPageScrolled(v1, v0, v2);
        if (this.mCalledSuper) {
            return;
        } else {
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }
     boolean pageUp()
    {
        v0 = 1;
        if (this.mCurItem <= 0) {
            v0 = 0;
        } else {
            this.setCurrentItem((this.mCurItem - 1), 1);
        }
        return v0;
    }
     void populate()
    {
        v6 = 0;
        v2 = 0;
        if ((this.mAdapter != 0) && ((this.mPopulatePending) && (this.getWindowToken() != 0))) {
            this.mAdapter.startUpdate(this);
            v0 = this.mOffscreenPageLimit;
            v5 = Math.max(0, (this.mCurItem - v0));
            v7 = Math.min((this.mAdapter.getCount() - 1), (v0 + this.mCurItem));
            v1 = 0;
            v3 = -1;
            while (v1 < this.mItems.size()) {
                v0 = this.mItems.get(v1);
                if (((v0.b >= v5) && (v0.b <= v7)) || (v0.c)) {
                    if ((v3 < v7) && (v0.b > v5)) {
                        v3++;
                        if (v3 < v5) {
                            v3 = v5;
                        }
                        while ((v3 <= v7) && (v3 < v0.b)) {
                            this.addNewItem(v3, v1);
                            v3++;
                            v1++;
                        }
                    }
                    v3 = v1;
                } else {
                    this.mItems.remove(v1);
                    v1--;
                    this.mAdapter.destroyItem(this, v0.b, v0.a);
                    v3 = v1;
                }
                v1 = v0.b;
                v0 = (v3 + 1);
                v3 = v1;
                v1 = v0;
            }
            if (this.mItems.size() <= 0) {
                v0 = -1;
            } else {
                v0 = this.mItems.get((this.mItems.size() - 1)).b;
            }
            if (v0 < v7) {
                v0++;
                if (v0 <= v5) {
                    v0 = v5;
                }
                while (v0 <= v7) {
                    this.addNewItem(v0, -1);
                    v0++;
                }
            }
            v1 = 0;
            while (v1 < this.mItems.size()) {
                if (this.mItems.get(v1).b != this.mCurItem) {
                    v1++;
                } else {
                    v0 = this.mItems.get(v1);
                }
                if (v0 == 0) {
                    v0 = 0;
                } else {
                    v0 = v0.a;
                }
                this.mAdapter.setPrimaryItem(this, this.mCurItem, v0);
                this.mAdapter.finishUpdate(this);
                if (this.hasFocus() != 0) {
                    v0 = this.findFocus();
                    if (v0 != 0) {
                        v6 = this.infoForAnyChild(v0);
                    }
                    if ((v6 != 0) && (v6.b == this.mCurItem)) {
                        return;
                    }
                    while (v2 < this.getChildCount()) {
                        v0 = this.getChildAt(v2);
                        v1 = this.infoForChild(v0);
                        if ((v1 != 0) && ((v1.b == this.mCurItem) && (v0.requestFocus(2) != 0))) {
                            break;
                        }
                        v2++;
                    }
                }
            }
            v0 = 0;
        }
    }
    private void recomputeScrollPosition(int p7, int p8, int p9, int p10)
    {
        v3 = (p7 + p9);
        if (p8 <= 0) {
            v0 = (this.mCurItem * v3);
            if (v0 != this.getScrollY()) {
                this.completeScroll();
                this.scrollTo(this.getScrollX(), v0);
            }
        } else {
            v0 = this.getScrollY();
            v2 = (p8 + p10);
            v2 = ((int) (((((float) (v0 % v2)) / ((float) v2)) + ((float) (v0 / v2))) * ((float) v3)));
            this.scrollTo(this.getScrollX(), v2);
            if (this.mScroller.isFinished() == 0) {
                this.mScroller.startScroll(0, v2, (v3 * this.mCurItem), 0, (v0 - this.mScroller.timePassed()));
            }
        }
        return;
    }
    private void removeNonDecorViews()
    {
        v1 = 0;
        while (v1 < this.getChildCount()) {
            if (this.getChildAt(v1).getLayoutParams().a) {
                this.removeViewAt(v1);
                v1--;
            }
            v1++;
        }
        return;
    }
    public void setAdapter(com.wancms.sdk.pager.a p7)
    {
        if (this.mAdapter != 0) {
            this.mAdapter.startUpdate(this);
            v1 = 0;
            while (v1 < this.mItems.size()) {
                v0 = this.mItems.get(v1);
                this.mAdapter.destroyItem(this, v0.b, v0.a);
                v1++;
            }
            this.mAdapter.finishUpdate(this);
            this.mItems.clear();
            this.removeNonDecorViews();
            this.mCurItem = 0;
            this.scrollTo(0, 0);
        }
        v0 = this.mAdapter;
        this.mAdapter = p7;
        if (this.mAdapter != 0) {
            if (this.mObserver == 0) {
                this.mObserver = new com.wancms.sdk.pager.i(this, 0);
            }
            this.mPopulatePending = 0;
            if (this.mRestoredCurItem < 0) {
                this.populate();
            } else {
                this.mAdapter.restoreState(this.mRestoredAdapterState, this.mRestoredClassLoader);
                this.setCurrentItemInternal(this.mRestoredCurItem, 0, 1);
                this.mRestoredCurItem = -1;
                this.mRestoredAdapterState = 0;
                this.mRestoredClassLoader = 0;
            }
        }
        if ((this.mAdapterChangeListener != 0) && (v0 != p7)) {
            this.mAdapterChangeListener.a(v0, p7);
        }
        return;
    }
    public void setCurrentItem(int p3)
    {
        this.mPopulatePending = 0;
        if (this.mFirstLayout) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        this.setCurrentItemInternal(p3, v0, 0);
        return;
    }
    public void setCurrentItem(int p2, boolean p3)
    {
        this.mPopulatePending = 0;
        this.setCurrentItemInternal(p2, p3, 0);
        return;
    }
     void setCurrentItemInternal(int p2, boolean p3, boolean p4)
    {
        this.setCurrentItemInternal(p2, p3, p4, 0);
        return;
    }
     void setCurrentItemInternal(int p5, boolean p6, boolean p7, int p8)
    {
        if ((this.mAdapter != 0) && (this.mAdapter.getCount() > 0)) {
            if ((p7 != 0) || ((this.mCurItem != p5) || (this.mItems.size() == 0))) {
                if (p5 >= 0) {
                    if (p5 >= this.mAdapter.getCount()) {
                        p5 = (this.mAdapter.getCount() - 1);
                    }
                } else {
                    p5 = 0;
                }
                v0 = this.mOffscreenPageLimit;
                if ((p5 > (this.mCurItem + v0)) || (p5 < (this.mCurItem - v0))) {
                    v2 = 0;
                    while (v2 < this.mItems.size()) {
                        this.mItems.get(v2).c = 1;
                        v2++;
                    }
                }
                if (this.mCurItem == p5) {
                    v0 = 0;
                } else {
                    v0 = 1;
                }
                this.mCurItem = p5;
                this.populate();
                v2 = ((this.getHeight() + this.mPageMargin) * p5);
                if (p6 == 0) {
                    if ((v0 != 0) && (this.mOnPageChangeListener != 0)) {
                        this.mOnPageChangeListener.a(p5);
                    }
                    if ((v0 != 0) && (this.mInternalPageChangeListener != 0)) {
                        this.mInternalPageChangeListener.a(p5);
                    }
                    this.completeScroll();
                    this.scrollTo(0, v2);
                } else {
                    this.smoothScrollTo(0, v2, p8);
                    if ((v0 != 0) && (this.mOnPageChangeListener != 0)) {
                        this.mOnPageChangeListener.a(p5);
                    }
                    if ((v0 != 0) && (this.mInternalPageChangeListener != 0)) {
                        this.mInternalPageChangeListener.a(p5);
                    }
                }
            } else {
                this.setScrollingCacheEnabled(0);
            }
        } else {
            this.setScrollingCacheEnabled(0);
        }
        return;
    }
     com.wancms.sdk.pager.h setInternalPageChangeListener(com.wancms.sdk.pager.h p2)
    {
        this.mInternalPageChangeListener = p2;
        return this.mInternalPageChangeListener;
    }
    public void setOffscreenPageLimit(int p5)
    {
        if (p5 < 1) {
            android.util.Log.w("VerticalViewPager", new StringBuilder().append("Requested offscreen page limit ").append(p5).append(" too small; defaulting to ").append(1).toString());
            p5 = 1;
        }
        if (p5 != this.mOffscreenPageLimit) {
            this.mOffscreenPageLimit = p5;
            this.populate();
        }
        return;
    }
     void setOnAdapterChangeListener(com.wancms.sdk.pager.g p1)
    {
        this.mAdapterChangeListener = p1;
        return;
    }
    public void setOnClickListener(android.view.View$OnClickListener p2)
    {
        super.setOnClickListener(new com.wancms.sdk.pager.b(this));
        return;
    }
    public void setOnPageChangeListener(com.wancms.sdk.pager.h p1)
    {
        this.mOnPageChangeListener = p1;
        return;
    }
    public void setPageMargin(int p3)
    {
        this.mPageMargin = p3;
        this.recomputeScrollPosition(this.getHeight(), this.getHeight(), p3, this.mPageMargin);
        this.requestLayout();
        return;
    }
    public void setPageMarginDrawable(int p2)
    {
        this.setPageMarginDrawable(this.getContext().getResources().getDrawable(p2));
        return;
    }
    public void setPageMarginDrawable(android.graphics.drawable.Drawable p2)
    {
        this.mMarginDrawable = p2;
        if (p2 != 0) {
            this.refreshDrawableState();
        }
        if (p2 != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        this.setWillNotDraw(v0);
        this.invalidate();
        return;
    }
    private void setScrollState(int p2)
    {
        if (this.mScrollState != p2) {
            this.mScrollState = p2;
            if (this.mOnPageChangeListener != 0) {
                this.mOnPageChangeListener.b(p2);
            }
        }
        return;
    }
    private void setScrollingCacheEnabled(boolean p2)
    {
        if (this.mScrollingCacheEnabled != p2) {
            this.mScrollingCacheEnabled = p2;
        }
        return;
    }
     void smoothScrollTo(int p2, int p3)
    {
        this.smoothScrollTo(p2, p3, 0);
        return;
    }
     void smoothScrollTo(int p10, int p11, int p12)
    {
        if (this.getChildCount() != 0) {
            v1 = this.getScrollX();
            v2 = this.getScrollY();
            v3 = (p10 - v1);
            v4 = (p11 - v2);
            if ((v3 != 0) || (v4 != 0)) {
                this.setScrollingCacheEnabled(1);
                this.mScrolling = 1;
                this.setScrollState(2);
                v0 = this.getHeight();
                v5 = (v0 / 2);
                v5 = ((((float) v5) * this.distanceInfluenceForSnapDuration(Math.min(1.0, ((((float) Math.abs(v4)) * 1.0) / ((float) v0))))) + ((float) v5));
                v6 = Math.abs(p12);
                if (v6 <= 0) {
                    v0 = ((int) (((((float) Math.abs(v4)) / ((float) (v0 + this.mPageMargin))) + 1.0) * 100.0));
                } else {
                    v0 = (Math.round((1000.0 * Math.abs((v5 / ((float) v6))))) * 4);
                }
                this.mScroller.startScroll(v1, v2, v3, v4, Math.min(v0, 600));
                this.invalidate();
            } else {
                this.completeScroll();
                this.setScrollState(0);
            }
        } else {
            this.setScrollingCacheEnabled(0);
        }
        return;
    }
    protected boolean verifyDrawable(android.graphics.drawable.Drawable p2)
    {
        if ((super.verifyDrawable(p2) == 0) && (p2 != this.mMarginDrawable)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    static VerticalViewPager()
    {
        v0 = new int[1];
        v0[0] = 2.369405967361196e-38;
        com.wancms.sdk.pager.VerticalViewPager.LAYOUT_ATTRS = v0;
        com.wancms.sdk.pager.VerticalViewPager.COMPARATOR = new com.wancms.sdk.pager.c();
        com.wancms.sdk.pager.VerticalViewPager.sInterpolator = new com.wancms.sdk.pager.d();
        return;
    }
    public VerticalViewPager(android.content.Context p5)
    {
        this(p5);
        this.mItems = new java.util.ArrayList();
        this.mRestoredCurItem = -1;
        this.mRestoredAdapterState = 0;
        this.mRestoredClassLoader = 0;
        this.mOffscreenPageLimit = 1;
        this.mActivePointerId = -1;
        this.mFirstLayout = 1;
        this.mScrollState = 0;
        this.initViewPager();
        return;
    }
    public VerticalViewPager(android.content.Context p5, android.util.AttributeSet p6)
    {
        this(p5, p6);
        this.mItems = new java.util.ArrayList();
        this.mRestoredCurItem = -1;
        this.mRestoredAdapterState = 0;
        this.mRestoredClassLoader = 0;
        this.mOffscreenPageLimit = 1;
        this.mActivePointerId = -1;
        this.mFirstLayout = 1;
        this.mScrollState = 0;
        this.initViewPager();
        return;
    }
    static synthetic int[] access$100()
    {
        return com.wancms.sdk.pager.VerticalViewPager.LAYOUT_ATTRS;
    }
    public void addFocusables(java.util.ArrayList p7, int p8, int p9)
    {
        v1 = p7.size();
        v2 = this.getDescendantFocusability();
        if (v2 != 5.510129769479473e-40) {
            v0 = 0;
            while (v0 < this.getChildCount()) {
                v3 = this.getChildAt(v0);
                if (v3.getVisibility() == 0) {
                    v4 = this.infoForChild(v3);
                    if ((v4 != 0) && (v4.b == this.mCurItem)) {
                        v3.addFocusables(p7, p8, p9);
                    }
                }
                v0++;
            }
        }
        if (((v2 != 3.6734198463196485e-40) || (v1 == p7.size())) && (((this.isFocusable() != 0) && (((p9 & 1) != 1) || ((this.isInTouchMode() == 0) || (this.isFocusableInTouchMode() != 0)))) && (p7 != 0))) {
            p7.add(this);
        }
        return;
    }
     void addNewItem(int p3, int p4)
    {
        v0 = new com.wancms.sdk.pager.f();
        v0.b = p3;
        v0.a = this.mAdapter.instantiateItem(this, p3);
        if (p4 >= 0) {
            this.mItems.add(p4, v0);
        } else {
            this.mItems.add(v0);
        }
        return;
    }
    public void addTouchables(java.util.ArrayList p5)
    {
        v0 = 0;
        while (v0 < this.getChildCount()) {
            v1 = this.getChildAt(v0);
            if (v1.getVisibility() == 0) {
                v2 = this.infoForChild(v1);
                if ((v2 != 0) && (v2.b == this.mCurItem)) {
                    v1.addTouchables(p5);
                }
            }
            v0++;
        }
        return;
    }
    public void addView(android.view.View p5, int p6, android.view.ViewGroup$LayoutParams p7)
    {
        if (this.checkLayoutParams(p7) != 0) {
            v1 = p7;
        } else {
            v1 = this.generateLayoutParams(p7);
        }
        v0 = v1;
        v0.a = (v0.a | (p5 instanceof com.wancms.sdk.pager.e));
        if (!this.mInLayout) {
            super.addView(p5, p6, v1);
        } else {
            if ((v0 == 0) || (!v0.a)) {
                this.addViewInLayout(p5, p6, v1);
                p5.measure(this.mChildWidthMeasureSpec, this.mChildHeightMeasureSpec);
            } else {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
        }
        return;
    }
    public boolean arrowScroll(int p6)
    {
        v0 = this.findFocus();
        if (v0 == this) {
            v0 = 0;
        }
        v2 = android.view.FocusFinder.getInstance().findNextFocus(this, v0, p6);
        if ((v2 == 0) || (v2 == v0)) {
            if ((p6 != 33) && (p6 != 1)) {
                if ((p6 != 130) && (p6 != 2)) {
                    v0 = 0;
                } else {
                    v0 = this.pageDown();
                }
            } else {
                v0 = this.pageUp();
            }
        } else {
            if (p6 != 33) {
                } else {
                    if ((v0 == 0) || (v2.getTop() > v0.getTop())) {
                        v0 = v2.requestFocus();
                    } else {
                        v0 = this.pageDown();
                    }
                }
            } else {
                if ((v0 == 0) || (v2.getTop() < v0.getTop())) {
                    v0 = v2.requestFocus();
                } else {
                    v0 = this.pageUp();
                }
            }
        }
        if (v0 != 0) {
            this.playSoundEffect(android.view.SoundEffectConstants.getContantForFocusDirection(p6));
        }
        return v0;
    }
    public boolean beginFakeDrag()
    {
        v4 = 0;
        if (!this.mIsBeingDragged) {
            this.mFakeDragging = 1;
            this.setScrollState(1);
            this.mLastMotionY = 0;
            this.mInitialMotionY = 0;
            if (this.mVelocityTracker != 0) {
                this.mVelocityTracker.clear();
            } else {
                this.mVelocityTracker = android.view.VelocityTracker.obtain();
            }
            v0 = android.os.SystemClock.uptimeMillis();
            v2 = android.view.MotionEvent.obtain(v0, v1, v0, v3, 0, 0, 0, 0);
            this.mVelocityTracker.addMovement(v2);
            v2.recycle();
            this.mFakeDragBeginTime = v0;
            v4 = 1;
        }
        return v4;
    }
    protected boolean canScroll(android.view.View p11, boolean p12, int p13, int p14, int p15)
    {
        v2 = 1;
        if ((p11 instanceof android.view.ViewGroup) == 0) {
            if ((p12 == 0) || (android.support.v4.view.ViewCompat.canScrollVertically(p11, (- p13)) == 0)) {
                v2 = 0;
            }
        } else {
            v6 = p11;
            v8 = p11.getScrollX();
            v9 = p11.getScrollY();
            v7 = (v6.getChildCount() - 1);
            while (v7 >= 0) {
                v1 = v6.getChildAt(v7);
                if (((p14 + v8) < v1.getLeft()) || (((p14 + v8) >= v1.getRight()) || (((p15 + v9) < v1.getTop()) || (((p15 + v9) >= v1.getBottom()) || (this.canScroll(v1, 1, p13, ((p14 + v8) - v1.getLeft()), (v0 - v1.getTop())) == 0))))) {
                    v7--;
                }
            }
        }
        return v2;
    }
    protected boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p2)
    {
        if (((p2 instanceof com.wancms.sdk.pager.VerticalViewPager$LayoutParams) == 0) || (super.checkLayoutParams(p2) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    private void completeScroll()
    {
        v0 = this.mScrolling;
        if (v0 != 0) {
            this.setScrollingCacheEnabled(0);
            this.mScroller.abortAnimation();
            v1 = this.getScrollX();
            v3 = this.getScrollY();
            v4 = this.mScroller.getCurrX();
            v5 = this.mScroller.getCurrY();
            if ((v1 != v4) || (v3 != v5)) {
                this.scrollTo(v4, v5);
            }
            this.setScrollState(0);
        }
        this.mPopulatePending = 0;
        this.mScrolling = 0;
        v1 = 0;
        v3 = v0;
        while (v1 < this.mItems.size()) {
            v0 = this.mItems.get(v1);
            if (v0.c) {
                v3 = 1;
                v0.c = 0;
            }
            v1++;
        }
        if (v3 != 0) {
            this.populate();
        }
        return;
    }
    public void computeScroll()
    {
        if ((this.mScroller.isFinished() != 0) || (this.mScroller.computeScrollOffset() == 0)) {
            this.completeScroll();
        } else {
            v0 = this.getScrollX();
            v1 = this.getScrollY();
            v2 = this.mScroller.getCurrX();
            v3 = this.mScroller.getCurrY();
            if ((v0 != v2) || (v1 != v3)) {
                this.scrollTo(v2, v3);
                this.pageScrolled(v3);
            }
            this.invalidate();
        }
        return;
    }
     void dataSetChanged()
    {
        v1 = 1;
        if ((this.mItems.size() >= 3) || (this.mItems.size() >= this.mAdapter.getCount())) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        v3 = 0;
        v4 = 0;
        v5 = -1;
        v7 = v0;
        while (v3 < this.mItems.size()) {
            v0 = this.mItems.get(v3);
            v8 = this.mAdapter.getItemPosition(v0.a);
            if (v8 != -1) {
                if (v8 != -2) {
                    if (v0.b == v8) {
                        v0 = v3;
                        v3 = v4;
                        v4 = v5;
                        v5 = v7;
                    } else {
                        if (v0.b == this.mCurItem) {
                            v5 = v8;
                        }
                        v0.b = v8;
                        v0 = v3;
                        v3 = v4;
                        v4 = v5;
                        v5 = 1;
                    }
                } else {
                    this.mItems.remove(v3);
                    v3--;
                    if (v4 == 0) {
                        this.mAdapter.startUpdate(this);
                        v4 = 1;
                    }
                    this.mAdapter.destroyItem(this, v0.b, v0.a);
                    if (this.mCurItem != v0.b) {
                        v0 = v3;
                        v3 = v4;
                        v4 = v5;
                        v5 = 1;
                    } else {
                        v0 = v3;
                        v3 = v4;
                        v4 = Math.max(0, Math.min(this.mCurItem, (this.mAdapter.getCount() - 1)));
                        v5 = 1;
                    }
                }
            } else {
                v0 = v3;
                v3 = v4;
                v4 = v5;
                v5 = v7;
            }
            v7 = v5;
            v5 = v4;
            v4 = v3;
            v3 = (v0 + 1);
        }
        if (v4 != 0) {
            this.mAdapter.finishUpdate(this);
        }
        java.util.Collections.sort(this.mItems, com.wancms.sdk.pager.VerticalViewPager.COMPARATOR);
        if (v5 < 0) {
            v1 = v7;
        } else {
            this.setCurrentItemInternal(v5, 0, 1);
        }
        if (v1 != 0) {
            this.populate();
            this.requestLayout();
        }
        return;
    }
    private int determineTargetPage(int p3, float p4, int p5, int p6)
    {
        if ((Math.abs(p6) <= this.mFlingDistance) || (Math.abs(p5) <= this.mMinimumVelocity)) {
            p3 = ((int) ((((float) p3) + p4) + 0.5));
        } else {
            if (p5 <= 0) {
                p3++;
            }
        }
        return p3;
    }
    public boolean dispatchKeyEvent(android.view.KeyEvent p2)
    {
        if ((super.dispatchKeyEvent(p2) == 0) && (this.executeKeyEvent(p2) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public boolean dispatchPopulateAccessibilityEvent(android.view.accessibility.AccessibilityEvent p7)
    {
        v0 = 0;
        v2 = this.getChildCount();
        v1 = 0;
        while (v1 < v2) {
            v3 = this.getChildAt(v1);
            if (v3.getVisibility() == 0) {
                v4 = this.infoForChild(v3);
                if ((v4 != 0) && ((v4.b == this.mCurItem) && (v3.dispatchPopulateAccessibilityEvent(p7) != 0))) {
                    v0 = 1;
                    break;
                }
            }
            v1++;
        }
        return v0;
    }
     float distanceInfluenceForSnapDuration(float p5)
    {
        return ((float) Math.sin(((double) ((float) (((double) (p5 - 0.5)) * 0.4712389167638204)))));
    }
    public void draw(android.graphics.Canvas p8)
    {
        v1 = 1;
        super.draw(p8);
        v0 = 0;
        v2 = android.support.v4.view.ViewCompat.getOverScrollMode(this);
        if ((v2 != 0) && ((v2 != 1) || ((this.mAdapter == 0) || (this.mAdapter.getCount() <= 1)))) {
            this.mTopEdge.finish();
            this.mBottomEdge.finish();
        } else {
            if (this.mTopEdge.isFinished() == 0) {
                v2 = p8.save();
                v3 = ((this.getWidth() - this.getPaddingLeft()) - this.getPaddingRight());
                p8.rotate(270.0);
                p8.translate(((float) ((- v3) + this.getPaddingLeft())), 0);
                this.mTopEdge.setSize(v3, this.getHeight());
                v0 = (0 | this.mTopEdge.draw(p8));
                p8.restoreToCount(v2);
            }
            if (this.mBottomEdge.isFinished() == 0) {
                v2 = p8.save();
                v3 = ((this.getWidth() - this.getPaddingLeft()) - this.getPaddingRight());
                v4 = this.getHeight();
                if (this.mAdapter != 0) {
                    v1 = this.mAdapter.getCount();
                }
                p8.rotate(180.0);
                p8.translate(((float) ((- v3) + this.getPaddingLeft())), ((float) (((- v1) * (this.mPageMargin + v4)) + this.mPageMargin)));
                this.mBottomEdge.setSize(v3, v4);
                v0 |= this.mBottomEdge.draw(p8);
                p8.restoreToCount(v2);
            }
        }
        if (v0 != 0) {
            this.invalidate();
        }
        return;
    }
    protected void drawableStateChanged()
    {
        super.drawableStateChanged();
        v0 = this.mMarginDrawable;
        if ((v0 != 0) && (v0.isStateful() != 0)) {
            v0.setState(this.getDrawableState());
        }
        return;
    }
    private void endDrag()
    {
        this.mIsBeingDragged = 0;
        this.mIsUnableToDrag = 0;
        if (this.mVelocityTracker != 0) {
            this.mVelocityTracker.recycle();
            this.mVelocityTracker = 0;
        }
        return;
    }
    public void endFakeDrag()
    {
        if (this.mFakeDragging) {
            v0 = this.mVelocityTracker;
            v0.computeCurrentVelocity(1000, ((float) this.mMaximumVelocity));
            v0 = ((int) android.support.v4.view.VelocityTrackerCompat.getXVelocity(v0, this.mActivePointerId));
            this.mPopulatePending = 1;
            v2 = this.getScrollY();
            v3 = (this.getHeight() + this.mPageMargin);
            this.determineTargetPage((v2 / v3), (((float) (v2 % v3)) / ((float) v3)), v0, ((int) (this.mLastMotionY - this.mInitialMotionY)));
            this.setCurrentItemInternal(this, 1, 1, v0);
            this.endDrag();
            this.mFakeDragging = 0;
            return;
        } else {
            throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
        }
    }
    public boolean executeKeyEvent(android.view.KeyEvent p5)
    {
        v0 = 0;
        if (p5.getAction() == 0) {
            switch (p5.getKeyCode()) {
                case 19:
                    v0 = this.arrowScroll(33);
                    break;
                case 20:
                    v0 = this.arrowScroll(130);
                    break;
                case 61:
                    if (android.os.Build$VERSION.SDK_INT >= 11) {
                        if (android.support.v4.view.KeyEventCompat.hasNoModifiers(p5) == 0) {
                            if (android.support.v4.view.KeyEventCompat.hasModifiers(p5, 1) != 0) {
                                v0 = this.arrowScroll(1);
                            }
                        } else {
                            v0 = this.arrowScroll(2);
                        }
                    }
                    break;
            }
        }
        return v0;
    }
    public void fakeDragBy(float p9)
    {
        if (this.mFakeDragging) {
            this.mLastMotionY = (this.mLastMotionY + p9);
            v2 = (((float) this.getScrollY()) - p9);
            v1 = (this.mPageMargin + this.getHeight());
            v0 = ((float) Math.max(0, ((this.mCurItem - 1) * v1)));
            v1 = ((float) (v1 * Math.min((this.mCurItem + 1), (this.mAdapter.getCount() - 1))));
            v3 = v2 cmp v0;
            if (v3 >= 0) {
                if (v2 <= v1) {
                    v0 = v2;
                } else {
                    v0 = v1;
                }
            }
            this.mLastMotionY = (this.mLastMotionY + (v0 - ((float) ((int) v0))));
            v1 = this.getScrollX();
            this.scrollTo(v1, ((int) v0));
            this.pageScrolled(((int) v0));
            v0 = android.view.MotionEvent.obtain(this.mFakeDragBeginTime, v1, android.os.SystemClock.uptimeMillis(), v3, 2, 0, this.mLastMotionY, 0);
            this.mVelocityTracker.addMovement(v0);
            v0.recycle();
            return;
        } else {
            throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
        }
    }
    protected android.view.ViewGroup$LayoutParams generateDefaultLayoutParams()
    {
        return new com.wancms.sdk.pager.VerticalViewPager$LayoutParams();
    }
    public android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p3)
    {
        return new com.wancms.sdk.pager.VerticalViewPager$LayoutParams(this.getContext(), p3);
    }
    protected android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p2)
    {
        return this.generateDefaultLayoutParams();
    }
    public com.wancms.sdk.pager.a getAdapter()
    {
        return this.mAdapter;
    }
    public int getCurrentItem()
    {
        return this.mCurItem;
    }
}
