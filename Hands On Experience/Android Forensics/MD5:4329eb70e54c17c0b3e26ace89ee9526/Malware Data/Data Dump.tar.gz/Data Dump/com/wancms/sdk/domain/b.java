package com.wancms.sdk.domain;
public class b {
    public String a;
    public String c;
    public String b;
    public int e;
    public String d;
    public String g;
    public String f;
    public String i;
    public int h;
    public b()
    {
        this.a = "";
        this.b = "";
        this.c = "";
        this.d = "";
        this.e = 0;
        this.f = "aa";
        this.g = "";
        this.h = 2;
        this.i = "";
        return;
    }
}
