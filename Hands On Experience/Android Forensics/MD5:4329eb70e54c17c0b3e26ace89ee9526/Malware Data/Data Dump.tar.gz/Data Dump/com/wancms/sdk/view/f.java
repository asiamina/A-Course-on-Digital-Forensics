package com.wancms.sdk.view;
 class f extends android.os.AsyncTask {
    final synthetic android.support.v4.app.FragmentActivity a;
    final synthetic com.wancms.sdk.view.d b;
    protected void a(java.util.List p5)
    {
        super.onPostExecute(p5);
        com.wancms.sdk.view.d.d = p5;
        com.wancms.sdk.view.d.a(this.b, new com.wancms.sdk.view.g(this.b, 0));
        com.wancms.sdk.view.d.e(this.b).setAdapter(com.wancms.sdk.view.d.d(this.b));
        com.wancms.sdk.view.d.a(this.b, this.b.a());
        com.wancms.sdk.view.d.c(this.b).setAdapter(new com.wancms.sdk.pager.a(this.a.getSupportFragmentManager(), com.wancms.sdk.view.d.f(this.b)));
        com.wancms.sdk.view.d.c(this.b).setOnPageChangeListener(new com.wancms.sdk.view.h(this.b, 0));
        return;
    }
    protected synthetic Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
    protected synthetic void onPostExecute(Object p1)
    {
        this.a(p1);
        return;
    }
     f(com.wancms.sdk.view.d p1, android.support.v4.app.FragmentActivity p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }
    protected varargs java.util.List a(Void[] p3)
    {
        return com.wancms.sdk.util.g.a(com.wancms.sdk.view.d.b(this.b)).q(com.wancms.sdk.WancmsSDKAppService.d);
    }
}
