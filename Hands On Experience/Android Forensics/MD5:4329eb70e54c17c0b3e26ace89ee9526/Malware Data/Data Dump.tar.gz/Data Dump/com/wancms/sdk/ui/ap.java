package com.wancms.sdk.ui;
 class ap extends android.os.AsyncTask {
    final synthetic com.wancms.sdk.ui.WXH5PayActivity a;
    protected synthetic void onPostExecute(Object p1)
    {
        this.a(p1);
        return;
    }
     ap(com.wancms.sdk.ui.WXH5PayActivity p1)
    {
        this.a = p1;
        return;
    }
    protected varargs com.wancms.sdk.domain.f a(Void[] p21)
    {
        com.wancms.sdk.util.Logger.msg(com.wancms.sdk.ui.WXH5PayActivity.b(this.a));
        v1 = com.wancms.sdk.util.g.a(this.a);
        v2 = com.wancms.sdk.ui.WXH5PayActivity.b(this.a);
        v3 = com.wancms.sdk.ui.WXH5PayActivity.c(this.a);
        v5 = com.wancms.sdk.ui.WXH5PayActivity.d(this.a);
        v7 = com.wancms.sdk.ui.WXH5PayActivity.e(this.a);
        v8 = com.wancms.sdk.ui.WXH5PayActivity.f(this.a);
        v9 = Double.valueOf(com.wancms.sdk.ui.WXH5PayActivity.g(this.a));
        v10 = Double.valueOf(com.wancms.sdk.ui.WXH5PayActivity.h(this.a));
        v12 = com.wancms.sdk.ui.WXH5PayActivity.i(this.a);
        if (com.wancms.sdk.util.k.a(this.a).b("imei").equals("") == 0) {
            v13 = com.wancms.sdk.util.k.a(this.a).b("imei");
        } else {
            v13 = com.wancms.sdk.WancmsSDKAppService.b.a;
        }
        return v1.c(v2, v3, v4, v5, com.wancms.sdk.WancmsSDKAppService.a.i, v7, v8, v9, v10, com.wancms.sdk.WancmsSDKAppService.c, v12, v13, com.wancms.sdk.WancmsSDKAppService.d, com.wancms.sdk.WancmsSDKAppService.e, com.wancms.sdk.ui.WXH5PayActivity.j(this.a), com.wancms.sdk.ui.WXH5PayActivity.k(this.a), com.wancms.sdk.ui.WXH5PayActivity.l(this.a), com.wancms.sdk.ui.WXH5PayActivity.m(this.a));
    }
    protected void a(com.wancms.sdk.domain.f p4)
    {
        super.onPostExecute(p4);
        if ((p4 == 0) || ("1".equals(p4.k) == 0)) {
            if (p4 != 0) {
                v0 = p4.h;
            } else {
                v0 = "\u672c\u5730\u670d\u52a1\u5668\u9519\u8bef,\u751f\u6210\u9884\u652f\u4ed8\u8ba2\u5355\u5931\u8d25";
            }
            android.widget.Toast.makeText(this.a, v0, 0).show();
        } else {
            com.wancms.sdk.util.Logger.msg(new StringBuilder().append("\u672c\u5730\u670d\u52a1\u5668\u8fd4\u56de\u6570\u636e\uff1a\uff1a\uff1a\uff1a\uff1a").append(p4.h).toString());
            v0 = new java.util.HashMap();
            v0.put("Referer", "http://sdk.hehesy.com");
            com.wancms.sdk.ui.WXH5PayActivity.a(this.a).loadUrl(p4.b, v0);
        }
        return;
    }
    protected synthetic Object doInBackground(Object[] p2)
    {
        return this.a(p2);
    }
}
