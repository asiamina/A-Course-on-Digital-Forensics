package com.wancms.sdk.view;
 class ad extends android.view.GestureDetector$SimpleOnGestureListener {
    final synthetic com.wancms.sdk.view.MyNoFocusListView a;
     ad(com.wancms.sdk.view.MyNoFocusListView p1)
    {
        this.a = p1;
        return;
    }
    public boolean onScroll(android.view.MotionEvent p3, android.view.MotionEvent p4, float p5, float p6)
    {
        // Both branches of the conditions point to the same code.
        // if ((p6 != 0) && (p5 == 0)) {
            if (Math.abs(p6) < Math.abs(p5)) {
                v0 = 0;
            } else {
                v0 = 1;
            }
            return v0;
        // }
    }
}
