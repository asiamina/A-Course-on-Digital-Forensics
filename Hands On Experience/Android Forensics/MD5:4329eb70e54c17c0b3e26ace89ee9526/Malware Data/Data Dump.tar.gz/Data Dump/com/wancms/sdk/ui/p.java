package com.wancms.sdk.ui;
 class p extends android.webkit.WebViewClient {
    final synthetic com.wancms.sdk.ui.JZWebPayActivity a;
     p(com.wancms.sdk.ui.JZWebPayActivity p1)
    {
        this.a = p1;
        return;
    }
    public void onPageFinished(android.webkit.WebView p4, String p5)
    {
        super.onPageFinished(p4, p5);
        com.wancms.sdk.util.Logger.msg(new StringBuilder().append("webViewfinish\u5730\u5740").append(com.wancms.sdk.ui.JZWebPayActivity.a(this.a).getUrl()).toString());
        com.wancms.sdk.util.Logger.msg(String.valueOf(com.wancms.sdk.ui.JZWebPayActivity.a(this.a).getUrl().contains("queryordertz.asp")));
        if (com.wancms.sdk.ui.JZWebPayActivity.a(this.a).getUrl().contains("queryordertz.asp") != 0) {
            com.wancms.sdk.util.Logger.msg(String.valueOf(com.wancms.sdk.ui.JZWebPayActivity.a(this.a).getUrl().contains("queryordertz.asp")));
            this.a.setResult(300, new android.content.Intent(this.a, com.wancms.sdk.ui.ChargeActivity));
            com.wancms.sdk.ui.ChargeActivity.c.finish();
            com.wancms.sdk.ui.ChargeActivity.b.paymentSuccess(com.wancms.sdk.ui.JZWebPayActivity.b(this.a));
            this.a.finish();
        }
        com.wancms.sdk.util.d.a();
        return;
    }
    public void onPageStarted(android.webkit.WebView p4, String p5, android.graphics.Bitmap p6)
    {
        super.onPageStarted(p4, p5, p6);
        com.wancms.sdk.util.Logger.msg(new StringBuilder().append("webView\u5730\u5740").append(com.wancms.sdk.ui.JZWebPayActivity.a(this.a).getUrl()).toString());
        if ((com.wancms.sdk.ui.JZWebPayActivity.a(this.a).getUrl().contains("h5/cashierPay.htm") != 0) || (com.wancms.sdk.ui.JZWebPayActivity.a(this.a).getUrl().contains("queryordertz.asp") != 0)) {
            this.a.setResult(200, new android.content.Intent(this.a, com.wancms.sdk.ui.ChargeActivity));
            com.wancms.sdk.ui.ChargeActivity.c.finish();
            com.wancms.sdk.ui.ChargeActivity.b.paymentSuccess(com.wancms.sdk.ui.JZWebPayActivity.b(this.a));
            this.a.finish();
        }
        return;
    }
    public void onReceivedError(android.webkit.WebView p1, int p2, String p3, String p4)
    {
        super.onReceivedError(p1, p2, p3, p4);
        return;
    }
    public void onReceivedSslError(android.webkit.WebView p1, android.webkit.SslErrorHandler p2, android.net.http.SslError p3)
    {
        super.onReceivedSslError(p1, p2, p3);
        p2.proceed();
        return;
    }
    public void onUnhandledKeyEvent(android.webkit.WebView p1, android.view.KeyEvent p2)
    {
        super.onUnhandledKeyEvent(p1, p2);
        return;
    }
    public boolean shouldOverrideKeyEvent(android.webkit.WebView p2, android.view.KeyEvent p3)
    {
        return super.shouldOverrideKeyEvent(p2, p3);
    }
    public boolean shouldOverrideUrlLoading(android.webkit.WebView p4, String p5)
    {
        if ((p5.startsWith("http:") == 0) && (p5.startsWith("https:") == 0)) {
            this.a.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(p5)));
            v0 = 1;
        } else {
            v0 = 0;
        }
        return v0;
    }
}
