package com.lidroid.xutils.http.client.multipart.content;
public class StringBody extends com.lidroid.xutils.http.client.multipart.content.AbstractContentBody {
    final private byte[] content;
    final private java.nio.charset.Charset charset;
    public java.io.Reader getReader()
    {
        return new java.io.InputStreamReader(new java.io.ByteArrayInputStream(this.content), this.charset);
    }
    public String getTransferEncoding()
    {
        return "8bit";
    }
    public void writeTo(java.io.OutputStream p10)
    {
        if (p10 != 0) {
            v0 = new java.io.ByteArrayInputStream(this.content);
            v2 = new byte[4096];
            do {
                v1 = v0.read(v2);
                if (v1 != -1) {
                    p10.write(v2, 0, v1);
                    v3 = this.callBackInfo;
                    v3.pos = (v3.pos + ((long) v1));
                } else {
                    p10.flush();
                    return;
                }
            } while(this.callBackInfo.doCallBack(0) != 0);
            throw new java.io.InterruptedIOException("stop");
        } else {
            throw new IllegalArgumentException("Output stream may not be null");
        }
    }
    public StringBody(String p3)
    {
        this(p3, "text/plain", 0);
        return;
    }
    public StringBody(String p3, String p4, java.nio.charset.Charset p5)
    {
        this(p4);
        if (p3 != 0) {
            if (p5 == 0) {
                p5 = java.nio.charset.Charset.forName("UTF-8");
            }
            this.content = p3.getBytes(p5.name());
            this.charset = p5;
            return;
        } else {
            throw new IllegalArgumentException("Text may not be null");
        }
    }
    public StringBody(String p2, java.nio.charset.Charset p3)
    {
        this(p2, "text/plain", p3);
        return;
    }
    public static com.lidroid.xutils.http.client.multipart.content.StringBody create(String p1)
    {
        return com.lidroid.xutils.http.client.multipart.content.StringBody.create(p1, 0, 0);
    }
    public static com.lidroid.xutils.http.client.multipart.content.StringBody create(String p4, String p5, java.nio.charset.Charset p6)
    {
        return new com.lidroid.xutils.http.client.multipart.content.StringBody(p4, p5, p6);
    }
    public static com.lidroid.xutils.http.client.multipart.content.StringBody create(String p1, java.nio.charset.Charset p2)
    {
        return com.lidroid.xutils.http.client.multipart.content.StringBody.create(p1, 0, p2);
    }
    public String getCharset()
    {
        return this.charset.name();
    }
    public long getContentLength()
    {
        return ((long) this.content.length);
    }
    public String getFilename()
    {
        return 0;
    }
}
