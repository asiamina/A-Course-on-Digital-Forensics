package com.lidroid.xutils.util.core;
 class CompatibleAsyncTask$3 extends java.util.concurrent.FutureTask {
    final synthetic com.lidroid.xutils.util.core.CompatibleAsyncTask this$0;
     CompatibleAsyncTask$3(com.lidroid.xutils.util.core.CompatibleAsyncTask p1, java.util.concurrent.Callable p2)
    {
        this.this$0 = p1;
        this(p2);
        return;
    }
    protected void done()
    {
        com.lidroid.xutils.util.core.CompatibleAsyncTask.access$3(this.this$0, this.get());
        return;
    }
}
