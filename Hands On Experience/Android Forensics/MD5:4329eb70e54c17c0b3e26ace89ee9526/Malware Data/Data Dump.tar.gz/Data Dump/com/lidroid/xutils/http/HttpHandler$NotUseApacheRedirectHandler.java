package com.lidroid.xutils.http;
final class HttpHandler$NotUseApacheRedirectHandler implements org.apache.http.client.RedirectHandler {
    synthetic HttpHandler$NotUseApacheRedirectHandler(com.lidroid.xutils.http.HttpHandler$NotUseApacheRedirectHandler p1)
    {
        return;
    }
    public java.net.URI getLocationURI(org.apache.http.HttpResponse p2, org.apache.http.protocol.HttpContext p3)
    {
        return 0;
    }
    public boolean isRedirectRequested(org.apache.http.HttpResponse p2, org.apache.http.protocol.HttpContext p3)
    {
        return 0;
    }
    private HttpHandler$NotUseApacheRedirectHandler()
    {
        return;
    }
}
