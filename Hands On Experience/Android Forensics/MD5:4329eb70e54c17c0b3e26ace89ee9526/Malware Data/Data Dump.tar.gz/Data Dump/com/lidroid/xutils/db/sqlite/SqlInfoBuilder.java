package com.lidroid.xutils.db.sqlite;
public class SqlInfoBuilder {
    private SqlInfoBuilder()
    {
        return;
    }
    public static com.lidroid.xutils.db.sqlite.SqlInfo buildCreateTableSqlInfo(Class p9)
    {
        v5 = com.lidroid.xutils.db.table.TableUtils.getTableName(p9);
        v3 = com.lidroid.xutils.db.table.TableUtils.getId(p9);
        v4 = new StringBuffer();
        v4.append("CREATE TABLE IF NOT EXISTS ");
        v4.append(v5);
        v4.append(" ( ");
        if (v3.isAutoIncrement() == 0) {
            v4.append("\"").append(v3.getColumnName()).append("\"  ").append(v3.getColumnDbType()).append(" PRIMARY KEY,");
        } else {
            v4.append("\"").append(v3.getColumnName()).append("\"  ").append("INTEGER PRIMARY KEY AUTOINCREMENT,");
        }
        v6 = com.lidroid.xutils.db.table.TableUtils.getColumnMap(p9).values().iterator();
        while (v6.hasNext() != 0) {
            v1 = v6.next();
            if ((v1 instanceof com.lidroid.xutils.db.table.Finder) == 0) {
                v4.append("\"").append(v1.getColumnName()).append("\"  ");
                v4.append(v1.getColumnDbType());
                if (com.lidroid.xutils.db.table.ColumnUtils.isUnique(v1.getColumnField()) != 0) {
                    v4.append(" UNIQUE");
                }
                if (com.lidroid.xutils.db.table.ColumnUtils.isNotNull(v1.getColumnField()) != 0) {
                    v4.append(" NOT NULL");
                }
                v0 = com.lidroid.xutils.db.table.ColumnUtils.getCheck(v1.getColumnField());
                if (v0 != 0) {
                    v4.append(" CHECK(").append(v0).append(")");
                }
                v4.append(",");
            }
        }
        v4.deleteCharAt((v4.length() - 1));
        v4.append(" )");
        return new com.lidroid.xutils.db.sqlite.SqlInfo(v4.toString());
    }
    private static String buildDeleteSqlByTableName(String p2)
    {
        return new StringBuilder("DELETE FROM ").append(p2).toString();
    }
    public static com.lidroid.xutils.db.sqlite.SqlInfo buildDeleteSqlInfo(Class p4, com.lidroid.xutils.db.sqlite.WhereBuilder p5)
    {
        v0 = new StringBuilder(com.lidroid.xutils.db.sqlite.SqlInfoBuilder.buildDeleteSqlByTableName(com.lidroid.xutils.db.table.TableUtils.getTableName(p4)));
        if ((p5 != 0) && (p5.getWhereItemSize() > 0)) {
            v0.append(" WHERE ").append(p5.toString());
        }
        return new com.lidroid.xutils.db.sqlite.SqlInfo(v0.toString());
    }
    public static com.lidroid.xutils.db.sqlite.SqlInfo buildDeleteSqlInfo(Class p7, Object p8)
    {
        v1 = new com.lidroid.xutils.db.sqlite.SqlInfo();
        v3 = com.lidroid.xutils.db.table.TableUtils.getTableName(p7);
        v0 = com.lidroid.xutils.db.table.TableUtils.getId(p7);
        if (p8 != 0) {
            v2 = new StringBuilder(com.lidroid.xutils.db.sqlite.SqlInfoBuilder.buildDeleteSqlByTableName(v3));
            v2.append(" WHERE ").append(com.lidroid.xutils.db.sqlite.WhereBuilder.b(v0.getColumnName(), "=", p8));
            v1.setSql(v2.toString());
            return v1;
        } else {
            throw new com.lidroid.xutils.exception.DbException(new StringBuilder("this entity[").append(p7).append("]\'s id value is null").toString());
        }
    }
    public static com.lidroid.xutils.db.sqlite.SqlInfo buildDeleteSqlInfo(Object p9)
    {
        v3 = new com.lidroid.xutils.db.sqlite.SqlInfo();
        v0 = p9.getClass();
        v5 = com.lidroid.xutils.db.table.TableUtils.getTableName(v0);
        v1 = com.lidroid.xutils.db.table.TableUtils.getId(v0);
        v2 = v1.getColumnValue(p9);
        if (v2 != 0) {
            v4 = new StringBuilder(com.lidroid.xutils.db.sqlite.SqlInfoBuilder.buildDeleteSqlByTableName(v5));
            v4.append(" WHERE ").append(com.lidroid.xutils.db.sqlite.WhereBuilder.b(v1.getColumnName(), "=", v2));
            v3.setSql(v4.toString());
            return v3;
        } else {
            throw new com.lidroid.xutils.exception.DbException(new StringBuilder("this entity[").append(p9.getClass()).append("]\'s id value is null").toString());
        }
    }
    public static com.lidroid.xutils.db.sqlite.SqlInfo buildInsertSqlInfo(com.lidroid.xutils.DbUtils p9, Object p10)
    {
        v1 = com.lidroid.xutils.db.sqlite.SqlInfoBuilder.entity2KeyValueList(p9, p10);
        if (v1.size() != 0) {
            v4 = new com.lidroid.xutils.db.sqlite.SqlInfo();
            v5 = new StringBuffer();
            v5.append("INSERT INTO ");
            v5.append(com.lidroid.xutils.db.table.TableUtils.getTableName(p10.getClass()));
            v5.append(" (");
            v6 = v1.iterator();
            while (v6.hasNext() != 0) {
                v2 = v6.next();
                v5.append(v2.getKey()).append(",");
                v4.addBindArgWithoutConverter(v2.getValue());
            }
            v5.deleteCharAt((v5.length() - 1));
            v5.append(") VALUES (");
            v3 = v1.size();
            v0 = 0;
            while (v0 < v3) {
                v5.append("?,");
                v0++;
            }
            v5.deleteCharAt((v5.length() - 1));
            v5.append(")");
            v4.setSql(v5.toString());
        } else {
            v4 = 0;
        }
        return v4;
    }
    public static com.lidroid.xutils.db.sqlite.SqlInfo buildReplaceSqlInfo(com.lidroid.xutils.DbUtils p9, Object p10)
    {
        v1 = com.lidroid.xutils.db.sqlite.SqlInfoBuilder.entity2KeyValueList(p9, p10);
        if (v1.size() != 0) {
            v4 = new com.lidroid.xutils.db.sqlite.SqlInfo();
            v5 = new StringBuffer();
            v5.append("REPLACE INTO ");
            v5.append(com.lidroid.xutils.db.table.TableUtils.getTableName(p10.getClass()));
            v5.append(" (");
            v6 = v1.iterator();
            while (v6.hasNext() != 0) {
                v2 = v6.next();
                v5.append(v2.getKey()).append(",");
                v4.addBindArgWithoutConverter(v2.getValue());
            }
            v5.deleteCharAt((v5.length() - 1));
            v5.append(") VALUES (");
            v3 = v1.size();
            v0 = 0;
            while (v0 < v3) {
                v5.append("?,");
                v0++;
            }
            v5.deleteCharAt((v5.length() - 1));
            v5.append(")");
            v4.setSql(v5.toString());
        } else {
            v4 = 0;
        }
        return v4;
    }
    public static varargs com.lidroid.xutils.db.sqlite.SqlInfo buildUpdateSqlInfo(com.lidroid.xutils.DbUtils p10, Object p11, com.lidroid.xutils.db.sqlite.WhereBuilder p12, String[] p13)
    {
        v1 = com.lidroid.xutils.db.sqlite.SqlInfoBuilder.entity2KeyValueList(p10, p11);
        if (v1.size() != 0) {
            v6 = 0;
            if ((p13 != 0) && (p13.length > 0)) {
                v6 = new java.util.HashSet(p13.length);
                java.util.Collections.addAll(v6, p13);
            }
            v5 = com.lidroid.xutils.db.table.TableUtils.getTableName(p11.getClass());
            v3 = new com.lidroid.xutils.db.sqlite.SqlInfo();
            v4 = new StringBuffer("UPDATE ");
            v4.append(v5);
            v4.append(" SET ");
            v7 = v1.iterator();
            while (v7.hasNext() != 0) {
                v2 = v7.next();
                if ((v6 == 0) || (v6.contains(v2.getKey()) != 0)) {
                    v4.append(v2.getKey()).append("=?,");
                    v3.addBindArgWithoutConverter(v2.getValue());
                }
            }
            v4.deleteCharAt((v4.length() - 1));
            if ((p12 != 0) && (p12.getWhereItemSize() > 0)) {
                v4.append(" WHERE ").append(p12.toString());
            }
            v3.setSql(v4.toString());
        } else {
            v3 = 0;
        }
        return v3;
    }
    public static varargs com.lidroid.xutils.db.sqlite.SqlInfo buildUpdateSqlInfo(com.lidroid.xutils.DbUtils p12, Object p13, String[] p14)
    {
        v3 = com.lidroid.xutils.db.sqlite.SqlInfoBuilder.entity2KeyValueList(p12, p13);
        if (v3.size() != 0) {
            v8 = 0;
            if ((p14 != 0) && (p14.length > 0)) {
                v8 = new java.util.HashSet(p14.length);
                java.util.Collections.addAll(v8, p14);
            }
            v0 = p13.getClass();
            v7 = com.lidroid.xutils.db.table.TableUtils.getTableName(v0);
            v1 = com.lidroid.xutils.db.table.TableUtils.getId(v0);
            v2 = v1.getColumnValue(p13);
            if (v2 != 0) {
                v5 = new com.lidroid.xutils.db.sqlite.SqlInfo();
                v6 = new StringBuffer("UPDATE ");
                v6.append(v7);
                v6.append(" SET ");
                v9 = v3.iterator();
                while (v9.hasNext() != 0) {
                    v4 = v9.next();
                    if ((v8 == 0) || (v8.contains(v4.getKey()) != 0)) {
                        v6.append(v4.getKey()).append("=?,");
                        v5.addBindArgWithoutConverter(v4.getValue());
                    }
                }
                v6.deleteCharAt((v6.length() - 1));
                v6.append(" WHERE ").append(com.lidroid.xutils.db.sqlite.WhereBuilder.b(v1.getColumnName(), "=", v2));
                v5.setSql(v6.toString());
            } else {
                throw new com.lidroid.xutils.exception.DbException(new StringBuilder("this entity[").append(p13.getClass()).append("]\'s id value is null").toString());
            }
        } else {
            v5 = 0;
        }
        return v5;
    }
    private static com.lidroid.xutils.db.table.KeyValue column2KeyValue(Object p3, com.lidroid.xutils.db.table.Column p4)
    {
        v1 = 0;
        v0 = p4.getColumnName();
        v2 = p4.getColumnValue(p3);
        if (v2 == 0) {
            v2 = p4.getDefaultValue();
        }
        if (v0 != 0) {
            v1 = new com.lidroid.xutils.db.table.KeyValue(v0, v2);
        }
        return v1;
    }
    public static java.util.List entity2KeyValueList(com.lidroid.xutils.DbUtils p9, Object p10)
    {
        v5 = new java.util.ArrayList();
        v2 = p10.getClass();
        v3 = com.lidroid.xutils.db.table.TableUtils.getId(v2);
        if (v3.isAutoIncrement() == 0) {
            v5.add(new com.lidroid.xutils.db.table.KeyValue(v3.getColumnName(), v3.getColumnValue(p10)));
        }
        v8 = com.lidroid.xutils.db.table.TableUtils.getColumnMap(v2).values().iterator();
        while (v8.hasNext() != 0) {
            v0 = v8.next();
            if ((v0 instanceof com.lidroid.xutils.db.table.Finder) == 0) {
                if ((v0 instanceof com.lidroid.xutils.db.table.Foreign) != 0) {
                    v0.db = p9;
                }
                v6 = com.lidroid.xutils.db.sqlite.SqlInfoBuilder.column2KeyValue(p10, v0);
                if (v6 != 0) {
                    v5.add(v6);
                }
            } else {
                v0.db = p9;
            }
        }
        return v5;
    }
}
