package com.lidroid.xutils.http.callback;
public abstract class RequestCallBack {
    final private static int DEFAULT_RATE;
    final private static int MIN_RATE;
    private int rate;
    private String requestUrl;
    protected Object userTag;
    public RequestCallBack()
    {
        this.rate = 1000;
        return;
    }
    public RequestCallBack(int p1)
    {
        this.rate = p1;
        return;
    }
    public RequestCallBack(int p1, Object p2)
    {
        this.rate = p1;
        this.userTag = p2;
        return;
    }
    public RequestCallBack(Object p2)
    {
        this.rate = 1000;
        this.userTag = p2;
        return;
    }
    public final int getRate()
    {
        v0 = 200;
        if (this.rate >= 200) {
            v0 = this.rate;
        }
        return v0;
    }
    public final String getRequestUrl()
    {
        return this.requestUrl;
    }
    public Object getUserTag()
    {
        return this.userTag;
    }
    abstract public void onFailure();
    public void onLoading(long p1, long p3, boolean p5)
    {
        return;
    }
    public void onStart()
    {
        return;
    }
    public void onStopped()
    {
        return;
    }
    abstract public void onSuccess();
    public final void setRate(int p1)
    {
        this.rate = p1;
        return;
    }
    public final void setRequestUrl(String p1)
    {
        this.requestUrl = p1;
        return;
    }
    public void setUserTag(Object p1)
    {
        this.userTag = p1;
        return;
    }
}
