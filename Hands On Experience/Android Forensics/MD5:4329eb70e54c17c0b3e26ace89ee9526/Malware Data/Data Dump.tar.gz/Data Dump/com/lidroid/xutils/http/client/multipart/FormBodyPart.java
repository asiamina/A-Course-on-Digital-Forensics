package com.lidroid.xutils.http.client.multipart;
public class FormBodyPart {
    final private com.lidroid.xutils.http.client.multipart.content.ContentBody body;
    final private com.lidroid.xutils.http.client.multipart.MinimalFieldHeader header;
    final private String name;
    public FormBodyPart(String p3, com.lidroid.xutils.http.client.multipart.content.ContentBody p4)
    {
        if (p3 != 0) {
            if (p4 != 0) {
                this.name = p3;
                this.body = p4;
                this.header = new com.lidroid.xutils.http.client.multipart.MinimalFieldHeader();
                this.generateContentDisposition(p4);
                this.generateContentType(p4);
                this.generateTransferEncoding(p4);
                return;
            } else {
                throw new IllegalArgumentException("Body may not be null");
            }
        } else {
            throw new IllegalArgumentException("Name may not be null");
        }
    }
    public FormBodyPart(String p3, com.lidroid.xutils.http.client.multipart.content.ContentBody p4, String p5)
    {
        if (p3 != 0) {
            if (p4 != 0) {
                this.name = p3;
                this.body = p4;
                this.header = new com.lidroid.xutils.http.client.multipart.MinimalFieldHeader();
                if (p5 == 0) {
                    this.generateContentDisposition(p4);
                } else {
                    this.addField("Content-Disposition", p5);
                }
                this.generateContentType(p4);
                this.generateTransferEncoding(p4);
                return;
            } else {
                throw new IllegalArgumentException("Body may not be null");
            }
        } else {
            throw new IllegalArgumentException("Name may not be null");
        }
    }
    public void addField(String p3, String p4)
    {
        if (p3 != 0) {
            this.header.addField(new com.lidroid.xutils.http.client.multipart.MinimalField(p3, p4));
            return;
        } else {
            throw new IllegalArgumentException("Field name may not be null");
        }
    }
    protected void generateContentDisposition(com.lidroid.xutils.http.client.multipart.content.ContentBody p4)
    {
        v0 = new StringBuilder();
        v0.append("form-data; name=\"");
        v0.append(this.getName());
        v0.append("\"");
        if (p4.getFilename() != 0) {
            v0.append("; filename=\"");
            v0.append(p4.getFilename());
            v0.append("\"");
        }
        this.addField("Content-Disposition", v0.toString());
        return;
    }
    protected void generateContentType(com.lidroid.xutils.http.client.multipart.content.ContentBody p4)
    {
        v0 = new StringBuilder();
        v0.append(p4.getMimeType());
        if (p4.getCharset() != 0) {
            v0.append("; charset=");
            v0.append(p4.getCharset());
        }
        this.addField("Content-Type", v0.toString());
        return;
    }
    protected void generateTransferEncoding(com.lidroid.xutils.http.client.multipart.content.ContentBody p3)
    {
        this.addField("Content-Transfer-Encoding", p3.getTransferEncoding());
        return;
    }
    public com.lidroid.xutils.http.client.multipart.content.ContentBody getBody()
    {
        return this.body;
    }
    public com.lidroid.xutils.http.client.multipart.MinimalFieldHeader getHeader()
    {
        return this.header;
    }
    public String getName()
    {
        return this.name;
    }
}
