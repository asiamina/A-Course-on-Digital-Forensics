package com.lidroid.xutils.util;
public interface abstract class LogUtils$CustomLogger {
    abstract public void d();
    abstract public void d();
    abstract public void e();
    abstract public void e();
    abstract public void i();
    abstract public void i();
    abstract public void v();
    abstract public void v();
    abstract public void w();
    abstract public void w();
    abstract public void w();
    abstract public void wtf();
    abstract public void wtf();
    abstract public void wtf();
}
