package com.lidroid.xutils.http;
public class RequestParams$HeaderItem {
    final public org.apache.http.Header header;
    final synthetic com.lidroid.xutils.http.RequestParams this$0;
    final public boolean overwrite;
    public RequestParams$HeaderItem(com.lidroid.xutils.http.RequestParams p2, String p3, String p4)
    {
        this.this$0 = p2;
        this.overwrite = 0;
        this.header = new org.apache.http.message.BasicHeader(p3, p4);
        return;
    }
    public RequestParams$HeaderItem(com.lidroid.xutils.http.RequestParams p2, String p3, String p4, boolean p5)
    {
        this.this$0 = p2;
        this.overwrite = p5;
        this.header = new org.apache.http.message.BasicHeader(p3, p4);
        return;
    }
    public RequestParams$HeaderItem(com.lidroid.xutils.http.RequestParams p2, org.apache.http.Header p3)
    {
        this.this$0 = p2;
        this.overwrite = 0;
        this.header = p3;
        return;
    }
    public RequestParams$HeaderItem(com.lidroid.xutils.http.RequestParams p1, org.apache.http.Header p2, boolean p3)
    {
        this.this$0 = p1;
        this.overwrite = p3;
        this.header = p2;
        return;
    }
}
