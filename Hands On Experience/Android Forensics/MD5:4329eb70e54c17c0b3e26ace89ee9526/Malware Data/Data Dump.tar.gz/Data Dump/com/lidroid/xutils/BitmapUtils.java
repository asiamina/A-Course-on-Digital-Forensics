package com.lidroid.xutils;
public class BitmapUtils {
    private com.lidroid.xutils.bitmap.BitmapDisplayConfig defaultDisplayConfig;
    private com.lidroid.xutils.bitmap.BitmapGlobalConfig globalConfig;
    private boolean pauseTask;
    final private Object pauseTaskLock;
    private android.content.Context context;
    public BitmapUtils(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }
    public BitmapUtils(android.content.Context p3, String p4)
    {
        this.pauseTask = 0;
        this.pauseTaskLock = new Object();
        if (p3 != 0) {
            this.context = p3;
            this.globalConfig = new com.lidroid.xutils.bitmap.BitmapGlobalConfig(p3, p4);
            this.defaultDisplayConfig = new com.lidroid.xutils.bitmap.BitmapDisplayConfig();
            return;
        } else {
            throw new IllegalArgumentException("context may not be null");
        }
    }
    public BitmapUtils(android.content.Context p2, String p3, float p4)
    {
        this(p2, p3);
        this.globalConfig.setMemCacheSizePercent(p4);
        return;
    }
    public BitmapUtils(android.content.Context p2, String p3, float p4, int p5)
    {
        this(p2, p3);
        this.globalConfig.setMemCacheSizePercent(p4);
        this.globalConfig.setDiskCacheSize(p5);
        return;
    }
    public BitmapUtils(android.content.Context p2, String p3, int p4)
    {
        this(p2, p3);
        this.globalConfig.setMemoryCacheSize(p4);
        return;
    }
    public BitmapUtils(android.content.Context p2, String p3, int p4, int p5)
    {
        this(p2, p3);
        this.globalConfig.setMemoryCacheSize(p4);
        this.globalConfig.setDiskCacheSize(p5);
        return;
    }
    static synthetic Object access$0(com.lidroid.xutils.BitmapUtils p1)
    {
        return p1.pauseTaskLock;
    }
    static synthetic boolean access$1(com.lidroid.xutils.BitmapUtils p1)
    {
        return p1.pauseTask;
    }
    static synthetic com.lidroid.xutils.bitmap.BitmapGlobalConfig access$2(com.lidroid.xutils.BitmapUtils p1)
    {
        return p1.globalConfig;
    }
    static synthetic com.lidroid.xutils.BitmapUtils$BitmapLoadTask access$3(android.view.View p1, com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack p2)
    {
        return com.lidroid.xutils.BitmapUtils.getBitmapTaskFromContainer(p1, p2);
    }
    private static boolean bitmapLoadTaskExist(android.view.View p4, String p5, com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack p6)
    {
        v2 = 1;
        v0 = com.lidroid.xutils.BitmapUtils.getBitmapTaskFromContainer(p4, p6);
        if (v0 == 0) {
            v2 = 0;
        } else {
            v1 = com.lidroid.xutils.BitmapUtils$BitmapLoadTask.access$3(v0);
            if ((android.text.TextUtils.isEmpty(v1) != 0) || (v1.equals(p5) == 0)) {
                v0.cancel(1);
            }
        }
        return v2;
    }
    public void clearCache()
    {
        this.globalConfig.clearCache();
        return;
    }
    public void clearCache(String p2)
    {
        this.globalConfig.clearCache(p2);
        return;
    }
    public void clearDiskCache()
    {
        this.globalConfig.clearDiskCache();
        return;
    }
    public void clearDiskCache(String p2)
    {
        this.globalConfig.clearDiskCache(p2);
        return;
    }
    public void clearMemoryCache()
    {
        this.globalConfig.clearMemoryCache();
        return;
    }
    public void clearMemoryCache(String p2)
    {
        this.globalConfig.clearMemoryCache(p2);
        return;
    }
    public void closeCache()
    {
        this.globalConfig.closeCache();
        return;
    }
    public com.lidroid.xutils.BitmapUtils configBitmapCacheListener(com.lidroid.xutils.bitmap.BitmapCacheListener p2)
    {
        this.globalConfig.setBitmapCacheListener(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultAutoRotation(boolean p2)
    {
        this.defaultDisplayConfig.setAutoRotation(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultBitmapConfig(android.graphics.Bitmap$Config p2)
    {
        this.defaultDisplayConfig.setBitmapConfig(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultBitmapMaxSize(int p3, int p4)
    {
        this.defaultDisplayConfig.setBitmapMaxSize(new com.lidroid.xutils.bitmap.core.BitmapSize(p3, p4));
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultBitmapMaxSize(com.lidroid.xutils.bitmap.core.BitmapSize p2)
    {
        this.defaultDisplayConfig.setBitmapMaxSize(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultCacheExpiry(long p2)
    {
        this.globalConfig.setDefaultCacheExpiry(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultConnectTimeout(int p2)
    {
        this.globalConfig.setDefaultConnectTimeout(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultDisplayConfig(com.lidroid.xutils.bitmap.BitmapDisplayConfig p1)
    {
        this.defaultDisplayConfig = p1;
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultImageLoadAnimation(android.view.animation.Animation p2)
    {
        this.defaultDisplayConfig.setAnimation(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultLoadFailedImage(int p3)
    {
        this.defaultDisplayConfig.setLoadFailedDrawable(this.context.getResources().getDrawable(p3));
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultLoadFailedImage(android.graphics.Bitmap p4)
    {
        this.defaultDisplayConfig.setLoadFailedDrawable(new android.graphics.drawable.BitmapDrawable(this.context.getResources(), p4));
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultLoadFailedImage(android.graphics.drawable.Drawable p2)
    {
        this.defaultDisplayConfig.setLoadFailedDrawable(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultLoadingImage(int p3)
    {
        this.defaultDisplayConfig.setLoadingDrawable(this.context.getResources().getDrawable(p3));
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultLoadingImage(android.graphics.Bitmap p4)
    {
        this.defaultDisplayConfig.setLoadingDrawable(new android.graphics.drawable.BitmapDrawable(this.context.getResources(), p4));
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultLoadingImage(android.graphics.drawable.Drawable p2)
    {
        this.defaultDisplayConfig.setLoadingDrawable(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultReadTimeout(int p2)
    {
        this.globalConfig.setDefaultReadTimeout(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDefaultShowOriginal(boolean p2)
    {
        this.defaultDisplayConfig.setShowOriginal(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDiskCacheEnabled(boolean p2)
    {
        this.globalConfig.setDiskCacheEnabled(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDiskCacheFileNameGenerator(com.lidroid.xutils.util.core.LruDiskCache$DiskCacheFileNameGenerator p2)
    {
        this.globalConfig.setDiskCacheFileNameGenerator(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configDownloader(com.lidroid.xutils.bitmap.download.Downloader p2)
    {
        this.globalConfig.setDownloader(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configGlobalConfig(com.lidroid.xutils.bitmap.BitmapGlobalConfig p1)
    {
        this.globalConfig = p1;
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configMemoryCacheEnabled(boolean p2)
    {
        this.globalConfig.setMemoryCacheEnabled(p2);
        return this;
    }
    public com.lidroid.xutils.BitmapUtils configThreadPoolSize(int p2)
    {
        this.globalConfig.setThreadPoolSize(p2);
        return this;
    }
    public void display(android.view.View p2, String p3)
    {
        this.display(p2, p3, 0, 0);
        return;
    }
    public void display(android.view.View p2, String p3, com.lidroid.xutils.bitmap.BitmapDisplayConfig p4)
    {
        this.display(p2, p3, p4, 0);
        return;
    }
    public void display(android.view.View p17, String p18, com.lidroid.xutils.bitmap.BitmapDisplayConfig p19, com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack p20)
    {
        if (p17 != 0) {
            p17.clearAnimation();
            if (p20 == 0) {
                p20 = new com.lidroid.xutils.bitmap.callback.DefaultBitmapLoadCallBack();
            }
            if ((p19 == 0) || (p19 == this.defaultDisplayConfig)) {
                p19 = this.defaultDisplayConfig.cloneNew();
            }
            v15 = p19.getBitmapMaxSize();
            p19.setBitmapMaxSize(com.lidroid.xutils.bitmap.BitmapCommonUtils.optimizeMaxSizeByView(p17, v15.getWidth(), v15.getHeight()));
            p20.onPreLoad(p17, p18, p19);
            if (android.text.TextUtils.isEmpty(p18) == 0) {
                v7 = this.globalConfig.getBitmapCache().getBitmapFromMemCache(p18, p19);
                if (v7 == 0) {
                    if (com.lidroid.xutils.BitmapUtils.bitmapLoadTaskExist(p17, p18, p20) == 0) {
                        v8 = new com.lidroid.xutils.BitmapUtils$BitmapLoadTask(this, p17, p18, p19, p20);
                        p20.setDrawable(p17, new com.lidroid.xutils.bitmap.core.AsyncDrawable(p19.getLoadingDrawable(), v8));
                        v5 = new Object[0];
                        v8.executeOnExecutor(this.globalConfig.getBitmapLoadExecutor(), v5);
                    }
                } else {
                    p20.onLoadStarted(p17, p18, p19);
                    p20.onLoadCompleted(p17, p18, v7, p19, com.lidroid.xutils.bitmap.callback.BitmapLoadFrom.MEMORY_CACHE);
                }
            } else {
                p20.onLoadFailed(p17, p18, p19.getLoadFailedDrawable());
            }
        }
        return;
    }
    public void display(android.view.View p2, String p3, com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack p4)
    {
        this.display(p2, p3, 0, p4);
        return;
    }
    public void flushCache()
    {
        this.globalConfig.flushCache();
        return;
    }
    public java.io.File getBitmapFileFromDiskCache(String p2)
    {
        return this.globalConfig.getBitmapCache().getBitmapFileFromDiskCache(p2);
    }
    public android.graphics.Bitmap getBitmapFromMemCache(String p2, com.lidroid.xutils.bitmap.BitmapDisplayConfig p3)
    {
        if (p3 == 0) {
            p3 = this.defaultDisplayConfig;
        }
        return this.globalConfig.getBitmapCache().getBitmapFromMemCache(p2, p3);
    }
    private static com.lidroid.xutils.BitmapUtils$BitmapLoadTask getBitmapTaskFromContainer(android.view.View p3, com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack p4)
    {
        if (p3 == 0) {
            v2 = 0;
        } else {
            v1 = p4.getDrawable(p3);
            } else {
                v2 = v1.getBitmapWorkerTask();
            }
        }
        return v2;
    }
    public void pauseTasks()
    {
        this.pauseTask = 1;
        this.flushCache();
        return;
    }
    public void resumeTasks()
    {
        this.pauseTask = 0;
        this.pauseTaskLock.notifyAll();
        return;
    }
    public void stopTasks()
    {
        this.pauseTask = 1;
        this.pauseTaskLock.notifyAll();
        return;
    }
}
