package com.lidroid.xutils.bitmap.core;
 class BitmapCache$1 extends com.lidroid.xutils.util.core.LruMemoryCache {
    final synthetic com.lidroid.xutils.bitmap.core.BitmapCache this$0;
    protected synthetic bridge int sizeOf(Object p2, Object p3)
    {
        return this.sizeOf(p2, p3);
    }
     BitmapCache$1(com.lidroid.xutils.bitmap.core.BitmapCache p1, int p2)
    {
        this.this$0 = p1;
        this(p2);
        return;
    }
    protected int sizeOf(com.lidroid.xutils.bitmap.core.BitmapCache$MemoryCacheKey p3, android.graphics.Bitmap p4)
    {
        if (p4 != 0) {
            v0 = (p4.getRowBytes() * p4.getHeight());
        } else {
            v0 = 0;
        }
        return v0;
    }
}
