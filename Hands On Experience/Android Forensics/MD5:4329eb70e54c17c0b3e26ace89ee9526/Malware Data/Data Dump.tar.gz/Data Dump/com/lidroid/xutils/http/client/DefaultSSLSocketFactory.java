package com.lidroid.xutils.http.client;
public class DefaultSSLSocketFactory extends org.apache.http.conn.ssl.SSLSocketFactory {
    private static com.lidroid.xutils.http.client.DefaultSSLSocketFactory instance;
    private static java.security.KeyStore trustStore;
    private javax.net.ssl.SSLContext sslContext;
    static DefaultSSLSocketFactory()
    {
        com.lidroid.xutils.http.client.DefaultSSLSocketFactory.trustStore = java.security.KeyStore.getInstance(java.security.KeyStore.getDefaultType());
        com.lidroid.xutils.http.client.DefaultSSLSocketFactory.trustStore.load(0, 0);
        return;
    }
    private DefaultSSLSocketFactory()
    {
        this(com.lidroid.xutils.http.client.DefaultSSLSocketFactory.trustStore);
        this.sslContext = javax.net.ssl.SSLContext.getInstance("TLS");
        v2 = new javax.net.ssl.TrustManager[1];
        v2[0] = new com.lidroid.xutils.http.client.DefaultSSLSocketFactory$1(this);
        this.sslContext.init(0, v2, 0);
        this.setHostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        return;
    }
    public java.net.Socket createSocket()
    {
        return this.sslContext.getSocketFactory().createSocket();
    }
    public java.net.Socket createSocket(java.net.Socket p2, String p3, int p4, boolean p5)
    {
        return this.sslContext.getSocketFactory().createSocket(p2, p3, p4, p5);
    }
    public static com.lidroid.xutils.http.client.DefaultSSLSocketFactory getSocketFactory()
    {
        if (com.lidroid.xutils.http.client.DefaultSSLSocketFactory.instance == 0) {
            com.lidroid.xutils.http.client.DefaultSSLSocketFactory.instance = new com.lidroid.xutils.http.client.DefaultSSLSocketFactory();
        }
        return com.lidroid.xutils.http.client.DefaultSSLSocketFactory.instance;
    }
    public static synthetic bridge org.apache.http.conn.ssl.SSLSocketFactory getSocketFactory()
    {
        return com.lidroid.xutils.http.client.DefaultSSLSocketFactory.getSocketFactory();
    }
}
