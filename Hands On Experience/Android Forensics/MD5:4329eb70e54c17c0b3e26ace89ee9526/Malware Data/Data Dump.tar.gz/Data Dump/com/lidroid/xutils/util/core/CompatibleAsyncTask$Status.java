package com.lidroid.xutils.util.core;
final public enum class CompatibleAsyncTask$Status extends java.lang.Enum {
    final private synthetic static com.lidroid.xutils.util.core.CompatibleAsyncTask$Status[] ENUM$VALUES;
    final public static enum com.lidroid.xutils.util.core.CompatibleAsyncTask$Status FINISHED;
    final public static enum com.lidroid.xutils.util.core.CompatibleAsyncTask$Status RUNNING;
    final public static enum com.lidroid.xutils.util.core.CompatibleAsyncTask$Status PENDING;
    static CompatibleAsyncTask$Status()
    {
        com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.PENDING = new com.lidroid.xutils.util.core.CompatibleAsyncTask$Status("PENDING", 0);
        com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.RUNNING = new com.lidroid.xutils.util.core.CompatibleAsyncTask$Status("RUNNING", 1);
        com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.FINISHED = new com.lidroid.xutils.util.core.CompatibleAsyncTask$Status("FINISHED", 2);
        v0 = new com.lidroid.xutils.util.core.CompatibleAsyncTask$Status[3];
        v0[0] = com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.PENDING;
        v0[1] = com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.RUNNING;
        v0[2] = com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.FINISHED;
        com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.ENUM$VALUES = v0;
        return;
    }
    private CompatibleAsyncTask$Status(String p1, int p2)
    {
        this(p1, p2);
        return;
    }
    public static com.lidroid.xutils.util.core.CompatibleAsyncTask$Status valueOf(String p1)
    {
        return Enum.valueOf(com.lidroid.xutils.util.core.CompatibleAsyncTask$Status, p1);
    }
    public static com.lidroid.xutils.util.core.CompatibleAsyncTask$Status[] values()
    {
        v0 = com.lidroid.xutils.util.core.CompatibleAsyncTask$Status.ENUM$VALUES;
        v1 = v0.length;
        v2 = new com.lidroid.xutils.util.core.CompatibleAsyncTask$Status[v1];
        System.arraycopy(v0, 0, v2, 0, v1);
        return v2;
    }
}
