package com.lidroid.xutils.http.client.multipart;
public class MultipartEntity$CallBackInfo {
    final public static com.lidroid.xutils.http.client.multipart.MultipartEntity$CallBackInfo DEFAULT;
    public com.lidroid.xutils.http.callback.RequestCallBackHandler callBackHandler;
    public long pos;
    public long totalLength;
    static MultipartEntity$CallBackInfo()
    {
        com.lidroid.xutils.http.client.multipart.MultipartEntity$CallBackInfo.DEFAULT = new com.lidroid.xutils.http.client.multipart.MultipartEntity$CallBackInfo();
        return;
    }
    public MultipartEntity$CallBackInfo()
    {
        this.callBackHandler = 0;
        this.totalLength = 0.0;
        this.pos = 0.0;
        return;
    }
    public boolean doCallBack(boolean p7)
    {
        if (this.callBackHandler == 0) {
            v0 = 1;
        } else {
            v0 = this.callBackHandler.updateProgress(this.totalLength, v2, this.pos, v4, p7);
        }
        return v0;
    }
}
