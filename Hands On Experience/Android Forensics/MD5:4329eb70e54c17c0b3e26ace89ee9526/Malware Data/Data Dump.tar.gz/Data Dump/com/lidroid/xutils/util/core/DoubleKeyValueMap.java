package com.lidroid.xutils.util.core;
public class DoubleKeyValueMap {
    private java.util.concurrent.ConcurrentHashMap k1_k2V_map;
    public DoubleKeyValueMap()
    {
        this.k1_k2V_map = new java.util.concurrent.ConcurrentHashMap();
        return;
    }
    public void clear()
    {
        if (this.k1_k2V_map.size() > 0) {
            v1 = this.k1_k2V_map.values().iterator();
            while (v1.hasNext() != 0) {
                v1.next().clear();
            }
            this.k1_k2V_map.clear();
        }
        return;
    }
    public boolean containsKey(Object p2)
    {
        return this.k1_k2V_map.containsKey(p2);
    }
    public boolean containsKey(Object p2, Object p3)
    {
        if (this.k1_k2V_map.containsKey(p2) == 0) {
            v0 = 0;
        } else {
            v0 = this.k1_k2V_map.get(p2).containsKey(p3);
        }
        return v0;
    }
    public Object get(Object p3, Object p4)
    {
        v0 = this.k1_k2V_map.get(p3);
        if (v0 != 0) {
            v1 = v0.get(p4);
        } else {
            v1 = 0;
        }
        return v1;
    }
    public java.util.concurrent.ConcurrentHashMap get(Object p2)
    {
        return this.k1_k2V_map.get(p2);
    }
    public java.util.Collection getAllValues()
    {
        v2 = 0;
        v1 = this.k1_k2V_map.keySet();
        if (v1 != 0) {
            v2 = new java.util.ArrayList();
            v5 = v1.iterator();
            while (v5.hasNext() != 0) {
                v3 = this.k1_k2V_map.get(v5.next()).values();
                if (v3 != 0) {
                    v2.addAll(v3);
                }
            }
        }
        return v2;
    }
    public java.util.Collection getAllValues(Object p3)
    {
        v0 = this.k1_k2V_map.get(p3);
        if (v0 != 0) {
            v1 = v0.values();
        } else {
            v1 = 0;
        }
        return v1;
    }
    public java.util.Set getFirstKeys()
    {
        return this.k1_k2V_map.keySet();
    }
    public void put(Object p3, Object p4, Object p5)
    {
        if ((p3 != 0) && ((p4 != 0) && (p5 != 0))) {
            if (this.k1_k2V_map.containsKey(p3) == 0) {
                v0 = new java.util.concurrent.ConcurrentHashMap();
                v0.put(p4, p5);
                this.k1_k2V_map.put(p3, v0);
            } else {
                v0 = this.k1_k2V_map.get(p3);
                if (v0 == 0) {
                    v0 = new java.util.concurrent.ConcurrentHashMap();
                    v0.put(p4, p5);
                    this.k1_k2V_map.put(p3, v0);
                } else {
                    v0.put(p4, p5);
                }
            }
        }
        return;
    }
    public void remove(Object p2)
    {
        this.k1_k2V_map.remove(p2);
        return;
    }
    public void remove(Object p3, Object p4)
    {
        v0 = this.k1_k2V_map.get(p3);
        if (v0 != 0) {
            v0.remove(p4);
        }
        return;
    }
    public int size()
    {
        if (this.k1_k2V_map.size() != 0) {
            v1 = 0;
            v2 = this.k1_k2V_map.values().iterator();
            while (v2.hasNext() != 0) {
                v1 += v2.next().size();
            }
        } else {
            v1 = 0;
        }
        return v1;
    }
}
