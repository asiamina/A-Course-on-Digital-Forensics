package com.lidroid.xutils.http.callback;
public interface abstract class RequestCallBackHandler {
    abstract public boolean updateProgress();
}
