package com.lidroid.xutils.http.client.multipart.content;
public interface abstract class ContentBody implements com.lidroid.xutils.http.client.multipart.content.ContentDescriptor {
    abstract public String getFilename();
    abstract public void setCallBackInfo();
    abstract public void writeTo();
}
