package com.lidroid.xutils.view.annotation;
public interface annotation abstract class ResInject implements java.lang.annotation.Annotation {
    abstract public int id();
    abstract public com.lidroid.xutils.view.ResType type();
}
