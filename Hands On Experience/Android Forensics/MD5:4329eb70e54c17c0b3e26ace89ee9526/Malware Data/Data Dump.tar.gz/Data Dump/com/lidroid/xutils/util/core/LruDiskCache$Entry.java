package com.lidroid.xutils.util.core;
final class LruDiskCache$Entry {
    private com.lidroid.xutils.util.core.LruDiskCache$Editor currentEditor;
    private long sequenceNumber;
    final private long[] lengths;
    final private String diskKey;
    private boolean readable;
    final synthetic com.lidroid.xutils.util.core.LruDiskCache this$0;
    private long expiryTimestamp;
    static synthetic long access$10(com.lidroid.xutils.util.core.LruDiskCache$Entry p2)
    {
        return p2.sequenceNumber;
    }
    static synthetic void access$11(com.lidroid.xutils.util.core.LruDiskCache$Entry p0, long p1)
    {
        p0.sequenceNumber = p1;
        return;
    }
    static synthetic com.lidroid.xutils.util.core.LruDiskCache$Editor access$2(com.lidroid.xutils.util.core.LruDiskCache$Entry p1)
    {
        return p1.currentEditor;
    }
    static synthetic String access$3(com.lidroid.xutils.util.core.LruDiskCache$Entry p1)
    {
        return p1.diskKey;
    }
    static synthetic void access$5(com.lidroid.xutils.util.core.LruDiskCache$Entry p0, boolean p1)
    {
        p0.readable = p1;
        return;
    }
    static synthetic void access$6(com.lidroid.xutils.util.core.LruDiskCache$Entry p0, com.lidroid.xutils.util.core.LruDiskCache$Editor p1)
    {
        p0.currentEditor = p1;
        return;
    }
    static synthetic void access$7(com.lidroid.xutils.util.core.LruDiskCache$Entry p0, String[] p1, int p2)
    {
        p0.setLengths(p1, p2);
        return;
    }
    static synthetic long[] access$8(com.lidroid.xutils.util.core.LruDiskCache$Entry p1)
    {
        return p1.lengths;
    }
    static synthetic long access$9(com.lidroid.xutils.util.core.LruDiskCache$Entry p2)
    {
        return p2.expiryTimestamp;
    }
    public java.io.File getCleanFile(int p5)
    {
        return new java.io.File(com.lidroid.xutils.util.core.LruDiskCache.access$8(this.this$0), new StringBuilder(String.valueOf(this.diskKey)).append(".").append(p5).toString());
    }
    public java.io.File getDirtyFile(int p5)
    {
        return new java.io.File(com.lidroid.xutils.util.core.LruDiskCache.access$8(this.this$0), new StringBuilder(String.valueOf(this.diskKey)).append(".").append(p5).append(".tmp").toString());
    }
    public String getLengths()
    {
        v0 = new StringBuilder();
        v4 = this.lengths;
        v5 = v4.length;
        v3 = 0;
        while (v3 < v5) {
            v0.append(32).append(v4[v3]);
            v3++;
        }
        return v0.toString();
    }
    private java.io.IOException invalidLengths(String[] p4)
    {
        throw new java.io.IOException(new StringBuilder("unexpected journal line: ").append(java.util.Arrays.toString(p4)).toString());
    }
    private void setLengths(String[] p6, int p7)
    {
        if ((p6.length - p7) == com.lidroid.xutils.util.core.LruDiskCache.access$7(this.this$0)) {
            v1 = 0;
            while (v1 < com.lidroid.xutils.util.core.LruDiskCache.access$7(this.this$0)) {
                this.lengths[v1] = Long.parseLong(p6[(v1 + p7)]);
                v1++;
            }
            return;
        } else {
            this.invalidLengths(p6);
            throw this;
        }
    }
    private LruDiskCache$Entry(com.lidroid.xutils.util.core.LruDiskCache p3, String p4)
    {
        this.this$0 = p3;
        this.expiryTimestamp = nan;
        this.diskKey = p4;
        v0 = new long[com.lidroid.xutils.util.core.LruDiskCache.access$7(p3)];
        this.lengths = v0;
        return;
    }
    synthetic LruDiskCache$Entry(com.lidroid.xutils.util.core.LruDiskCache p1, String p2, com.lidroid.xutils.util.core.LruDiskCache$Entry p3)
    {
        this(p1, p2);
        return;
    }
    static synthetic boolean access$0(com.lidroid.xutils.util.core.LruDiskCache$Entry p1)
    {
        return p1.readable;
    }
    static synthetic void access$1(com.lidroid.xutils.util.core.LruDiskCache$Entry p0, long p1)
    {
        p0.expiryTimestamp = p1;
        return;
    }
}
