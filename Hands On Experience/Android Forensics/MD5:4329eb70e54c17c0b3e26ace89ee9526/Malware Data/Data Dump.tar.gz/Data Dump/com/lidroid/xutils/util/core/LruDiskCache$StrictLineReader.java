package com.lidroid.xutils.util.core;
 class LruDiskCache$StrictLineReader implements java.io.Closeable {
    final private static byte LF;
    private int end;
    final private java.nio.charset.Charset charset;
    private int pos;
    final synthetic com.lidroid.xutils.util.core.LruDiskCache this$0;
    final private java.io.InputStream in;
    final private static byte CR;
    private byte[] buf;
    public LruDiskCache$StrictLineReader(com.lidroid.xutils.util.core.LruDiskCache p2, java.io.InputStream p3)
    {
        this(p2, p3, 8192);
        return;
    }
    public LruDiskCache$StrictLineReader(com.lidroid.xutils.util.core.LruDiskCache p3, java.io.InputStream p4, int p5)
    {
        this.this$0 = p3;
        this.charset = java.nio.charset.Charset.forName("US-ASCII");
        if (p4 != 0) {
            if (p5 >= 0) {
                this.in = p4;
                v0 = new byte[p5];
                this.buf = v0;
                return;
            } else {
                throw new IllegalArgumentException("capacity <= 0");
            }
        } else {
            throw new NullPointerException();
        }
    }
    static synthetic java.nio.charset.Charset access$0(com.lidroid.xutils.util.core.LruDiskCache$StrictLineReader p1)
    {
        return p1.charset;
    }
    public void close()
    {
        if (this.buf != 0) {
            this.buf = 0;
            this.in.close();
        }
        return;
    }
    private void fillBuf()
    {
        v0 = this.in.read(this.buf, 0, this.buf.length);
        if (v0 != -1) {
            this.pos = 0;
            this.end = v0;
            return;
        } else {
            throw new java.io.EOFException();
        }
    }
    public String readLine()
    {
        if (this.buf != 0) {
            if (this.pos >= this.end) {
                this.fillBuf();
            }
            v0 = this.pos;
            while (v0 != this.end) {
                if (this.buf[v0] != 10) {
                    v0++;
                } else {
                    if ((v0 == this.pos) || (this.buf[(v0 - 1)] != 13)) {
                        v1 = v0;
                    } else {
                        v1 = (v0 - 1);
                    }
                    v3 = new String(this.buf, this.pos, (v1 - this.pos), this.charset.name());
                    this.pos = (v0 + 1);
                }
                return v3;
            }
            v2 = new com.lidroid.xutils.util.core.LruDiskCache$StrictLineReader$1(this, ((this.end - this.pos) + 80));
            do {
                v2.write(this.buf, this.pos, (this.end - this.pos));
                this.end = -1;
                this.fillBuf();
                v0 = this.pos;
                if (v0 != this.end) {
                    break;
                }
            } while(v0 != this.end);
            if (this.buf[v0] != 10) {
                v0++;
                while (v0 == this.end) {
                }
            } else {
                if (v0 != this.pos) {
                    v2.write(this.buf, this.pos, (v0 - this.pos));
                }
                v2.flush();
                this.pos = (v0 + 1);
                v3 = v2.toString();
            }
        } else {
            throw new java.io.IOException("LineReader is closed");
        }
    }
}
