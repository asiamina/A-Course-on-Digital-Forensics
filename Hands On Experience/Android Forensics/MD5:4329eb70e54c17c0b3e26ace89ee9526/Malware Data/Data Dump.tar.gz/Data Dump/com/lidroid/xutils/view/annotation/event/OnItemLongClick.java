package com.lidroid.xutils.view.annotation.event;
public interface annotation abstract class OnItemLongClick implements java.lang.annotation.Annotation {
    abstract public int[] value();
    abstract public int[] parentId();
}
