package com.lidroid.xutils.http.client.multipart.content;
public class ByteArrayBody extends com.lidroid.xutils.http.client.multipart.content.AbstractContentBody {
    final private byte[] data;
    final private String filename;
    public ByteArrayBody(byte[] p2, String p3)
    {
        this(p2, "application/octet-stream", p3);
        return;
    }
    public ByteArrayBody(byte[] p3, String p4, String p5)
    {
        this(p4);
        if (p3 != 0) {
            this.data = p3;
            this.filename = p5;
            return;
        } else {
            throw new IllegalArgumentException("byte[] may not be null");
        }
    }
    public String getCharset()
    {
        return 0;
    }
    public long getContentLength()
    {
        return ((long) this.data.length);
    }
    public String getFilename()
    {
        return this.filename;
    }
    public String getTransferEncoding()
    {
        return "binary";
    }
    public void writeTo(java.io.OutputStream p6)
    {
        p6.write(this.data);
        v0 = this.callBackInfo;
        v0.pos = (v0.pos + ((long) this.data.length));
        this.callBackInfo.doCallBack(0);
        return;
    }
}
