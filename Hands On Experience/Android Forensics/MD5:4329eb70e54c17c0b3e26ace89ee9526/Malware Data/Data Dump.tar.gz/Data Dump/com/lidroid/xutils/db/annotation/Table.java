package com.lidroid.xutils.db.annotation;
public interface annotation abstract class Table implements java.lang.annotation.Annotation {
    abstract public String execAfterTableCreated();
    abstract public String name();
}
