package com.lidroid.xutils.util;
public class OtherUtils {
    private static javax.net.ssl.TrustManager[] trustAllCerts;
    final private static int STRING_BUFFER_LENGTH;
    private OtherUtils()
    {
        return;
    }
    public static StackTraceElement getCallerStackTraceElement()
    {
        return Thread.currentThread().getStackTrace()[4];
    }
    public static java.nio.charset.Charset getCharsetFromHttpRequest(org.apache.http.client.methods.HttpRequestBase p10)
    {
        v5 = 0;
        if (p10 != 0) {
            v0 = 0;
            v3 = p10.getFirstHeader("Content-Type");
            if (v3 != 0) {
                v7 = v3.getElements();
                v8 = v7.length;
                v6 = 0;
                while (v6 < v8) {
                    v1 = v7[v6].getParameterByName("charset");
                    if (v1 == 0) {
                        v6++;
                    } else {
                        v0 = v1.getValue();
                        break;
                    }
                }
            }
            v4 = 0;
            if (android.text.TextUtils.isEmpty(v0) == 0) {
                v4 = java.nio.charset.Charset.isSupported(v0);
            }
            if (v4 != 0) {
                v5 = java.nio.charset.Charset.forName(v0);
            }
        }
        return v5;
    }
    public static StackTraceElement getCurrentStackTraceElement()
    {
        return Thread.currentThread().getStackTrace()[3];
    }
    public static String getFileNameFromHttpResponse(org.apache.http.HttpResponse p8)
    {
        if (p8 != 0) {
            v3 = 0;
            v2 = p8.getFirstHeader("Content-Disposition");
            if (v2 != 0) {
                v5 = v2.getElements();
                v6 = v5.length;
                v4 = 0;
                while (v4 < v6) {
                    v1 = v5[v4].getParameterByName("filename");
                    if (v1 == 0) {
                        v4++;
                    } else {
                        v3 = v1.getValue();
                        v3 = com.lidroid.xutils.util.CharsetUtils.toCharset(v3, "UTF-8", v3.length());
                        break;
                    }
                }
            }
        } else {
            v3 = 0;
        }
        return v3;
    }
    public static String getSubString(String p2, int p3, int p4)
    {
        return new String(p2.substring(p3, p4));
    }
    public static boolean isSupportRange(org.apache.http.HttpResponse p4)
    {
        v2 = 0;
        if (p4 != 0) {
            v0 = p4.getFirstHeader("Accept-Ranges");
            if (v0 == 0) {
                v0 = p4.getFirstHeader("Content-Range");
                if (v0 != 0) {
                    v1 = v0.getValue();
                    if ((v1 != 0) && (v1.startsWith("bytes") != 0)) {
                        v2 = 1;
                    }
                }
            } else {
                v2 = "bytes".equals(v0.getValue());
            }
        }
        return v2;
    }
    public static long sizeOfString(String p8, String p9)
    {
        if (android.text.TextUtils.isEmpty(p8) == 0) {
            v2 = p8.length();
            if (v2 >= 100) {
                v3 = 0.0;
                v1 = 0;
                while (v1 < v2) {
                    v0 = (v1 + 100);
                    if (v0 >= v2) {
                        v0 = v2;
                    }
                    v3 += ((long) com.lidroid.xutils.util.OtherUtils.getSubString(p8, v1, v0).getBytes(p9).length);
                    v1 += 100;
                }
            } else {
                v3 = ((long) p8.getBytes(p9).length);
            }
        } else {
            v3 = 0.0;
        }
        return v3;
    }
    public static void trustAllSSLForHttpsURLConnection()
    {
        if (com.lidroid.xutils.util.OtherUtils.trustAllCerts == 0) {
            v2 = new javax.net.ssl.TrustManager[1];
            v2[0] = new com.lidroid.xutils.util.OtherUtils$1();
            com.lidroid.xutils.util.OtherUtils.trustAllCerts = v2;
        }
        v1 = javax.net.ssl.SSLContext.getInstance("TLS");
        v1.init(0, com.lidroid.xutils.util.OtherUtils.trustAllCerts, 0);
        javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(v1.getSocketFactory());
        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        return;
    }
}
