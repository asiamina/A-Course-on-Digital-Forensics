package com.lidroid.xutils.view.annotation.event;
public interface annotation abstract class OnGroupCollapse implements java.lang.annotation.Annotation {
    abstract public int[] parentId();
    abstract public int[] value();
}
