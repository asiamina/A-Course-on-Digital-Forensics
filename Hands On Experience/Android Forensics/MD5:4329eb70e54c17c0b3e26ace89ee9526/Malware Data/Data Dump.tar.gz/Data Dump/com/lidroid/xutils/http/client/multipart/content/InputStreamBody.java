package com.lidroid.xutils.http.client.multipart.content;
public class InputStreamBody extends com.lidroid.xutils.http.client.multipart.content.AbstractContentBody {
    private long length;
    final private java.io.InputStream in;
    final private String filename;
    public InputStreamBody(java.io.InputStream p7, long p8)
    {
        this(p7, p8, v3, "no_name", "application/octet-stream");
        return;
    }
    public InputStreamBody(java.io.InputStream p7, long p8, String p10)
    {
        this(p7, p8, v3, p10, "application/octet-stream");
        return;
    }
    public InputStreamBody(java.io.InputStream p3, long p4, String p6, String p7)
    {
        this(p7);
        if (p3 != 0) {
            this.in = p3;
            this.filename = p6;
            this.length = p4;
            return;
        } else {
            throw new IllegalArgumentException("Input stream may not be null");
        }
    }
    public String getCharset()
    {
        return 0;
    }
    public long getContentLength()
    {
        return this.length;
    }
    public String getFilename()
    {
        return this.filename;
    }
    public java.io.InputStream getInputStream()
    {
        return this.in;
    }
    public String getTransferEncoding()
    {
        return "binary";
    }
    public void writeTo(java.io.OutputStream p8)
    {
        if (p8 != 0) {
            v1 = new byte[4096];
            do {
                v0 = this.in.read(v1);
                if (v0 != -1) {
                    p8.write(v1, 0, v0);
                    v2 = this.callBackInfo;
                    v2.pos = (v2.pos + ((long) v0));
                } else {
                    p8.flush();
                    com.lidroid.xutils.util.IOUtils.closeQuietly(this.in);
                    return;
                }
            } while(this.callBackInfo.doCallBack(0) != 0);
            throw new java.io.InterruptedIOException("stop");
        } else {
            throw new IllegalArgumentException("Output stream may not be null");
        }
    }
}
