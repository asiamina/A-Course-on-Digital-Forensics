package com.lidroid.xutils.bitmap;
 class BitmapGlobalConfig$1 implements java.util.concurrent.ThreadFactory {
    final private java.util.concurrent.atomic.AtomicInteger mCount;
     BitmapGlobalConfig$1()
    {
        this.mCount = new java.util.concurrent.atomic.AtomicInteger(1);
        return;
    }
    public Thread newThread(Runnable p4)
    {
        v0 = new Thread(p4, new StringBuilder("BitmapUtils #").append(this.mCount.getAndIncrement()).toString());
        v0.setPriority(4);
        return v0;
    }
}
