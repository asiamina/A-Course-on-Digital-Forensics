package com.lidroid.xutils.http;
public class ResponseStream extends java.io.InputStream {
    private org.apache.http.HttpResponse baseResponse;
    private String charset;
    private String requestUrl;
    private long expiry;
    private String requestMethod;
    private String _directResult;
    private java.io.InputStream baseStream;
    public ResponseStream(String p3)
    {
        if (p3 != 0) {
            this._directResult = p3;
            return;
        } else {
            throw new IllegalArgumentException("result may not be null");
        }
    }
    public ResponseStream(org.apache.http.HttpResponse p7, String p8, long p9)
    {
        this(p7, "UTF-8", p8, p9, v5);
        return;
    }
    public ResponseStream(org.apache.http.HttpResponse p3, String p4, String p5, long p6)
    {
        if (p3 != 0) {
            this.baseResponse = p3;
            this.baseStream = p3.getEntity().getContent();
            this.charset = p4;
            this.requestUrl = p5;
            this.expiry = p6;
            return;
        } else {
            throw new IllegalArgumentException("baseResponse may not be null");
        }
    }
    public int available()
    {
        if (this.baseStream != 0) {
            v0 = this.baseStream.available();
        } else {
            v0 = 0;
        }
        return v0;
    }
    public void close()
    {
        if (this.baseStream != 0) {
            this.baseStream.close();
        }
        return;
    }
    public org.apache.http.HttpResponse getBaseResponse()
    {
        return this.baseResponse;
    }
    public java.io.InputStream getBaseStream()
    {
        return this.baseStream;
    }
    public java.util.Locale getLocale()
    {
        if (this._directResult == 0) {
            v0 = this.baseResponse.getLocale();
        } else {
            v0 = java.util.Locale.getDefault();
        }
        return v0;
    }
    public String getReasonPhrase()
    {
        if (this._directResult == 0) {
            v0 = this.baseResponse.getStatusLine().getReasonPhrase();
        } else {
            v0 = "";
        }
        return v0;
    }
    public String getRequestMethod()
    {
        return this.requestMethod;
    }
    public String getRequestUrl()
    {
        return this.requestUrl;
    }
    public int getStatusCode()
    {
        if (this._directResult == 0) {
            v0 = this.baseResponse.getStatusLine().getStatusCode();
        } else {
            v0 = 200;
        }
        return v0;
    }
    public void mark(int p2)
    {
        if (this.baseStream != 0) {
            this.baseStream.mark(p2);
        }
        return;
    }
    public boolean markSupported()
    {
        if (this.baseStream != 0) {
            v0 = this.baseStream.markSupported();
        } else {
            v0 = 0;
        }
        return v0;
    }
    public int read()
    {
        if (this.baseStream != 0) {
            v0 = this.baseStream.read();
        } else {
            v0 = -1;
        }
        return v0;
    }
    public int read(byte[] p2)
    {
        if (this.baseStream != 0) {
            v0 = this.baseStream.read(p2);
        } else {
            v0 = -1;
        }
        return v0;
    }
    public int read(byte[] p2, int p3, int p4)
    {
        if (this.baseStream != 0) {
            v0 = this.baseStream.read(p2, p3, p4);
        } else {
            v0 = -1;
        }
        return v0;
    }
    public void readFile(String p8)
    {
        if ((this._directResult == 0) && (this.baseStream != 0)) {
            v4 = new java.io.FileOutputStream(p8);
            v1 = new java.io.BufferedInputStream(this.baseStream);
            v0 = new byte[4096];
            while(true) {
                v2 = v1.read(v0);
                if (v2 == -1) {
                    break;
                }
                v4.write(v0, 0, v2);
            }
            v4.flush();
            com.lidroid.xutils.util.IOUtils.closeQuietly(v4);
            com.lidroid.xutils.util.IOUtils.closeQuietly(this.baseStream);
        }
        return;
    }
    public String readString()
    {
        if (this._directResult == 0) {
            if (this.baseStream != 0) {
                v1 = new java.io.BufferedReader(new java.io.InputStreamReader(this.baseStream, this.charset));
                v2 = new StringBuilder();
                while(true) {
                    v0 = v1.readLine();
                    if (v0 == 0) {
                        break;
                    }
                    v2.append(v0);
                }
                this._directResult = v2.toString();
                if ((this.requestUrl != 0) && (com.lidroid.xutils.HttpUtils.sHttpCache.isEnabled(this.requestMethod) != 0)) {
                    com.lidroid.xutils.HttpUtils.sHttpCache.put(this.requestUrl, this._directResult, this.expiry);
                }
                v3 = this._directResult;
                com.lidroid.xutils.util.IOUtils.closeQuietly(this.baseStream);
            } else {
                v3 = 0;
            }
        } else {
            v3 = this._directResult;
        }
        return v3;
    }
    public synchronized void reset()
    {
        if (this.baseStream != 0) {
            this.baseStream.reset();
        }
        return;
    }
     void setRequestMethod(String p1)
    {
        this.requestMethod = p1;
        return;
    }
    public long skip(long p3)
    {
        if (this.baseStream != 0) {
            v0 = this.baseStream.skip(p3);
        } else {
            v0 = 0.0;
        }
        return v0;
    }
}
