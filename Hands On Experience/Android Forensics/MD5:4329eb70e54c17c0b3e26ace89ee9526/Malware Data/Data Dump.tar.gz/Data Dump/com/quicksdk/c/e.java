package com.quicksdk.c;
final public class e implements com.quicksdk.c.c {
    public String a;
    private int c;
    private int b;
    private android.app.ProgressDialog e;
    private android.app.Activity d;
    private String g;
    private com.quicksdk.c.a f;
    private String i;
    private boolean h;
    private com.quicksdk.c.d j;
    static synthetic void c(com.quicksdk.c.e p0)
    {
        p0.j();
        return;
    }
    static synthetic String d(com.quicksdk.c.e p1)
    {
        return p1.g;
    }
    public final void d()
    {
        this.e.setProgress(0);
        this.j();
        return;
    }
    public final void e()
    {
        this.e.dismiss();
        com.quicksdk.c.b.a(this.d, new java.io.File(this.i, this.a));
        return;
    }
    public final void f()
    {
        com.quicksdk.net.Connect.getInstance().a(this.d, this.j);
        return;
    }
    private void g()
    {
        this.b = com.quicksdk.c.b.a(this.d);
        this.j = new com.quicksdk.c.d(this);
        this.f = new com.quicksdk.c.a(this.d, this.j);
        v1 = new com.quicksdk.c.e$1(this);
        v2 = new android.app.ProgressDialog(this.d);
        v2.setMessage("\u6b63\u5728\u4e0b\u8f7d\u66f4\u65b0");
        v2.setIndeterminate(0);
        v2.setProgressStyle(1);
        v2.setMax(100);
        v2.setProgress(0);
        v2.setProgressNumberFormat("%1d KB/%2d KB");
        v2.setCancelable(0);
        v2.setButton(-2, "\u53d6\u6d88", v1);
        this.e = v2;
        this.i = this.f.d();
        return;
    }
    private void h()
    {
        com.quicksdk.c.b.a(this.d, "\u66f4\u65b0", "\u53d1\u73b0\u65b0\u7248\u672c,\u662f\u5426\u7acb\u5373\u66f4\u65b0\uff1f", "\u66f4\u65b0", new com.quicksdk.c.e$4(this), "\u53d6\u6d88", new com.quicksdk.c.e$5(this)).show();
        return;
    }
    private void i()
    {
        switch (com.quicksdk.utility.AppConfig.getInstance().getNetType()) {
            case 1:
                v0 = 1;
                break;
            default:
                v0 = 0;
        }
        if (v0 == 0) {
            com.quicksdk.c.b.a(this.d, "\u66f4\u65b0", "\u5f53\u524d\u4e3a2G/3G/4G\u7f51\u7edc\uff0c\u662f\u5426\u7ee7\u7eed\u66f4\u65b0\uff1f", "\u66f4\u65b0", new com.quicksdk.c.e$6(this), "\u53d6\u6d88", new com.quicksdk.c.e$7(this)).show();
        } else {
            this.f.a(this.g, this.a);
        }
        return;
    }
    private void j()
    {
        if (!this.h) {
            com.quicksdk.User.getInstance().doLogin(this.d);
        } else {
            if (com.quicksdk.QuickSDK.getInstance().getExitNotifier() != 0) {
                com.quicksdk.QuickSDK.getInstance().getExitNotifier().onSuccess();
            }
        }
        return;
    }
    private static boolean k()
    {
        switch (com.quicksdk.utility.AppConfig.getInstance().getNetType()) {
            case 1:
                v0 = 1;
                break;
            default:
                v0 = 0;
        }
        return v0;
    }
    public e(android.app.Activity p6)
    {
        this.b = 1;
        this.c = 1;
        this.g = "";
        this.a = "";
        this.h = 0;
        this.i = "";
        this.d = p6;
        this.b = com.quicksdk.c.b.a(this.d);
        this.j = new com.quicksdk.c.d(this);
        this.f = new com.quicksdk.c.a(this.d, this.j);
        v1 = new com.quicksdk.c.e$1(this);
        v2 = new android.app.ProgressDialog(this.d);
        v2.setMessage("\u6b63\u5728\u4e0b\u8f7d\u66f4\u65b0");
        v2.setIndeterminate(0);
        v2.setProgressStyle(1);
        v2.setMax(100);
        v2.setProgress(0);
        v2.setProgressNumberFormat("%1d KB/%2d KB");
        v2.setCancelable(0);
        v2.setButton(-2, "\u53d6\u6d88", v1);
        this.e = v2;
        this.i = this.f.d();
        return;
    }
    static synthetic com.quicksdk.c.a a(com.quicksdk.c.e p1)
    {
        return p1.f;
    }
    public final void a()
    {
        if (this.e != 0) {
            this.e.setMax(this.f.c());
            this.e.show();
        }
        return;
    }
    public final void a(com.quicksdk.entity.b p9)
    {
        this.c = p9.a();
        this.g = p9.c();
        this.a = new StringBuilder(String.valueOf(p9.d())).append(".apk").toString();
        this.h = p9.b();
        if (this.b < this.c) {
            android.util.Log.e("base", "\u5224\u65ad\u672c\u5730\u662f\u5426\u6709\u6700\u65b0\u5305\uff0c\u6ca1\u6709\u5219\u4e0b\u8f7d\uff0c\u6709\u5c31\u5b89\u88c5");
            v7 = new java.io.File(this.i, this.a);
            if (v7.exists() == 0) {
                com.quicksdk.c.b.a(this.d, "\u66f4\u65b0", "\u53d1\u73b0\u65b0\u7248\u672c,\u662f\u5426\u7acb\u5373\u66f4\u65b0\uff1f", "\u66f4\u65b0", new com.quicksdk.c.e$4(this), "\u53d6\u6d88", new com.quicksdk.c.e$5(this)).show();
            } else {
                com.quicksdk.c.b.a(this.d, v7);
            }
        } else {
            android.util.Log.e("base", "versionCode >= updateVersionCode");
            com.quicksdk.User.getInstance().doLogin(this.d);
        }
        return;
    }
    public final void b()
    {
        if ((this.e != 0) && (this.e.isShowing() != 0)) {
            this.e.setProgress(this.f.b());
        }
        return;
    }
    static synthetic void b(com.quicksdk.c.e p7)
    {
        switch (com.quicksdk.utility.AppConfig.getInstance().getNetType()) {
            case 1:
                v0 = 1;
                break;
            default:
                v0 = 0;
        }
        if (v0 == 0) {
            com.quicksdk.c.b.a(p7.d, "\u66f4\u65b0", "\u5f53\u524d\u4e3a2G/3G/4G\u7f51\u7edc\uff0c\u662f\u5426\u7ee7\u7eed\u66f4\u65b0\uff1f", "\u66f4\u65b0", new com.quicksdk.c.e$6(p7), "\u53d6\u6d88", new com.quicksdk.c.e$7(p7)).show();
        } else {
            p7.f.a(p7.g, p7.a);
        }
        return;
    }
    public final void c()
    {
        this.e.dismiss();
        com.quicksdk.c.b.a(this.d, "\u9519\u8bef", "\u4e0b\u8f7d\u66f4\u65b0\u5931\u8d25\uff0c\u662f\u5426\u91cd\u8bd5\uff1f", "\u91cd\u65b0\u4e0b\u8f7d", new com.quicksdk.c.e$2(this), "\u53d6\u6d88", new com.quicksdk.c.e$3(this)).show();
        return;
    }
}
