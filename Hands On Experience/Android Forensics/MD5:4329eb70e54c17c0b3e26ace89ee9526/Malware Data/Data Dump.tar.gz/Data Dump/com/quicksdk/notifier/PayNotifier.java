package com.quicksdk.notifier;
public interface abstract class PayNotifier {
    abstract public void onCancel();
    abstract public void onFailed();
    abstract public void onSuccess();
}
