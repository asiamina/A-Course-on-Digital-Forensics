package com.quicksdk.net;
final class Connect$11 implements java.lang.Runnable {
    final synthetic com.quicksdk.net.Connect a;
    final private synthetic android.os.Handler c;
    final private synthetic android.content.Context b;
     Connect$11(com.quicksdk.net.Connect p1, android.content.Context p2, android.os.Handler p3)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        return;
    }
    public final void run()
    {
        v5 = com.quicksdk.net.Connect.b(this.a).c(this.b);
        if (v5.getResult() == 0) {
            v2 = "\u672a\u77e5\u9519\u8bef";
            v1 = "-1";
            if (v5.getError() != 0) {
                v2 = v5.getError().optString("message");
                v1 = v5.getError().optString("id");
            }
            v4 = this.c.obtainMessage();
            v4.what = 0;
            this.c.sendMessage(v4);
            android.util.Log.e(com.quicksdk.net.Connect.a(), new StringBuilder("gdu failed, code = ").append(v1).append(", error = ").append(v2).toString());
        } else {
            v0 = new android.os.Bundle();
            v6 = v5.getData().toString();
            v0.putString("users", v6);
            android.util.Log.d(com.quicksdk.net.Connect.a(), new StringBuilder("gdu ret = ").append(v6).toString());
            v4 = this.c.obtainMessage();
            v4.setData(v0);
            v4.what = 1;
            this.c.sendMessage(v4);
        }
        return;
    }
}
