package com.quicksdk.ex;
public class a {
    final private static String a;
    private android.content.Context c;
    private static volatile com.quicksdk.ex.a b;
    private static String e;
    final private static String d;
    private static String b(android.content.Context p3)
    {
        return new StringBuilder(String.valueOf(p3.getSystemService("phone").getDeviceId())).append("_qSdk_ex.log").toString();
    }
    public final void b()
    {
        com.quicksdk.utility.i.a("BaseLib ExFs", "=>cleanLogFile");
        v2 = new java.io.BufferedWriter(new java.io.FileWriter(new java.io.File(new java.io.File(com.quicksdk.ex.a.e), com.quicksdk.ex.a.b(this.c))));
        v2.write("");
        v2.close();
        return;
    }
    public final String c()
    {
        com.quicksdk.utility.i.a("BaseLib ExFs", "getLogFileContent");
        v1 = "";
        v3 = this.a();
        if (v3 != 0) {
            com.quicksdk.utility.i.a("BaseLib ExFs", new StringBuilder("getLogFileContent...file path:").append(v3.getPath()).toString());
            v5 = new java.io.FileInputStream(v3);
            com.quicksdk.utility.i.a("BaseLib ExFs", "getLogFileContent...if (instream != null)");
            v0 = new java.io.BufferedReader(new java.io.InputStreamReader(v5));
            while(true) {
                v6 = v0.readLine();
                if (v6 == 0) {
                    break;
                }
                v1 = new StringBuilder(String.valueOf(v1)).append(v6).append("\n").toString();
            }
            v5.close();
            v0.close();
            com.quicksdk.utility.i.a("BaseLib ExFs", new StringBuilder("getLogFileContent content:").append(v1).toString());
        }
        return v1;
    }
    static a()
    {
        com.quicksdk.ex.a.e = "";
        return;
    }
    private a(android.content.Context p2)
    {
        this.c = 0;
        this.c = p2.getApplicationContext();
        return;
    }
    public static com.quicksdk.ex.a a(android.content.Context p3)
    {
        if ((com.quicksdk.ex.a.b != 0) || (com.quicksdk.ex.a.b != 0)) {
            v0 = com.quicksdk.ex.a.b;
        } else {
            if (p3 != 0) {
                com.quicksdk.ex.a.b = new com.quicksdk.ex.a(p3);
                com.quicksdk.ex.a.e = new StringBuilder(String.valueOf(p3.getFilesDir().getPath())).append("/log").toString();
            } else {
                android.util.Log.e("BaseLib ExFs", "Context is null");
                v0 = 0;
            }
        }
        return v0;
    }
    public final java.io.File a()
    {
        v0 = new java.io.File(com.quicksdk.ex.a.e);
        if (v0.exists() == 0) {
            v0.mkdirs();
        }
        v2 = new java.io.File(v0, com.quicksdk.ex.a.b(this.c));
        if (v2.exists() == 0) {
            v2.createNewFile();
        }
        return v2;
    }
    private Boolean a(Throwable p16)
    {
        com.quicksdk.utility.i.a("BaseLib ExFs", "isExStoredInLog");
        v6 = Boolean.valueOf(0);
        v1 = this.a();
        if (v1 != 0) {
            v5 = new java.io.FileInputStream(v1);
            com.quicksdk.utility.i.a("BaseLib ExFs", "isExStoredInLog...if (instream != null)");
            v0 = new java.io.BufferedReader(new java.io.InputStreamReader(v5));
            v2 = new StringBuilder();
            do {
                v7 = v0.readLine();
                if (v7 != 0) {
                    v2.append(v7);
                    v2.append("\n");
                    if (v7.contains("eTrace") != 0) {
                        v10 = "";
                        while(true) {
                            v7 = v0.readLine();
                            if (v7 == 0) {
                                break;
                            }
                            v2.append(v7);
                            v2.append("\n");
                            if (v7.equals("}") != 0) {
                                break;
                            }
                            v10 = new StringBuilder(String.valueOf(v10)).append(v7).append("\n").toString();
                        }
                        v11 = com.quicksdk.ex.ExUtils.a(p16).split("\n");
                        v12 = v10.split("\n");
                        if ((v11[0].equals(v12[0]) == 0) || ((v11[1].equals(v12[1]) == 0) || (v11[2].equals(v12[2]) == 0))) {
                            v11 = Boolean.valueOf(0);
                        } else {
                            v11 = Boolean.valueOf(1);
                        }
                    }
                } else {
                    v5.close();
                    v0.close();
                    if (v6.booleanValue() != 0) {
                        v9 = new java.io.BufferedWriter(new java.io.FileWriter(v1));
                        v9.write(v2.toString());
                        v9.close();
                    }
                }
            } while(v11.booleanValue() == 0);
            com.quicksdk.utility.i.a("BaseLib ExFs", "isExStoredInLog..if isExEqualWithLogETrace");
            v7 = v0.readLine();
            v8 = Integer.parseInt(v7.substring((v7.indexOf(":") + 1), v7.length()));
            v2.append(v7.replace(String.valueOf(v8), String.valueOf((v8 + 1))));
            v2.append("\n");
            v6 = Boolean.valueOf(1);
        }
        return v6;
    }
    private static Boolean a(Throwable p7, String p8)
    {
        v0 = com.quicksdk.ex.ExUtils.a(p7).split("\n");
        v1 = p8.split("\n");
        if ((v0[0].equals(v1[0]) == 0) || ((v0[1].equals(v1[1]) == 0) || (v0[2].equals(v1[2]) == 0))) {
            v2 = Boolean.valueOf(0);
        } else {
            v2 = Boolean.valueOf(1);
        }
        return v2;
    }
    private String a(String p12)
    {
        com.quicksdk.utility.i.a("BaseLib ExFs", "getLogItemValue");
        v2 = this.a();
        if (v2 == 0) {
            com.quicksdk.utility.i.a("BaseLib ExFs", "getLogItemValue...return empty");
            v5 = "";
        } else {
            v4 = new java.io.FileInputStream(v2);
            v0 = new java.io.BufferedReader(new java.io.InputStreamReader(v4));
            while(true) {
                v6 = v0.readLine();
                if (v6 != 0) {
                    if (v6.contains(p12) != 0) {
                        if (p12.equals("eTrace") != 0) {
                            v1 = "";
                            while(true) {
                                v7 = v0.readLine();
                                if (v7 == 0) {
                                    break;
                                }
                                if (v7.equals("}") != 0) {
                                    v4.close();
                                    v0.close();
                                    com.quicksdk.utility.i.a("BaseLib ExFs", new StringBuilder("getLogItemValue...").append(p12).append(":").append(v1).toString());
                                    v5 = v1;
                                } else {
                                    v1 = new StringBuilder(String.valueOf(v1)).append(v7).append("\n").toString();
                                }
                            }
                        } else {
                            v5 = v6.substring((v6.indexOf(":") + 1), v6.length());
                            v4.close();
                            v0.close();
                            com.quicksdk.utility.i.a("BaseLib ExFs", new StringBuilder("getLogItemValue...").append(p12).append(":").append(v5).toString());
                        }
                    }
                } else {
                    v4.close();
                    v0.close();
                }
            }
        }
        return v5;
    }
    private void a(java.util.ArrayList p10)
    {
        com.quicksdk.utility.i.a("BaseLib ExFs", "initExInfoListFromLog");
        v2 = this.a();
        if (v2 != 0) {
            v4 = new java.io.FileInputStream(v2);
            v0 = new java.io.BufferedReader(new java.io.InputStreamReader(v4));
            v1 = 0;
            while(true) {
                v5 = v0.readLine();
                if (v5 != 0) {
                    if (v5.startsWith("=") == 0) {
                        if (v5.startsWith("uid") == 0) {
                            if (v5.startsWith("user_name") == 0) {
                                if (v5.startsWith("roleName") == 0) {
                                    if (v5.startsWith("eType") == 0) {
                                        if (v5.startsWith("eTrace") == 0) {
                                            break;
                                        }
                                        if (v1 != 0) {
                                            v6 = "";
                                            while(true) {
                                                v5 = v0.readLine();
                                                if ((v5 == 0) || (v5.equals("}") != 0)) {
                                                    break;
                                                }
                                                v6 = new StringBuilder(String.valueOf(v6)).append(v5).append("\n").toString();
                                            }
                                            v1.e(v6);
                                        }
                                    } else {
                                        if (v1 != 0) {
                                            v1.d(v5.substring((v5.indexOf(":") + 1), v5.length()));
                                        }
                                    }
                                } else {
                                    if (v1 != 0) {
                                        v1.c(v5.substring((v5.indexOf(":") + 1), v5.length()));
                                    }
                                }
                            } else {
                                if (v1 != 0) {
                                    v1.b(v5.substring((v5.indexOf(":") + 1), v5.length()));
                                }
                            }
                        } else {
                            v1 = new com.quicksdk.entity.a();
                            v1.a(v5.substring((v5.indexOf(":") + 1), v5.length()));
                        }
                    }
                } else {
                    v4.close();
                    v0.close();
                }
            }
            if (v5.startsWith("eNum") == 0) {
                if (v5.startsWith("crashMem") == 0) {
                    if (v5.startsWith("crashNode") == 0) {
                        if (v5.startsWith("totalMem") == 0) {
                            if (v5.startsWith("cpuName") == 0) {
                                if (v5.startsWith("isCrash") == 0) {
                                    if (v5.startsWith("sdMem") == 0) {
                                        if ((v5.startsWith("sdAvailableMem") != 0) && (v1 != 0)) {
                                            v1.m(v5.substring((v5.indexOf(":") + 1), v5.length()));
                                            p10.add(v1);
                                            v1 = 0;
                                        }
                                    } else {
                                        if (v1 != 0) {
                                            v1.l(v5.substring((v5.indexOf(":") + 1), v5.length()));
                                        }
                                    }
                                } else {
                                    if (v1 != 0) {
                                        v1.k(v5.substring((v5.indexOf(":") + 1), v5.length()));
                                    }
                                }
                            } else {
                                if (v1 != 0) {
                                    v1.j(v5.substring((v5.indexOf(":") + 1), v5.length()));
                                }
                            }
                        } else {
                            if (v1 != 0) {
                                v1.i(v5.substring((v5.indexOf(":") + 1), v5.length()));
                            }
                        }
                    } else {
                        if (v1 != 0) {
                            v1.h(v5.substring((v5.indexOf(":") + 1), v5.length()));
                        }
                    }
                } else {
                    if (v1 != 0) {
                        v1.g(v5.substring((v5.indexOf(":") + 1), v5.length()));
                    }
                }
            } else {
                if (v1 != 0) {
                    v1.f(v5.substring((v5.indexOf(":") + 1), v5.length()));
                }
            }
        }
        return;
    }
    public final boolean a(String p12, String p13, String p14, Throwable p15, String p16)
    {
        com.quicksdk.utility.i.a("BaseLib ExFs", "saveExLog2Internal");
        this.a(p15);
        if (this.booleanValue() != 0) {
            com.quicksdk.utility.i.a("BaseLib ExFs", "saveExLog2Internal...else ex already exist");
        } else {
            com.quicksdk.utility.i.a("BaseLib ExFs", "saveExLog2Internal...if append ex to log file");
            v9 = this.a();
            v10 = com.quicksdk.ex.ExUtils.a(this.c, p12, p13, p14, p15, "1", p16);
            v8 = new java.io.FileOutputStream(v9, 1);
            v8.write(v10.getBytes("UTF-8"));
            v8.close();
        }
        com.quicksdk.ex.ExCollector.a();
        return 1;
    }
}
