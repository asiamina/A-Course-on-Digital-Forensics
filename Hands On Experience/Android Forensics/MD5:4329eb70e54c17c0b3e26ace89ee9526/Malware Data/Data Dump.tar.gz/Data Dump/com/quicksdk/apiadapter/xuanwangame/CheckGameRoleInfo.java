package com.quicksdk.apiadapter.xuanwangame;
public class CheckGameRoleInfo {
    private static String a;
    private static String c;
    private static com.quicksdk.entity.GameRoleInfo b;
    private static String e;
    private static String d;
    private static String g;
    private static String f;
    public static void setGameRoleInfo(com.quicksdk.entity.GameRoleInfo p2)
    {
        android.util.Log.d(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "CheckGameRoleInfo setGameRoleInfo");
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b = p2;
        return;
    }
    static CheckGameRoleInfo()
    {
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a = com.quicksdk.apiadapter.xuanwangame.ActivityAdapter.a;
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b = 0;
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.c = "undefine";
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.d = "9999";
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.e = "undefine";
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.f = "1";
        com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g = "null";
        return;
    }
    public CheckGameRoleInfo()
    {
        return;
    }
    public static String getGameBalance()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getGameBalance();
            if ((v0 == 0) || ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) != 0) || (android.text.TextUtils.isEmpty(v0) != 0))) {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("gameBalance error, value = ").append(v0).toString());
                v0 = "0";
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getGameBalance but not call setGameRoleInfo error");
            v0 = "0";
        }
        return v0;
    }
    public static String getGameRoleID()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getGameRoleID();
            if ((v0 != 0) && ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) == 0) && (android.text.TextUtils.isEmpty(v0) == 0))) {
                com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.f = v0;
            } else {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("gameRoleID error, value = ").append(v0).toString());
                v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.f;
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getGameRoleID but not call setGameRoleInfo error");
            v0 = "gameRoleId";
        }
        return v0;
    }
    public static String getGameRoleLevel()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getGameRoleLevel();
            if ((v0 == 0) || ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) != 0) || (android.text.TextUtils.isEmpty(v0) != 0))) {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("gameRoleLevel error, value = ").append(v0).toString());
                v0 = "0";
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getGameRoleLevel but not call setGameRoleInfo error");
            v0 = "0";
        }
        return v0;
    }
    public static String getGameRoleName()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getGameRoleName();
            if ((v0 != 0) && ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) == 0) && (android.text.TextUtils.isEmpty(v0) == 0))) {
                com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.e = v0;
            } else {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("gameRoleName error, value = ").append(v0).toString());
                v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.e;
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getGameRoleName but not call setGameRoleInfo error");
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.e;
        }
        return v0;
    }
    public static String getPartyName()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getPartyName();
            if ((v0 == 0) || ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) != 0) || (android.text.TextUtils.isEmpty(v0) != 0))) {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("partyName error, value = ").append(v0).toString());
                v0 = "";
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getPartyName but not call setGameRoleInfo error");
            v0 = "";
        }
        return v0;
    }
    public static String getServerID()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getServerID();
            if ((v0 != 0) && ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) == 0) && (android.text.TextUtils.isEmpty(v0) == 0))) {
                com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.d = v0;
            } else {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("serverID error, value = ").append(v0).toString());
                v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.d;
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getServerID but not call setGameRoleInfo error");
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.d;
        }
        return v0;
    }
    public static String getServerName()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getServerName();
            if ((v0 != 0) && ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) == 0) && (android.text.TextUtils.isEmpty(v0) == 0))) {
                com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.c = v0;
            } else {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("serverName error, value = ").append(v0).toString());
                v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.c;
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getServerName but not call setGameRoleInfo error");
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.c;
        }
        return v0;
    }
    public static String getVipLevel()
    {
        if (com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b != 0) {
            v0 = com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.b.getVipLevel();
            if ((v0 == 0) || ((v0.equalsIgnoreCase(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.g) != 0) || (android.text.TextUtils.isEmpty(v0) != 0))) {
                android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, new StringBuilder("vipLevel error, value = ").append(v0).toString());
                v0 = "0";
            }
        } else {
            android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.CheckGameRoleInfo.a, "getVipLevel but not call setGameRoleInfo error");
            v0 = "0";
        }
        return v0;
    }
}
