package com.quicksdk.apiadapter.undefined.a;
final public class w {
    public w()
    {
        return;
    }
    public static android.widget.Toast a(android.content.Context p4, String p5)
    {
        v1 = new android.widget.Toast(p4);
        v0 = new com.quicksdk.apiadapter.undefined.a.x(p4);
        v1.setGravity(17, 0, 0);
        v1.setDuration(1);
        v0.setText(p5);
        v1.setView(v0);
        return v1;
    }
}
