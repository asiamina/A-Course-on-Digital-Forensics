package com.quicksdk.notifier;
public interface abstract class g {
    abstract public void a();
    abstract public void b();
}
