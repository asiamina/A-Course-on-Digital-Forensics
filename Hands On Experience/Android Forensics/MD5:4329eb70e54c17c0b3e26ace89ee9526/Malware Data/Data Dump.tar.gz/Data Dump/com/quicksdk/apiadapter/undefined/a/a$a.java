package com.quicksdk.apiadapter.undefined.a;
final class a$a extends android.widget.ListView {
    final synthetic com.quicksdk.apiadapter.undefined.a.a a;
    private com.quicksdk.apiadapter.undefined.a.k b;
    public a$a(com.quicksdk.apiadapter.undefined.a.a p3, android.content.Context p4)
    {
        this.a = p3;
        this(p4);
        this.b = new com.quicksdk.apiadapter.undefined.a.k(p4);
        this.setDivider(new android.graphics.drawable.ColorDrawable(nan));
        this.setDividerHeight(this.b.a(0.5));
        return;
    }
}
