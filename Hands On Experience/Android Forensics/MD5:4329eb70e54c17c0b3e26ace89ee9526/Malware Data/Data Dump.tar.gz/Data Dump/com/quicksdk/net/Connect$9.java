package com.quicksdk.net;
final class Connect$9 implements java.lang.Runnable {
    final synthetic com.quicksdk.net.Connect a;
    final private synthetic android.os.Handler c;
    final private synthetic android.content.Context b;
    public final void run()
    {
        v7 = com.quicksdk.net.Connect.b(this.a).b(this.b);
        if (v7.getResult() == 0) {
            v2 = "\u672a\u77e5\u9519\u8bef";
            v1 = "-1";
            if (v7.getError() != 0) {
                v2 = v7.getError().optString("message");
                v1 = v7.getError().optString("id");
            }
            android.util.Log.e(com.quicksdk.net.Connect.a(), new StringBuilder("cv failed, code = ").append(v1).append(", error = ").append(v2).toString());
        } else {
            v0 = new android.os.Bundle();
            v5 = v7.getData();
            v9 = v5.optString("versionCode");
            v10 = v5.optString("versionName");
            v11 = v5.optString("versionUrl");
            v8 = v5.optString("updateTime");
            v4 = v5.optString("isMust");
            v0.putString("versionCode", v9);
            v0.putString("versionName", v10);
            v0.putString("versionUrl", v11);
            v0.putString("updateTime", v8);
            v0.putString("isMust", v4);
            if (this.c != 0) {
                v6 = this.c.obtainMessage();
                v6.what = 1;
                v6.setData(v0);
                this.c.sendMessage(v6);
            }
        }
        com.quicksdk.net.Connect.a(this.a).sendEmptyMessage(10);
        return;
    }
     Connect$9(com.quicksdk.net.Connect p1, android.content.Context p2, android.os.Handler p3)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        return;
    }
}
