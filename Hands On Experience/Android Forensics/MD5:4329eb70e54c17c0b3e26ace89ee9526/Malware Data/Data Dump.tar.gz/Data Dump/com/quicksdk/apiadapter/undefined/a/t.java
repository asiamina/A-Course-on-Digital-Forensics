package com.quicksdk.apiadapter.undefined.a;
final public class t extends com.quicksdk.apiadapter.undefined.a.f {
    private com.quicksdk.apiadapter.undefined.a.k i;
    private android.content.Context j;
    public t(android.content.Context p13)
    {
        this(p13);
        this.j = p13;
        this.i = new com.quicksdk.apiadapter.undefined.a.k(p13);
        this.addView(this.a("\u63a5\u5165\u8981\u6c42"));
        this.addView(this.b("\u4e3a\u4e86\u4fdd\u8bc1\u6240\u6709\u6e20\u9053\u80fd\u591f\u6b63\u5e38\u7684\u663e\u793a\u652f\u4ed8\u4fe1\u606f\uff0c\u6e38\u620f\u5e94\u4ee5\u5982\u4e0b\u65b9\u5f0f\u4f20\u503c\uff1a"));
        v8 = new android.widget.LinearLayout(this.j);
        v8.setLayoutParams(this.i.a(-1, -2, 20, 2, 20, 10));
        v8.setOrientation(0);
        v8.setPadding(this.i.a(4.0), this.i.a(4.0), this.i.a(4.0), this.i.a(4.0));
        v0 = new android.widget.TextView(this.j);
        v3 = this.i.a(-1, -2);
        v3.weight = 1.0;
        v0.setLayoutParams(v3);
        v0.setTextColor(android.graphics.Color.parseColor("#787878"));
        v0.setTextSize(12.0);
        v0.setText("\u94bb\u77f3\u7c7b\n\u5546\u54c1\uff1a60\u94bb\u77f3(6\u5143)\naccout=60\ngoodsName=\u94bb\u77f3\namount=6.0");
        v8.addView(v0);
        v0 = new android.widget.TextView(this.j);
        v1 = this.i.a(-1, -2);
        v1.weight = 1.0;
        v0.setLayoutParams(v1);
        v0.setTextColor(android.graphics.Color.parseColor("#787878"));
        v0.setTextSize(12.0);
        v0.setText("\u6708\u5361\u7c7b\n\u5546\u54c1\uff1a\u6708\u5361(30\u5143)\naccout=1\ngoodsName=\u6708\u5361\namount=30.0");
        v8.addView(v0);
        this.addView(v8);
        return;
    }
    public final android.widget.LinearLayout$LayoutParams a()
    {
        return this.i.a(300, -2);
    }
    private android.widget.LinearLayout b()
    {
        v9 = new android.widget.LinearLayout(this.j);
        v9.setLayoutParams(this.i.a(-1, -2, 20, 2, 20, 10));
        v9.setOrientation(0);
        v9.setPadding(this.i.a(4.0), this.i.a(4.0), this.i.a(4.0), this.i.a(4.0));
        v8 = new android.widget.TextView(this.j);
        v10 = this.i.a(-1, -2);
        v10.weight = 1.0;
        v8.setLayoutParams(v10);
        v8.setTextColor(android.graphics.Color.parseColor("#787878"));
        v8.setTextSize(12.0);
        v8.setText("\u94bb\u77f3\u7c7b\n\u5546\u54c1\uff1a60\u94bb\u77f3(6\u5143)\naccout=60\ngoodsName=\u94bb\u77f3\namount=6.0");
        v9.addView(v8);
        v7 = new android.widget.TextView(this.j);
        v11 = this.i.a(-1, -2);
        v11.weight = 1.0;
        v7.setLayoutParams(v11);
        v7.setTextColor(android.graphics.Color.parseColor("#787878"));
        v7.setTextSize(12.0);
        v7.setText("\u6708\u5361\u7c7b\n\u5546\u54c1\uff1a\u6708\u5361(30\u5143)\naccout=1\ngoodsName=\u6708\u5361\namount=30.0");
        v9.addView(v7);
        return v9;
    }
}
