package com.quicksdk.entity;
public class ShareInfo {
    private String a;
    private String c;
    private String b;
    private String e;
    private String d;
    private String g;
    private String f;
    private String h;
    public ShareInfo()
    {
        return;
    }
    public String getContent()
    {
        return this.b;
    }
    public String getExtenal()
    {
        return this.h;
    }
    public String getImgPath()
    {
        return this.c;
    }
    public String getImgUrl()
    {
        return this.d;
    }
    public String getShareTo()
    {
        return this.g;
    }
    public String getTitle()
    {
        return this.a;
    }
    public String getType()
    {
        return this.f;
    }
    public String getUrl()
    {
        return this.e;
    }
    public void setContent(String p1)
    {
        this.b = p1;
        return;
    }
    public void setExtenal(String p1)
    {
        this.h = p1;
        return;
    }
    public void setImgPath(String p1)
    {
        this.c = p1;
        return;
    }
    public void setImgUrl(String p1)
    {
        this.d = p1;
        return;
    }
    public void setShareTo(String p1)
    {
        this.g = p1;
        return;
    }
    public void setTitle(String p1)
    {
        this.a = p1;
        return;
    }
    public void setType(String p1)
    {
        this.f = p1;
        return;
    }
    public void setUrl(String p1)
    {
        this.e = p1;
        return;
    }
}
