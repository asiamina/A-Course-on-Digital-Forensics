package com.quicksdk.ex;
public class ExUtils {
    final private static String a;
    public ExUtils()
    {
        return;
    }
    public static String a(android.content.Context p5, String p6, String p7, String p8, Throwable p9, String p10, String p11)
    {
        v0 = new StringBuilder("{").append("\r\n").append(com.quicksdk.ex.ExUtils.a(p9)).append("}").append("\r\n").toString();
        v2 = new StringBuilder();
        v2.append("=begin").append("\r\n");
        v2.append(new StringBuilder("uid:").append(p6).toString()).append("\r\n");
        v2.append(new StringBuilder("user_name:").append(p7).toString()).append("\r\n");
        v2.append(new StringBuilder("roleName:").append(p8).toString()).append("\r\n");
        v2.append(new StringBuilder("eType:").append(p9.toString()).toString()).append("\r\n");
        v2.append(new StringBuilder("eTrace:").append(v0).toString());
        v2.append(new StringBuilder("eNum:").append(p10).toString()).append("\r\n");
        v2.append(new StringBuilder("crashMem:").append(com.quicksdk.utility.f.a(p5).l()).toString()).append("\r\n");
        v2.append(new StringBuilder("crashNode:").append(p11).toString()).append("\r\n");
        v2.append(new StringBuilder("totalMem:").append(com.quicksdk.utility.f.a(p5).k()).toString()).append("\r\n");
        v2.append(new StringBuilder("cpuName:").append(com.quicksdk.utility.f.a(p5).j()).toString()).append("\r\n");
        v2.append("isCrash:false").append("\r\n");
        v2.append("=end").append("\r\n").append("\r\n");
        return v2.toString();
    }
    public static String a(Throwable p3)
    {
        v1 = new java.io.StringWriter();
        p3.printStackTrace(new java.io.PrintWriter(v1));
        return v1.toString();
    }
    public static void printThrowableInfo(Throwable p4)
    {
        android.util.Log.e("BaseLib ExU", "====printThrowableInfo begin====");
        v1 = new java.io.StringWriter();
        p4.printStackTrace(new java.io.PrintWriter(v1));
        android.util.Log.e("BaseLib ExU", v1.toString());
        android.util.Log.e("BaseLib ExU", "====printThrowableInfo end====");
        return;
    }
}
