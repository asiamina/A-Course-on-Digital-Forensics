package com.quicksdk.apiadapter.undefined.a;
final public class c extends android.widget.LinearLayout {
    final public static int a;
    private android.content.Context c;
    final public static int b;
    private android.widget.TextView e;
    private com.quicksdk.apiadapter.undefined.a.k d;
    private android.widget.TextView f;
    private static android.graphics.drawable.Drawable b()
    {
        v3 = android.graphics.Color.parseColor("#EAEAEA");
        v4 = android.graphics.Color.parseColor("#F2F2F2");
        v1 = new android.graphics.drawable.GradientDrawable();
        v1.setColor(v3);
        v2 = new android.graphics.drawable.GradientDrawable();
        v2.setColor(v4);
        v0 = new android.graphics.drawable.StateListDrawable();
        v5 = new int[1];
        v5[0] = 2.3694026042448817e-38;
        v0.addState(v5, v1);
        v5 = new int[1];
        v5[0] = -1.6947496715221809e+38;
        v0.addState(v5, v2);
        return v0;
    }
    public c(android.content.Context p12)
    {
        this(p12);
        this.d = new com.quicksdk.apiadapter.undefined.a.k(p12);
        this.setOrientation(1);
        this.setLayoutParams(new android.widget.AbsListView$LayoutParams(-1, -1));
        v1 = android.graphics.Color.parseColor("#EAEAEA");
        v2 = android.graphics.Color.parseColor("#F2F2F2");
        v3 = new android.graphics.drawable.GradientDrawable();
        v3.setColor(v1);
        v1 = new android.graphics.drawable.GradientDrawable();
        v1.setColor(v2);
        v2 = new android.graphics.drawable.StateListDrawable();
        v4 = new int[1];
        v4[0] = 2.3694026042448817e-38;
        v2.addState(v4, v3);
        v3 = new int[1];
        v3[0] = -1.6947496715221809e+38;
        v2.addState(v3, v1);
        this.setBackgroundDrawable(v2);
        this.setPadding(this.d.a(6.0), this.d.a(6.0), this.d.a(6.0), this.d.a(6.0));
        this.c = p12;
        this.e = new android.widget.TextView(this.c);
        this.e.setId(1000);
        v1 = new android.widget.AbsListView$LayoutParams(-1, -2);
        this.e.setLayoutParams(v1);
        this.e.setText("");
        this.e.setTextColor(android.graphics.Color.parseColor("#1E1E1E"));
        this.e.setTextSize(14.0);
        this.f = new android.widget.TextView(this.c);
        this.f.setId(1001);
        this.f.setPadding(0, this.d.a(2.0), 0, 0);
        this.f.setLayoutParams(v1);
        this.f.setText("");
        this.f.setLineSpacing(1.0, 1.0);
        this.f.setTextColor(android.graphics.Color.parseColor("#787878"));
        this.f.setTextSize(10.0);
        this.addView(this.e);
        this.addView(this.f);
        return;
    }
    private void a()
    {
        this.e = new android.widget.TextView(this.c);
        this.e.setId(1000);
        v0 = new android.widget.AbsListView$LayoutParams(-1, -2);
        this.e.setLayoutParams(v0);
        this.e.setText("");
        this.e.setTextColor(android.graphics.Color.parseColor("#1E1E1E"));
        this.e.setTextSize(14.0);
        this.f = new android.widget.TextView(this.c);
        this.f.setId(1001);
        this.f.setPadding(0, this.d.a(2.0), 0, 0);
        this.f.setLayoutParams(v0);
        this.f.setText("");
        this.f.setLineSpacing(1.0, 1.0);
        this.f.setTextColor(android.graphics.Color.parseColor("#787878"));
        this.f.setTextSize(10.0);
        this.addView(this.e);
        this.addView(this.f);
        return;
    }
}
