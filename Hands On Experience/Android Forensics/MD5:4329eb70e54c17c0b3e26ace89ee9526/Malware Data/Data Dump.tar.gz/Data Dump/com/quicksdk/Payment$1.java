package com.quicksdk;
 class Payment$1 implements com.quicksdk.notifier.PayNotifier {
    final synthetic com.quicksdk.Payment a;
    final private synthetic com.quicksdk.entity.UserInfo c;
    final private synthetic android.app.Activity b;
    final private synthetic com.quicksdk.entity.GameRoleInfo e;
    final private synthetic com.quicksdk.entity.OrderInfo d;
     Payment$1(com.quicksdk.Payment p1, android.app.Activity p2, com.quicksdk.entity.UserInfo p3, com.quicksdk.entity.OrderInfo p4, com.quicksdk.entity.GameRoleInfo p5)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        this.e = p5;
        return;
    }
    public void onCancel(String p4)
    {
        android.util.Log.d("BaseLib.Payment", "qk pay cancel");
        com.quicksdk.utility.l.a(this.b, "\u652f\u4ed8\u53d6\u6d88(q)", "\u652f\u4ed8\u53d6\u6d88(q)");
        if (com.quicksdk.QuickSDK.getInstance().getPayNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getPayNotifier().onCancel(p4);
        }
        return;
    }
    public void onFailed(String p4, String p5, String p6)
    {
        android.util.Log.d("BaseLib.Payment", "qk pay failed");
        com.quicksdk.utility.l.a(this.b, "\u652f\u4ed8\u5931\u8d25(q)", "\u652f\u4ed8\u5931\u8d25(q)");
        if (com.quicksdk.QuickSDK.getInstance().getPayNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getPayNotifier().onFailed(p4, p5, p6);
        }
        return;
    }
    public void onSuccess(String p10, String p11, String p12)
    {
        android.util.Log.d("BaseLib.Payment", "qk pay success, call channel pay");
        com.quicksdk.utility.l.a(this.b, "\u652f\u4ed8\u6210\u529f(q)", "\u652f\u4ed8\u6210\u529f(q)");
        v0 = com.quicksdk.plugin.PluginManager.a();
        v2 = new Object[7];
        v2[0] = this.b;
        v2[1] = this.c;
        v2[2] = this.d;
        v2[3] = this.e;
        v2[4] = p10;
        v2[5] = p11;
        v2[6] = p12;
        v0.a(com.quicksdk.plugin.PluginNode.BEFOER_CHANNEL_PAY, v2);
        if (com.quicksdk.Sdk.getInstance().getSwitchToQuickGame().booleanValue() == 0) {
            if (this.c.getIsQGPay().booleanValue() != 0) {
                v0 = com.quicksdk.plugin.PluginManager.a();
                v2 = new Object[8];
                v2[0] = this.b;
                v2[1] = "switchToQkGamePay";
                v2[2] = this.d;
                v2[3] = this.e;
                v2[4] = this.c;
                v2[5] = p10;
                v2[6] = p11;
                v2[7] = p12;
                v0.a(com.quicksdk.plugin.PluginNode.BEFOER_CHANNEL_PAY, v2);
            } else {
                com.quicksdk.Payment.a(this.a).adtPay().pay(this.b, p10, p12, this.d, this.e);
            }
        } else {
            v0 = com.quicksdk.plugin.PluginManager.a();
            v2 = new Object[8];
            v2[0] = this.b;
            v2[1] = "switchToQkGameChannel";
            v2[2] = this.d;
            v2[3] = this.e;
            v2[4] = this.c;
            v2[5] = p10;
            v2[6] = p11;
            v2[7] = p12;
            v0.a(com.quicksdk.plugin.PluginNode.BEFOER_CHANNEL_PAY, v2);
        }
        return;
    }
}
