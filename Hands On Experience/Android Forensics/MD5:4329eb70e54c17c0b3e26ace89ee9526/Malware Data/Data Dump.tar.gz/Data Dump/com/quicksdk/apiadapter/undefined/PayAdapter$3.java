package com.quicksdk.apiadapter.undefined;
final class PayAdapter$3 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.quicksdk.apiadapter.undefined.PayAdapter a;
     PayAdapter$3(com.quicksdk.apiadapter.undefined.PayAdapter p1)
    {
        this.a = p1;
        return;
    }
    public final void onClick(android.content.DialogInterface p5, int p6)
    {
        if (com.quicksdk.QuickSDK.getInstance().getPayNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getPayNotifier().onFailed(com.quicksdk.apiadapter.undefined.PayAdapter.a(this.a).getCpOrderID(), "\u652f\u4ed8\u5931\u8d25", "trace");
        }
        return;
    }
}
