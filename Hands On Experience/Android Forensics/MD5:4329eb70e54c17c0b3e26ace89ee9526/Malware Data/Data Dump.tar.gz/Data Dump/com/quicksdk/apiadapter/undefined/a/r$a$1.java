package com.quicksdk.apiadapter.undefined.a;
final class r$a$1 implements android.view.View$OnClickListener {
    final synthetic com.quicksdk.apiadapter.undefined.a.r$a a;
     r$a$1(com.quicksdk.apiadapter.undefined.a.r$a p1)
    {
        this.a = p1;
        return;
    }
    public final void onClick(android.view.View p4)
    {
        new com.quicksdk.apiadapter.undefined.a.k(com.quicksdk.apiadapter.undefined.a.r$a.a(this.a)).a(com.quicksdk.apiadapter.undefined.a.r$a.b(this.a).e.getText().toString());
        com.quicksdk.apiadapter.undefined.a.r$a.c(this.a).onClick(com.quicksdk.apiadapter.undefined.a.r$a.d(this.a), -1);
        return;
    }
}
