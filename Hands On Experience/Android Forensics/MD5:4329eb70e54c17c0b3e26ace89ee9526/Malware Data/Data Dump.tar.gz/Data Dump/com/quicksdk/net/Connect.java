package com.quicksdk.net;
public class Connect {
    private static String a;
    private com.quicksdk.net.a c;
    private static com.quicksdk.net.Connect b;
    final private int e;
    final private int d;
    final private int g;
    final private int f;
    final private int i;
    final private int h;
    final private int k;
    final private int j;
    private android.os.Handler l;
    static Connect()
    {
        com.quicksdk.net.Connect.b = 0;
        return;
    }
    private Connect()
    {
        this.c = new com.quicksdk.net.a();
        this.d = 3;
        this.e = 4;
        this.f = 5;
        this.g = 6;
        this.h = 7;
        this.i = 8;
        this.j = 9;
        this.k = 10;
        this.l = new com.quicksdk.net.Connect$1(this);
        v0 = this.getClass().getCanonicalName();
        com.quicksdk.net.Connect.a = new StringBuilder("BaseLib ").append(v0.substring((v0.lastIndexOf(".") + 1), v0.length())).toString();
        return;
    }
    static synthetic android.os.Handler a(com.quicksdk.net.Connect p1)
    {
        return p1.l;
    }
    static synthetic String a()
    {
        return com.quicksdk.net.Connect.a;
    }
    public final void a(android.content.Context p4)
    {
        v0 = new com.quicksdk.net.Connect$4(this, p4);
        this.l.sendEmptyMessage(9);
        com.quicksdk.utility.k.a().a(v0);
        return;
    }
    public final void a(android.content.Context p4, android.os.Handler p5)
    {
        v0 = new com.quicksdk.net.Connect$9(this, p4, p5);
        this.l.sendEmptyMessage(9);
        com.quicksdk.utility.k.a().a(v0);
        return;
    }
    public final void a(android.content.Context p3, String p4, String p5)
    {
        com.quicksdk.utility.k.a().a(new com.quicksdk.net.Connect$3(this, p3, p4, p5));
        return;
    }
    public final void a(android.content.Context p8, String p9, String p10, String p11, com.quicksdk.entity.GameRoleInfo p12)
    {
        com.quicksdk.utility.k.a().a(new com.quicksdk.net.Connect$6(this, p8, p9, p10, p11, p12));
        return;
    }
    public final void a(android.content.Context p11, String p12, String p13, String p14, com.quicksdk.entity.OrderInfo p15, com.quicksdk.entity.GameRoleInfo p16, String p17, com.quicksdk.notifier.PayNotifier p18)
    {
        v0 = new com.quicksdk.net.Connect$7(this, p12, p11, p13, p14, p15, p16, p17, p18);
        this.l.sendEmptyMessage(9);
        com.quicksdk.utility.k.a().a(v0);
        return;
    }
    public final void a(android.content.Context p13, String p14, String p15, String p16, String p17, String p18, String p19, String p20, String p21, com.quicksdk.notifier.h p22)
    {
        com.quicksdk.utility.k.a().a(new com.quicksdk.net.Connect$8(this, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22));
        return;
    }
    static synthetic com.quicksdk.net.a b(com.quicksdk.net.Connect p1)
    {
        return p1.c;
    }
    public void bindPlatformUser(android.content.Context p7, String p8, String p9, String p10)
    {
        com.quicksdk.utility.k.a().a(new com.quicksdk.net.Connect$2(this, p7, p8, p9, p10));
        return;
    }
    public com.quicksdk.net.ApiResult checkCoins(android.content.Context p12, String p13, String p14, String p15, String p16, String p17, String p18, String p19, String p20, String p21)
    {
        return this.c.a(p12, p13, p14, p15, p16, p17, p18, p19, p20, p21);
    }
    public com.quicksdk.net.ApiResult extramsNetApi(android.content.Context p2, String p3, java.util.HashMap p4)
    {
        return this.c.a(p2, p3, p4);
    }
    public void getDeviceUsers(android.content.Context p3, android.os.Handler p4)
    {
        com.quicksdk.utility.k.a().a(new com.quicksdk.net.Connect$11(this, p3, p4));
        return;
    }
    public void getGameRoleData(android.content.Context p7, String p8, String p9, android.os.Handler p10)
    {
        com.quicksdk.utility.k.a().a(new com.quicksdk.net.Connect$10(this, p7, p8, p9, p10));
        return;
    }
    public static com.quicksdk.net.Connect getInstance()
    {
        if (com.quicksdk.net.Connect.b == 0) {
            com.quicksdk.net.Connect.b = new com.quicksdk.net.Connect();
        }
        return com.quicksdk.net.Connect.b;
    }
    public void login(android.content.Context p4, com.quicksdk.entity.UserInfo p5, com.quicksdk.notifier.LoginNotifier p6)
    {
        v0 = new com.quicksdk.net.Connect$5(this, p4, p5, p6);
        this.l.sendEmptyMessage(9);
        com.quicksdk.utility.k.a().a(v0);
        return;
    }
    public com.quicksdk.net.ApiResult tencentPay(android.content.Context p10, String p11, String p12, String p13, String p14, String p15, String p16, String p17)
    {
        return this.c.a(p10, p11, p12, p13, p14, p15, p16, p17);
    }
}
