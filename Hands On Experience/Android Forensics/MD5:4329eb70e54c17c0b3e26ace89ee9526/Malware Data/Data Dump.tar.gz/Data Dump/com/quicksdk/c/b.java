package com.quicksdk.c;
final public class b {
    final private static String a;
    private static android.app.ProgressDialog a(android.app.Activity p3, android.content.DialogInterface$OnClickListener p4)
    {
        v0 = new android.app.ProgressDialog(p3);
        v0.setMessage("\u6b63\u5728\u4e0b\u8f7d\u66f4\u65b0");
        v0.setIndeterminate(0);
        v0.setProgressStyle(1);
        v0.setMax(100);
        v0.setProgress(0);
        v0.setProgressNumberFormat("%1d KB/%2d KB");
        v0.setCancelable(0);
        v0.setButton(-2, "\u53d6\u6d88", p4);
        return v0;
    }
    public static void a(android.app.Activity p3, java.io.File p4)
    {
        v0 = new android.content.Intent("android.intent.action.VIEW");
        v0.setDataAndType(android.net.Uri.fromFile(p4), "application/vnd.android.package-archive");
        p3.startActivity(v0);
        return;
    }
    public b()
    {
        return;
    }
    public static int a(android.app.Activity p5)
    {
        v0 = p5.getPackageManager().getPackageInfo(p5.getPackageName(), 0).versionCode;
        android.util.Log.d("BaseLib U", new StringBuilder("currentVersionCode:").append(v0).toString());
        return v0;
    }
    public static android.app.AlertDialog a(android.content.Context p2, CharSequence p3, CharSequence p4, CharSequence p5, android.content.DialogInterface$OnClickListener p6, CharSequence p7, android.content.DialogInterface$OnClickListener p8)
    {
        v0 = new android.app.AlertDialog$Builder(p2);
        v0.setMessage(p4);
        v0.setTitle(p3);
        v0.setPositiveButton(p5, p6);
        v0.setNegativeButton(p7, p8);
        v0.setCancelable(0);
        return v0.create();
    }
}
