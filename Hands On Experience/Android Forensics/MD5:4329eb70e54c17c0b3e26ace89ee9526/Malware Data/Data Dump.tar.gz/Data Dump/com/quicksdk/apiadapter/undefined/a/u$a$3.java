package com.quicksdk.apiadapter.undefined.a;
final class u$a$3 implements android.view.View$OnClickListener {
    final synthetic com.quicksdk.apiadapter.undefined.a.u$a a;
    static synthetic com.quicksdk.apiadapter.undefined.a.u$a a(com.quicksdk.apiadapter.undefined.a.u$a$3 p1)
    {
        return p1.a;
    }
    public final void onClick(android.view.View p4)
    {
        v0 = new com.quicksdk.apiadapter.undefined.a.u$a$3$1(this, new com.quicksdk.apiadapter.undefined.a.t(com.quicksdk.apiadapter.undefined.a.u$a.d(this.a)));
        com.quicksdk.apiadapter.undefined.a.u$a.b(this.a).dismiss();
        v0.show();
        return;
    }
     u$a$3(com.quicksdk.apiadapter.undefined.a.u$a p1)
    {
        this.a = p1;
        return;
    }
}
