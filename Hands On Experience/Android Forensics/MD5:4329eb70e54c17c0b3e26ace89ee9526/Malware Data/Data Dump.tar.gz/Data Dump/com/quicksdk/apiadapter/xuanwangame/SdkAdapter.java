package com.quicksdk.apiadapter.xuanwangame;
public class SdkAdapter implements com.quicksdk.apiadapter.ISdkAdapter {
    private static String a;
    private boolean b;
    public SdkAdapter()
    {
        this.b = 0;
        return;
    }
    public void checkUpdate(android.app.Activity p1)
    {
        return;
    }
    public void exit(android.app.Activity p3)
    {
        android.util.Log.d(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "exit");
        this.exitSuccessed();
        return;
    }
    public void exitFailed(String p4)
    {
        android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, new StringBuilder("exit failed :").append(p4).toString());
        if (com.quicksdk.QuickSDK.getInstance().getExitNotifier() != 0) {
            v0 = com.quicksdk.QuickSDK.getInstance().getExitNotifier();
            if (p4 == 0) {
                p4 = "";
            }
            v0.onFailed(p4, "");
        }
        return;
    }
    public void exitFailed(Throwable p4)
    {
        android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "exit failed");
        com.quicksdk.apiadapter.xuanwangame.SdkAdapter.printThrowableInfo(p4);
        if (com.quicksdk.QuickSDK.getInstance().getExitNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getExitNotifier().onFailed(p4.getMessage(), "");
        }
        return;
    }
    public void exitSuccessed()
    {
        android.util.Log.d(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "exit successed");
        if (com.quicksdk.QuickSDK.getInstance().getExitNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getExitNotifier().onSuccess();
        }
        return;
    }
    public String getChannelSdkVersion()
    {
        return "2.0.0";
    }
    public static com.quicksdk.apiadapter.xuanwangame.SdkAdapter getInstance()
    {
        return com.quicksdk.apiadapter.xuanwangame.SdkAdapter$AdapterHolder.a();
    }
    public String getSdkSubVersion()
    {
        return "3";
    }
    public void init(android.app.Activity p3)
    {
        android.util.Log.d(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "init");
        com.wancms.sdk.WancmsSDKManager.getInstance(p3);
        this.initSuccessed();
        return;
    }
    public void initFailed(String p4)
    {
        android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, new StringBuilder("init failed:").append(p4).toString());
        if (com.quicksdk.QuickSDK.getInstance().getInitNotifier() != 0) {
            v0 = com.quicksdk.QuickSDK.getInstance().getInitNotifier();
            if (p4 == 0) {
                p4 = "";
            }
            v0.onFailed(p4, "");
        }
        return;
    }
    public void initFailed(Throwable p4)
    {
        android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "init failed");
        com.quicksdk.apiadapter.xuanwangame.SdkAdapter.printThrowableInfo(p4);
        if (com.quicksdk.QuickSDK.getInstance().getInitNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getInitNotifier().onFailed(p4.getMessage(), "");
        }
        return;
    }
    public void initSuccessed()
    {
        android.util.Log.d(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "init successed");
        if (com.quicksdk.QuickSDK.getInstance().getInitNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getInitNotifier().onSuccess();
        }
        return;
    }
    public boolean isShowExitDialog()
    {
        return this.b;
    }
    public static void printThrowableInfo(Throwable p2)
    {
        android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "====printThrowableInfo begin====");
        v0 = new java.io.StringWriter();
        p2.printStackTrace(new java.io.PrintWriter(v0));
        android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, v0.toString());
        android.util.Log.e(com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a, "====printThrowableInfo end====");
        return;
    }
    static SdkAdapter()
    {
        com.quicksdk.apiadapter.xuanwangame.SdkAdapter.a = com.quicksdk.apiadapter.xuanwangame.ActivityAdapter.a;
        return;
    }
}
