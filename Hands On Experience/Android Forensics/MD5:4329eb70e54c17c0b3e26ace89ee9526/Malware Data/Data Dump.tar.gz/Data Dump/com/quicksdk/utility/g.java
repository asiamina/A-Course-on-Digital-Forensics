package com.quicksdk.utility;
final public class g {
    private android.content.Context a;
    private android.app.Dialog b;
    public g()
    {
        return;
    }
    public final void a()
    {
        if ((this.b != 0) && (this.b.isShowing() != 0)) {
            this.b.dismiss();
        }
        this.b = 0;
        this.a = 0;
        return;
    }
    public final void a(android.content.Context p2)
    {
        if (this.b == 0) {
            this.b(p2);
        }
        if (this.a != p2) {
            if (this.b.isShowing() != 0) {
                this.b.dismiss();
            }
            this.b(p2);
        }
        if ((this.b != 0) && (this.b.isShowing() == 0)) {
            this.b.show();
        }
        return;
    }
    public final void b()
    {
        if ((this.b != 0) && (this.b.isShowing() != 0)) {
            this.b.dismiss();
        }
        return;
    }
    private void b(android.content.Context p7)
    {
        this.a = p7;
        this.b = new android.app.Dialog(this.a, this.a.getResources().getIdentifier("qk_game_style_loading", "style", this.a.getPackageName()));
        this.b.requestWindowFeature(1);
        v1 = android.view.LayoutInflater.from(this.a).inflate(this.a.getResources().getIdentifier("qk_game_view_loading", "layout", this.a.getPackageName()), 0);
        v0 = v1.findViewById(this.a.getResources().getIdentifier("qk_img_loading", "id", this.a.getPackageName()));
        this.b.setContentView(v1);
        this.b.setCancelable(1);
        this.b.setOnShowListener(new com.quicksdk.utility.g$1(this, v0));
        return;
    }
    public static com.quicksdk.utility.g c()
    {
        return com.quicksdk.utility.g$a.a();
    }
    private void d()
    {
        this.b = new android.app.Dialog(this.a, this.a.getResources().getIdentifier("qk_game_style_loading", "style", this.a.getPackageName()));
        this.b.requestWindowFeature(1);
        v1 = android.view.LayoutInflater.from(this.a).inflate(this.a.getResources().getIdentifier("qk_game_view_loading", "layout", this.a.getPackageName()), 0);
        v0 = v1.findViewById(this.a.getResources().getIdentifier("qk_img_loading", "id", this.a.getPackageName()));
        this.b.setContentView(v1);
        this.b.setCancelable(1);
        this.b.setOnShowListener(new com.quicksdk.utility.g$1(this, v0));
        return;
    }
}
