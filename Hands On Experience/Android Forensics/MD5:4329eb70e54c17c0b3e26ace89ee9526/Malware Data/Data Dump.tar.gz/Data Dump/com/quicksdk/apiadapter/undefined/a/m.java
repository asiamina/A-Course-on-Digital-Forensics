package com.quicksdk.apiadapter.undefined.a;
final public class m extends android.widget.Button {
    private static android.graphics.drawable.Drawable b(int p7, int p8, int p9)
    {
        v1 = new com.quicksdk.apiadapter.undefined.a.n();
        v1.a(p7, p8, p9, "#e026adf0");
        v2 = new com.quicksdk.apiadapter.undefined.a.n();
        v2.a(p7, p8, p9, "#e01974a1");
        v0 = new android.graphics.drawable.StateListDrawable();
        v3 = new int[1];
        v3[0] = 2.3694026042448817e-38;
        v0.addState(v3, v2);
        v3 = new int[1];
        v3[0] = -1.6947496715221809e+38;
        v0.addState(v3, v1);
        return v0;
    }
    public m(android.content.Context p3)
    {
        this(p3);
        this.setBackgroundDrawable(com.quicksdk.apiadapter.undefined.a.m.b(60, 60, 26));
        return;
    }
    public final void a(int p2, int p3, int p4)
    {
        this.setBackgroundDrawable(com.quicksdk.apiadapter.undefined.a.m.b(p2, p3, p4));
        return;
    }
}
