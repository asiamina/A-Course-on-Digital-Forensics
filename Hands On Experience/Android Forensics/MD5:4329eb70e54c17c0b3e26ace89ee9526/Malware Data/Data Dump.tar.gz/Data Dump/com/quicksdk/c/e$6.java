package com.quicksdk.c;
final class e$6 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.quicksdk.c.e a;
     e$6(com.quicksdk.c.e p1)
    {
        this.a = p1;
        return;
    }
    public final void onClick(android.content.DialogInterface p4, int p5)
    {
        com.quicksdk.c.e.a(this.a).a(com.quicksdk.c.e.d(this.a), this.a.a);
        return;
    }
}
