package com.quicksdk.net;
final class Connect$6 implements java.lang.Runnable {
    final synthetic com.quicksdk.net.Connect a;
    final private synthetic String c;
    final private synthetic android.content.Context b;
    final private synthetic String e;
    final private synthetic String d;
    final private synthetic com.quicksdk.entity.GameRoleInfo f;
     Connect$6(com.quicksdk.net.Connect p1, android.content.Context p2, String p3, String p4, String p5, com.quicksdk.entity.GameRoleInfo p6)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p4;
        this.e = p5;
        this.f = p6;
        return;
    }
    public final void run()
    {
        v9 = com.quicksdk.net.Connect.b(this.a).a(this.b, this.c, this.d, this.e, this.f);
        if (v9.getResult() == 0) {
            v7 = "\u672a\u77e5\u9519\u8bef";
            v6 = "-1";
            if (v9.getError() != 0) {
                v7 = v9.getError().optString("message");
                v6 = v9.getError().optString("id");
            }
            android.util.Log.e(com.quicksdk.net.Connect.a(), new StringBuilder("ug failed, code = ").append(v6).append(", error = ").append(v7).toString());
        }
        com.quicksdk.net.Connect.a(this.a).sendEmptyMessage(10);
        return;
    }
}
