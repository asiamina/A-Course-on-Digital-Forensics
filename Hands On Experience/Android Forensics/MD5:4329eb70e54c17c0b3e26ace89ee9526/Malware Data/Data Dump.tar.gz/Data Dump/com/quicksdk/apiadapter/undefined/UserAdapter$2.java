package com.quicksdk.apiadapter.undefined;
final class UserAdapter$2 implements android.content.DialogInterface$OnClickListener {
    final synthetic com.quicksdk.apiadapter.undefined.UserAdapter a;
    final private synthetic android.app.Activity b;
     UserAdapter$2(com.quicksdk.apiadapter.undefined.UserAdapter p1, android.app.Activity p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }
    public final void onClick(android.content.DialogInterface p5, int p6)
    {
        p5.dismiss();
        com.quicksdk.apiadapter.undefined.a.y.b();
        com.quicksdk.apiadapter.undefined.UserAdapter.a(this.a, new com.quicksdk.entity.UserInfo());
        com.quicksdk.apiadapter.undefined.UserAdapter.a(this.a).setUserName(com.quicksdk.apiadapter.undefined.UserAdapter.b(this.a).a());
        com.quicksdk.apiadapter.undefined.UserAdapter.a(this.a).setUID(this.a.getUid(com.quicksdk.apiadapter.undefined.UserAdapter.a(this.a).getUserName()));
        com.quicksdk.apiadapter.undefined.UserAdapter.a(this.a).setToken("000000001");
        com.quicksdk.net.Connect.getInstance().login(this.b, com.quicksdk.apiadapter.undefined.UserAdapter.a(this.a), com.quicksdk.QuickSDK.getInstance().getSwitchAccountNotifier());
        return;
    }
}
