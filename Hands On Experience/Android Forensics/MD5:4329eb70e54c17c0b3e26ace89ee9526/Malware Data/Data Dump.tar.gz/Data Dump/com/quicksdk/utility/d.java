package com.quicksdk.utility;
final public class d {
    final private static char[] a;
    static d()
    {
        com.quicksdk.utility.d.a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
        return;
    }
    public d()
    {
        return;
    }
    private static int a(char p3)
    {
        if ((p3 < 65) || (p3 > 90)) {
            if ((p3 < 97) || (p3 > 122)) {
                if ((p3 < 48) || (p3 > 57)) {
                    switch (p3) {
                        case 43:
                            v0 = 62;
                            break;
                        case 47:
                            v0 = 63;
                            break;
                        case 61:
                            v0 = 0;
                            break;
                        default:
                            throw new RuntimeException(new StringBuilder("unexpected code: ").append(p3).toString());
                    }
                } else {
                    v0 = (((p3 - 48) + 26) + 26);
                }
            } else {
                v0 = ((p3 - 97) + 26);
            }
        } else {
            v0 = (p3 - 65);
        }
        return v0;
    }
    public static String a(byte[] p7)
    {
        v4 = p7.length;
        v0 = new StringBuffer(((p7.length * 3) / 2));
        v2 = (v4 - 3);
        v3 = 0;
        while (v3 <= v2) {
            v1 = ((((p7[v3] & 255) << 16) | ((p7[(v3 + 1)] & 255) << 8)) | (p7[(v3 + 2)] & 255));
            v0.append(com.quicksdk.utility.d.a[((v1 >> 18) & 63)]);
            v0.append(com.quicksdk.utility.d.a[((v1 >> 12) & 63)]);
            v0.append(com.quicksdk.utility.d.a[((v1 >> 6) & 63)]);
            v0.append(com.quicksdk.utility.d.a[(v1 & 63)]);
            v3 += 3;
        }
        if (v3 != ((v4 + 0) - 2)) {
            if (v3 == ((v4 + 0) - 1)) {
                v1 = ((p7[v3] & 255) << 16);
                v0.append(com.quicksdk.utility.d.a[((v1 >> 18) & 63)]);
                v0.append(com.quicksdk.utility.d.a[((v1 >> 12) & 63)]);
                v0.append("==");
            }
        } else {
            v1 = (((p7[v3] & 255) << 16) | ((p7[(v3 + 1)] & 255) << 8));
            v0.append(com.quicksdk.utility.d.a[((v1 >> 18) & 63)]);
            v0.append(com.quicksdk.utility.d.a[((v1 >> 12) & 63)]);
            v0.append(com.quicksdk.utility.d.a[((v1 >> 6) & 63)]);
            v0.append("=");
        }
        return v0.toString();
    }
    private static void a(String p6, java.io.OutputStream p7)
    {
        v0 = 0;
        v1 = p6.length();
        while(true) {
            if ((v0 < v1) && (p6.charAt(v0) <= 32)) {
                v0++;
            } else {
                if (v0 == v1) {
                    break;
                }
                v2 = ((((com.quicksdk.utility.d.a(p6.charAt(v0)) << 18) + (com.quicksdk.utility.d.a(p6.charAt((v0 + 1))) << 12)) + (com.quicksdk.utility.d.a(p6.charAt((v0 + 2))) << 6)) + com.quicksdk.utility.d.a(p6.charAt((v0 + 3))));
                p7.write(((v2 >> 16) & 255));
                if (p6.charAt((v0 + 2)) == 61) {
                    break;
                }
                p7.write(((v2 >> 8) & 255));
                if (p6.charAt((v0 + 3)) == 61) {
                    break;
                }
                p7.write((v2 & 255));
                v0 += 4;
            }
        }
        return;
    }
    public static byte[] a(String p6)
    {
        v0 = new java.io.ByteArrayOutputStream();
        com.quicksdk.utility.d.a(p6, v0);
        v1 = v0.toByteArray();
        v0.close();
        return v1;
    }
}
