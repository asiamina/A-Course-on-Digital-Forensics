package com.quicksdk;
 class QuickSDK$1 implements com.quicksdk.notifier.SwitchAccountNotifier {
    final synthetic com.quicksdk.QuickSDK a;
     QuickSDK$1(com.quicksdk.QuickSDK p1)
    {
        this.a = p1;
        return;
    }
    public void onCancel()
    {
        if (com.quicksdk.QuickSDK.a(this.a) != 0) {
            com.quicksdk.QuickSDK.a(this.a).onCancel();
        }
        return;
    }
    public void onFailed(String p2, String p3)
    {
        if (com.quicksdk.QuickSDK.a(this.a) != 0) {
            com.quicksdk.QuickSDK.a(this.a).onFailed(p2, p3);
        }
        return;
    }
    public void onSuccess(com.quicksdk.entity.UserInfo p2)
    {
        if (com.quicksdk.QuickSDK.a(this.a) != 0) {
            com.quicksdk.QuickSDK.a(this.a).onSuccess(p2);
        }
        return;
    }
}
