package com.quicksdk.apiadapter.xuanwangame;
 class ExtendAdapter$AdapterHolder {
    private static com.quicksdk.apiadapter.xuanwangame.ExtendAdapter a;
    static ExtendAdapter$AdapterHolder()
    {
        com.quicksdk.apiadapter.xuanwangame.ExtendAdapter$AdapterHolder.a = new com.quicksdk.apiadapter.xuanwangame.ExtendAdapter();
        return;
    }
    private ExtendAdapter$AdapterHolder()
    {
        return;
    }
    static synthetic com.quicksdk.apiadapter.xuanwangame.ExtendAdapter a()
    {
        return com.quicksdk.apiadapter.xuanwangame.ExtendAdapter$AdapterHolder.a;
    }
}
