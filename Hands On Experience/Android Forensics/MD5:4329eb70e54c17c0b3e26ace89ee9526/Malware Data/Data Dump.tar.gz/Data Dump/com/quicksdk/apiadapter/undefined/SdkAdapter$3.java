package com.quicksdk.apiadapter.undefined;
final class SdkAdapter$3 implements android.content.DialogInterface$OnCancelListener {
    final synthetic com.quicksdk.apiadapter.undefined.SdkAdapter a;
     SdkAdapter$3(com.quicksdk.apiadapter.undefined.SdkAdapter p1)
    {
        this.a = p1;
        return;
    }
    public final void onCancel(android.content.DialogInterface p4)
    {
        if (com.quicksdk.QuickSDK.getInstance().getExitNotifier() != 0) {
            com.quicksdk.QuickSDK.getInstance().getExitNotifier().onFailed("", "");
        }
        return;
    }
}
