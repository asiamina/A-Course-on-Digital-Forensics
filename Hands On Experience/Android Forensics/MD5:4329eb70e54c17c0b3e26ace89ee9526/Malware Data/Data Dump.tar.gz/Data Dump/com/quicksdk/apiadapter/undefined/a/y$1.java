package com.quicksdk.apiadapter.undefined.a;
final class y$1 implements android.view.View$OnTouchListener {
     float a;
    final synthetic com.quicksdk.apiadapter.undefined.a.y c;
     float b;
     y$1(com.quicksdk.apiadapter.undefined.a.y p1)
    {
        this.c = p1;
        return;
    }
    public final boolean onTouch(android.view.View p4, android.view.MotionEvent p5)
    {
        this.c.a = p5.getRawX();
        this.c.b = (p5.getRawY() - 25.0);
        switch (p5.getAction()) {
            case 0:
                this.a = p5.getX();
                this.b = p5.getY();
                break;
            case 1:
                this.b = 0;
                this.a = 0;
                break;
            case 2:
                com.quicksdk.apiadapter.undefined.a.y.a(this.c).x = ((int) (this.c.a - this.a));
                com.quicksdk.apiadapter.undefined.a.y.a(this.c).y = ((int) (this.c.b - this.b));
                com.quicksdk.apiadapter.undefined.a.y.b(this.c).updateViewLayout(com.quicksdk.apiadapter.undefined.a.y.c(this.c), com.quicksdk.apiadapter.undefined.a.y.a(this.c));
                break;
        }
        return 0;
    }
}
