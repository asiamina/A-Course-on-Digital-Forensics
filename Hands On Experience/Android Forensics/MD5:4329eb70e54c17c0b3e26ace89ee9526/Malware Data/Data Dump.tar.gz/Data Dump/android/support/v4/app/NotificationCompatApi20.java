package android.support.v4.app;
 class NotificationCompatApi20 {
     NotificationCompatApi20()
    {
        return;
    }
    public static void addAction(android.app.Notification$Builder p8, android.support.v4.app.NotificationCompatBase$Action p9)
    {
        v0 = new android.app.Notification$Action$Builder(p9.getIcon(), p9.getTitle(), p9.getActionIntent());
        if (p9.getRemoteInputs() != 0) {
            v1 = android.support.v4.app.RemoteInputCompatApi20.fromCompat(p9.getRemoteInputs());
            v3 = v1.length;
            v2 = 0;
            while (v2 < v3) {
                v0.addRemoteInput(v1[v2]);
                v2++;
            }
        }
        if (p9.getExtras() != 0) {
            v0.addExtras(p9.getExtras());
        }
        p8.addAction(v0.build());
        return;
    }
    public static android.support.v4.app.NotificationCompatBase$Action getAction(android.app.Notification p1, int p2, android.support.v4.app.NotificationCompatBase$Action$Factory p3, android.support.v4.app.RemoteInputCompatBase$RemoteInput$Factory p4)
    {
        return android.support.v4.app.NotificationCompatApi20.getActionCompatFromAction(p1.actions[p2], p3, p4);
    }
    private static android.support.v4.app.NotificationCompatBase$Action getActionCompatFromAction(android.app.Notification$Action p6, android.support.v4.app.NotificationCompatBase$Action$Factory p7, android.support.v4.app.RemoteInputCompatBase$RemoteInput$Factory p8)
    {
        return p7.build(p6.icon, p6.title, p6.actionIntent, p6.getExtras(), android.support.v4.app.RemoteInputCompatApi20.toCompat(p6.getRemoteInputs(), p8));
    }
    private static android.app.Notification$Action getActionFromActionCompat(android.support.v4.app.NotificationCompatBase$Action p11)
    {
        v0 = new android.app.Notification$Action$Builder(v8, p11.getTitle(), p11.getActionIntent()).addExtras(p11.getExtras());
        v5 = p11.getRemoteInputs();
        if (v5 != 0) {
            v1 = android.support.v4.app.RemoteInputCompatApi20.fromCompat(v5);
            v3 = v1.length;
            v2 = 0;
            while (v2 < v3) {
                v0.addRemoteInput(v1[v2]);
                v2++;
            }
        }
        return v0.build();
    }
    public static android.support.v4.app.NotificationCompatBase$Action[] getActionsFromParcelableArrayList(java.util.ArrayList p4, android.support.v4.app.NotificationCompatBase$Action$Factory p5, android.support.v4.app.RemoteInputCompatBase$RemoteInput$Factory p6)
    {
        if (p4 != 0) {
            v1 = p5.newArray(p4.size());
            v2 = 0;
            while (v2 < v1.length) {
                v1[v2] = android.support.v4.app.NotificationCompatApi20.getActionCompatFromAction(p4.get(v2), p5, p6);
                v2++;
            }
        } else {
            v1 = 0;
        }
        return v1;
    }
    public static String getGroup(android.app.Notification p1)
    {
        return p1.getGroup();
    }
    public static boolean getLocalOnly(android.app.Notification p1)
    {
        if ((p1.flags & 256) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static java.util.ArrayList getParcelableArrayListForActions(android.support.v4.app.NotificationCompatBase$Action[] p6)
    {
        if (p6 != 0) {
            v4 = new java.util.ArrayList(p6.length);
            v1 = p6;
            v3 = v1.length;
            v2 = 0;
            while (v2 < v3) {
                v4.add(android.support.v4.app.NotificationCompatApi20.getActionFromActionCompat(v1[v2]));
                v2++;
            }
        } else {
            v4 = 0;
        }
        return v4;
    }
    public static String getSortKey(android.app.Notification p1)
    {
        return p1.getSortKey();
    }
    public static boolean isGroupSummary(android.app.Notification p1)
    {
        if ((p1.flags & 512) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
}
