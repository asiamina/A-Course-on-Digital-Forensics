package android.support.v4.animation;
interface abstract class AnimatorProvider {
    abstract public void clearInterpolator();
    abstract public android.support.v4.animation.ValueAnimatorCompat emptyValueAnimator();
}
