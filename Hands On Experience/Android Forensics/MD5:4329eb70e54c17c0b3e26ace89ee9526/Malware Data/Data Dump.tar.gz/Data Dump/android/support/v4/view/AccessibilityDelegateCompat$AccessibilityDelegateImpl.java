package android.support.v4.view;
interface abstract class AccessibilityDelegateCompat$AccessibilityDelegateImpl {
    abstract public boolean dispatchPopulateAccessibilityEvent();
    abstract public android.support.v4.view.accessibility.AccessibilityNodeProviderCompat getAccessibilityNodeProvider();
    abstract public Object newAccessiblityDelegateBridge();
    abstract public Object newAccessiblityDelegateDefaultImpl();
    abstract public void onInitializeAccessibilityEvent();
    abstract public void onInitializeAccessibilityNodeInfo();
    abstract public void onPopulateAccessibilityEvent();
    abstract public boolean onRequestSendAccessibilityEvent();
    abstract public boolean performAccessibilityAction();
    abstract public void sendAccessibilityEvent();
    abstract public void sendAccessibilityEventUnchecked();
}
