package android.support.v4.media.session;
 class IMediaControllerCallback$Stub$Proxy implements android.support.v4.media.session.IMediaControllerCallback {
    private android.os.IBinder mRemote;
     IMediaControllerCallback$Stub$Proxy(android.os.IBinder p1)
    {
        this.mRemote = p1;
        return;
    }
    public android.os.IBinder asBinder()
    {
        return this.mRemote;
    }
    public String getInterfaceDescriptor()
    {
        return "android.support.v4.media.session.IMediaControllerCallback";
    }
    public void onEvent(String p6, android.os.Bundle p7)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        v0.writeString(p6);
        if (p7 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            p7.writeToParcel(v0, 0);
        }
        this.mRemote.transact(1, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void onExtrasChanged(android.os.Bundle p6)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        if (p6 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            p6.writeToParcel(v0, 0);
        }
        this.mRemote.transact(7, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void onMetadataChanged(android.support.v4.media.MediaMetadataCompat p6)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        if (p6 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            p6.writeToParcel(v0, 0);
        }
        this.mRemote.transact(4, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void onPlaybackStateChanged(android.support.v4.media.session.PlaybackStateCompat p6)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        if (p6 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            p6.writeToParcel(v0, 0);
        }
        this.mRemote.transact(3, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void onQueueChanged(java.util.List p6)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        v0.writeTypedList(p6);
        this.mRemote.transact(5, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void onQueueTitleChanged(CharSequence p6)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        if (p6 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            android.text.TextUtils.writeToParcel(p6, v0, 0);
        }
        this.mRemote.transact(6, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void onSessionDestroyed()
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        this.mRemote.transact(2, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void onVolumeInfoChanged(android.support.v4.media.session.ParcelableVolumeInfo p6)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
        if (p6 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            p6.writeToParcel(v0, 0);
        }
        this.mRemote.transact(8, v0, 0, 1);
        v0.recycle();
        return;
    }
}
