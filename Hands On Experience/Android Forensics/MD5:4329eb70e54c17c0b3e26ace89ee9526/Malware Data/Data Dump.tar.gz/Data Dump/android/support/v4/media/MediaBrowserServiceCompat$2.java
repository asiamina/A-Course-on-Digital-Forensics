package android.support.v4.media;
 class MediaBrowserServiceCompat$2 implements java.lang.Runnable {
    final synthetic String val$parentId;
    final synthetic android.support.v4.media.MediaBrowserServiceCompat this$0;
     MediaBrowserServiceCompat$2(android.support.v4.media.MediaBrowserServiceCompat p1, String p2)
    {
        this.this$0 = p1;
        this.val$parentId = p2;
        return;
    }
    public void run()
    {
        v2 = android.support.v4.media.MediaBrowserServiceCompat.access$100(this.this$0).keySet().iterator();
        while (v2.hasNext() != 0) {
            v1 = android.support.v4.media.MediaBrowserServiceCompat.access$100(this.this$0).get(v2.next());
            if (v1.subscriptions.contains(this.val$parentId) != 0) {
                android.support.v4.media.MediaBrowserServiceCompat.access$700(this.this$0, this.val$parentId, v1);
            }
        }
        return;
    }
}
