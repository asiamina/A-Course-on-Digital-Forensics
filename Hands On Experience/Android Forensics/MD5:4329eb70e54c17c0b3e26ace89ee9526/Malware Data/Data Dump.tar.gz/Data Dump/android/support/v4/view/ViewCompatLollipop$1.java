package android.support.v4.view;
final class ViewCompatLollipop$1 implements android.view.View$OnApplyWindowInsetsListener {
    final synthetic android.support.v4.view.OnApplyWindowInsetsListener val$listener;
     ViewCompatLollipop$1(android.support.v4.view.OnApplyWindowInsetsListener p1)
    {
        this.val$listener = p1;
        return;
    }
    public android.view.WindowInsets onApplyWindowInsets(android.view.View p3, android.view.WindowInsets p4)
    {
        return this.val$listener.onApplyWindowInsets(p3, new android.support.v4.view.WindowInsetsCompatApi21(p4)).unwrap();
    }
}
