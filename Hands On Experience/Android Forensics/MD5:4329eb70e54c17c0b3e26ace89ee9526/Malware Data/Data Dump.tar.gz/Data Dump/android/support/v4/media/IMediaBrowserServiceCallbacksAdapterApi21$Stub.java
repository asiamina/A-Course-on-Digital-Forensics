package android.support.v4.media;
 class IMediaBrowserServiceCallbacksAdapterApi21$Stub {
    static reflect.Method sAsInterfaceMethod;
    static Object asInterface(android.os.IBinder p6)
    {
        v4 = new Object[1];
        v4[0] = p6;
        return android.support.v4.media.IMediaBrowserServiceCallbacksAdapterApi21$Stub.sAsInterfaceMethod.invoke(0, v4);
    }
    static IMediaBrowserServiceCallbacksAdapterApi21$Stub()
    {
        v1 = Class.forName("android.service.media.IMediaBrowserServiceCallbacks$Stub");
        v3 = new Class[1];
        v3[0] = android.os.IBinder;
        android.support.v4.media.IMediaBrowserServiceCallbacksAdapterApi21$Stub.sAsInterfaceMethod = v1.getMethod("asInterface", v3);
        return;
    }
     IMediaBrowserServiceCallbacksAdapterApi21$Stub()
    {
        return;
    }
}
