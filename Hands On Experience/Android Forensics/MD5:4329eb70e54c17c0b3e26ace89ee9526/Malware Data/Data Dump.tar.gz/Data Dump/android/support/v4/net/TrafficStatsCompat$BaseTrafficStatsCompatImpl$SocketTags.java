package android.support.v4.net;
 class TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags {
    public int statsTag;
    private TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags()
    {
        this.statsTag = -1;
        return;
    }
    synthetic TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags(android.support.v4.net.TrafficStatsCompat$1 p1)
    {
        return;
    }
}
