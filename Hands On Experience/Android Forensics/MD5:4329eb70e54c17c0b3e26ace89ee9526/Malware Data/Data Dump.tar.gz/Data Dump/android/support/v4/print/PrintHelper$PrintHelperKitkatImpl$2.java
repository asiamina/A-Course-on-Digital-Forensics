package android.support.v4.print;
 class PrintHelper$PrintHelperKitkatImpl$2 implements android.support.v4.print.PrintHelperKitkat$OnPrintFinishCallback {
    final synthetic android.support.v4.print.PrintHelper$OnPrintFinishCallback val$callback;
    final synthetic android.support.v4.print.PrintHelper$PrintHelperKitkatImpl this$0;
     PrintHelper$PrintHelperKitkatImpl$2(android.support.v4.print.PrintHelper$PrintHelperKitkatImpl p1, android.support.v4.print.PrintHelper$OnPrintFinishCallback p2)
    {
        this.this$0 = p1;
        this.val$callback = p2;
        return;
    }
    public void onFinish()
    {
        this.val$callback.onFinish();
        return;
    }
}
