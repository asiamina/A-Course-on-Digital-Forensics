package android.support.v4.media.routing;
public interface abstract class MediaRouterJellybean$VolumeCallback {
    abstract public void onVolumeSetRequest();
    abstract public void onVolumeUpdateRequest();
}
