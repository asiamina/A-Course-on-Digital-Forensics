package android.support.v4.view;
interface abstract class MarginLayoutParamsCompat$MarginLayoutParamsCompatImpl {
    abstract public int getLayoutDirection();
    abstract public int getMarginEnd();
    abstract public int getMarginStart();
    abstract public boolean isMarginRelative();
    abstract public void resolveLayoutDirection();
    abstract public void setLayoutDirection();
    abstract public void setMarginEnd();
    abstract public void setMarginStart();
}
