package android.support.v4.media;
 class MediaBrowserCompat$MediaBrowserImplBase$7 implements java.lang.Runnable {
    final synthetic String val$parentId;
    final synthetic android.support.v4.media.IMediaBrowserServiceCompatCallbacks val$callback;
    final synthetic android.support.v4.media.MediaBrowserCompat$MediaBrowserImplBase this$0;
    final synthetic java.util.List val$list;
     MediaBrowserCompat$MediaBrowserImplBase$7(android.support.v4.media.MediaBrowserCompat$MediaBrowserImplBase p1, android.support.v4.media.IMediaBrowserServiceCompatCallbacks p2, java.util.List p3, String p4)
    {
        this.this$0 = p1;
        this.val$callback = p2;
        this.val$list = p3;
        this.val$parentId = p4;
        return;
    }
    public void run()
    {
        if (android.support.v4.media.MediaBrowserCompat$MediaBrowserImplBase.access$500(this.this$0, this.val$callback, "onLoadChildren") != 0) {
            v0 = this.val$list;
            if (v0 == 0) {
                v0 = java.util.Collections.emptyList();
            }
            v1 = android.support.v4.media.MediaBrowserCompat$MediaBrowserImplBase.access$1100(this.this$0).get(this.val$parentId);
            if (v1 != 0) {
                v1.callback.onChildrenLoaded(this.val$parentId, v0);
            }
        }
        return;
    }
}
