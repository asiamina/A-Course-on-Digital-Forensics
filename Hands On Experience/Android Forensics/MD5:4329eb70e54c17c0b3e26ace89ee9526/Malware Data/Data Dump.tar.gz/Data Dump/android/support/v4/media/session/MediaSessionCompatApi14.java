package android.support.v4.media.session;
 class MediaSessionCompatApi14 {
    final private static String METADATA_KEY_AUTHOR;
    final private static String METADATA_KEY_TRACK_NUMBER;
    final private static String METADATA_KEY_ART;
    final private static String METADATA_KEY_GENRE;
    final static int STATE_SKIPPING_TO_QUEUE_ITEM;
    final static int STATE_BUFFERING;
    final private static String METADATA_KEY_COMPOSER;
    final static int RCC_PLAYSTATE_NONE;
    final private static String METADATA_KEY_DATE;
    final static int STATE_FAST_FORWARDING;
    final static int STATE_CONNECTING;
    final static int STATE_PLAYING;
    final static int STATE_NONE;
    final private static String METADATA_KEY_ALBUM;
    final private static String METADATA_KEY_DISC_NUMBER;
    final private static String METADATA_KEY_WRITER;
    final private static long ACTION_SKIP_TO_PREVIOUS;
    final private static String METADATA_KEY_ARTIST;
    final private static String METADATA_KEY_ALBUM_ARTIST;
    final static int STATE_PAUSED;
    final static int STATE_SKIPPING_TO_NEXT;
    final private static String METADATA_KEY_COMPILATION;
    final private static String METADATA_KEY_TITLE;
    final private static String METADATA_KEY_ALBUM_ART;
    final private static String METADATA_KEY_DURATION;
    final private static long ACTION_STOP;
    final private static long ACTION_PAUSE;
    final static int STATE_STOPPED;
    final private static long ACTION_SKIP_TO_NEXT;
    final private static long ACTION_PLAY;
    final static int STATE_SKIPPING_TO_PREVIOUS;
    final static int STATE_REWINDING;
    final private static long ACTION_PLAY_PAUSE;
    final static int STATE_ERROR;
    final private static long ACTION_FAST_FORWARD;
    final private static long ACTION_REWIND;
     MediaSessionCompatApi14()
    {
        return;
    }
    static void buildOldMetadata(android.os.Bundle p4, android.media.RemoteControlClient$MetadataEditor p5)
    {
        if (p4 != 0) {
            if (p4.containsKey("android.media.metadata.ART") == 0) {
                if (p4.containsKey("android.media.metadata.ALBUM_ART") != 0) {
                    p5.putBitmap(100, p4.getParcelable("android.media.metadata.ALBUM_ART"));
                }
            } else {
                p5.putBitmap(100, p4.getParcelable("android.media.metadata.ART"));
            }
            if (p4.containsKey("android.media.metadata.ALBUM") != 0) {
                p5.putString(1, p4.getString("android.media.metadata.ALBUM"));
            }
            if (p4.containsKey("android.media.metadata.ALBUM_ARTIST") != 0) {
                p5.putString(13, p4.getString("android.media.metadata.ALBUM_ARTIST"));
            }
            if (p4.containsKey("android.media.metadata.ARTIST") != 0) {
                p5.putString(2, p4.getString("android.media.metadata.ARTIST"));
            }
            if (p4.containsKey("android.media.metadata.AUTHOR") != 0) {
                p5.putString(3, p4.getString("android.media.metadata.AUTHOR"));
            }
            if (p4.containsKey("android.media.metadata.COMPILATION") != 0) {
                p5.putString(15, p4.getString("android.media.metadata.COMPILATION"));
            }
            if (p4.containsKey("android.media.metadata.COMPOSER") != 0) {
                p5.putString(4, p4.getString("android.media.metadata.COMPOSER"));
            }
            if (p4.containsKey("android.media.metadata.DATE") != 0) {
                p5.putString(5, p4.getString("android.media.metadata.DATE"));
            }
            if (p4.containsKey("android.media.metadata.DISC_NUMBER") != 0) {
                p5.putLong(14, p4.getLong("android.media.metadata.DISC_NUMBER"));
            }
            if (p4.containsKey("android.media.metadata.DURATION") != 0) {
                p5.putLong(9, p4.getLong("android.media.metadata.DURATION"));
            }
            if (p4.containsKey("android.media.metadata.GENRE") != 0) {
                p5.putString(6, p4.getString("android.media.metadata.GENRE"));
            }
            if (p4.containsKey("android.media.metadata.TITLE") != 0) {
                p5.putString(7, p4.getString("android.media.metadata.TITLE"));
            }
            if (p4.containsKey("android.media.metadata.TRACK_NUMBER") != 0) {
                p5.putLong(0, p4.getLong("android.media.metadata.TRACK_NUMBER"));
            }
            if (p4.containsKey("android.media.metadata.WRITER") != 0) {
                p5.putString(11, p4.getString("android.media.metadata.WRITER"));
            }
        }
        return;
    }
    public static Object createRemoteControlClient(android.app.PendingIntent p1)
    {
        return new android.media.RemoteControlClient(p1);
    }
    static int getRccStateFromState(int p1)
    {
        switch (p1) {
            case 0:
                v0 = 0;
                break;
            case 1:
                v0 = 1;
                break;
            case 2:
                v0 = 2;
                break;
            case 3:
                v0 = 3;
                break;
            case 4:
                v0 = 4;
                break;
            case 5:
                v0 = 5;
                break;
            case 6:
            case 8:
                v0 = 8;
                break;
            case 7:
                v0 = 9;
                break;
            case 9:
                v0 = 7;
                break;
            case 10:
            case 11:
                v0 = 6;
                break;
            default:
                v0 = -1;
        }
        return v0;
    }
    static int getRccTransportControlFlagsFromActions(long p5)
    {
        v0 = 0;
        if ((1.0 & p5) != 0.0) {
            v0 = (0 | 32);
        }
        if ((2.0 & p5) != 0.0) {
            v0 |= 16;
        }
        if ((4.0 & p5) != 0.0) {
            v0 |= 4;
        }
        if ((8.0 & p5) != 0.0) {
            v0 |= 2;
        }
        if ((16.0 & p5) != 0.0) {
            v0 |= 1;
        }
        if ((32.0 & p5) != 0.0) {
            v0 |= 128;
        }
        if ((64.0 & p5) != 0.0) {
            v0 |= 64;
        }
        if ((512.0 & p5) != 0.0) {
            v0 |= 8;
        }
        return v0;
    }
    public static void registerRemoteControlClient(android.content.Context p2, Object p3)
    {
        p2.getSystemService("audio").registerRemoteControlClient(p3);
        return;
    }
    public static void setMetadata(Object p2, android.os.Bundle p3)
    {
        v0 = p2.editMetadata(1);
        android.support.v4.media.session.MediaSessionCompatApi14.buildOldMetadata(p3, v0);
        v0.apply();
        return;
    }
    public static void setState(Object p1, int p2)
    {
        p1.setPlaybackState(android.support.v4.media.session.MediaSessionCompatApi14.getRccStateFromState(p2));
        return;
    }
    public static void setTransportControlFlags(Object p1, long p2)
    {
        p1.setTransportControlFlags(android.support.v4.media.session.MediaSessionCompatApi14.getRccTransportControlFlagsFromActions(p2));
        return;
    }
    public static void unregisterRemoteControlClient(android.content.Context p2, Object p3)
    {
        p2.getSystemService("audio").unregisterRemoteControlClient(p3);
        return;
    }
}
