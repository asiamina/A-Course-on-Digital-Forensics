package android.support.v4.os;
public class ParcelableCompat {
    public static android.os.Parcelable$Creator newCreator(android.support.v4.os.ParcelableCompatCreatorCallbacks p2)
    {
        if (android.os.Build$VERSION.SDK_INT < 13) {
            v0 = new android.support.v4.os.ParcelableCompat$CompatCreator(p2);
        } else {
            v0 = android.support.v4.os.ParcelableCompatCreatorHoneycombMR2Stub.instantiate(p2);
        }
        return v0;
    }
    public ParcelableCompat()
    {
        return;
    }
}
