package android.support.v4.content;
 class ModernAsyncTask$3 extends java.util.concurrent.FutureTask {
    final synthetic android.support.v4.content.ModernAsyncTask this$0;
     ModernAsyncTask$3(android.support.v4.content.ModernAsyncTask p1, java.util.concurrent.Callable p2)
    {
        this.this$0 = p1;
        this(p2);
        return;
    }
    protected void done()
    {
        android.support.v4.content.ModernAsyncTask.access$300(this.this$0, this.get());
        return;
    }
}
