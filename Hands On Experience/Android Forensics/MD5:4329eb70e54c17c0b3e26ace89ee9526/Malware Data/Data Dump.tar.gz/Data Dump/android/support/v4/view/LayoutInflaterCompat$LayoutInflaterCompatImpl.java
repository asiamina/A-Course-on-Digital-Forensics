package android.support.v4.view;
interface abstract class LayoutInflaterCompat$LayoutInflaterCompatImpl {
    abstract public void setFactory();
}
