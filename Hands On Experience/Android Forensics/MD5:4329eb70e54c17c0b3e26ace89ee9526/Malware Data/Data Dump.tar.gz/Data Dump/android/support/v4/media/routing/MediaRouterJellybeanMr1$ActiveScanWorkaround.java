package android.support.v4.media.routing;
final public class MediaRouterJellybeanMr1$ActiveScanWorkaround implements java.lang.Runnable {
    private boolean mActivelyScanningWifiDisplays;
    final private android.os.Handler mHandler;
    private reflect.Method mScanWifiDisplaysMethod;
    final private android.hardware.display.DisplayManager mDisplayManager;
    final private static int WIFI_DISPLAY_SCAN_INTERVAL;
    public void setActiveScanRouteTypes(int p3)
    {
        if ((p3 & 2) == 0) {
            if (this.mActivelyScanningWifiDisplays) {
                this.mActivelyScanningWifiDisplays = 0;
                this.mHandler.removeCallbacks(this);
            }
        } else {
            if (this.mActivelyScanningWifiDisplays) {
                if (this.mScanWifiDisplaysMethod == 0) {
                    android.util.Log.w("MediaRouterJellybeanMr1", "Cannot scan for wifi displays because the DisplayManager.scanWifiDisplays() method is not available on this device.");
                } else {
                    this.mActivelyScanningWifiDisplays = 1;
                    this.mHandler.post(this);
                }
            }
        }
        return;
    }
    public MediaRouterJellybeanMr1$ActiveScanWorkaround(android.content.Context p4, android.os.Handler p5)
    {
        if (android.os.Build$VERSION.SDK_INT == 17) {
            this.mDisplayManager = p4.getSystemService("display");
            this.mHandler = p5;
            v2 = new Class[0];
            this.mScanWifiDisplaysMethod = android.hardware.display.DisplayManager.getMethod("scanWifiDisplays", v2);
            return;
        } else {
            throw new UnsupportedOperationException();
        }
    }
    public void run()
    {
        if (this.mActivelyScanningWifiDisplays) {
            v3 = new Object[0];
            this.mScanWifiDisplaysMethod.invoke(this.mDisplayManager, v3);
            this.mHandler.postDelayed(this, 15000.0);
        }
        return;
    }
}
