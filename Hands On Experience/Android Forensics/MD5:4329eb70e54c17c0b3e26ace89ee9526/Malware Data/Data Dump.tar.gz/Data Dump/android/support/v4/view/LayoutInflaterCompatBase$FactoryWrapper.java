package android.support.v4.view;
 class LayoutInflaterCompatBase$FactoryWrapper implements android.view.LayoutInflater$Factory {
    final android.support.v4.view.LayoutInflaterFactory mDelegateFactory;
     LayoutInflaterCompatBase$FactoryWrapper(android.support.v4.view.LayoutInflaterFactory p1)
    {
        this.mDelegateFactory = p1;
        return;
    }
    public android.view.View onCreateView(String p3, android.content.Context p4, android.util.AttributeSet p5)
    {
        return this.mDelegateFactory.onCreateView(0, p3, p4, p5);
    }
    public String toString()
    {
        return new StringBuilder().append(this.getClass().getName()).append("{").append(this.mDelegateFactory).append("}").toString();
    }
}
