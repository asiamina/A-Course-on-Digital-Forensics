package android.support.v4.app;
final public class NotificationCompat$WearableExtender implements android.support.v4.app.NotificationCompat$Extender {
    private int mCustomSizePreset;
    final public static int SIZE_DEFAULT;
    final private static int FLAG_HINT_SHOW_BACKGROUND_ONLY;
    final private static String KEY_DISPLAY_INTENT;
    final public static int UNSET_ACTION_INDEX;
    final public static int SIZE_XSMALL;
    final public static int SCREEN_TIMEOUT_SHORT;
    final private static int FLAG_START_SCROLL_BOTTOM;
    final private static String KEY_CONTENT_ACTION_INDEX;
    final private static String KEY_FLAGS;
    final private static String KEY_CUSTOM_SIZE_PRESET;
    final private static String KEY_HINT_SCREEN_TIMEOUT;
    final public static int SIZE_FULL_SCREEN;
    final private static String KEY_ACTIONS;
    final private static String KEY_CONTENT_ICON_GRAVITY;
    private android.app.PendingIntent mDisplayIntent;
    private int mHintScreenTimeout;
    final private static String KEY_PAGES;
    final private static int DEFAULT_CONTENT_ICON_GRAVITY;
    private int mContentIcon;
    private int mContentActionIndex;
    private int mFlags;
    final public static int SCREEN_TIMEOUT_LONG;
    final private static String KEY_GRAVITY;
    final private static String EXTRA_WEARABLE_EXTENSIONS;
    final private static int DEFAULT_GRAVITY;
    private android.graphics.Bitmap mBackground;
    final private static int FLAG_CONTENT_INTENT_AVAILABLE_OFFLINE;
    final private static String KEY_BACKGROUND;
    final private static int DEFAULT_FLAGS;
    final public static int SIZE_SMALL;
    final public static int SIZE_MEDIUM;
    final private static int FLAG_HINT_HIDE_ICON;
    final private static int FLAG_HINT_AVOID_BACKGROUND_CLIPPING;
    private java.util.ArrayList mActions;
    private java.util.ArrayList mPages;
    private int mGravity;
    final private static String KEY_CUSTOM_CONTENT_HEIGHT;
    private int mCustomContentHeight;
    private int mContentIconGravity;
    final private static String KEY_CONTENT_ICON;
    final public static int SIZE_LARGE;
    public int getContentIconGravity()
    {
        return this.mContentIconGravity;
    }
    public boolean getContentIntentAvailableOffline()
    {
        if ((this.mFlags & 1) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public int getCustomContentHeight()
    {
        return this.mCustomContentHeight;
    }
    public int getCustomSizePreset()
    {
        return this.mCustomSizePreset;
    }
    public android.app.PendingIntent getDisplayIntent()
    {
        return this.mDisplayIntent;
    }
    public int getGravity()
    {
        return this.mGravity;
    }
    public boolean getHintAvoidBackgroundClipping()
    {
        if ((this.mFlags & 16) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public boolean getHintHideIcon()
    {
        if ((this.mFlags & 2) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public int getHintScreenTimeout()
    {
        return this.mHintScreenTimeout;
    }
    public boolean getHintShowBackgroundOnly()
    {
        if ((this.mFlags & 4) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public java.util.List getPages()
    {
        return this.mPages;
    }
    public boolean getStartScrollBottom()
    {
        if ((this.mFlags & 8) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setBackground(android.graphics.Bitmap p1)
    {
        this.mBackground = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setContentAction(int p1)
    {
        this.mContentActionIndex = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setContentIcon(int p1)
    {
        this.mContentIcon = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setContentIconGravity(int p1)
    {
        this.mContentIconGravity = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setContentIntentAvailableOffline(boolean p2)
    {
        this.setFlag(1, p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setCustomContentHeight(int p1)
    {
        this.mCustomContentHeight = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setCustomSizePreset(int p1)
    {
        this.mCustomSizePreset = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setDisplayIntent(android.app.PendingIntent p1)
    {
        this.mDisplayIntent = p1;
        return this;
    }
    private void setFlag(int p3, boolean p4)
    {
        if (p4 == 0) {
            this.mFlags = (this.mFlags & (p3 ^ -1));
        } else {
            this.mFlags = (this.mFlags | p3);
        }
        return;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setGravity(int p1)
    {
        this.mGravity = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setHintAvoidBackgroundClipping(boolean p2)
    {
        this.setFlag(16, p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setHintHideIcon(boolean p2)
    {
        this.setFlag(2, p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setHintScreenTimeout(int p1)
    {
        this.mHintScreenTimeout = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setHintShowBackgroundOnly(boolean p2)
    {
        this.setFlag(4, p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender setStartScrollBottom(boolean p2)
    {
        this.setFlag(8, p2);
        return this;
    }
    public NotificationCompat$WearableExtender()
    {
        this.mActions = new java.util.ArrayList();
        this.mFlags = 1;
        this.mPages = new java.util.ArrayList();
        this.mContentIconGravity = 1.1754950514715197e-38;
        this.mContentActionIndex = -1;
        this.mCustomSizePreset = 0;
        this.mGravity = 80;
        return;
    }
    public NotificationCompat$WearableExtender(android.app.Notification p12)
    {
        this.mActions = new java.util.ArrayList();
        this.mFlags = 1;
        this.mPages = new java.util.ArrayList();
        this.mContentIconGravity = 1.1754950514715197e-38;
        this.mContentActionIndex = -1;
        this.mCustomSizePreset = 0;
        this.mGravity = 80;
        v1 = android.support.v4.app.NotificationCompat.getExtras(p12);
        if (v1 == 0) {
            v3 = 0;
        } else {
            v3 = v1.getBundle("android.wearable.EXTENSIONS");
        }
        if (v3 != 0) {
            v0 = android.support.v4.app.NotificationCompat.access$200().getActionsFromParcelableArrayList(v3.getParcelableArrayList("actions"));
            if (v0 != 0) {
                java.util.Collections.addAll(this.mActions, v0);
            }
            this.mFlags = v3.getInt("flags", 1);
            this.mDisplayIntent = v3.getParcelable("displayIntent");
            v2 = android.support.v4.app.NotificationCompat.access$500(v3, "pages");
            if (v2 != 0) {
                java.util.Collections.addAll(this.mPages, v2);
            }
            this.mBackground = v3.getParcelable("background");
            this.mContentIcon = v3.getInt("contentIcon");
            this.mContentIconGravity = v3.getInt("contentIconGravity", 1.1754950514715197e-38);
            this.mContentActionIndex = v3.getInt("contentActionIndex", -1);
            this.mCustomSizePreset = v3.getInt("customSizePreset", 0);
            this.mCustomContentHeight = v3.getInt("customContentHeight");
            this.mGravity = v3.getInt("gravity", 80);
            this.mHintScreenTimeout = v3.getInt("hintScreenTimeout");
        }
        return;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender addAction(android.support.v4.app.NotificationCompat$Action p2)
    {
        this.mActions.add(p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender addActions(java.util.List p2)
    {
        this.mActions.addAll(p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender addPage(android.app.Notification p2)
    {
        this.mPages.add(p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender addPages(java.util.List p2)
    {
        this.mPages.addAll(p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender clearActions()
    {
        this.mActions.clear();
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender clearPages()
    {
        this.mPages.clear();
        return this;
    }
    public android.support.v4.app.NotificationCompat$WearableExtender clone()
    {
        v0 = new android.support.v4.app.NotificationCompat$WearableExtender();
        v0.mActions = new java.util.ArrayList(this.mActions);
        v0.mFlags = this.mFlags;
        v0.mDisplayIntent = this.mDisplayIntent;
        v0.mPages = new java.util.ArrayList(this.mPages);
        v0.mBackground = this.mBackground;
        v0.mContentIcon = this.mContentIcon;
        v0.mContentIconGravity = this.mContentIconGravity;
        v0.mContentActionIndex = this.mContentActionIndex;
        v0.mCustomSizePreset = this.mCustomSizePreset;
        v0.mCustomContentHeight = this.mCustomContentHeight;
        v0.mGravity = this.mGravity;
        v0.mHintScreenTimeout = this.mHintScreenTimeout;
        return v0;
    }
    public synthetic bridge Object clone()
    {
        return this.clone();
    }
    public android.support.v4.app.NotificationCompat$Builder extend(android.support.v4.app.NotificationCompat$Builder p6)
    {
        v0 = new android.os.Bundle();
        if (this.mActions.isEmpty() == 0) {
            v4 = new android.support.v4.app.NotificationCompat$Action[this.mActions.size()];
            v0.putParcelableArrayList("actions", android.support.v4.app.NotificationCompat.access$200().getParcelableArrayListForActions(this.mActions.toArray(v4)));
        }
        if (this.mFlags != 1) {
            v0.putInt("flags", this.mFlags);
        }
        if (this.mDisplayIntent != 0) {
            v0.putParcelable("displayIntent", this.mDisplayIntent);
        }
        if (this.mPages.isEmpty() == 0) {
            v3 = new android.app.Notification[this.mPages.size()];
            v0.putParcelableArray("pages", this.mPages.toArray(v3));
        }
        if (this.mBackground != 0) {
            v0.putParcelable("background", this.mBackground);
        }
        if (this.mContentIcon != 0) {
            v0.putInt("contentIcon", this.mContentIcon);
        }
        if (this.mContentIconGravity != 1.1754950514715197e-38) {
            v0.putInt("contentIconGravity", this.mContentIconGravity);
        }
        if (this.mContentActionIndex != -1) {
            v0.putInt("contentActionIndex", this.mContentActionIndex);
        }
        if (this.mCustomSizePreset != 0) {
            v0.putInt("customSizePreset", this.mCustomSizePreset);
        }
        if (this.mCustomContentHeight != 0) {
            v0.putInt("customContentHeight", this.mCustomContentHeight);
        }
        if (this.mGravity != 80) {
            v0.putInt("gravity", this.mGravity);
        }
        if (this.mHintScreenTimeout != 0) {
            v0.putInt("hintScreenTimeout", this.mHintScreenTimeout);
        }
        p6.getExtras().putBundle("android.wearable.EXTENSIONS", v0);
        return p6;
    }
    public java.util.List getActions()
    {
        return this.mActions;
    }
    public android.graphics.Bitmap getBackground()
    {
        return this.mBackground;
    }
    public int getContentAction()
    {
        return this.mContentActionIndex;
    }
    public int getContentIcon()
    {
        return this.mContentIcon;
    }
}
