package android.support.v4.app;
final public class NotificationCompatExtras {
    final public static String EXTRA_ACTION_EXTRAS;
    final public static String EXTRA_GROUP_SUMMARY;
    final public static String EXTRA_GROUP_KEY;
    final public static String EXTRA_LOCAL_ONLY;
    final public static String EXTRA_REMOTE_INPUTS;
    final public static String EXTRA_SORT_KEY;
    private NotificationCompatExtras()
    {
        return;
    }
}
