package android.support.v4.util;
public interface abstract class Pools$Pool {
    abstract public Object acquire();
    abstract public boolean release();
}
