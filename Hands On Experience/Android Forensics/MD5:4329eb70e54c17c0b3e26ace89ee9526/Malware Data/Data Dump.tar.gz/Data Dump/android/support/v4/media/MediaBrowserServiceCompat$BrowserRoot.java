package android.support.v4.media;
final public class MediaBrowserServiceCompat$BrowserRoot {
    final private String mRootId;
    final private android.os.Bundle mExtras;
    public MediaBrowserServiceCompat$BrowserRoot(String p3, android.os.Bundle p4)
    {
        if (p3 != 0) {
            this.mRootId = p3;
            this.mExtras = p4;
            return;
        } else {
            throw new IllegalArgumentException("The root id in BrowserRoot cannot be null. Use null for BrowserRoot instead.");
        }
    }
    public android.os.Bundle getExtras()
    {
        return this.mExtras;
    }
    public String getRootId()
    {
        return this.mRootId;
    }
}
