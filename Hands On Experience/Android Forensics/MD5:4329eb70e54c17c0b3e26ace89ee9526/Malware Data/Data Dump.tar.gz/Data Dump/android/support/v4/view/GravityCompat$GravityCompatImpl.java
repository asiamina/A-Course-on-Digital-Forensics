package android.support.v4.view;
interface abstract class GravityCompat$GravityCompatImpl {
    abstract public void apply();
    abstract public void apply();
    abstract public void applyDisplay();
    abstract public int getAbsoluteGravity();
}
