package android.support.v4.view.accessibility;
 class AccessibilityNodeInfoCompatKitKat$CollectionItemInfo {
     AccessibilityNodeInfoCompatKitKat$CollectionItemInfo()
    {
        return;
    }
    static int getColumnIndex(Object p1)
    {
        return p1.getColumnIndex();
    }
    static int getColumnSpan(Object p1)
    {
        return p1.getColumnSpan();
    }
    static int getRowIndex(Object p1)
    {
        return p1.getRowIndex();
    }
    static int getRowSpan(Object p1)
    {
        return p1.getRowSpan();
    }
    static boolean isHeading(Object p1)
    {
        return p1.isHeading();
    }
}
