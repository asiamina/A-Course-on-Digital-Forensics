package android.support.v4.view.accessibility;
public class AccessibilityNodeInfoCompat$CollectionItemInfoCompat {
    final private Object mInfo;
    private AccessibilityNodeInfoCompat$CollectionItemInfoCompat(Object p1)
    {
        this.mInfo = p1;
        return;
    }
    synthetic AccessibilityNodeInfoCompat$CollectionItemInfoCompat(Object p1, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$1 p2)
    {
        this(p1);
        return;
    }
    static synthetic Object access$300(android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$CollectionItemInfoCompat p1)
    {
        return p1.mInfo;
    }
    public int getColumnIndex()
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.access$000().getCollectionItemColumnIndex(this.mInfo);
    }
    public int getColumnSpan()
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.access$000().getCollectionItemColumnSpan(this.mInfo);
    }
    public int getRowIndex()
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.access$000().getCollectionItemRowIndex(this.mInfo);
    }
    public int getRowSpan()
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.access$000().getCollectionItemRowSpan(this.mInfo);
    }
    public boolean isHeading()
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.access$000().isCollectionItemHeading(this.mInfo);
    }
    public boolean isSelected()
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.access$000().isCollectionItemSelected(this.mInfo);
    }
    public static android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$CollectionItemInfoCompat obtain(int p8, int p9, int p10, int p11, boolean p12, boolean p13)
    {
        return new android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$CollectionItemInfoCompat(android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.access$000().obtainCollectionItemInfo(p8, p9, p10, p11, p12, p13));
    }
}
