package android.support.v4.media;
 class MediaBrowserServiceCompat$ServiceBinder$1 implements java.lang.Runnable {
    final synthetic String val$pkg;
    final synthetic int val$uid;
    final synthetic android.os.Bundle val$rootHints;
    final synthetic android.support.v4.media.IMediaBrowserServiceCompatCallbacks val$callbacks;
    final synthetic android.support.v4.media.MediaBrowserServiceCompat$ServiceBinder this$1;
     MediaBrowserServiceCompat$ServiceBinder$1(android.support.v4.media.MediaBrowserServiceCompat$ServiceBinder p1, android.support.v4.media.IMediaBrowserServiceCompatCallbacks p2, String p3, android.os.Bundle p4, int p5)
    {
        this.this$1 = p1;
        this.val$callbacks = p2;
        this.val$pkg = p3;
        this.val$rootHints = p4;
        this.val$uid = p5;
        return;
    }
    public void run()
    {
        v0 = this.val$callbacks.asBinder();
        android.support.v4.media.MediaBrowserServiceCompat.access$100(this.this$1.this$0).remove(v0);
        v1 = new android.support.v4.media.MediaBrowserServiceCompat$ConnectionRecord(this.this$1.this$0, 0);
        v1.pkg = this.val$pkg;
        v1.rootHints = this.val$rootHints;
        v1.callbacks = this.val$callbacks;
        v1.root = this.this$1.this$0.onGetRoot(this.val$pkg, this.val$uid, this.val$rootHints);
        if (v1.root != 0) {
            android.support.v4.media.MediaBrowserServiceCompat.access$100(this.this$1.this$0).put(v0, v1);
            if (this.this$1.this$0.mSession != 0) {
                this.val$callbacks.onConnect(v1.root.getRootId(), this.this$1.this$0.mSession, v1.root.getExtras());
            }
        } else {
            android.util.Log.i("MediaBrowserServiceCompat", new StringBuilder().append("No root for client ").append(this.val$pkg).append(" from service ").append(this.getClass().getName()).toString());
            this.val$callbacks.onConnectFailed();
        }
        return;
    }
}
