package android.support.v4.graphics.drawable;
 class DrawableWrapperKitKat$DrawableWrapperStateKitKat extends android.support.v4.graphics.drawable.DrawableWrapperDonut$DrawableWrapperState {
     DrawableWrapperKitKat$DrawableWrapperStateKitKat(android.support.v4.graphics.drawable.DrawableWrapperDonut$DrawableWrapperState p1, android.content.res.Resources p2)
    {
        this(p1, p2);
        return;
    }
    public android.graphics.drawable.Drawable newDrawable(android.content.res.Resources p2)
    {
        return new android.support.v4.graphics.drawable.DrawableWrapperKitKat(this, p2);
    }
}
