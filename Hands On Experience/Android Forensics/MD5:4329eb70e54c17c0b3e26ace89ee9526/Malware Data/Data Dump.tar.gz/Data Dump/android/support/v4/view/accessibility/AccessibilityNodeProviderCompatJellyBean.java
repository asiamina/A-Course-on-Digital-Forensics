package android.support.v4.view.accessibility;
 class AccessibilityNodeProviderCompatJellyBean {
     AccessibilityNodeProviderCompatJellyBean()
    {
        return;
    }
    public static Object newAccessibilityNodeProviderBridge(android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge p1)
    {
        return new android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$1(p1);
    }
}
