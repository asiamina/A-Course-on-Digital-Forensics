package android.support.v4.content;
 class ContextCompatApi23 {
     ContextCompatApi23()
    {
        return;
    }
    public static int getColor(android.content.Context p1, int p2)
    {
        return p1.getColor(p2);
    }
    public static android.content.res.ColorStateList getColorStateList(android.content.Context p1, int p2)
    {
        return p1.getColorStateList(p2);
    }
}
