package android.support.v4.hardware.fingerprint;
public class FingerprintManagerCompatApi23$CryptoObject {
    final private javax.crypto.Mac mMac;
    final private javax.crypto.Cipher mCipher;
    final private java.security.Signature mSignature;
    public FingerprintManagerCompatApi23$CryptoObject(java.security.Signature p2)
    {
        this.mSignature = p2;
        this.mCipher = 0;
        this.mMac = 0;
        return;
    }
    public FingerprintManagerCompatApi23$CryptoObject(javax.crypto.Cipher p2)
    {
        this.mCipher = p2;
        this.mSignature = 0;
        this.mMac = 0;
        return;
    }
    public FingerprintManagerCompatApi23$CryptoObject(javax.crypto.Mac p2)
    {
        this.mMac = p2;
        this.mCipher = 0;
        this.mSignature = 0;
        return;
    }
    public javax.crypto.Cipher getCipher()
    {
        return this.mCipher;
    }
    public javax.crypto.Mac getMac()
    {
        return this.mMac;
    }
    public java.security.Signature getSignature()
    {
        return this.mSignature;
    }
}
