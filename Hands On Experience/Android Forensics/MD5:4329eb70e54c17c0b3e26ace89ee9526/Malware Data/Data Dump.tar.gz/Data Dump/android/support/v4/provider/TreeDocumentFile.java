package android.support.v4.provider;
 class TreeDocumentFile extends android.support.v4.provider.DocumentFile {
    private android.net.Uri mUri;
    private android.content.Context mContext;
    public long length()
    {
        return android.support.v4.provider.DocumentsContractApi19.length(this.mContext, this.mUri);
    }
    public android.support.v4.provider.DocumentFile[] listFiles()
    {
        v1 = android.support.v4.provider.DocumentsContractApi21.listFiles(this.mContext, this.mUri);
        v2 = new android.support.v4.provider.DocumentFile[v1.length];
        v0 = 0;
        while (v0 < v1.length) {
            v2[v0] = new android.support.v4.provider.TreeDocumentFile(this, this.mContext, v1[v0]);
            v0++;
        }
        return v2;
    }
    public boolean renameTo(String p4)
    {
        v0 = android.support.v4.provider.DocumentsContractApi21.renameTo(this.mContext, this.mUri, p4);
        if (v0 == 0) {
            v1 = 0;
        } else {
            this.mUri = v0;
            v1 = 1;
        }
        return v1;
    }
     TreeDocumentFile(android.support.v4.provider.DocumentFile p1, android.content.Context p2, android.net.Uri p3)
    {
        this(p1);
        this.mContext = p2;
        this.mUri = p3;
        return;
    }
    public boolean canRead()
    {
        return android.support.v4.provider.DocumentsContractApi19.canRead(this.mContext, this.mUri);
    }
    public boolean canWrite()
    {
        return android.support.v4.provider.DocumentsContractApi19.canWrite(this.mContext, this.mUri);
    }
    public android.support.v4.provider.DocumentFile createDirectory(String p4)
    {
        v0 = android.support.v4.provider.DocumentsContractApi21.createDirectory(this.mContext, this.mUri, p4);
        if (v0 == 0) {
            v1 = 0;
        } else {
            v1 = new android.support.v4.provider.TreeDocumentFile(this, this.mContext, v0);
        }
        return v1;
    }
    public android.support.v4.provider.DocumentFile createFile(String p4, String p5)
    {
        v0 = android.support.v4.provider.DocumentsContractApi21.createFile(this.mContext, this.mUri, p4, p5);
        if (v0 == 0) {
            v1 = 0;
        } else {
            v1 = new android.support.v4.provider.TreeDocumentFile(this, this.mContext, v0);
        }
        return v1;
    }
    public boolean delete()
    {
        return android.support.v4.provider.DocumentsContractApi19.delete(this.mContext, this.mUri);
    }
    public boolean exists()
    {
        return android.support.v4.provider.DocumentsContractApi19.exists(this.mContext, this.mUri);
    }
    public String getName()
    {
        return android.support.v4.provider.DocumentsContractApi19.getName(this.mContext, this.mUri);
    }
    public String getType()
    {
        return android.support.v4.provider.DocumentsContractApi19.getType(this.mContext, this.mUri);
    }
    public android.net.Uri getUri()
    {
        return this.mUri;
    }
    public boolean isDirectory()
    {
        return android.support.v4.provider.DocumentsContractApi19.isDirectory(this.mContext, this.mUri);
    }
    public boolean isFile()
    {
        return android.support.v4.provider.DocumentsContractApi19.isFile(this.mContext, this.mUri);
    }
    public long lastModified()
    {
        return android.support.v4.provider.DocumentsContractApi19.lastModified(this.mContext, this.mUri);
    }
}
