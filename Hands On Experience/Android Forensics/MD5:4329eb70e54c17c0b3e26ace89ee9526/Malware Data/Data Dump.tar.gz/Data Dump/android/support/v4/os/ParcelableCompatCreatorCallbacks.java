package android.support.v4.os;
public interface abstract class ParcelableCompatCreatorCallbacks {
    abstract public Object createFromParcel();
    abstract public Object[] newArray();
}
