package android.support.v4.content;
public class IntentCompat {
    final public static String ACTION_EXTERNAL_APPLICATIONS_UNAVAILABLE;
    final public static int FLAG_ACTIVITY_TASK_ON_HOME;
    final public static String ACTION_EXTERNAL_APPLICATIONS_AVAILABLE;
    final public static String EXTRA_HTML_TEXT;
    final public static String EXTRA_CHANGED_UID_LIST;
    final public static String EXTRA_CHANGED_PACKAGE_LIST;
    final public static int FLAG_ACTIVITY_CLEAR_TASK;
    final private static android.support.v4.content.IntentCompat$IntentCompatImpl IMPL;
    public static android.content.Intent makeRestartActivityTask(android.content.ComponentName p1)
    {
        return android.support.v4.content.IntentCompat.IMPL.makeRestartActivityTask(p1);
    }
    static IntentCompat()
    {
        v0 = android.os.Build$VERSION.SDK_INT;
        if (v0 < 15) {
            if (v0 < 11) {
                android.support.v4.content.IntentCompat.IMPL = new android.support.v4.content.IntentCompat$IntentCompatImplBase();
            } else {
                android.support.v4.content.IntentCompat.IMPL = new android.support.v4.content.IntentCompat$IntentCompatImplHC();
            }
        } else {
            android.support.v4.content.IntentCompat.IMPL = new android.support.v4.content.IntentCompat$IntentCompatImplIcsMr1();
        }
        return;
    }
    private IntentCompat()
    {
        return;
    }
    public static android.content.Intent makeMainActivity(android.content.ComponentName p1)
    {
        return android.support.v4.content.IntentCompat.IMPL.makeMainActivity(p1);
    }
    public static android.content.Intent makeMainSelectorActivity(String p1, String p2)
    {
        return android.support.v4.content.IntentCompat.IMPL.makeMainSelectorActivity(p1, p2);
    }
}
