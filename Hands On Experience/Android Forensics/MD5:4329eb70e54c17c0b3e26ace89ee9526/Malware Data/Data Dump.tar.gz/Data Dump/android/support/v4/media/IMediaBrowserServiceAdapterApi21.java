package android.support.v4.media;
 class IMediaBrowserServiceAdapterApi21 {
     IMediaBrowserServiceAdapterApi21()
    {
        return;
    }
}
