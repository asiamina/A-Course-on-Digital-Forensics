package android.support.v4.text;
 class ICUCompat$ICUCompatImplLollipop implements android.support.v4.text.ICUCompat$ICUCompatImpl {
    public String maximizeAndGetScript(java.util.Locale p2)
    {
        return android.support.v4.text.ICUCompatApi23.maximizeAndGetScript(p2);
    }
     ICUCompat$ICUCompatImplLollipop()
    {
        return;
    }
}
