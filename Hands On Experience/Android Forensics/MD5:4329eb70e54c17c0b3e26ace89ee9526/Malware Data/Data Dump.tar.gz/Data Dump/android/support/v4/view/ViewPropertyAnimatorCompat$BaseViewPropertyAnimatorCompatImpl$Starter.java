package android.support.v4.view;
 class ViewPropertyAnimatorCompat$BaseViewPropertyAnimatorCompatImpl$Starter implements java.lang.Runnable {
     ref.WeakReference mViewRef;
     android.support.v4.view.ViewPropertyAnimatorCompat mVpa;
    final synthetic android.support.v4.view.ViewPropertyAnimatorCompat$BaseViewPropertyAnimatorCompatImpl this$0;
    private ViewPropertyAnimatorCompat$BaseViewPropertyAnimatorCompatImpl$Starter(android.support.v4.view.ViewPropertyAnimatorCompat$BaseViewPropertyAnimatorCompatImpl p2, android.support.v4.view.ViewPropertyAnimatorCompat p3, android.view.View p4)
    {
        this.this$0 = p2;
        this.mViewRef = new ref.WeakReference(p4);
        this.mVpa = p3;
        return;
    }
    synthetic ViewPropertyAnimatorCompat$BaseViewPropertyAnimatorCompatImpl$Starter(android.support.v4.view.ViewPropertyAnimatorCompat$BaseViewPropertyAnimatorCompatImpl p1, android.support.v4.view.ViewPropertyAnimatorCompat p2, android.view.View p3, android.support.v4.view.ViewPropertyAnimatorCompat$1 p4)
    {
        this(p1, p2, p3);
        return;
    }
    public void run()
    {
        v0 = this.mViewRef.get();
        if (v0 != 0) {
            android.support.v4.view.ViewPropertyAnimatorCompat$BaseViewPropertyAnimatorCompatImpl.access$200(this.this$0, this.mVpa, v0);
        }
        return;
    }
}
