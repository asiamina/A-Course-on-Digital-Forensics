package android.support.v4.view;
 class ViewPropertyAnimatorCompat$LollipopViewPropertyAnimatorCompatImpl extends android.support.v4.view.ViewPropertyAnimatorCompat$KitKatViewPropertyAnimatorCompatImpl {
    public void translationZ(android.support.v4.view.ViewPropertyAnimatorCompat p1, android.view.View p2, float p3)
    {
        android.support.v4.view.ViewPropertyAnimatorCompatLollipop.translationZ(p2, p3);
        return;
    }
    public void translationZBy(android.support.v4.view.ViewPropertyAnimatorCompat p1, android.view.View p2, float p3)
    {
        android.support.v4.view.ViewPropertyAnimatorCompatLollipop.translationZBy(p2, p3);
        return;
    }
    public void z(android.support.v4.view.ViewPropertyAnimatorCompat p1, android.view.View p2, float p3)
    {
        android.support.v4.view.ViewPropertyAnimatorCompatLollipop.z(p2, p3);
        return;
    }
    public void zBy(android.support.v4.view.ViewPropertyAnimatorCompat p1, android.view.View p2, float p3)
    {
        android.support.v4.view.ViewPropertyAnimatorCompatLollipop.zBy(p2, p3);
        return;
    }
     ViewPropertyAnimatorCompat$LollipopViewPropertyAnimatorCompatImpl()
    {
        return;
    }
}
