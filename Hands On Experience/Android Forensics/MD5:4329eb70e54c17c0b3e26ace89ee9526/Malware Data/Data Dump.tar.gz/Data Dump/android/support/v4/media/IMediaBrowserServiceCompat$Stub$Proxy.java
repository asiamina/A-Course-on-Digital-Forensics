package android.support.v4.media;
 class IMediaBrowserServiceCompat$Stub$Proxy implements android.support.v4.media.IMediaBrowserServiceCompat {
    private android.os.IBinder mRemote;
     IMediaBrowserServiceCompat$Stub$Proxy(android.os.IBinder p1)
    {
        this.mRemote = p1;
        return;
    }
    public void addSubscription(String p6, android.support.v4.media.IMediaBrowserServiceCompatCallbacks p7)
    {
        v1 = 0;
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.IMediaBrowserServiceCompat");
        v0.writeString(p6);
        if (p7 != 0) {
            v1 = p7.asBinder();
        }
        v0.writeStrongBinder(v1);
        this.mRemote.transact(3, v0, 0, 1);
        v0.recycle();
        return;
    }
    public android.os.IBinder asBinder()
    {
        return this.mRemote;
    }
    public void connect(String p6, android.os.Bundle p7, android.support.v4.media.IMediaBrowserServiceCompatCallbacks p8)
    {
        v1 = 0;
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.IMediaBrowserServiceCompat");
        v0.writeString(p6);
        if (p7 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            p7.writeToParcel(v0, 0);
        }
        if (p8 != 0) {
            v1 = p8.asBinder();
        }
        v0.writeStrongBinder(v1);
        this.mRemote.transact(1, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void disconnect(android.support.v4.media.IMediaBrowserServiceCompatCallbacks p6)
    {
        v1 = 0;
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.IMediaBrowserServiceCompat");
        if (p6 != 0) {
            v1 = p6.asBinder();
        }
        v0.writeStrongBinder(v1);
        this.mRemote.transact(2, v0, 0, 1);
        v0.recycle();
        return;
    }
    public String getInterfaceDescriptor()
    {
        return "android.support.v4.media.IMediaBrowserServiceCompat";
    }
    public void getMediaItem(String p6, android.support.v4.os.ResultReceiver p7)
    {
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.IMediaBrowserServiceCompat");
        v0.writeString(p6);
        if (p7 == 0) {
            v0.writeInt(0);
        } else {
            v0.writeInt(1);
            p7.writeToParcel(v0, 0);
        }
        this.mRemote.transact(5, v0, 0, 1);
        v0.recycle();
        return;
    }
    public void removeSubscription(String p6, android.support.v4.media.IMediaBrowserServiceCompatCallbacks p7)
    {
        v1 = 0;
        v0 = android.os.Parcel.obtain();
        v0.writeInterfaceToken("android.support.v4.media.IMediaBrowserServiceCompat");
        v0.writeString(p6);
        if (p7 != 0) {
            v1 = p7.asBinder();
        }
        v0.writeStrongBinder(v1);
        this.mRemote.transact(4, v0, 0, 1);
        v0.recycle();
        return;
    }
}
