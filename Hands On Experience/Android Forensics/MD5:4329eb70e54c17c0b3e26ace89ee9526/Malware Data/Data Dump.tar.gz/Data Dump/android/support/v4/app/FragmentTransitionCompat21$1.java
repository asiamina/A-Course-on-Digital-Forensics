package android.support.v4.app;
final class FragmentTransitionCompat21$1 extends android.transition.Transition$EpicenterCallback {
    final synthetic android.graphics.Rect val$epicenter;
     FragmentTransitionCompat21$1(android.graphics.Rect p1)
    {
        this.val$epicenter = p1;
        return;
    }
    public android.graphics.Rect onGetEpicenter(android.transition.Transition p2)
    {
        return this.val$epicenter;
    }
}
