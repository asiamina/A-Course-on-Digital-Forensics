package android.support.v4.net;
 class ConnectivityManagerCompat$HoneycombMR2ConnectivityManagerCompatImpl implements android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl {
     ConnectivityManagerCompat$HoneycombMR2ConnectivityManagerCompatImpl()
    {
        return;
    }
    public boolean isActiveNetworkMetered(android.net.ConnectivityManager p2)
    {
        return android.support.v4.net.ConnectivityManagerCompatHoneycombMR2.isActiveNetworkMetered(p2);
    }
}
