package android.support.v4.widget;
public class PopupWindowCompat {
    final static android.support.v4.widget.PopupWindowCompat$PopupWindowImpl IMPL;
    static PopupWindowCompat()
    {
        v0 = android.os.Build$VERSION.SDK_INT;
        if (v0 < 23) {
            if (v0 < 21) {
                if (v0 < 19) {
                    if (v0 < 9) {
                        android.support.v4.widget.PopupWindowCompat.IMPL = new android.support.v4.widget.PopupWindowCompat$BasePopupWindowImpl();
                    } else {
                        android.support.v4.widget.PopupWindowCompat.IMPL = new android.support.v4.widget.PopupWindowCompat$GingerbreadPopupWindowImpl();
                    }
                } else {
                    android.support.v4.widget.PopupWindowCompat.IMPL = new android.support.v4.widget.PopupWindowCompat$KitKatPopupWindowImpl();
                }
            } else {
                android.support.v4.widget.PopupWindowCompat.IMPL = new android.support.v4.widget.PopupWindowCompat$Api21PopupWindowImpl();
            }
        } else {
            android.support.v4.widget.PopupWindowCompat.IMPL = new android.support.v4.widget.PopupWindowCompat$Api23PopupWindowImpl();
        }
        return;
    }
    private PopupWindowCompat()
    {
        return;
    }
    public static boolean getOverlapAnchor(android.widget.PopupWindow p1)
    {
        return android.support.v4.widget.PopupWindowCompat.IMPL.getOverlapAnchor(p1);
    }
    public static int getWindowLayoutType(android.widget.PopupWindow p1)
    {
        return android.support.v4.widget.PopupWindowCompat.IMPL.getWindowLayoutType(p1);
    }
    public static void setOverlapAnchor(android.widget.PopupWindow p1, boolean p2)
    {
        android.support.v4.widget.PopupWindowCompat.IMPL.setOverlapAnchor(p1, p2);
        return;
    }
    public static void setWindowLayoutType(android.widget.PopupWindow p1, int p2)
    {
        android.support.v4.widget.PopupWindowCompat.IMPL.setWindowLayoutType(p1, p2);
        return;
    }
    public static void showAsDropDown(android.widget.PopupWindow p6, android.view.View p7, int p8, int p9, int p10)
    {
        android.support.v4.widget.PopupWindowCompat.IMPL.showAsDropDown(p6, p7, p8, p9, p10);
        return;
    }
}
