package android.support.v4.app;
 class ActivityCompat21 {
    public static void setMediaController(android.app.Activity p0, Object p1)
    {
        p0.setMediaController(p1);
        return;
    }
    public static void startPostponedEnterTransition(android.app.Activity p0)
    {
        p0.startPostponedEnterTransition();
        return;
    }
     ActivityCompat21()
    {
        return;
    }
    private static android.app.SharedElementCallback createCallback(android.support.v4.app.ActivityCompat21$SharedElementCallback21 p1)
    {
        v0 = 0;
        if (p1 != 0) {
            v0 = new android.support.v4.app.ActivityCompat21$SharedElementCallbackImpl(p1);
        }
        return v0;
    }
    public static void finishAfterTransition(android.app.Activity p0)
    {
        p0.finishAfterTransition();
        return;
    }
    public static void postponeEnterTransition(android.app.Activity p0)
    {
        p0.postponeEnterTransition();
        return;
    }
    public static void setEnterSharedElementCallback(android.app.Activity p1, android.support.v4.app.ActivityCompat21$SharedElementCallback21 p2)
    {
        p1.setEnterSharedElementCallback(android.support.v4.app.ActivityCompat21.createCallback(p2));
        return;
    }
    public static void setExitSharedElementCallback(android.app.Activity p1, android.support.v4.app.ActivityCompat21$SharedElementCallback21 p2)
    {
        p1.setExitSharedElementCallback(android.support.v4.app.ActivityCompat21.createCallback(p2));
        return;
    }
}
