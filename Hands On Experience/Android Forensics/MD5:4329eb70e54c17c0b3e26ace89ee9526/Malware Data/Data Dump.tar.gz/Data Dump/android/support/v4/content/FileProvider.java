package android.support.v4.content;
public class FileProvider extends android.content.ContentProvider {
    final private static String TAG_CACHE_PATH;
    private static java.util.HashMap sCache;
    private android.support.v4.content.FileProvider$PathStrategy mStrategy;
    final private static String TAG_FILES_PATH;
    final private static java.io.File DEVICE_ROOT;
    final private static String ATTR_NAME;
    final private static String META_DATA_FILE_PROVIDER_PATHS;
    final private static String TAG_ROOT_PATH;
    final private static String ATTR_PATH;
    final private static String TAG_EXTERNAL;
    final private static String[] COLUMNS;
    public FileProvider()
    {
        return;
    }
    public void attachInfo(android.content.Context p3, android.content.pm.ProviderInfo p4)
    {
        super.attachInfo(p3, p4);
        if (!p4.exported) {
            if (p4.grantUriPermissions) {
                this.mStrategy = android.support.v4.content.FileProvider.getPathStrategy(p3, p4.authority);
                return;
            } else {
                throw new SecurityException("Provider must grant uri permissions");
            }
        } else {
            throw new SecurityException("Provider must not be exported");
        }
    }
    private static varargs java.io.File buildPath(java.io.File p6, String[] p7)
    {
        v0 = p7;
        v4 = v0.length;
        v3 = 0;
        v2 = p6;
        while (v3 < v4) {
            v5 = v0[v3];
            if (v5 == 0) {
                v1 = v2;
            } else {
                v1 = new java.io.File(v2, v5);
            }
            v3++;
            v2 = v1;
        }
        return v2;
    }
    private static Object[] copyOf(Object[] p2, int p3)
    {
        v0 = new Object[p3];
        System.arraycopy(p2, 0, v0, 0, p3);
        return v0;
    }
    private static String[] copyOf(String[] p2, int p3)
    {
        v0 = new String[p3];
        System.arraycopy(p2, 0, v0, 0, p3);
        return v0;
    }
    public int delete(android.net.Uri p3, String p4, String[] p5)
    {
        if (this.mStrategy.getFileForUri(p3).delete() == 0) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        return v1;
    }
    private static android.support.v4.content.FileProvider$PathStrategy getPathStrategy(android.content.Context p5, String p6)
    {
        v1 = android.support.v4.content.FileProvider.sCache.get(p6);
        if (v1 == 0) {
            v1 = android.support.v4.content.FileProvider.parsePathStrategy(p5, p6);
            android.support.v4.content.FileProvider.sCache.put(p6, v1);
        }
        return v1;
    }
    public String getType(android.net.Uri p7)
    {
        v1 = this.mStrategy.getFileForUri(p7);
        v2 = v1.getName().lastIndexOf(46);
        if (v2 < 0) {
            v3 = "application/octet-stream";
        } else {
            v3 = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(v1.getName().substring((v2 + 1)));
            }
        }
        return v3;
    }
    public static android.net.Uri getUriForFile(android.content.Context p2, String p3, java.io.File p4)
    {
        return android.support.v4.content.FileProvider.getPathStrategy(p2, p3).getUriForFile(p4);
    }
    public android.net.Uri insert(android.net.Uri p3, android.content.ContentValues p4)
    {
        throw new UnsupportedOperationException("No external inserts");
    }
    private static int modeToMode(String p4)
    {
        if ("r".equals(p4) == 0) {
            if (("w".equals(p4) == 0) && ("wt".equals(p4) == 0)) {
                if ("wa".equals(p4) == 0) {
                    if ("rw".equals(p4) == 0) {
                        if ("rwt".equals(p4) == 0) {
                            throw new IllegalArgumentException(new StringBuilder().append("Invalid mode: ").append(p4).toString());
                        } else {
                            v0 = 0.0078125;
                        }
                    } else {
                        v0 = 3.0517578125e-05;
                    }
                } else {
                    v0 = 1.1368683772161603e-13;
                }
            } else {
                v0 = 1.8189894035458565e-12;
            }
        } else {
            v0 = 2.524354896707238e-29;
        }
        return v0;
    }
    public boolean onCreate()
    {
        return 1;
    }
    public android.os.ParcelFileDescriptor openFile(android.net.Uri p4, String p5)
    {
        return android.os.ParcelFileDescriptor.open(this.mStrategy.getFileForUri(p4), android.support.v4.content.FileProvider.modeToMode(p5));
    }
    private static android.support.v4.content.FileProvider$PathStrategy parsePathStrategy(android.content.Context p13, String p14)
    {
        v4 = new android.support.v4.content.FileProvider$SimplePathStrategy(p14);
        v0 = p13.getPackageManager().resolveContentProvider(p14, 128).loadXmlMetaData(p13.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
        if (v0 == 0) {
            throw new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
        }
        while(true) {
            v7 = v0.next();
            if (v7 == 1) {
                break;
            }
            if (v7 == 2) {
                v5 = v0.getName();
                v2 = v0.getAttributeValue(0, "name");
                v3 = v0.getAttributeValue(0, "path");
                v6 = 0;
                if ("root-path".equals(v5) == 0) {
                    if ("files-path".equals(v5) == 0) {
                        if ("cache-path".equals(v5) == 0) {
                            if ("external-path".equals(v5) != 0) {
                                v8 = android.os.Environment.getExternalStorageDirectory();
                                v9 = new String[1];
                                v9[0] = v3;
                                v6 = android.support.v4.content.FileProvider.buildPath(v8, v9);
                            }
                        } else {
                            v8 = p13.getCacheDir();
                            v9 = new String[1];
                            v9[0] = v3;
                            v6 = android.support.v4.content.FileProvider.buildPath(v8, v9);
                        }
                    } else {
                        v8 = p13.getFilesDir();
                        v9 = new String[1];
                        v9[0] = v3;
                        v6 = android.support.v4.content.FileProvider.buildPath(v8, v9);
                    }
                } else {
                    v9 = new String[1];
                    v9[0] = v3;
                    v6 = android.support.v4.content.FileProvider.buildPath(android.support.v4.content.FileProvider.DEVICE_ROOT, v9);
                }
                if (v6 != 0) {
                    v4.addRoot(v2, v6);
                }
            }
        }
        return v4;
    }
    public android.database.Cursor query(android.net.Uri p13, String[] p14, String p15, String[] p16, String p17)
    {
        v4 = this.mStrategy.getFileForUri(p13);
        if (p14 == 0) {
            p14 = android.support.v4.content.FileProvider.COLUMNS;
        }
        v2 = new String[p14.length];
        v9 = new Object[p14.length];
        v0 = p14;
        v8 = v0.length;
        v7 = 0;
        v6 = 0;
        while (v7 < v8) {
            v1 = v0[v7];
            if ("_display_name".equals(v1) == 0) {
                if ("_size".equals(v1) == 0) {
                    v5 = v6;
                } else {
                    v2[v6] = "_size";
                    v5 = (v6 + 1);
                    v9[v6] = Long.valueOf(v4.length());
                }
            } else {
                v2[v6] = "_display_name";
                v5 = (v6 + 1);
                v9[v6] = v4.getName();
            }
            v7++;
            v6 = v5;
        }
        v2 = android.support.v4.content.FileProvider.copyOf(v2, v6);
        v9 = android.support.v4.content.FileProvider.copyOf(v9, v6);
        v3 = new android.database.MatrixCursor(v2, 1);
        v3.addRow(v9);
        return v3;
    }
    public int update(android.net.Uri p3, android.content.ContentValues p4, String p5, String[] p6)
    {
        throw new UnsupportedOperationException("No external updates");
    }
    static FileProvider()
    {
        v0 = new String[2];
        v0[0] = "_display_name";
        v0[1] = "_size";
        android.support.v4.content.FileProvider.COLUMNS = v0;
        android.support.v4.content.FileProvider.DEVICE_ROOT = new java.io.File("/");
        android.support.v4.content.FileProvider.sCache = new java.util.HashMap();
        return;
    }
}
