package android.support.v4.media.session;
public interface abstract class IMediaControllerCallback implements android.os.IInterface {
    abstract public void onEvent();
    abstract public void onExtrasChanged();
    abstract public void onMetadataChanged();
    abstract public void onPlaybackStateChanged();
    abstract public void onQueueChanged();
    abstract public void onQueueTitleChanged();
    abstract public void onSessionDestroyed();
    abstract public void onVolumeInfoChanged();
}
