package android.support.v4.view;
public interface abstract class ScrollingView {
    abstract public int computeHorizontalScrollExtent();
    abstract public int computeHorizontalScrollOffset();
    abstract public int computeHorizontalScrollRange();
    abstract public int computeVerticalScrollExtent();
    abstract public int computeVerticalScrollOffset();
    abstract public int computeVerticalScrollRange();
}
