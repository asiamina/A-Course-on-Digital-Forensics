package android.support.annotation;
public interface annotation abstract class RequiresPermission implements java.lang.annotation.Annotation {
    abstract public String[] allOf();
    abstract public String[] anyOf();
    abstract public boolean conditional();
    abstract public String value();
}
