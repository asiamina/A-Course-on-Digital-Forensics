package android.support.v4.content;
 class FileProvider$SimplePathStrategy implements android.support.v4.content.FileProvider$PathStrategy {
    final private java.util.HashMap mRoots;
    final private String mAuthority;
    public FileProvider$SimplePathStrategy(String p2)
    {
        this.mRoots = new java.util.HashMap();
        this.mAuthority = p2;
        return;
    }
    public void addRoot(String p5, java.io.File p6)
    {
        if (android.text.TextUtils.isEmpty(p5) == 0) {
            this.mRoots.put(p5, p6.getCanonicalFile());
            return;
        } else {
            throw new IllegalArgumentException("Name must not be empty");
        }
    }
    public java.io.File getFileForUri(android.net.Uri p10)
    {
        v2 = p10.getEncodedPath();
        v4 = v2.indexOf(47, 1);
        v5 = android.net.Uri.decode(v2.substring(1, v4));
        v2 = android.net.Uri.decode(v2.substring((v4 + 1)));
        v3 = this.mRoots.get(v5);
        if (v3 != 0) {
            v1 = new java.io.File(v3, v2).getCanonicalFile();
            if (v1.getPath().startsWith(v3.getPath()) != 0) {
                return v1;
            } else {
                throw new SecurityException("Resolved path jumped beyond configured root");
            }
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("Unable to find configured root for ").append(p10).toString());
        }
    }
    public android.net.Uri getUriForFile(java.io.File p10)
    {
        v3 = p10.getCanonicalPath();
        v2 = 0;
        v1 = this.mRoots.entrySet().iterator();
        while (v1.hasNext() != 0) {
            v4 = v1.next();
            v5 = v4.getValue().getPath();
            if ((v3.startsWith(v5) != 0) && ((v2 == 0) || (v5.length() > v2.getValue().getPath().length()))) {
                v2 = v4;
            }
        }
        if (v2 != 0) {
            v5 = v2.getValue().getPath();
            if (v5.endsWith("/") == 0) {
                v3 = v3.substring((v5.length() + 1));
            } else {
                v3 = v3.substring(v5.length());
            }
            return new android.net.Uri$Builder().scheme("content").authority(this.mAuthority).encodedPath(new StringBuilder().append(android.net.Uri.encode(v2.getKey())).append(47).append(android.net.Uri.encode(v3, "/")).toString()).build();
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("Failed to find configured root that contains ").append(v3).toString());
        }
    }
}
