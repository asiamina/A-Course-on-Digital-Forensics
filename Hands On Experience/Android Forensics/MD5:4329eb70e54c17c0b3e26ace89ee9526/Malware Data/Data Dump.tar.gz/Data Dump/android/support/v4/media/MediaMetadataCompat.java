package android.support.v4.media;
final public class MediaMetadataCompat implements android.os.Parcelable {
    final public static String METADATA_KEY_AUTHOR;
    private android.support.v4.media.MediaDescriptionCompat mDescription;
    final public static String METADATA_KEY_TRACK_NUMBER;
    final public static String METADATA_KEY_ART;
    final public static String METADATA_KEY_GENRE;
    final public static String METADATA_KEY_COMPOSER;
    final public static String METADATA_KEY_MEDIA_ID;
    final private static int METADATA_TYPE_BITMAP;
    final private static int METADATA_TYPE_LONG;
    final private static int METADATA_TYPE_TEXT;
    final public static String METADATA_KEY_DATE;
    final private android.os.Bundle mBundle;
    final public static String METADATA_KEY_ART_URI;
    final public static android.os.Parcelable$Creator CREATOR;
    final public static String METADATA_KEY_USER_RATING;
    final private static int METADATA_TYPE_RATING;
    final public static String METADATA_KEY_COMPILATION;
    final public static String METADATA_KEY_ALBUM;
    final public static String METADATA_KEY_DISC_NUMBER;
    final public static String METADATA_KEY_YEAR;
    final public static String METADATA_KEY_WRITER;
    final private static String TAG;
    final public static String METADATA_KEY_ALBUM_ART;
    final public static String METADATA_KEY_ARTIST;
    final public static String METADATA_KEY_DISPLAY_SUBTITLE;
    final private static String[] PREFERRED_DESCRIPTION_ORDER;
    final public static String METADATA_KEY_ALBUM_ART_URI;
    final public static String METADATA_KEY_RATING;
    final private static android.support.v4.util.ArrayMap METADATA_KEYS_TYPE;
    final public static String METADATA_KEY_ALBUM_ARTIST;
    private Object mMetadataObj;
    final public static String METADATA_KEY_DISPLAY_ICON;
    final public static String METADATA_KEY_DISPLAY_TITLE;
    final public static String METADATA_KEY_NUM_TRACKS;
    final public static String METADATA_KEY_DURATION;
    final private static String[] PREFERRED_BITMAP_ORDER;
    final private static String[] PREFERRED_URI_ORDER;
    final public static String METADATA_KEY_TITLE;
    final public static String METADATA_KEY_DISPLAY_ICON_URI;
    final public static String METADATA_KEY_DISPLAY_DESCRIPTION;
    public String getString(String p3)
    {
        v0 = this.mBundle.getCharSequence(p3);
        if (v0 == 0) {
            v1 = 0;
        } else {
            v1 = v0.toString();
        }
        return v1;
    }
    public CharSequence getText(String p2)
    {
        return this.mBundle.getCharSequence(p2);
    }
    public java.util.Set keySet()
    {
        return this.mBundle.keySet();
    }
    public int size()
    {
        return this.mBundle.size();
    }
    public void writeToParcel(android.os.Parcel p2, int p3)
    {
        p2.writeBundle(this.mBundle);
        return;
    }
    static MediaMetadataCompat()
    {
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE = new android.support.v4.util.ArrayMap();
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.TITLE", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.ARTIST", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DURATION", Integer.valueOf(0));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.ALBUM", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.AUTHOR", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.WRITER", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.COMPOSER", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.COMPILATION", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DATE", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.YEAR", Integer.valueOf(0));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.GENRE", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.TRACK_NUMBER", Integer.valueOf(0));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.NUM_TRACKS", Integer.valueOf(0));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DISC_NUMBER", Integer.valueOf(0));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.ALBUM_ARTIST", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.ART", Integer.valueOf(2));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.ART_URI", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.ALBUM_ART", Integer.valueOf(2));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.ALBUM_ART_URI", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.USER_RATING", Integer.valueOf(3));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.RATING", Integer.valueOf(3));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DISPLAY_TITLE", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DISPLAY_SUBTITLE", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DISPLAY_DESCRIPTION", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DISPLAY_ICON", Integer.valueOf(2));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.DISPLAY_ICON_URI", Integer.valueOf(1));
        android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.put("android.media.metadata.MEDIA_ID", Integer.valueOf(1));
        v0 = new String[7];
        v0[0] = "android.media.metadata.TITLE";
        v0[1] = "android.media.metadata.ARTIST";
        v0[2] = "android.media.metadata.ALBUM";
        v0[3] = "android.media.metadata.ALBUM_ARTIST";
        v0[4] = "android.media.metadata.WRITER";
        v0[5] = "android.media.metadata.AUTHOR";
        v0[6] = "android.media.metadata.COMPOSER";
        android.support.v4.media.MediaMetadataCompat.PREFERRED_DESCRIPTION_ORDER = v0;
        v0 = new String[3];
        v0[0] = "android.media.metadata.DISPLAY_ICON";
        v0[1] = "android.media.metadata.ART";
        v0[2] = "android.media.metadata.ALBUM_ART";
        android.support.v4.media.MediaMetadataCompat.PREFERRED_BITMAP_ORDER = v0;
        v0 = new String[3];
        v0[0] = "android.media.metadata.DISPLAY_ICON_URI";
        v0[1] = "android.media.metadata.ART_URI";
        v0[2] = "android.media.metadata.ALBUM_ART_URI";
        android.support.v4.media.MediaMetadataCompat.PREFERRED_URI_ORDER = v0;
        android.support.v4.media.MediaMetadataCompat.CREATOR = new android.support.v4.media.MediaMetadataCompat$1();
        return;
    }
    private MediaMetadataCompat(android.os.Bundle p2)
    {
        this.mBundle = new android.os.Bundle(p2);
        return;
    }
    synthetic MediaMetadataCompat(android.os.Bundle p1, android.support.v4.media.MediaMetadataCompat$1 p2)
    {
        this(p1);
        return;
    }
    private MediaMetadataCompat(android.os.Parcel p2)
    {
        this.mBundle = p2.readBundle();
        return;
    }
    synthetic MediaMetadataCompat(android.os.Parcel p1, android.support.v4.media.MediaMetadataCompat$1 p2)
    {
        this(p1);
        return;
    }
    static synthetic android.os.Bundle access$100(android.support.v4.media.MediaMetadataCompat p1)
    {
        return p1.mBundle;
    }
    static synthetic android.support.v4.util.ArrayMap access$200()
    {
        return android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE;
    }
    public boolean containsKey(String p2)
    {
        return this.mBundle.containsKey(p2);
    }
    public int describeContents()
    {
        return 0;
    }
    public static android.support.v4.media.MediaMetadataCompat fromMediaMetadata(Object p7)
    {
        if ((p7 != 0) && (android.os.Build$VERSION.SDK_INT >= 21)) {
            v0 = new android.support.v4.media.MediaMetadataCompat$Builder();
            v1 = android.support.v4.media.MediaMetadataCompatApi21.keySet(p7).iterator();
            while (v1.hasNext() != 0) {
                v2 = v1.next();
                v4 = android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.get(v2);
                if (v4 != 0) {
                    switch (v4.intValue()) {
                        case 0:
                            v0.putLong(v2, android.support.v4.media.MediaMetadataCompatApi21.getLong(p7, v2));
                            break;
                        case 1:
                            v0.putText(v2, android.support.v4.media.MediaMetadataCompatApi21.getText(p7, v2));
                            break;
                        case 2:
                            v0.putBitmap(v2, android.support.v4.media.MediaMetadataCompatApi21.getBitmap(p7, v2));
                            break;
                        case 3:
                            v0.putRating(v2, android.support.v4.media.RatingCompat.fromRating(android.support.v4.media.MediaMetadataCompatApi21.getRating(p7, v2)));
                            break;
                        default:
                            if (v1.hasNext() != 0) {
                                break;
                            }
                    }
                }
            }
            v3 = v0.build();
            v3.mMetadataObj = p7;
        } else {
            v3 = 0;
        }
        return v3;
    }
    public android.graphics.Bitmap getBitmap(String p6)
    {
        return this.mBundle.getParcelable(p6);
    }
    public android.os.Bundle getBundle()
    {
        return this.mBundle;
    }
    public android.support.v4.media.MediaDescriptionCompat getDescription()
    {
        if (this.mDescription == 0) {
            v7 = this.getString("android.media.metadata.MEDIA_ID");
            v9 = new CharSequence[3];
            v3 = 0;
            v4 = 0;
            v1 = this.getText("android.media.metadata.DISPLAY_TITLE");
            if (android.text.TextUtils.isEmpty(v1) != 0) {
                v10 = 0;
                v5 = 0;
                while ((v10 < v9.length) && (v5 < android.support.v4.media.MediaMetadataCompat.PREFERRED_DESCRIPTION_ORDER.length)) {
                    v6 = (v5 + 1);
                    v8 = this.getText(android.support.v4.media.MediaMetadataCompat.PREFERRED_DESCRIPTION_ORDER[v5]);
                    if (android.text.TextUtils.isEmpty(v8) == 0) {
                        v11 = (v10 + 1);
                        v9[v10] = v8;
                        v10 = v11;
                    }
                    v5 = v6;
                }
            } else {
                v9[0] = v1;
                v9[1] = this.getText("android.media.metadata.DISPLAY_SUBTITLE");
                v9[2] = this.getText("android.media.metadata.DISPLAY_DESCRIPTION");
            }
            v2 = 0;
            while (v2 < android.support.v4.media.MediaMetadataCompat.PREFERRED_BITMAP_ORDER.length) {
                v8 = this.getBitmap(android.support.v4.media.MediaMetadataCompat.PREFERRED_BITMAP_ORDER[v2]);
                if (v8 == 0) {
                    v2++;
                } else {
                    v3 = v8;
                    break;
                }
            }
            v2 = 0;
            while (v2 < android.support.v4.media.MediaMetadataCompat.PREFERRED_URI_ORDER.length) {
                v8 = this.getString(android.support.v4.media.MediaMetadataCompat.PREFERRED_URI_ORDER[v2]);
                if (android.text.TextUtils.isEmpty(v8) != 0) {
                    v2++;
                } else {
                    v4 = android.net.Uri.parse(v8);
                    break;
                }
            }
            v0 = new android.support.v4.media.MediaDescriptionCompat$Builder();
            v0.setMediaId(v7);
            v0.setTitle(v9[0]);
            v0.setSubtitle(v9[1]);
            v0.setDescription(v9[2]);
            v0.setIconBitmap(v3);
            v0.setIconUri(v4);
            this.mDescription = v0.build();
            v12 = this.mDescription;
        } else {
            v12 = this.mDescription;
        }
        return v12;
    }
    public long getLong(String p4)
    {
        return this.mBundle.getLong(p4, 0.0);
    }
    public Object getMediaMetadata()
    {
        if ((this.mMetadataObj == 0) && (android.os.Build$VERSION.SDK_INT >= 21)) {
            v0 = android.support.v4.media.MediaMetadataCompatApi21$Builder.newInstance();
            v1 = this.keySet().iterator();
            while (v1.hasNext() != 0) {
                v2 = v1.next();
                v3 = android.support.v4.media.MediaMetadataCompat.METADATA_KEYS_TYPE.get(v2);
                if (v3 != 0) {
                    switch (v3.intValue()) {
                        case 0:
                            android.support.v4.media.MediaMetadataCompatApi21$Builder.putLong(v0, v2, this.getLong(v2));
                            break;
                        case 1:
                            android.support.v4.media.MediaMetadataCompatApi21$Builder.putText(v0, v2, this.getText(v2));
                            break;
                        case 2:
                            android.support.v4.media.MediaMetadataCompatApi21$Builder.putBitmap(v0, v2, this.getBitmap(v2));
                            break;
                        case 3:
                            android.support.v4.media.MediaMetadataCompatApi21$Builder.putRating(v0, v2, this.getRating(v2).getRating());
                            break;
                        default:
                            if (v1.hasNext() != 0) {
                                break;
                            }
                    }
                }
            }
            this.mMetadataObj = android.support.v4.media.MediaMetadataCompatApi21$Builder.build(v0);
            v4 = this.mMetadataObj;
        } else {
            v4 = this.mMetadataObj;
        }
        return v4;
    }
    public android.support.v4.media.RatingCompat getRating(String p6)
    {
        return this.mBundle.getParcelable(p6);
    }
}
