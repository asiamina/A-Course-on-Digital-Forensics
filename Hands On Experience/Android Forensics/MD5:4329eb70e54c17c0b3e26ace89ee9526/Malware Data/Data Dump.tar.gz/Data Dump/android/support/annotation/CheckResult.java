package android.support.annotation;
public interface annotation abstract class CheckResult implements java.lang.annotation.Annotation {
    abstract public String suggest();
}
