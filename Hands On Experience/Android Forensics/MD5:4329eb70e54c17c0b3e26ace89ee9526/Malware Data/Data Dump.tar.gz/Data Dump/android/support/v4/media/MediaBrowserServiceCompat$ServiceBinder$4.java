package android.support.v4.media;
 class MediaBrowserServiceCompat$ServiceBinder$4 implements java.lang.Runnable {
    final synthetic String val$id;
    final synthetic android.support.v4.media.IMediaBrowserServiceCompatCallbacks val$callbacks;
    final synthetic android.support.v4.media.MediaBrowserServiceCompat$ServiceBinder this$1;
     MediaBrowserServiceCompat$ServiceBinder$4(android.support.v4.media.MediaBrowserServiceCompat$ServiceBinder p1, android.support.v4.media.IMediaBrowserServiceCompatCallbacks p2, String p3)
    {
        this.this$1 = p1;
        this.val$callbacks = p2;
        this.val$id = p3;
        return;
    }
    public void run()
    {
        v1 = android.support.v4.media.MediaBrowserServiceCompat.access$100(this.this$1.this$0).get(this.val$callbacks.asBinder());
        if (v1 != 0) {
            if (v1.subscriptions.remove(this.val$id) == 0) {
                android.util.Log.w("MediaBrowserServiceCompat", new StringBuilder().append("removeSubscription called for ").append(this.val$id).append(" which is not subscribed").toString());
            }
        } else {
            android.util.Log.w("MediaBrowserServiceCompat", new StringBuilder().append("removeSubscription for callback that isn\'t registered id=").append(this.val$id).toString());
        }
        return;
    }
}
