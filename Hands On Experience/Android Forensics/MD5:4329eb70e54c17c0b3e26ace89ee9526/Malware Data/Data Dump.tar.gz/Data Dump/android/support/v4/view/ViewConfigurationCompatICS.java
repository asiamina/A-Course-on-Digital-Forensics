package android.support.v4.view;
 class ViewConfigurationCompatICS {
     ViewConfigurationCompatICS()
    {
        return;
    }
    static boolean hasPermanentMenuKey(android.view.ViewConfiguration p1)
    {
        return p1.hasPermanentMenuKey();
    }
}
