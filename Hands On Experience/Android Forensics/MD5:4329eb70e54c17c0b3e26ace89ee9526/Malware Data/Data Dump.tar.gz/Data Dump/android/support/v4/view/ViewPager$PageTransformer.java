package android.support.v4.view;
public interface abstract class ViewPager$PageTransformer {
    abstract public void transformPage();
}
