package android.support.v4.view;
 class WindowInsetsCompatApi21 extends android.support.v4.view.WindowInsetsCompat {
    final private android.view.WindowInsets mSource;
     WindowInsetsCompatApi21(android.view.WindowInsets p1)
    {
        this.mSource = p1;
        return;
    }
    public android.support.v4.view.WindowInsetsCompat consumeStableInsets()
    {
        return new android.support.v4.view.WindowInsetsCompatApi21(this.mSource.consumeStableInsets());
    }
    public android.support.v4.view.WindowInsetsCompat consumeSystemWindowInsets()
    {
        return new android.support.v4.view.WindowInsetsCompatApi21(this.mSource.consumeSystemWindowInsets());
    }
    public int getStableInsetBottom()
    {
        return this.mSource.getStableInsetBottom();
    }
    public int getStableInsetLeft()
    {
        return this.mSource.getStableInsetLeft();
    }
    public int getStableInsetRight()
    {
        return this.mSource.getStableInsetRight();
    }
    public int getStableInsetTop()
    {
        return this.mSource.getStableInsetTop();
    }
    public int getSystemWindowInsetBottom()
    {
        return this.mSource.getSystemWindowInsetBottom();
    }
    public int getSystemWindowInsetLeft()
    {
        return this.mSource.getSystemWindowInsetLeft();
    }
    public int getSystemWindowInsetRight()
    {
        return this.mSource.getSystemWindowInsetRight();
    }
    public int getSystemWindowInsetTop()
    {
        return this.mSource.getSystemWindowInsetTop();
    }
    public boolean hasInsets()
    {
        return this.mSource.hasInsets();
    }
    public boolean hasStableInsets()
    {
        return this.mSource.hasStableInsets();
    }
    public boolean hasSystemWindowInsets()
    {
        return this.mSource.hasSystemWindowInsets();
    }
    public boolean isConsumed()
    {
        return this.mSource.isConsumed();
    }
    public boolean isRound()
    {
        return this.mSource.isRound();
    }
    public android.support.v4.view.WindowInsetsCompat replaceSystemWindowInsets(int p3, int p4, int p5, int p6)
    {
        return new android.support.v4.view.WindowInsetsCompatApi21(this.mSource.replaceSystemWindowInsets(p3, p4, p5, p6));
    }
    public android.support.v4.view.WindowInsetsCompat replaceSystemWindowInsets(android.graphics.Rect p3)
    {
        return new android.support.v4.view.WindowInsetsCompatApi21(this.mSource.replaceSystemWindowInsets(p3));
    }
     android.view.WindowInsets unwrap()
    {
        return this.mSource;
    }
}
