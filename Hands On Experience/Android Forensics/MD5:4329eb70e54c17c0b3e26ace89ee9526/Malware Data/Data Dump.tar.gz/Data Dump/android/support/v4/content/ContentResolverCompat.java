package android.support.v4.content;
public class ContentResolverCompat {
    final private static android.support.v4.content.ContentResolverCompat$ContentResolverCompatImpl IMPL;
    static ContentResolverCompat()
    {
        if (android.os.Build$VERSION.SDK_INT < 16) {
            android.support.v4.content.ContentResolverCompat.IMPL = new android.support.v4.content.ContentResolverCompat$ContentResolverCompatImplBase();
        } else {
            android.support.v4.content.ContentResolverCompat.IMPL = new android.support.v4.content.ContentResolverCompat$ContentResolverCompatImplJB();
        }
        return;
    }
    private ContentResolverCompat()
    {
        return;
    }
    public static android.database.Cursor query(android.content.ContentResolver p8, android.net.Uri p9, String[] p10, String p11, String[] p12, String p13, android.support.v4.os.CancellationSignal p14)
    {
        return android.support.v4.content.ContentResolverCompat.IMPL.query(p8, p9, p10, p11, p12, p13, p14);
    }
}
