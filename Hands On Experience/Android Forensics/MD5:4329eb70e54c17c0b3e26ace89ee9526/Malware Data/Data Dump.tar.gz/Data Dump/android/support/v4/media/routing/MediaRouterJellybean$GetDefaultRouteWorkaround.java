package android.support.v4.media.routing;
final public class MediaRouterJellybean$GetDefaultRouteWorkaround {
    private reflect.Method mGetSystemAudioRouteMethod;
    public MediaRouterJellybean$GetDefaultRouteWorkaround()
    {
        if ((android.os.Build$VERSION.SDK_INT >= 16) && (android.os.Build$VERSION.SDK_INT <= 17)) {
            v2 = new Class[0];
            this.mGetSystemAudioRouteMethod = android.media.MediaRouter.getMethod("getSystemAudioRoute", v2);
            return;
        } else {
            throw new UnsupportedOperationException();
        }
    }
    public Object getDefaultRoute(Object p5)
    {
        v0 = p5;
        if (this.mGetSystemAudioRouteMethod == 0) {
            v1 = v0.getRouteAt(0);
        } else {
            v2 = new Object[0];
            v1 = this.mGetSystemAudioRouteMethod.invoke(v0, v2);
        }
        return v1;
    }
}
