package android.support.v4.media.session;
final public class MediaControllerCompat {
    final private android.support.v4.media.session.MediaSessionCompat$Token mToken;
    final private static String TAG;
    final private android.support.v4.media.session.MediaControllerCompat$MediaControllerImpl mImpl;
    public android.support.v4.media.session.MediaControllerCompat$TransportControls getTransportControls()
    {
        return this.mImpl.getTransportControls();
    }
    public void registerCallback(android.support.v4.media.session.MediaControllerCompat$Callback p2)
    {
        this.registerCallback(p2, 0);
        return;
    }
    public void registerCallback(android.support.v4.media.session.MediaControllerCompat$Callback p3, android.os.Handler p4)
    {
        if (p3 != 0) {
            if (p4 == 0) {
                p4 = new android.os.Handler();
            }
            this.mImpl.registerCallback(p3, p4);
            return;
        } else {
            throw new IllegalArgumentException("callback cannot be null");
        }
    }
    public void sendCommand(String p3, android.os.Bundle p4, android.os.ResultReceiver p5)
    {
        if (android.text.TextUtils.isEmpty(p3) == 0) {
            this.mImpl.sendCommand(p3, p4, p5);
            return;
        } else {
            throw new IllegalArgumentException("command cannot be null or empty");
        }
    }
    public void setVolumeTo(int p2, int p3)
    {
        this.mImpl.setVolumeTo(p2, p3);
        return;
    }
    public void unregisterCallback(android.support.v4.media.session.MediaControllerCompat$Callback p3)
    {
        if (p3 != 0) {
            this.mImpl.unregisterCallback(p3);
            return;
        } else {
            throw new IllegalArgumentException("callback cannot be null");
        }
    }
    public MediaControllerCompat(android.content.Context p3, android.support.v4.media.session.MediaSessionCompat$Token p4)
    {
        if (p4 != 0) {
            this.mToken = p4;
            if (android.os.Build$VERSION.SDK_INT < 21) {
                this.mImpl = new android.support.v4.media.session.MediaControllerCompat$MediaControllerImplBase(this.mToken);
            } else {
                this.mImpl = new android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21(p3, p4);
            }
            return;
        } else {
            throw new IllegalArgumentException("sessionToken must not be null");
        }
    }
    public MediaControllerCompat(android.content.Context p3, android.support.v4.media.session.MediaSessionCompat p4)
    {
        if (p4 != 0) {
            this.mToken = p4.getSessionToken();
            if (android.os.Build$VERSION.SDK_INT < 23) {
                if (android.os.Build$VERSION.SDK_INT < 21) {
                    this.mImpl = new android.support.v4.media.session.MediaControllerCompat$MediaControllerImplBase(this.mToken);
                } else {
                    this.mImpl = new android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21(p3, p4);
                }
            } else {
                this.mImpl = new android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi23(p3, p4);
            }
            return;
        } else {
            throw new IllegalArgumentException("session must not be null");
        }
    }
    public void adjustVolume(int p2, int p3)
    {
        this.mImpl.adjustVolume(p2, p3);
        return;
    }
    public boolean dispatchMediaButtonEvent(android.view.KeyEvent p3)
    {
        if (p3 != 0) {
            return this.mImpl.dispatchMediaButtonEvent(p3);
        } else {
            throw new IllegalArgumentException("KeyEvent may not be null");
        }
    }
    public android.os.Bundle getExtras()
    {
        return this.mImpl.getExtras();
    }
    public long getFlags()
    {
        return this.mImpl.getFlags();
    }
    public Object getMediaController()
    {
        return this.mImpl.getMediaController();
    }
    public android.support.v4.media.MediaMetadataCompat getMetadata()
    {
        return this.mImpl.getMetadata();
    }
    public String getPackageName()
    {
        return this.mImpl.getPackageName();
    }
    public android.support.v4.media.session.MediaControllerCompat$PlaybackInfo getPlaybackInfo()
    {
        return this.mImpl.getPlaybackInfo();
    }
    public android.support.v4.media.session.PlaybackStateCompat getPlaybackState()
    {
        return this.mImpl.getPlaybackState();
    }
    public java.util.List getQueue()
    {
        return this.mImpl.getQueue();
    }
    public CharSequence getQueueTitle()
    {
        return this.mImpl.getQueueTitle();
    }
    public int getRatingType()
    {
        return this.mImpl.getRatingType();
    }
    public android.app.PendingIntent getSessionActivity()
    {
        return this.mImpl.getSessionActivity();
    }
    public android.support.v4.media.session.MediaSessionCompat$Token getSessionToken()
    {
        return this.mToken;
    }
}
