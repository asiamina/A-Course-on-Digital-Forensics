package android.support.v4.hardware.fingerprint;
final public class FingerprintManagerCompat$AuthenticationResult {
    private android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject mCryptoObject;
    public FingerprintManagerCompat$AuthenticationResult(android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject p1)
    {
        this.mCryptoObject = p1;
        return;
    }
    public android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject getCryptoObject()
    {
        return this.mCryptoObject;
    }
}
