package android.support.v4.content;
 class ContentResolverCompat$ContentResolverCompatImplBase implements android.support.v4.content.ContentResolverCompat$ContentResolverCompatImpl {
     ContentResolverCompat$ContentResolverCompatImplBase()
    {
        return;
    }
    public android.database.Cursor query(android.content.ContentResolver p2, android.net.Uri p3, String[] p4, String p5, String[] p6, String p7, android.support.v4.os.CancellationSignal p8)
    {
        if (p8 != 0) {
            p8.throwIfCanceled();
        }
        return p2.query(p3, p4, p5, p6, p7);
    }
}
