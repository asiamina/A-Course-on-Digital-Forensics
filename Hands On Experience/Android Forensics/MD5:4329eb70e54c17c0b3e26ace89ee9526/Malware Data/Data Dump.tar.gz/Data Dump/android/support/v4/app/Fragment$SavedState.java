package android.support.v4.app;
public class Fragment$SavedState implements android.os.Parcelable {
    final android.os.Bundle mState;
    final public static android.os.Parcelable$Creator CREATOR;
    public void writeToParcel(android.os.Parcel p2, int p3)
    {
        p2.writeBundle(this.mState);
        return;
    }
    static Fragment$SavedState()
    {
        android.support.v4.app.Fragment$SavedState.CREATOR = new android.support.v4.app.Fragment$SavedState$1();
        return;
    }
     Fragment$SavedState(android.os.Bundle p1)
    {
        this.mState = p1;
        return;
    }
     Fragment$SavedState(android.os.Parcel p2, ClassLoader p3)
    {
        this.mState = p2.readBundle();
        if ((p3 != 0) && (this.mState != 0)) {
            this.mState.setClassLoader(p3);
        }
        return;
    }
    public int describeContents()
    {
        return 0;
    }
}
