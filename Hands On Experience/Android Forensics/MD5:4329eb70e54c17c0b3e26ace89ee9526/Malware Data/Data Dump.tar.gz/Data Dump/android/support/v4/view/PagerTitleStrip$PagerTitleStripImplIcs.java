package android.support.v4.view;
 class PagerTitleStrip$PagerTitleStripImplIcs implements android.support.v4.view.PagerTitleStrip$PagerTitleStripImpl {
     PagerTitleStrip$PagerTitleStripImplIcs()
    {
        return;
    }
    public void setSingleLineAllCaps(android.widget.TextView p1)
    {
        android.support.v4.view.PagerTitleStripIcs.setSingleLineAllCaps(p1);
        return;
    }
}
