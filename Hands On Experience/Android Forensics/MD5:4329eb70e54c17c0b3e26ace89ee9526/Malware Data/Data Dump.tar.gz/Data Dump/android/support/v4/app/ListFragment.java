package android.support.v4.app;
public class ListFragment extends android.support.v4.app.Fragment {
     android.view.View mListContainer;
     boolean mListShown;
     android.view.View mProgressContainer;
     android.widget.TextView mStandardEmptyView;
    final private android.widget.AdapterView$OnItemClickListener mOnClickListener;
     CharSequence mEmptyText;
    final private Runnable mRequestFocus;
    final static int INTERNAL_EMPTY_ID;
     android.widget.ListView mList;
     android.widget.ListAdapter mAdapter;
    final private android.os.Handler mHandler;
     android.view.View mEmptyView;
    final static int INTERNAL_PROGRESS_CONTAINER_ID;
    final static int INTERNAL_LIST_CONTAINER_ID;
    public android.view.View onCreateView(android.view.LayoutInflater p13, android.view.ViewGroup p14, android.os.Bundle p15)
    {
        v0 = this.getActivity();
        v5 = new android.widget.FrameLayout(v0);
        v3 = new android.widget.LinearLayout(v0);
        v3.setId(2.3418054322884688e-38);
        v3.setOrientation(1);
        v3.setVisibility(8);
        v3.setGravity(17);
        v3.addView(new android.widget.ProgressBar(v0, 0, 2.369389992558703e-38), new android.widget.FrameLayout$LayoutParams(-2, -2));
        v5.addView(v3, new android.widget.FrameLayout$LayoutParams(-1, -1));
        v1 = new android.widget.FrameLayout(v0);
        v1.setId(2.3418055724183152e-38);
        v6 = new android.widget.TextView(this.getActivity());
        v6.setId(2.3418052921586223e-38);
        v6.setGravity(17);
        v1.addView(v6, new android.widget.FrameLayout$LayoutParams(-1, -1));
        v2 = new android.widget.ListView(this.getActivity());
        v2.setId(2.3877257027047e-38);
        v2.setDrawSelectorOnTop(0);
        v1.addView(v2, new android.widget.FrameLayout$LayoutParams(-1, -1));
        v5.addView(v1, new android.widget.FrameLayout$LayoutParams(-1, -1));
        v5.setLayoutParams(new android.widget.FrameLayout$LayoutParams(-1, -1));
        return v5;
    }
    public void onDestroyView()
    {
        this.mHandler.removeCallbacks(this.mRequestFocus);
        this.mList = 0;
        this.mListShown = 0;
        this.mListContainer = 0;
        this.mProgressContainer = 0;
        this.mEmptyView = 0;
        this.mStandardEmptyView = 0;
        super.onDestroyView();
        return;
    }
    public void onListItemClick(android.widget.ListView p1, android.view.View p2, int p3, long p4)
    {
        return;
    }
    public void onViewCreated(android.view.View p1, android.os.Bundle p2)
    {
        super.onViewCreated(p1, p2);
        this.ensureList();
        return;
    }
    public void setEmptyText(CharSequence p3)
    {
        this.ensureList();
        if (this.mStandardEmptyView != 0) {
            this.mStandardEmptyView.setText(p3);
            if (this.mEmptyText == 0) {
                this.mList.setEmptyView(this.mStandardEmptyView);
            }
            this.mEmptyText = p3;
            return;
        } else {
            throw new IllegalStateException("Can\'t be used with a custom content view");
        }
    }
    public void setListAdapter(android.widget.ListAdapter p5)
    {
        v2 = 0;
        if (this.mAdapter == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        this.mAdapter = p5;
        if (this.mList != 0) {
            this.mList.setAdapter(p5);
            if ((this.mListShown) && (v0 == 0)) {
                if (this.getView().getWindowToken() != 0) {
                    v2 = 1;
                }
                this.setListShown(1, v2);
            }
        }
        return;
    }
    public void setListShown(boolean p2)
    {
        this.setListShown(p2, 1);
        return;
    }
    private void setListShown(boolean p7, boolean p8)
    {
        this.ensureList();
        if (this.mProgressContainer != 0) {
            if (this.mListShown != p7) {
                this.mListShown = p7;
                if (p7 == 0) {
                    if (p8 == 0) {
                        this.mProgressContainer.clearAnimation();
                        this.mListContainer.clearAnimation();
                    } else {
                        this.mProgressContainer.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this.getActivity(), 2.5346596939605574e-38));
                        this.mListContainer.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this.getActivity(), 2.5346599742202503e-38));
                    }
                    this.mProgressContainer.setVisibility(0);
                    this.mListContainer.setVisibility(8);
                } else {
                    if (p8 == 0) {
                        this.mProgressContainer.clearAnimation();
                        this.mListContainer.clearAnimation();
                    } else {
                        this.mProgressContainer.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this.getActivity(), 2.5346599742202503e-38));
                        this.mListContainer.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this.getActivity(), 2.5346596939605574e-38));
                    }
                    this.mProgressContainer.setVisibility(8);
                    this.mListContainer.setVisibility(0);
                }
            }
            return;
        } else {
            throw new IllegalStateException("Can\'t be used with a custom content view");
        }
    }
    public void setListShownNoAnimation(boolean p2)
    {
        this.setListShown(p2, 0);
        return;
    }
    public void setSelection(int p2)
    {
        this.ensureList();
        this.mList.setSelection(p2);
        return;
    }
    public ListFragment()
    {
        this.mHandler = new android.os.Handler();
        this.mRequestFocus = new android.support.v4.app.ListFragment$1(this);
        this.mOnClickListener = new android.support.v4.app.ListFragment$2(this);
        return;
    }
    private void ensureList()
    {
        if (this.mList == 0) {
            v2 = this.getView();
            if (v2 != 0) {
                if ((v2 instanceof android.widget.ListView) == 0) {
                    this.mStandardEmptyView = v2.findViewById(2.3418052921586223e-38);
                    if (this.mStandardEmptyView != 0) {
                        this.mStandardEmptyView.setVisibility(8);
                    } else {
                        this.mEmptyView = v2.findViewById(2.387724021146543e-38);
                    }
                    this.mProgressContainer = v2.findViewById(2.3418054322884688e-38);
                    this.mListContainer = v2.findViewById(2.3418055724183152e-38);
                    v1 = v2.findViewById(2.3877257027047e-38);
                    if ((v1 instanceof android.widget.ListView) != 0) {
                        this.mList = v1;
                        if (this.mEmptyView == 0) {
                            if (this.mEmptyText != 0) {
                                this.mStandardEmptyView.setText(this.mEmptyText);
                                this.mList.setEmptyView(this.mStandardEmptyView);
                            }
                        } else {
                            this.mList.setEmptyView(this.mEmptyView);
                        }
                    } else {
                        if (v1 != 0) {
                            throw new RuntimeException("Content has view with id attribute \'android.R.id.list\' that is not a ListView class");
                        } else {
                            throw new RuntimeException("Your content must have a ListView whose id attribute is \'android.R.id.list\'");
                        }
                    }
                } else {
                    this.mList = v2;
                }
                this.mListShown = 1;
                this.mList.setOnItemClickListener(this.mOnClickListener);
                if (this.mAdapter == 0) {
                    if (this.mProgressContainer != 0) {
                        this.setListShown(0, 0);
                    }
                } else {
                    this.mAdapter = 0;
                    this.setListAdapter(this.mAdapter);
                }
                this.mHandler.post(this.mRequestFocus);
            } else {
                throw new IllegalStateException("Content view not yet created");
            }
        }
        return;
    }
    public android.widget.ListAdapter getListAdapter()
    {
        return this.mAdapter;
    }
    public android.widget.ListView getListView()
    {
        this.ensureList();
        return this.mList;
    }
    public long getSelectedItemId()
    {
        this.ensureList();
        return this.mList.getSelectedItemId();
    }
    public int getSelectedItemPosition()
    {
        this.ensureList();
        return this.mList.getSelectedItemPosition();
    }
}
