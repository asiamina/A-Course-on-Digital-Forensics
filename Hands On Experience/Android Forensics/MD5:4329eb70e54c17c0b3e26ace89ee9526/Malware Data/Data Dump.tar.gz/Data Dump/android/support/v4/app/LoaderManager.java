package android.support.v4.app;
public abstract class LoaderManager {
    public LoaderManager()
    {
        return;
    }
    abstract public void destroyLoader();
    abstract public void dump();
    public static void enableDebugLogging(boolean p0)
    {
        android.support.v4.app.LoaderManagerImpl.DEBUG = p0;
        return;
    }
    abstract public android.support.v4.content.Loader getLoader();
    public boolean hasRunningLoaders()
    {
        return 0;
    }
    abstract public android.support.v4.content.Loader initLoader();
    abstract public android.support.v4.content.Loader restartLoader();
}
