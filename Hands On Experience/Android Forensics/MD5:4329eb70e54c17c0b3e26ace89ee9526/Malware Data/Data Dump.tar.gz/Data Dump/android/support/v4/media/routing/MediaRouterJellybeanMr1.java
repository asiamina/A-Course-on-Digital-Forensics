package android.support.v4.media.routing;
 class MediaRouterJellybeanMr1 extends android.support.v4.media.routing.MediaRouterJellybean {
    final private static String TAG;
     MediaRouterJellybeanMr1()
    {
        return;
    }
    public static Object createCallback(android.support.v4.media.routing.MediaRouterJellybeanMr1$Callback p1)
    {
        return new android.support.v4.media.routing.MediaRouterJellybeanMr1$CallbackProxy(p1);
    }
}
