package android.support.annotation;
public interface annotation abstract class RequiresPermission$Write implements java.lang.annotation.Annotation {
    abstract public android.support.annotation.RequiresPermission value();
}
