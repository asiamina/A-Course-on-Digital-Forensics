package android.support.annotation;
public interface annotation abstract class StringDef implements java.lang.annotation.Annotation {
    abstract public String[] value();
}
