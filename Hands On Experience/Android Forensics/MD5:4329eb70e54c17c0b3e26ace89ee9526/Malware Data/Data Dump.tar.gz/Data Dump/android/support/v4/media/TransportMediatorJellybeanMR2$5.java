package android.support.v4.media;
 class TransportMediatorJellybeanMR2$5 implements android.media.RemoteControlClient$OnGetPlaybackPositionListener {
    final synthetic android.support.v4.media.TransportMediatorJellybeanMR2 this$0;
     TransportMediatorJellybeanMR2$5(android.support.v4.media.TransportMediatorJellybeanMR2 p1)
    {
        this.this$0 = p1;
        return;
    }
    public long onGetPlaybackPosition()
    {
        return this.this$0.mTransportCallback.getPlaybackPosition();
    }
}
