package android.support.v4.media.session;
final class PlaybackStateCompat$CustomAction$1 implements android.os.Parcelable$Creator {
     PlaybackStateCompat$CustomAction$1()
    {
        return;
    }
    public android.support.v4.media.session.PlaybackStateCompat$CustomAction createFromParcel(android.os.Parcel p3)
    {
        return new android.support.v4.media.session.PlaybackStateCompat$CustomAction(p3, 0);
    }
    public synthetic bridge Object createFromParcel(android.os.Parcel p2)
    {
        return this.createFromParcel(p2);
    }
    public android.support.v4.media.session.PlaybackStateCompat$CustomAction[] newArray(int p2)
    {
        v0 = new android.support.v4.media.session.PlaybackStateCompat$CustomAction[p2];
        return v0;
    }
    public synthetic bridge Object[] newArray(int p2)
    {
        return this.newArray(p2);
    }
}
