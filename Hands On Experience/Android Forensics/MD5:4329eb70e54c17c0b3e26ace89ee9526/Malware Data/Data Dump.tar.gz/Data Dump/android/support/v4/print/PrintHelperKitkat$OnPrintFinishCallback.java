package android.support.v4.print;
public interface abstract class PrintHelperKitkat$OnPrintFinishCallback {
    abstract public void onFinish();
}
