package android.support.v4.app;
 class FragmentManagerImpl$AnimateOnHWLayerIfNeededListener$2 implements java.lang.Runnable {
    final synthetic android.support.v4.app.FragmentManagerImpl$AnimateOnHWLayerIfNeededListener this$0;
     FragmentManagerImpl$AnimateOnHWLayerIfNeededListener$2(android.support.v4.app.FragmentManagerImpl$AnimateOnHWLayerIfNeededListener p1)
    {
        this.this$0 = p1;
        return;
    }
    public void run()
    {
        android.support.v4.view.ViewCompat.setLayerType(android.support.v4.app.FragmentManagerImpl$AnimateOnHWLayerIfNeededListener.access$000(this.this$0), 0, 0);
        return;
    }
}
