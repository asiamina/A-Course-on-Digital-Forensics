package android.support.v4.app;
 class BackStackRecord$1 implements android.support.v4.app.FragmentTransitionCompat21$ViewRetriever {
    final synthetic android.support.v4.app.Fragment val$inFragment;
    final synthetic android.support.v4.app.BackStackRecord this$0;
     BackStackRecord$1(android.support.v4.app.BackStackRecord p1, android.support.v4.app.Fragment p2)
    {
        this.this$0 = p1;
        this.val$inFragment = p2;
        return;
    }
    public android.view.View getView()
    {
        return this.val$inFragment.getView();
    }
}
