package android.support.v4.os;
public class ResultReceiver implements android.os.Parcelable {
    final android.os.Handler mHandler;
    final boolean mLocal;
     android.support.v4.os.IResultReceiver mReceiver;
    final public static android.os.Parcelable$Creator CREATOR;
    static ResultReceiver()
    {
        android.support.v4.os.ResultReceiver.CREATOR = new android.support.v4.os.ResultReceiver$1();
        return;
    }
    public ResultReceiver(android.os.Handler p2)
    {
        this.mLocal = 1;
        this.mHandler = p2;
        return;
    }
     ResultReceiver(android.os.Parcel p2)
    {
        this.mLocal = 0;
        this.mHandler = 0;
        this.mReceiver = android.support.v4.os.IResultReceiver$Stub.asInterface(p2.readStrongBinder());
        return;
    }
    public int describeContents()
    {
        return 0;
    }
    protected void onReceiveResult(int p1, android.os.Bundle p2)
    {
        return;
    }
    public void send(int p3, android.os.Bundle p4)
    {
        if (!this.mLocal) {
            if (this.mReceiver != 0) {
                this.mReceiver.send(p3, p4);
            }
        } else {
            if (this.mHandler == 0) {
                this.onReceiveResult(p3, p4);
            } else {
                this.mHandler.post(new android.support.v4.os.ResultReceiver$MyRunnable(this, p3, p4));
            }
        }
        return;
    }
    public void writeToParcel(android.os.Parcel p2, int p3)
    {
        if (this.mReceiver == 0) {
            this.mReceiver = new android.support.v4.os.ResultReceiver$MyResultReceiver(this);
        }
        p2.writeStrongBinder(this.mReceiver.asBinder());
        return;
    }
}
