package android.support.v4.media;
 class MediaBrowserServiceCompat$ServiceImpl$2 implements java.lang.Runnable {
    final synthetic android.support.v4.media.MediaBrowserServiceCompat$ServiceCallbacks val$callbacks;
    final synthetic android.support.v4.media.MediaBrowserServiceCompat$ServiceImpl this$1;
     MediaBrowserServiceCompat$ServiceImpl$2(android.support.v4.media.MediaBrowserServiceCompat$ServiceImpl p1, android.support.v4.media.MediaBrowserServiceCompat$ServiceCallbacks p2)
    {
        this.this$1 = p1;
        this.val$callbacks = p2;
        return;
    }
    public void run()
    {
        // Both branches of the conditions point to the same code.
        // if (android.support.v4.media.MediaBrowserServiceCompat.access$500(this.this$1.this$0).remove(this.val$callbacks.asBinder()) == 0) {
            return;
        // }
    }
}
