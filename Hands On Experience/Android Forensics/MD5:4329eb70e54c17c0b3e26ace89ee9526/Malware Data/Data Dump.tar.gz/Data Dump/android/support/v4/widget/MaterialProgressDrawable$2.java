package android.support.v4.widget;
 class MaterialProgressDrawable$2 implements android.view.animation.Animation$AnimationListener {
    final synthetic android.support.v4.widget.MaterialProgressDrawable$Ring val$ring;
    final synthetic android.support.v4.widget.MaterialProgressDrawable this$0;
     MaterialProgressDrawable$2(android.support.v4.widget.MaterialProgressDrawable p1, android.support.v4.widget.MaterialProgressDrawable$Ring p2)
    {
        this.this$0 = p1;
        this.val$ring = p2;
        return;
    }
    public void onAnimationEnd(android.view.animation.Animation p1)
    {
        return;
    }
    public void onAnimationRepeat(android.view.animation.Animation p4)
    {
        this.val$ring.storeOriginals();
        this.val$ring.goToNextColor();
        this.val$ring.setStartTrim(this.val$ring.getEndTrim());
        if (!this.this$0.mFinishing) {
            android.support.v4.widget.MaterialProgressDrawable.access$402(this.this$0, ((android.support.v4.widget.MaterialProgressDrawable.access$400(this.this$0) + 1.0) % 5.0));
        } else {
            this.this$0.mFinishing = 0;
            p4.setDuration(1332.0);
            this.val$ring.setShowArrow(0);
        }
        return;
    }
    public void onAnimationStart(android.view.animation.Animation p3)
    {
        android.support.v4.widget.MaterialProgressDrawable.access$402(this.this$0, 0);
        return;
    }
}
