package android.support.v4.media.routing;
final public class MediaRouterJellybeanMr2$UserRouteInfo {
    public MediaRouterJellybeanMr2$UserRouteInfo()
    {
        return;
    }
    public static void setDescription(Object p0, CharSequence p1)
    {
        p0.setDescription(p1);
        return;
    }
}
