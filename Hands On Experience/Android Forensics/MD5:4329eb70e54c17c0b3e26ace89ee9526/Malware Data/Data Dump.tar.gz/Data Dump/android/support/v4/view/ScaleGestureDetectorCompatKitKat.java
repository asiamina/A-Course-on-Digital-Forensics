package android.support.v4.view;
 class ScaleGestureDetectorCompatKitKat {
    private ScaleGestureDetectorCompatKitKat()
    {
        return;
    }
    public static boolean isQuickScaleEnabled(Object p1)
    {
        return p1.isQuickScaleEnabled();
    }
    public static void setQuickScaleEnabled(Object p0, boolean p1)
    {
        p0.setQuickScaleEnabled(p1);
        return;
    }
}
