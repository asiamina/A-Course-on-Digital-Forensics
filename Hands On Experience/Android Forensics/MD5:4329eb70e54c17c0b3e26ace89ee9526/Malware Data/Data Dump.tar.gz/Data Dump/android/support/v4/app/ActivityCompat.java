package android.support.v4.app;
public class ActivityCompat extends android.support.v4.content.ContextCompat {
    public ActivityCompat()
    {
        return;
    }
    private static android.support.v4.app.ActivityCompat21$SharedElementCallback21 createCallback(android.support.v4.app.SharedElementCallback p1)
    {
        v0 = 0;
        if (p1 != 0) {
            v0 = new android.support.v4.app.ActivityCompat$SharedElementCallback21Impl(p1);
        }
        return v0;
    }
    public static void finishAffinity(android.app.Activity p2)
    {
        if (android.os.Build$VERSION.SDK_INT < 16) {
            p2.finish();
        } else {
            android.support.v4.app.ActivityCompatJB.finishAffinity(p2);
        }
        return;
    }
    public static void finishAfterTransition(android.app.Activity p2)
    {
        if (android.os.Build$VERSION.SDK_INT < 21) {
            p2.finish();
        } else {
            android.support.v4.app.ActivityCompat21.finishAfterTransition(p2);
        }
        return;
    }
    public android.net.Uri getReferrer(android.app.Activity p6)
    {
        if (android.os.Build$VERSION.SDK_INT < 22) {
            v0 = p6.getIntent();
            v1 = v0.getParcelableExtra("android.intent.extra.REFERRER");
            if (v1 == 0) {
                v2 = v0.getStringExtra("android.intent.extra.REFERRER_NAME");
                if (v2 == 0) {
                    v1 = 0;
                } else {
                    v1 = android.net.Uri.parse(v2);
                }
            }
        } else {
            v1 = android.support.v4.app.ActivityCompat22.getReferrer(p6);
        }
        return v1;
    }
    public static boolean invalidateOptionsMenu(android.app.Activity p2)
    {
        if (android.os.Build$VERSION.SDK_INT < 11) {
            v0 = 0;
        } else {
            android.support.v4.app.ActivityCompatHoneycomb.invalidateOptionsMenu(p2);
            v0 = 1;
        }
        return v0;
    }
    public static void postponeEnterTransition(android.app.Activity p2)
    {
        if (android.os.Build$VERSION.SDK_INT >= 21) {
            android.support.v4.app.ActivityCompat21.postponeEnterTransition(p2);
        }
        return;
    }
    public static void requestPermissions(android.app.Activity p3, String[] p4, int p5)
    {
        if (android.os.Build$VERSION.SDK_INT < 23) {
            if ((p3 instanceof android.support.v4.app.ActivityCompat$OnRequestPermissionsResultCallback) != 0) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(new android.support.v4.app.ActivityCompat$1(p4, p3, p5));
            }
        } else {
            android.support.v4.app.ActivityCompatApi23.requestPermissions(p3, p4, p5);
        }
        return;
    }
    public static void setEnterSharedElementCallback(android.app.Activity p2, android.support.v4.app.SharedElementCallback p3)
    {
        if (android.os.Build$VERSION.SDK_INT >= 21) {
            android.support.v4.app.ActivityCompat21.setEnterSharedElementCallback(p2, android.support.v4.app.ActivityCompat.createCallback(p3));
        }
        return;
    }
    public static void setExitSharedElementCallback(android.app.Activity p2, android.support.v4.app.SharedElementCallback p3)
    {
        if (android.os.Build$VERSION.SDK_INT >= 21) {
            android.support.v4.app.ActivityCompat21.setExitSharedElementCallback(p2, android.support.v4.app.ActivityCompat.createCallback(p3));
        }
        return;
    }
    public static boolean shouldShowRequestPermissionRationale(android.app.Activity p2, String p3)
    {
        if (android.os.Build$VERSION.SDK_INT < 23) {
            v0 = 0;
        } else {
            v0 = android.support.v4.app.ActivityCompatApi23.shouldShowRequestPermissionRationale(p2, p3);
        }
        return v0;
    }
    public static void startActivity(android.app.Activity p2, android.content.Intent p3, android.os.Bundle p4)
    {
        if (android.os.Build$VERSION.SDK_INT < 16) {
            p2.startActivity(p3);
        } else {
            android.support.v4.app.ActivityCompatJB.startActivity(p2, p3, p4);
        }
        return;
    }
    public static void startActivityForResult(android.app.Activity p2, android.content.Intent p3, int p4, android.os.Bundle p5)
    {
        if (android.os.Build$VERSION.SDK_INT < 16) {
            p2.startActivityForResult(p3, p4);
        } else {
            android.support.v4.app.ActivityCompatJB.startActivityForResult(p2, p3, p4, p5);
        }
        return;
    }
    public static void startPostponedEnterTransition(android.app.Activity p2)
    {
        if (android.os.Build$VERSION.SDK_INT >= 21) {
            android.support.v4.app.ActivityCompat21.startPostponedEnterTransition(p2);
        }
        return;
    }
}
