package android.support.v4.media;
 class MediaBrowserServiceCompat$MediaBrowserServiceImplApi23 implements android.support.v4.media.MediaBrowserServiceCompat$MediaBrowserServiceImpl {
    final synthetic android.support.v4.media.MediaBrowserServiceCompat this$0;
    private Object mServiceObj;
    public android.os.IBinder onBind(android.content.Intent p2)
    {
        return android.support.v4.media.MediaBrowserServiceCompatApi23.onBind(this.mServiceObj, p2);
    }
    public void onCreate()
    {
        this.mServiceObj = android.support.v4.media.MediaBrowserServiceCompatApi23.createService();
        android.support.v4.media.MediaBrowserServiceCompatApi23.onCreate(this.mServiceObj, new android.support.v4.media.MediaBrowserServiceCompat$ServiceImplApi23(this.this$0, 0));
        return;
    }
     MediaBrowserServiceCompat$MediaBrowserServiceImplApi23(android.support.v4.media.MediaBrowserServiceCompat p1)
    {
        this.this$0 = p1;
        return;
    }
}
