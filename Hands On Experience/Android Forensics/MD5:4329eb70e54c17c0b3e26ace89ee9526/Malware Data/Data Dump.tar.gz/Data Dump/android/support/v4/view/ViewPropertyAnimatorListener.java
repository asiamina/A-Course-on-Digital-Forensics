package android.support.v4.view;
public interface abstract class ViewPropertyAnimatorListener {
    abstract public void onAnimationCancel();
    abstract public void onAnimationEnd();
    abstract public void onAnimationStart();
}
