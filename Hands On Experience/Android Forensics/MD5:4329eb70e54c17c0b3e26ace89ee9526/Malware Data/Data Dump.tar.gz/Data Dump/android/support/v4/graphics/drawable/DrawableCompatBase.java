package android.support.v4.graphics.drawable;
 class DrawableCompatBase {
     DrawableCompatBase()
    {
        return;
    }
    public static void setTint(android.graphics.drawable.Drawable p1, int p2)
    {
        if ((p1 instanceof android.support.v4.graphics.drawable.DrawableWrapper) != 0) {
            p1.setTint(p2);
        }
        return;
    }
    public static void setTintList(android.graphics.drawable.Drawable p1, android.content.res.ColorStateList p2)
    {
        if ((p1 instanceof android.support.v4.graphics.drawable.DrawableWrapper) != 0) {
            p1.setTintList(p2);
        }
        return;
    }
    public static void setTintMode(android.graphics.drawable.Drawable p1, android.graphics.PorterDuff$Mode p2)
    {
        if ((p1 instanceof android.support.v4.graphics.drawable.DrawableWrapper) != 0) {
            p1.setTintMode(p2);
        }
        return;
    }
    public static android.graphics.drawable.Drawable wrapForTinting(android.graphics.drawable.Drawable p1)
    {
        if ((p1 instanceof android.support.v4.graphics.drawable.DrawableWrapperDonut) == 0) {
            p1 = new android.support.v4.graphics.drawable.DrawableWrapperDonut(p1);
        }
        return p1;
    }
}
