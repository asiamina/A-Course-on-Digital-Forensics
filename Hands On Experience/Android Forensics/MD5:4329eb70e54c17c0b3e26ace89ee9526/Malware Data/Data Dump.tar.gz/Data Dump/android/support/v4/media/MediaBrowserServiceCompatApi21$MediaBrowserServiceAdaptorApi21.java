package android.support.v4.media;
 class MediaBrowserServiceCompatApi21$MediaBrowserServiceAdaptorApi21 {
     android.support.v4.media.MediaBrowserServiceCompatApi21$MediaBrowserServiceAdaptorApi21$ServiceBinderProxyApi21 mBinder;
     MediaBrowserServiceCompatApi21$MediaBrowserServiceAdaptorApi21()
    {
        return;
    }
    public android.os.IBinder onBind(android.content.Intent p3)
    {
        if ("android.media.browse.MediaBrowserService".equals(p3.getAction()) == 0) {
            v0 = 0;
        } else {
            v0 = this.mBinder;
        }
        return v0;
    }
    public void onCreate(android.support.v4.media.MediaBrowserServiceCompatApi21$ServiceImplApi21 p2)
    {
        this.mBinder = new android.support.v4.media.MediaBrowserServiceCompatApi21$MediaBrowserServiceAdaptorApi21$ServiceBinderProxyApi21(p2);
        return;
    }
}
