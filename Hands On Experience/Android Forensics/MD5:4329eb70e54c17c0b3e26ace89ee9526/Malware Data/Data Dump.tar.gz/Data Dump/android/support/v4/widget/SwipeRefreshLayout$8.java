package android.support.v4.widget;
 class SwipeRefreshLayout$8 extends android.view.animation.Animation {
    final synthetic android.support.v4.widget.SwipeRefreshLayout this$0;
     SwipeRefreshLayout$8(android.support.v4.widget.SwipeRefreshLayout p1)
    {
        this.this$0 = p1;
        return;
    }
    public void applyTransformation(float p4, android.view.animation.Transformation p5)
    {
        android.support.v4.widget.SwipeRefreshLayout.access$700(this.this$0, (android.support.v4.widget.SwipeRefreshLayout.access$1400(this.this$0) + ((- android.support.v4.widget.SwipeRefreshLayout.access$1400(this.this$0)) * p4)));
        android.support.v4.widget.SwipeRefreshLayout.access$1300(this.this$0, p4);
        return;
    }
}
