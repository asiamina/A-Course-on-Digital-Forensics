package android.support.v4.view.accessibility;
 class AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl implements android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl {
     AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl()
    {
        return;
    }
    public Object newAccessibilityNodeProviderBridge(android.support.v4.view.accessibility.AccessibilityNodeProviderCompat p2)
    {
        return 0;
    }
}
