package android.support.v4.app;
 class NotificationManagerCompat$SideChannelManager implements android.content.ServiceConnection, android.os.Handler$Callback {
    final private android.content.Context mContext;
    private java.util.Set mCachedEnabledPackages;
    final private static int MSG_SERVICE_CONNECTED;
    final private static int MSG_SERVICE_DISCONNECTED;
    final private static int MSG_RETRY_LISTENER_QUEUE;
    final private java.util.Map mRecordMap;
    final private android.os.Handler mHandler;
    final private static int MSG_QUEUE_TASK;
    final private android.os.HandlerThread mHandlerThread;
    final private static String KEY_BINDER;
    public NotificationManagerCompat$SideChannelManager(android.content.Context p3)
    {
        this.mRecordMap = new java.util.HashMap();
        this.mCachedEnabledPackages = new java.util.HashSet();
        this.mContext = p3;
        this.mHandlerThread = new android.os.HandlerThread("NotificationManagerCompat");
        this.mHandlerThread.start();
        this.mHandler = new android.os.Handler(this.mHandlerThread.getLooper(), this);
        return;
    }
    private boolean ensureServiceBound(android.support.v4.app.NotificationManagerCompat$SideChannelManager$ListenerRecord p5)
    {
        if (!p5.bound) {
            p5.bound = this.mContext.bindService(new android.content.Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(p5.componentName), this, android.support.v4.app.NotificationManagerCompat.access$000());
            if (!p5.bound) {
                android.util.Log.w("NotifManCompat", new StringBuilder().append("Unable to bind to listener ").append(p5.componentName).toString());
                this.mContext.unbindService(this);
            } else {
                p5.retryCount = 0;
            }
            v1 = p5.bound;
        } else {
            v1 = 1;
        }
        return v1;
    }
    private void ensureServiceUnbound(android.support.v4.app.NotificationManagerCompat$SideChannelManager$ListenerRecord p2)
    {
        if (p2.bound) {
            this.mContext.unbindService(this);
            p2.bound = 0;
        }
        p2.service = 0;
        return;
    }
    public boolean handleMessage(android.os.Message p5)
    {
        switch (p5.what) {
            case 0:
                this.handleQueueTask(p5.obj);
                v1 = 1;
                break;
            case 1:
                v0 = p5.obj;
                this.handleServiceConnected(v0.componentName, v0.iBinder);
                v1 = 1;
                break;
            case 2:
                this.handleServiceDisconnected(p5.obj);
                v1 = 1;
                break;
            case 3:
                this.handleRetryListenerQueue(p5.obj);
                v1 = 1;
                break;
            default:
                v1 = 0;
        }
        return v1;
    }
    private void handleQueueTask(android.support.v4.app.NotificationManagerCompat$Task p4)
    {
        this.updateListenerMap();
        v0 = this.mRecordMap.values().iterator();
        while (v0.hasNext() != 0) {
            v1 = v0.next();
            v1.taskQueue.add(p4);
            this.processListenerQueue(v1);
        }
        return;
    }
    private void handleRetryListenerQueue(android.content.ComponentName p3)
    {
        v0 = this.mRecordMap.get(p3);
        if (v0 != 0) {
            this.processListenerQueue(v0);
        }
        return;
    }
    private void handleServiceConnected(android.content.ComponentName p3, android.os.IBinder p4)
    {
        v0 = this.mRecordMap.get(p3);
        if (v0 != 0) {
            v0.service = android.support.v4.app.INotificationSideChannel$Stub.asInterface(p4);
            v0.retryCount = 0;
            this.processListenerQueue(v0);
        }
        return;
    }
    private void handleServiceDisconnected(android.content.ComponentName p3)
    {
        v0 = this.mRecordMap.get(p3);
        if (v0 != 0) {
            this.ensureServiceUnbound(v0);
        }
        return;
    }
    public void onServiceConnected(android.content.ComponentName p4, android.os.IBinder p5)
    {
        if (android.util.Log.isLoggable("NotifManCompat", 3) != 0) {
            android.util.Log.d("NotifManCompat", new StringBuilder().append("Connected to service ").append(p4).toString());
        }
        this.mHandler.obtainMessage(1, new android.support.v4.app.NotificationManagerCompat$ServiceConnectedEvent(p4, p5)).sendToTarget();
        return;
    }
    public void onServiceDisconnected(android.content.ComponentName p4)
    {
        if (android.util.Log.isLoggable("NotifManCompat", 3) != 0) {
            android.util.Log.d("NotifManCompat", new StringBuilder().append("Disconnected from service ").append(p4).toString());
        }
        this.mHandler.obtainMessage(2, p4).sendToTarget();
        return;
    }
    private void processListenerQueue(android.support.v4.app.NotificationManagerCompat$SideChannelManager$ListenerRecord p7)
    {
        if (android.util.Log.isLoggable("NotifManCompat", 3) != 0) {
            android.util.Log.d("NotifManCompat", new StringBuilder().append("Processing component ").append(p7.componentName).append(", ").append(p7.taskQueue.size()).append(" queued tasks").toString());
        }
        if (p7.taskQueue.isEmpty() == 0) {
            this.ensureServiceBound(p7);
            if ((this == 0) || (p7.service == 0)) {
                this.scheduleListenerRetry(p7);
                return;
            }
            while(true) {
                v1 = p7.taskQueue.peek();
                if (v1 == 0) {
                    break;
                }
                if (android.util.Log.isLoggable("NotifManCompat", 3) != 0) {
                    android.util.Log.d("NotifManCompat", new StringBuilder().append("Sending task ").append(v1).toString());
                }
                v1.send(p7.service);
                p7.taskQueue.remove();
            }
            if (p7.taskQueue.isEmpty() == 0) {
                this.scheduleListenerRetry(p7);
            }
        }
    }
    public void queueTask(android.support.v4.app.NotificationManagerCompat$Task p3)
    {
        this.mHandler.obtainMessage(0, p3).sendToTarget();
        return;
    }
    private void scheduleListenerRetry(android.support.v4.app.NotificationManagerCompat$SideChannelManager$ListenerRecord p7)
    {
        if (this.mHandler.hasMessages(3, p7.componentName) == 0) {
            p7.retryCount = (p7.retryCount + 1);
            if (p7.retryCount <= 6) {
                v0 = ((1 << (p7.retryCount - 1)) * 1000);
                if (android.util.Log.isLoggable("NotifManCompat", 3) != 0) {
                    android.util.Log.d("NotifManCompat", new StringBuilder().append("Scheduling retry for ").append(v0).append(" ms").toString());
                }
                this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(3, p7.componentName), ((long) v0));
            } else {
                android.util.Log.w("NotifManCompat", new StringBuilder().append("Giving up on delivering ").append(p7.taskQueue.size()).append(" tasks to ").append(p7.componentName).append(" after ").append(p7.retryCount).append(" retries").toString());
                p7.taskQueue.clear();
            }
        }
        return;
    }
    private void updateListenerMap()
    {
        v2 = android.support.v4.app.NotificationManagerCompat.getEnabledListenerPackages(this.mContext);
        if (v2.equals(this.mCachedEnabledPackages) == 0) {
            this.mCachedEnabledPackages = v2;
            v7 = this.mContext.getPackageManager().queryIntentServices(new android.content.Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 4);
            v1 = new java.util.HashSet();
            v4 = v7.iterator();
            while (v4.hasNext() != 0) {
                v6 = v4.next();
                if (v2.contains(v6.serviceInfo.packageName) != 0) {
                    v0 = new android.content.ComponentName(v6.serviceInfo.packageName, v6.serviceInfo.name);
                    if (v6.serviceInfo.permission == 0) {
                        v1.add(v0);
                    } else {
                        android.util.Log.w("NotifManCompat", new StringBuilder().append("Permission present on component ").append(v0).append(", not adding listener record.").toString());
                    }
                }
            }
            v4 = v1.iterator();
            while (v4.hasNext() != 0) {
                v0 = v4.next();
                if (this.mRecordMap.containsKey(v0) == 0) {
                    if (android.util.Log.isLoggable("NotifManCompat", 3) != 0) {
                        android.util.Log.d("NotifManCompat", new StringBuilder().append("Adding listener record for ").append(v0).toString());
                    }
                    this.mRecordMap.put(v0, new android.support.v4.app.NotificationManagerCompat$SideChannelManager$ListenerRecord(v0));
                }
            }
            v5 = this.mRecordMap.entrySet().iterator();
            while (v5.hasNext() != 0) {
                v3 = v5.next();
                if (v1.contains(v3.getKey()) == 0) {
                    if (android.util.Log.isLoggable("NotifManCompat", 3) != 0) {
                        android.util.Log.d("NotifManCompat", new StringBuilder().append("Removing listener record for ").append(v3.getKey()).toString());
                    }
                    this.ensureServiceUnbound(v3.getValue());
                    v5.remove();
                }
            }
        }
        return;
    }
}
