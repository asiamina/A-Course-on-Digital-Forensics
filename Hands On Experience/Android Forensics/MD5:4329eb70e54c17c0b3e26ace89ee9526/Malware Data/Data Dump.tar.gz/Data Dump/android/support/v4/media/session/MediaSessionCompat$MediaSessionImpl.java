package android.support.v4.media.session;
interface abstract class MediaSessionCompat$MediaSessionImpl {
    abstract public Object getMediaSession();
    abstract public Object getRemoteControlClient();
    abstract public android.support.v4.media.session.MediaSessionCompat$Token getSessionToken();
    abstract public boolean isActive();
    abstract public void release();
    abstract public void sendSessionEvent();
    abstract public void setActive();
    abstract public void setCallback();
    abstract public void setExtras();
    abstract public void setFlags();
    abstract public void setMediaButtonReceiver();
    abstract public void setMetadata();
    abstract public void setPlaybackState();
    abstract public void setPlaybackToLocal();
    abstract public void setPlaybackToRemote();
    abstract public void setQueue();
    abstract public void setQueueTitle();
    abstract public void setRatingType();
    abstract public void setSessionActivity();
}
