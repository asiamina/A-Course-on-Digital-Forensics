package android.support.v4.graphics.drawable;
 class DrawableCompat$BaseDrawableImpl implements android.support.v4.graphics.drawable.DrawableCompat$DrawableImpl {
    public void setLayoutDirection(android.graphics.drawable.Drawable p1, int p2)
    {
        return;
    }
    public void setTint(android.graphics.drawable.Drawable p1, int p2)
    {
        android.support.v4.graphics.drawable.DrawableCompatBase.setTint(p1, p2);
        return;
    }
    public void setTintList(android.graphics.drawable.Drawable p1, android.content.res.ColorStateList p2)
    {
        android.support.v4.graphics.drawable.DrawableCompatBase.setTintList(p1, p2);
        return;
    }
    public void setTintMode(android.graphics.drawable.Drawable p1, android.graphics.PorterDuff$Mode p2)
    {
        android.support.v4.graphics.drawable.DrawableCompatBase.setTintMode(p1, p2);
        return;
    }
    public android.graphics.drawable.Drawable wrap(android.graphics.drawable.Drawable p2)
    {
        return android.support.v4.graphics.drawable.DrawableCompatBase.wrapForTinting(p2);
    }
     DrawableCompat$BaseDrawableImpl()
    {
        return;
    }
    public int getLayoutDirection(android.graphics.drawable.Drawable p2)
    {
        return 0;
    }
    public boolean isAutoMirrored(android.graphics.drawable.Drawable p2)
    {
        return 0;
    }
    public void jumpToCurrentState(android.graphics.drawable.Drawable p1)
    {
        return;
    }
    public void setAutoMirrored(android.graphics.drawable.Drawable p1, boolean p2)
    {
        return;
    }
    public void setHotspot(android.graphics.drawable.Drawable p1, float p2, float p3)
    {
        return;
    }
    public void setHotspotBounds(android.graphics.drawable.Drawable p1, int p2, int p3, int p4, int p5)
    {
        return;
    }
}
