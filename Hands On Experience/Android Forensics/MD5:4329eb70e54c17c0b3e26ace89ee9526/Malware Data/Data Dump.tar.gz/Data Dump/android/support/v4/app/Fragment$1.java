package android.support.v4.app;
 class Fragment$1 extends android.support.v4.app.FragmentContainer {
    final synthetic android.support.v4.app.Fragment this$0;
     Fragment$1(android.support.v4.app.Fragment p1)
    {
        this.this$0 = p1;
        return;
    }
    public android.view.View onFindViewById(int p3)
    {
        if (this.this$0.mView != 0) {
            return this.this$0.mView.findViewById(p3);
        } else {
            throw new IllegalStateException("Fragment does not have a view");
        }
    }
    public boolean onHasView()
    {
        if (this.this$0.mView == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
}
