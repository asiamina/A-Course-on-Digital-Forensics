package android.support.v4.view;
 class ViewPropertyAnimatorCompat$KitKatViewPropertyAnimatorCompatImpl extends android.support.v4.view.ViewPropertyAnimatorCompat$JBMr2ViewPropertyAnimatorCompatImpl {
     ViewPropertyAnimatorCompat$KitKatViewPropertyAnimatorCompatImpl()
    {
        return;
    }
    public void setUpdateListener(android.support.v4.view.ViewPropertyAnimatorCompat p1, android.view.View p2, android.support.v4.view.ViewPropertyAnimatorUpdateListener p3)
    {
        android.support.v4.view.ViewPropertyAnimatorCompatKK.setUpdateListener(p2, p3);
        return;
    }
}
