package android.support.v4.view.accessibility;
 class AccessibilityNodeInfoCompat$AccessibilityNodeInfoKitKatImpl extends android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanMr2Impl {
    public boolean isDismissable(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.isDismissable(p2);
    }
    public boolean isMultiLine(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.isMultiLine(p2);
    }
    public Object obtainCollectionInfo(int p2, int p3, boolean p4, int p5)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.obtainCollectionInfo(p2, p3, p4, p5);
    }
    public Object obtainCollectionItemInfo(int p2, int p3, int p4, int p5, boolean p6, boolean p7)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.obtainCollectionItemInfo(p2, p3, p4, p5, p6);
    }
    public void setCanOpenPopup(Object p1, boolean p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setCanOpenPopup(p1, p2);
        return;
    }
    public void setCollectionInfo(Object p1, Object p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setCollectionInfo(p1, p2);
        return;
    }
    public void setCollectionItemInfo(Object p1, Object p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setCollectionItemInfo(p1, p2);
        return;
    }
    public void setContentInvalid(Object p1, boolean p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setContentInvalid(p1, p2);
        return;
    }
    public void setDismissable(Object p1, boolean p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setDismissable(p1, p2);
        return;
    }
    public void setInputType(Object p1, int p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setInputType(p1, p2);
        return;
    }
    public void setLiveRegion(Object p1, int p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setLiveRegion(p1, p2);
        return;
    }
    public void setMultiLine(Object p1, boolean p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setMultiLine(p1, p2);
        return;
    }
    public void setRangeInfo(Object p1, Object p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.setRangeInfo(p1, p2);
        return;
    }
     AccessibilityNodeInfoCompat$AccessibilityNodeInfoKitKatImpl()
    {
        return;
    }
    public boolean canOpenPopup(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.canOpenPopup(p2);
    }
    public Object getCollectionInfo(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.getCollectionInfo(p2);
    }
    public int getCollectionInfoColumnCount(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionInfo.getColumnCount(p2);
    }
    public int getCollectionInfoRowCount(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionInfo.getRowCount(p2);
    }
    public int getCollectionItemColumnIndex(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionItemInfo.getColumnIndex(p2);
    }
    public int getCollectionItemColumnSpan(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionItemInfo.getColumnSpan(p2);
    }
    public Object getCollectionItemInfo(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.getCollectionItemInfo(p2);
    }
    public int getCollectionItemRowIndex(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionItemInfo.getRowIndex(p2);
    }
    public int getCollectionItemRowSpan(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionItemInfo.getRowSpan(p2);
    }
    public android.os.Bundle getExtras(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.getExtras(p2);
    }
    public int getInputType(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.getInputType(p2);
    }
    public int getLiveRegion(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.getLiveRegion(p2);
    }
    public Object getRangeInfo(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.getRangeInfo(p2);
    }
    public boolean isCollectionInfoHierarchical(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionInfo.isHierarchical(p2);
    }
    public boolean isCollectionItemHeading(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat$CollectionItemInfo.isHeading(p2);
    }
    public boolean isContentInvalid(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat.isContentInvalid(p2);
    }
}
