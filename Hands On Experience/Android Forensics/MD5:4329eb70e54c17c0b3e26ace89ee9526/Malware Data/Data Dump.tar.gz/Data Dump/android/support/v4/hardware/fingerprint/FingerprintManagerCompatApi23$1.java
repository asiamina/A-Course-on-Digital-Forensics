package android.support.v4.hardware.fingerprint;
final class FingerprintManagerCompatApi23$1 extends android.hardware.fingerprint.FingerprintManager$AuthenticationCallback {
    final synthetic android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$AuthenticationCallback val$callback;
    public void onAuthenticationFailed()
    {
        this.val$callback.onAuthenticationFailed();
        return;
    }
    public void onAuthenticationHelp(int p2, CharSequence p3)
    {
        this.val$callback.onAuthenticationHelp(p2, p3);
        return;
    }
    public void onAuthenticationSucceeded(android.hardware.fingerprint.FingerprintManager$AuthenticationResult p4)
    {
        this.val$callback.onAuthenticationSucceeded(new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$AuthenticationResultInternal(android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23.access$000(p4.getCryptoObject())));
        return;
    }
     FingerprintManagerCompatApi23$1(android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$AuthenticationCallback p1)
    {
        this.val$callback = p1;
        return;
    }
    public void onAuthenticationError(int p2, CharSequence p3)
    {
        this.val$callback.onAuthenticationError(p2, p3);
        return;
    }
}
