package android.support.v4.view;
 class ViewCompatLollipop {
     ViewCompatLollipop()
    {
        return;
    }
    public static android.support.v4.view.WindowInsetsCompat dispatchApplyWindowInsets(android.view.View p3, android.support.v4.view.WindowInsetsCompat p4)
    {
        if ((p4 instanceof android.support.v4.view.WindowInsetsCompatApi21) != 0) {
            v1 = p4.unwrap();
            v0 = p3.dispatchApplyWindowInsets(v1);
            if (v0 != v1) {
                p4 = new android.support.v4.view.WindowInsetsCompatApi21(v0);
            }
        }
        return p4;
    }
    public static boolean dispatchNestedFling(android.view.View p1, float p2, float p3, boolean p4)
    {
        return p1.dispatchNestedFling(p2, p3, p4);
    }
    public static boolean dispatchNestedPreFling(android.view.View p1, float p2, float p3)
    {
        return p1.dispatchNestedPreFling(p2, p3);
    }
    public static boolean dispatchNestedPreScroll(android.view.View p1, int p2, int p3, int[] p4, int[] p5)
    {
        return p1.dispatchNestedPreScroll(p2, p3, p4, p5);
    }
    public static boolean dispatchNestedScroll(android.view.View p1, int p2, int p3, int p4, int p5, int[] p6)
    {
        return p1.dispatchNestedScroll(p2, p3, p4, p5, p6);
    }
    static android.content.res.ColorStateList getBackgroundTintList(android.view.View p1)
    {
        return p1.getBackgroundTintList();
    }
    static android.graphics.PorterDuff$Mode getBackgroundTintMode(android.view.View p1)
    {
        return p1.getBackgroundTintMode();
    }
    public static float getElevation(android.view.View p1)
    {
        return p1.getElevation();
    }
    public static String getTransitionName(android.view.View p1)
    {
        return p1.getTransitionName();
    }
    public static float getTranslationZ(android.view.View p1)
    {
        return p1.getTranslationZ();
    }
    public static float getZ(android.view.View p1)
    {
        return p1.getZ();
    }
    public static boolean hasNestedScrollingParent(android.view.View p1)
    {
        return p1.hasNestedScrollingParent();
    }
    public static boolean isImportantForAccessibility(android.view.View p1)
    {
        return p1.isImportantForAccessibility();
    }
    public static boolean isNestedScrollingEnabled(android.view.View p1)
    {
        return p1.isNestedScrollingEnabled();
    }
    public static android.support.v4.view.WindowInsetsCompat onApplyWindowInsets(android.view.View p3, android.support.v4.view.WindowInsetsCompat p4)
    {
        if ((p4 instanceof android.support.v4.view.WindowInsetsCompatApi21) != 0) {
            v1 = p4.unwrap();
            v0 = p3.onApplyWindowInsets(v1);
            if (v0 != v1) {
                p4 = new android.support.v4.view.WindowInsetsCompatApi21(v0);
            }
        }
        return p4;
    }
    public static void requestApplyInsets(android.view.View p0)
    {
        p0.requestApplyInsets();
        return;
    }
    static void setBackgroundTintList(android.view.View p0, android.content.res.ColorStateList p1)
    {
        p0.setBackgroundTintList(p1);
        return;
    }
    static void setBackgroundTintMode(android.view.View p0, android.graphics.PorterDuff$Mode p1)
    {
        p0.setBackgroundTintMode(p1);
        return;
    }
    public static void setElevation(android.view.View p0, float p1)
    {
        p0.setElevation(p1);
        return;
    }
    public static void setNestedScrollingEnabled(android.view.View p0, boolean p1)
    {
        p0.setNestedScrollingEnabled(p1);
        return;
    }
    public static void setOnApplyWindowInsetsListener(android.view.View p1, android.support.v4.view.OnApplyWindowInsetsListener p2)
    {
        p1.setOnApplyWindowInsetsListener(new android.support.v4.view.ViewCompatLollipop$1(p2));
        return;
    }
    public static void setTransitionName(android.view.View p0, String p1)
    {
        p0.setTransitionName(p1);
        return;
    }
    public static void setTranslationZ(android.view.View p0, float p1)
    {
        p0.setTranslationZ(p1);
        return;
    }
    public static boolean startNestedScroll(android.view.View p1, int p2)
    {
        return p1.startNestedScroll(p2);
    }
    public static void stopNestedScroll(android.view.View p0)
    {
        p0.stopNestedScroll();
        return;
    }
}
