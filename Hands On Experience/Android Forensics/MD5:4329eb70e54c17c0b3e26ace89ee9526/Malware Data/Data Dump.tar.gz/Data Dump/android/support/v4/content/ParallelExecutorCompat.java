package android.support.v4.content;
public class ParallelExecutorCompat {
    public ParallelExecutorCompat()
    {
        return;
    }
    public static java.util.concurrent.Executor getParallelExecutor()
    {
        if (android.os.Build$VERSION.SDK_INT < 11) {
            v0 = android.support.v4.content.ModernAsyncTask.THREAD_POOL_EXECUTOR;
        } else {
            v0 = android.support.v4.content.ExecutorCompatHoneycomb.getParallelExecutor();
        }
        return v0;
    }
}
