package android.support.v4.app;
 class FragmentManagerImpl$FragmentTag {
    final public static int[] Fragment;
    final public static int Fragment_id;
    final public static int Fragment_tag;
    final public static int Fragment_name;
    static FragmentManagerImpl$FragmentTag()
    {
        v0 = new int[3];
        v0 = {3, 0, 1, 1, 208, 0, 1, 1, 209, 0, 1};
        android.support.v4.app.FragmentManagerImpl$FragmentTag.Fragment = v0;
        return;
    }
     FragmentManagerImpl$FragmentTag()
    {
        return;
    }
}
