package android.support.v4.media;
final class MediaMetadataCompat$1 implements android.os.Parcelable$Creator {
     MediaMetadataCompat$1()
    {
        return;
    }
    public android.support.v4.media.MediaMetadataCompat createFromParcel(android.os.Parcel p3)
    {
        return new android.support.v4.media.MediaMetadataCompat(p3, 0);
    }
    public synthetic bridge Object createFromParcel(android.os.Parcel p2)
    {
        return this.createFromParcel(p2);
    }
    public android.support.v4.media.MediaMetadataCompat[] newArray(int p2)
    {
        v0 = new android.support.v4.media.MediaMetadataCompat[p2];
        return v0;
    }
    public synthetic bridge Object[] newArray(int p2)
    {
        return this.newArray(p2);
    }
}
