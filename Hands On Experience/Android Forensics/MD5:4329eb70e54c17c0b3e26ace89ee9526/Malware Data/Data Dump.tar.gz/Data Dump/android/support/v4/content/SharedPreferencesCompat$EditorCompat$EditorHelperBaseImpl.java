package android.support.v4.content;
 class SharedPreferencesCompat$EditorCompat$EditorHelperBaseImpl implements android.support.v4.content.SharedPreferencesCompat$EditorCompat$Helper {
    public void apply(android.content.SharedPreferences$Editor p1)
    {
        p1.commit();
        return;
    }
    private SharedPreferencesCompat$EditorCompat$EditorHelperBaseImpl()
    {
        return;
    }
    synthetic SharedPreferencesCompat$EditorCompat$EditorHelperBaseImpl(android.support.v4.content.SharedPreferencesCompat$1 p1)
    {
        return;
    }
}
