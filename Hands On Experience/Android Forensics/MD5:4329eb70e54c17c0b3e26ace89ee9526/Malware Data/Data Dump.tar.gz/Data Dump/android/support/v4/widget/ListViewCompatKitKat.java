package android.support.v4.widget;
 class ListViewCompatKitKat {
     ListViewCompatKitKat()
    {
        return;
    }
    static void scrollListBy(android.widget.ListView p0, int p1)
    {
        p0.scrollListBy(p1);
        return;
    }
}
