package android.support.v4.content;
abstract class ModernAsyncTask$WorkerRunnable implements java.util.concurrent.Callable {
     Object[] mParams;
    private ModernAsyncTask$WorkerRunnable()
    {
        return;
    }
    synthetic ModernAsyncTask$WorkerRunnable(android.support.v4.content.ModernAsyncTask$1 p1)
    {
        return;
    }
}
