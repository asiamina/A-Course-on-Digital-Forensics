package android.support.v4.app;
public abstract class FragmentContainer {
    public FragmentContainer()
    {
        return;
    }
    abstract public android.view.View onFindViewById();
    abstract public boolean onHasView();
}
