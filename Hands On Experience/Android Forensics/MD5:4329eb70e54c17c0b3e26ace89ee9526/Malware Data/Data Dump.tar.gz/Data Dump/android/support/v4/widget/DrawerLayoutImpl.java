package android.support.v4.widget;
interface abstract class DrawerLayoutImpl {
    abstract public void setChildInsets();
}
