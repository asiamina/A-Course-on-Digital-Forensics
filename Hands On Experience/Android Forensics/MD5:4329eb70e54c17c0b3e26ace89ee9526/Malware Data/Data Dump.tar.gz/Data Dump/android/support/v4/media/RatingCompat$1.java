package android.support.v4.media;
final class RatingCompat$1 implements android.os.Parcelable$Creator {
    public synthetic bridge Object createFromParcel(android.os.Parcel p2)
    {
        return this.createFromParcel(p2);
    }
    public android.support.v4.media.RatingCompat[] newArray(int p2)
    {
        v0 = new android.support.v4.media.RatingCompat[p2];
        return v0;
    }
    public synthetic bridge Object[] newArray(int p2)
    {
        return this.newArray(p2);
    }
     RatingCompat$1()
    {
        return;
    }
    public android.support.v4.media.RatingCompat createFromParcel(android.os.Parcel p5)
    {
        return new android.support.v4.media.RatingCompat(p5.readInt(), p5.readFloat(), 0);
    }
}
