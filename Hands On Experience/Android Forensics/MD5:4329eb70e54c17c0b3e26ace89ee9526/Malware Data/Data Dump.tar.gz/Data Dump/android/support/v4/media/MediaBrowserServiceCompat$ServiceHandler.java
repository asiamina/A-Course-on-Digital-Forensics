package android.support.v4.media;
final class MediaBrowserServiceCompat$ServiceHandler extends android.os.Handler {
    final private android.support.v4.media.MediaBrowserServiceCompat$ServiceImpl mServiceImpl;
    final synthetic android.support.v4.media.MediaBrowserServiceCompat this$0;
    private MediaBrowserServiceCompat$ServiceHandler(android.support.v4.media.MediaBrowserServiceCompat p4)
    {
        this.this$0 = p4;
        this.mServiceImpl = new android.support.v4.media.MediaBrowserServiceCompat$ServiceImpl(this.this$0, 0);
        return;
    }
    synthetic MediaBrowserServiceCompat$ServiceHandler(android.support.v4.media.MediaBrowserServiceCompat p1, android.support.v4.media.MediaBrowserServiceCompat$1 p2)
    {
        this(p1);
        return;
    }
    public android.support.v4.media.MediaBrowserServiceCompat$ServiceImpl getServiceImpl()
    {
        return this.mServiceImpl;
    }
    public void handleMessage(android.os.Message p9)
    {
        v0 = p9.getData();
        switch (p9.what) {
            case 1:
                this.mServiceImpl.connect(v0.getString("data_package_name"), v0.getInt("data_calling_uid"), v0.getBundle("data_root_hints"), new android.support.v4.media.MediaBrowserServiceCompat$ServiceCallbacksCompat(this.this$0, p9.replyTo));
                break;
            case 2:
                this.mServiceImpl.disconnect(new android.support.v4.media.MediaBrowserServiceCompat$ServiceCallbacksCompat(this.this$0, p9.replyTo));
                break;
            case 3:
                this.mServiceImpl.addSubscription(v0.getString("data_media_item_id"), v0.getBundle("data_options"), new android.support.v4.media.MediaBrowserServiceCompat$ServiceCallbacksCompat(this.this$0, p9.replyTo));
                break;
            case 4:
                this.mServiceImpl.removeSubscription(v0.getString("data_media_item_id"), v0.getBundle("data_options"), new android.support.v4.media.MediaBrowserServiceCompat$ServiceCallbacksCompat(this.this$0, p9.replyTo));
                break;
            case 5:
                this.mServiceImpl.getMediaItem(v0.getString("data_media_item_id"), v0.getParcelable("data_result_receiver"));
                break;
            case 6:
                this.mServiceImpl.registerCallbacks(new android.support.v4.media.MediaBrowserServiceCompat$ServiceCallbacksCompat(this.this$0, p9.replyTo));
                break;
            default:
                android.util.Log.w("MediaBrowserServiceCompat", new StringBuilder().append("Unhandled message: ").append(p9).append("\n  Service version: ").append(1).append("\n  Client version: ").append(p9.arg1).toString());
        }
        return;
    }
    public void postOrRun(Runnable p3)
    {
        if (Thread.currentThread() != this.getLooper().getThread()) {
            this.post(p3);
        } else {
            p3.run();
        }
        return;
    }
    public boolean sendMessageAtTime(android.os.Message p4, long p5)
    {
        v0 = p4.getData();
        v0.setClassLoader(android.support.v4.media.MediaBrowserCompat.getClassLoader());
        v0.putInt("data_calling_uid", android.os.Binder.getCallingUid());
        return super.sendMessageAtTime(p4, p5, v6);
    }
}
