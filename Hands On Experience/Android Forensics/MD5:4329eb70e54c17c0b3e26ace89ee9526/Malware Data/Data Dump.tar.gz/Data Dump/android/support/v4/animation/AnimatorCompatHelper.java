package android.support.v4.animation;
public abstract class AnimatorCompatHelper {
    static android.support.v4.animation.AnimatorProvider IMPL;
    static AnimatorCompatHelper()
    {
        if (android.os.Build$VERSION.SDK_INT < 12) {
            android.support.v4.animation.AnimatorCompatHelper.IMPL = new android.support.v4.animation.DonutAnimatorCompatProvider();
        } else {
            android.support.v4.animation.AnimatorCompatHelper.IMPL = new android.support.v4.animation.HoneycombMr1AnimatorCompatProvider();
        }
        return;
    }
     AnimatorCompatHelper()
    {
        return;
    }
    public static void clearInterpolator(android.view.View p1)
    {
        android.support.v4.animation.AnimatorCompatHelper.IMPL.clearInterpolator(p1);
        return;
    }
    public static android.support.v4.animation.ValueAnimatorCompat emptyValueAnimator()
    {
        return android.support.v4.animation.AnimatorCompatHelper.IMPL.emptyValueAnimator();
    }
}
