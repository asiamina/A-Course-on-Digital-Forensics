package android.support.v4.view.accessibility;
public class AccessibilityEventCompat {
    final public static int TYPE_TOUCH_INTERACTION_END;
    final public static int TYPE_VIEW_ACCESSIBILITY_FOCUSED;
    final public static int TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED;
    final public static int TYPE_VIEW_HOVER_ENTER;
    final public static int TYPE_VIEW_TEXT_TRAVERSED_AT_MOVEMENT_GRANULARITY;
    final public static int CONTENT_CHANGE_TYPE_SUBTREE;
    final public static int CONTENT_CHANGE_TYPE_TEXT;
    final public static int TYPE_TOUCH_EXPLORATION_GESTURE_START;
    final public static int TYPE_WINDOW_CONTENT_CHANGED;
    final public static int TYPE_TOUCH_EXPLORATION_GESTURE_END;
    final public static int TYPE_GESTURE_DETECTION_END;
    final public static int TYPE_VIEW_HOVER_EXIT;
    final public static int TYPE_VIEW_TEXT_SELECTION_CHANGED;
    final public static int TYPE_GESTURE_DETECTION_START;
    final public static int TYPES_ALL_MASK;
    final public static int CONTENT_CHANGE_TYPE_UNDEFINED;
    final public static int TYPE_ANNOUNCEMENT;
    final public static int TYPE_TOUCH_INTERACTION_START;
    final public static int TYPE_VIEW_SCROLLED;
    final private static android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl IMPL;
    final public static int CONTENT_CHANGE_TYPE_CONTENT_DESCRIPTION;
    static AccessibilityEventCompat()
    {
        if (android.os.Build$VERSION.SDK_INT < 19) {
            if (android.os.Build$VERSION.SDK_INT < 14) {
                android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL = new android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventStubImpl();
            } else {
                android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL = new android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventIcsImpl();
            }
        } else {
            android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL = new android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventKitKatImpl();
        }
        return;
    }
    private AccessibilityEventCompat()
    {
        return;
    }
    public static void appendRecord(android.view.accessibility.AccessibilityEvent p2, android.support.v4.view.accessibility.AccessibilityRecordCompat p3)
    {
        android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL.appendRecord(p2, p3.getImpl());
        return;
    }
    public static android.support.v4.view.accessibility.AccessibilityRecordCompat asRecord(android.view.accessibility.AccessibilityEvent p1)
    {
        return new android.support.v4.view.accessibility.AccessibilityRecordCompat(p1);
    }
    public static int getContentChangeTypes(android.view.accessibility.AccessibilityEvent p1)
    {
        return android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL.getContentChangeTypes(p1);
    }
    public static android.support.v4.view.accessibility.AccessibilityRecordCompat getRecord(android.view.accessibility.AccessibilityEvent p2, int p3)
    {
        return new android.support.v4.view.accessibility.AccessibilityRecordCompat(android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL.getRecord(p2, p3));
    }
    public static int getRecordCount(android.view.accessibility.AccessibilityEvent p1)
    {
        return android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL.getRecordCount(p1);
    }
    public static void setContentChangeTypes(android.view.accessibility.AccessibilityEvent p1, int p2)
    {
        android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL.setContentChangeTypes(p1, p2);
        return;
    }
}
