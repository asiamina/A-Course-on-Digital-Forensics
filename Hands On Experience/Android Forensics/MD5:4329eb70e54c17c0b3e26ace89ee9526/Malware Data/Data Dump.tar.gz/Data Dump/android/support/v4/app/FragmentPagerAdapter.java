package android.support.v4.app;
public abstract class FragmentPagerAdapter extends android.support.v4.view.PagerAdapter {
    final private static boolean DEBUG;
    private android.support.v4.app.FragmentTransaction mCurTransaction;
    final private android.support.v4.app.FragmentManager mFragmentManager;
    final private static String TAG;
    private android.support.v4.app.Fragment mCurrentPrimaryItem;
    public Object instantiateItem(android.view.ViewGroup p9, int p10)
    {
        if (this.mCurTransaction == 0) {
            this.mCurTransaction = this.mFragmentManager.beginTransaction();
        }
        v1 = this.getItemId(p10);
        v0 = this.mFragmentManager.findFragmentByTag(android.support.v4.app.FragmentPagerAdapter.makeFragmentName(p9.getId(), v1));
        if (v0 == 0) {
            v0 = this.getItem(p10);
            this.mCurTransaction.add(p9.getId(), v0, android.support.v4.app.FragmentPagerAdapter.makeFragmentName(p9.getId(), v1));
        } else {
            this.mCurTransaction.attach(v0);
        }
        if (v0 != this.mCurrentPrimaryItem) {
            v0.setMenuVisibility(0);
            v0.setUserVisibleHint(0);
        }
        return v0;
    }
    public boolean isViewFromObject(android.view.View p2, Object p3)
    {
        if (p3.getView() != p2) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    private static String makeFragmentName(int p2, long p3)
    {
        return new StringBuilder().append("android:switcher:").append(p2).append(":").append(p3).toString();
    }
    public void restoreState(android.os.Parcelable p1, ClassLoader p2)
    {
        return;
    }
    public android.os.Parcelable saveState()
    {
        return 0;
    }
    public void setPrimaryItem(android.view.ViewGroup p5, int p6, Object p7)
    {
        v0 = p7;
        if (v0 != this.mCurrentPrimaryItem) {
            if (this.mCurrentPrimaryItem != 0) {
                this.mCurrentPrimaryItem.setMenuVisibility(0);
                this.mCurrentPrimaryItem.setUserVisibleHint(0);
            }
            if (v0 != 0) {
                v0.setMenuVisibility(1);
                v0.setUserVisibleHint(1);
            }
            this.mCurrentPrimaryItem = v0;
        }
        return;
    }
    public void startUpdate(android.view.ViewGroup p1)
    {
        return;
    }
    public FragmentPagerAdapter(android.support.v4.app.FragmentManager p2)
    {
        this.mCurTransaction = 0;
        this.mCurrentPrimaryItem = 0;
        this.mFragmentManager = p2;
        return;
    }
    public void destroyItem(android.view.ViewGroup p2, int p3, Object p4)
    {
        if (this.mCurTransaction == 0) {
            this.mCurTransaction = this.mFragmentManager.beginTransaction();
        }
        this.mCurTransaction.detach(p4);
        return;
    }
    public void finishUpdate(android.view.ViewGroup p2)
    {
        if (this.mCurTransaction != 0) {
            this.mCurTransaction.commitAllowingStateLoss();
            this.mCurTransaction = 0;
            this.mFragmentManager.executePendingTransactions();
        }
        return;
    }
    abstract public android.support.v4.app.Fragment getItem();
    public long getItemId(int p3)
    {
        return ((long) p3);
    }
}
