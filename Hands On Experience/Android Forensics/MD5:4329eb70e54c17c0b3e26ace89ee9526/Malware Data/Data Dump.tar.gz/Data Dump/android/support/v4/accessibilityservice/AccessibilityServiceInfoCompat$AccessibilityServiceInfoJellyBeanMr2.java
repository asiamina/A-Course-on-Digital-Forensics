package android.support.v4.accessibilityservice;
 class AccessibilityServiceInfoCompat$AccessibilityServiceInfoJellyBeanMr2 extends android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl {
     AccessibilityServiceInfoCompat$AccessibilityServiceInfoJellyBeanMr2()
    {
        return;
    }
    public int getCapabilities(android.accessibilityservice.AccessibilityServiceInfo p2)
    {
        return android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatJellyBeanMr2.getCapabilities(p2);
    }
}
