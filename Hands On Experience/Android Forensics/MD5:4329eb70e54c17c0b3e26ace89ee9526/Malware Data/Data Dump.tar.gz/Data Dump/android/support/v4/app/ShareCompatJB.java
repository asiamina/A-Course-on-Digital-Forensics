package android.support.v4.app;
 class ShareCompatJB {
     ShareCompatJB()
    {
        return;
    }
    public static String escapeHtml(CharSequence p1)
    {
        return android.text.Html.escapeHtml(p1);
    }
}
