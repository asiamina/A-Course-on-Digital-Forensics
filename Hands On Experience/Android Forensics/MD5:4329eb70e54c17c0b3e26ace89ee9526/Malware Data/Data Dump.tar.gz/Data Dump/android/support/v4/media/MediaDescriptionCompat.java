package android.support.v4.media;
final public class MediaDescriptionCompat implements android.os.Parcelable {
    final private CharSequence mSubtitle;
    final private CharSequence mTitle;
    final private CharSequence mDescription;
    final public static android.os.Parcelable$Creator CREATOR;
    final private String mMediaId;
    final private android.os.Bundle mExtras;
    final private android.net.Uri mIconUri;
    final private android.net.Uri mMediaUri;
    final private android.graphics.Bitmap mIcon;
    private Object mDescriptionObj;
    public CharSequence getDescription()
    {
        return this.mDescription;
    }
    public android.os.Bundle getExtras()
    {
        return this.mExtras;
    }
    public android.graphics.Bitmap getIconBitmap()
    {
        return this.mIcon;
    }
    public android.net.Uri getIconUri()
    {
        return this.mIconUri;
    }
    public Object getMediaDescription()
    {
        if ((this.mDescriptionObj == 0) && (android.os.Build$VERSION.SDK_INT >= 21)) {
            v0 = android.support.v4.media.MediaDescriptionCompatApi21$Builder.newInstance();
            android.support.v4.media.MediaDescriptionCompatApi21$Builder.setMediaId(v0, this.mMediaId);
            android.support.v4.media.MediaDescriptionCompatApi21$Builder.setTitle(v0, this.mTitle);
            android.support.v4.media.MediaDescriptionCompatApi21$Builder.setSubtitle(v0, this.mSubtitle);
            android.support.v4.media.MediaDescriptionCompatApi21$Builder.setDescription(v0, this.mDescription);
            android.support.v4.media.MediaDescriptionCompatApi21$Builder.setIconBitmap(v0, this.mIcon);
            android.support.v4.media.MediaDescriptionCompatApi21$Builder.setIconUri(v0, this.mIconUri);
            android.support.v4.media.MediaDescriptionCompatApi21$Builder.setExtras(v0, this.mExtras);
            if (android.os.Build$VERSION.SDK_INT >= 23) {
                android.support.v4.media.MediaDescriptionCompatApi23$Builder.setMediaUri(v0, this.mMediaUri);
            }
            this.mDescriptionObj = android.support.v4.media.MediaDescriptionCompatApi21$Builder.build(v0);
            v1 = this.mDescriptionObj;
        } else {
            v1 = this.mDescriptionObj;
        }
        return v1;
    }
    public String getMediaId()
    {
        return this.mMediaId;
    }
    public android.net.Uri getMediaUri()
    {
        return this.mMediaUri;
    }
    public CharSequence getSubtitle()
    {
        return this.mSubtitle;
    }
    public CharSequence getTitle()
    {
        return this.mTitle;
    }
    public String toString()
    {
        return new StringBuilder().append(this.mTitle).append(", ").append(this.mSubtitle).append(", ").append(this.mDescription).toString();
    }
    public void writeToParcel(android.os.Parcel p3, int p4)
    {
        if (android.os.Build$VERSION.SDK_INT >= 21) {
            android.support.v4.media.MediaDescriptionCompatApi21.writeToParcel(this.getMediaDescription(), p3, p4);
        } else {
            p3.writeString(this.mMediaId);
            android.text.TextUtils.writeToParcel(this.mTitle, p3, p4);
            android.text.TextUtils.writeToParcel(this.mSubtitle, p3, p4);
            android.text.TextUtils.writeToParcel(this.mDescription, p3, p4);
            p3.writeParcelable(this.mIcon, p4);
            p3.writeParcelable(this.mIconUri, p4);
            p3.writeBundle(this.mExtras);
        }
        return;
    }
    static MediaDescriptionCompat()
    {
        android.support.v4.media.MediaDescriptionCompat.CREATOR = new android.support.v4.media.MediaDescriptionCompat$1();
        return;
    }
    private MediaDescriptionCompat(android.os.Parcel p3)
    {
        this.mMediaId = p3.readString();
        this.mTitle = android.text.TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(p3);
        this.mSubtitle = android.text.TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(p3);
        this.mDescription = android.text.TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(p3);
        this.mIcon = p3.readParcelable(0);
        this.mIconUri = p3.readParcelable(0);
        this.mExtras = p3.readBundle();
        this.mMediaUri = p3.readParcelable(0);
        return;
    }
    synthetic MediaDescriptionCompat(android.os.Parcel p1, android.support.v4.media.MediaDescriptionCompat$1 p2)
    {
        this(p1);
        return;
    }
    private MediaDescriptionCompat(String p1, CharSequence p2, CharSequence p3, CharSequence p4, android.graphics.Bitmap p5, android.net.Uri p6, android.os.Bundle p7, android.net.Uri p8)
    {
        this.mMediaId = p1;
        this.mTitle = p2;
        this.mSubtitle = p3;
        this.mDescription = p4;
        this.mIcon = p5;
        this.mIconUri = p6;
        this.mExtras = p7;
        this.mMediaUri = p8;
        return;
    }
    synthetic MediaDescriptionCompat(String p1, CharSequence p2, CharSequence p3, CharSequence p4, android.graphics.Bitmap p5, android.net.Uri p6, android.os.Bundle p7, android.net.Uri p8, android.support.v4.media.MediaDescriptionCompat$1 p9)
    {
        this(p1, p2, p3, p4, p5, p6, p7, p8);
        return;
    }
    public int describeContents()
    {
        return 0;
    }
    public static android.support.v4.media.MediaDescriptionCompat fromMediaDescription(Object p4)
    {
        if ((p4 != 0) && (android.os.Build$VERSION.SDK_INT >= 21)) {
            v0 = new android.support.v4.media.MediaDescriptionCompat$Builder();
            v0.setMediaId(android.support.v4.media.MediaDescriptionCompatApi21.getMediaId(p4));
            v0.setTitle(android.support.v4.media.MediaDescriptionCompatApi21.getTitle(p4));
            v0.setSubtitle(android.support.v4.media.MediaDescriptionCompatApi21.getSubtitle(p4));
            v0.setDescription(android.support.v4.media.MediaDescriptionCompatApi21.getDescription(p4));
            v0.setIconBitmap(android.support.v4.media.MediaDescriptionCompatApi21.getIconBitmap(p4));
            v0.setIconUri(android.support.v4.media.MediaDescriptionCompatApi21.getIconUri(p4));
            v0.setExtras(android.support.v4.media.MediaDescriptionCompatApi21.getExtras(p4));
            if (android.os.Build$VERSION.SDK_INT >= 23) {
                v0.setMediaUri(android.support.v4.media.MediaDescriptionCompatApi23.getMediaUri(p4));
            }
            v1 = v0.build();
            v1.mDescriptionObj = p4;
        } else {
            v1 = 0;
        }
        return v1;
    }
}
