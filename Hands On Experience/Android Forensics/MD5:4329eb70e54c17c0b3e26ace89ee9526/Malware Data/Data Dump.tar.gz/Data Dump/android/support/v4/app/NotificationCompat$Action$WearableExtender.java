package android.support.v4.app;
final public class NotificationCompat$Action$WearableExtender implements android.support.v4.app.NotificationCompat$Action$Extender {
    final private static String KEY_IN_PROGRESS_LABEL;
    final private static String EXTRA_WEARABLE_EXTENSIONS;
    final private static String KEY_CONFIRM_LABEL;
    final private static int FLAG_AVAILABLE_OFFLINE;
    final private static int DEFAULT_FLAGS;
    final private static String KEY_FLAGS;
    private CharSequence mInProgressLabel;
    private int mFlags;
    final private static String KEY_CANCEL_LABEL;
    private CharSequence mConfirmLabel;
    private CharSequence mCancelLabel;
    public NotificationCompat$Action$WearableExtender()
    {
        this.mFlags = 1;
        return;
    }
    public NotificationCompat$Action$WearableExtender(android.support.v4.app.NotificationCompat$Action p5)
    {
        this.mFlags = 1;
        v0 = p5.getExtras().getBundle("android.wearable.EXTENSIONS");
        if (v0 != 0) {
            this.mFlags = v0.getInt("flags", 1);
            this.mInProgressLabel = v0.getCharSequence("inProgressLabel");
            this.mConfirmLabel = v0.getCharSequence("confirmLabel");
            this.mCancelLabel = v0.getCharSequence("cancelLabel");
        }
        return;
    }
    public android.support.v4.app.NotificationCompat$Action$WearableExtender clone()
    {
        v0 = new android.support.v4.app.NotificationCompat$Action$WearableExtender();
        v0.mFlags = this.mFlags;
        v0.mInProgressLabel = this.mInProgressLabel;
        v0.mConfirmLabel = this.mConfirmLabel;
        v0.mCancelLabel = this.mCancelLabel;
        return v0;
    }
    public synthetic bridge Object clone()
    {
        return this.clone();
    }
    public android.support.v4.app.NotificationCompat$Action$Builder extend(android.support.v4.app.NotificationCompat$Action$Builder p4)
    {
        v0 = new android.os.Bundle();
        if (this.mFlags != 1) {
            v0.putInt("flags", this.mFlags);
        }
        if (this.mInProgressLabel != 0) {
            v0.putCharSequence("inProgressLabel", this.mInProgressLabel);
        }
        if (this.mConfirmLabel != 0) {
            v0.putCharSequence("confirmLabel", this.mConfirmLabel);
        }
        if (this.mCancelLabel != 0) {
            v0.putCharSequence("cancelLabel", this.mCancelLabel);
        }
        p4.getExtras().putBundle("android.wearable.EXTENSIONS", v0);
        return p4;
    }
    public CharSequence getCancelLabel()
    {
        return this.mCancelLabel;
    }
    public CharSequence getConfirmLabel()
    {
        return this.mConfirmLabel;
    }
    public CharSequence getInProgressLabel()
    {
        return this.mInProgressLabel;
    }
    public boolean isAvailableOffline()
    {
        if ((this.mFlags & 1) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public android.support.v4.app.NotificationCompat$Action$WearableExtender setAvailableOffline(boolean p2)
    {
        this.setFlag(1, p2);
        return this;
    }
    public android.support.v4.app.NotificationCompat$Action$WearableExtender setCancelLabel(CharSequence p1)
    {
        this.mCancelLabel = p1;
        return this;
    }
    public android.support.v4.app.NotificationCompat$Action$WearableExtender setConfirmLabel(CharSequence p1)
    {
        this.mConfirmLabel = p1;
        return this;
    }
    private void setFlag(int p3, boolean p4)
    {
        if (p4 == 0) {
            this.mFlags = (this.mFlags & (p3 ^ -1));
        } else {
            this.mFlags = (this.mFlags | p3);
        }
        return;
    }
    public android.support.v4.app.NotificationCompat$Action$WearableExtender setInProgressLabel(CharSequence p1)
    {
        this.mInProgressLabel = p1;
        return this;
    }
}
