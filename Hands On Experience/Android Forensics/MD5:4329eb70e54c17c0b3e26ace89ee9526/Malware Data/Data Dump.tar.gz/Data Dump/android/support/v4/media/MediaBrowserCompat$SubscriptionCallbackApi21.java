package android.support.v4.media;
 class MediaBrowserCompat$SubscriptionCallbackApi21 extends android.support.v4.media.MediaBrowserCompat$SubscriptionCallback {
    private android.os.Bundle mOptions;
     android.support.v4.media.MediaBrowserCompat$SubscriptionCallback mSubscriptionCallback;
    final private Object mSubscriptionCallbackObj;
    public MediaBrowserCompat$SubscriptionCallbackApi21(android.support.v4.media.MediaBrowserCompat$SubscriptionCallback p3, android.os.Bundle p4)
    {
        this.mSubscriptionCallback = p3;
        this.mOptions = p4;
        this.mSubscriptionCallbackObj = android.support.v4.media.MediaBrowserCompatApi21.createSubscriptionCallback(new android.support.v4.media.MediaBrowserCompat$SubscriptionCallbackApi21$StubApi21(this, 0));
        return;
    }
    static synthetic Object access$1800(android.support.v4.media.MediaBrowserCompat$SubscriptionCallbackApi21 p1)
    {
        return p1.mSubscriptionCallbackObj;
    }
    static synthetic android.os.Bundle access$400(android.support.v4.media.MediaBrowserCompat$SubscriptionCallbackApi21 p1)
    {
        return p1.mOptions;
    }
    public void onChildrenLoaded(String p2, java.util.List p3)
    {
        this.mSubscriptionCallback.onChildrenLoaded(p2, p3);
        return;
    }
    public void onChildrenLoaded(String p2, java.util.List p3, android.os.Bundle p4)
    {
        this.mSubscriptionCallback.onChildrenLoaded(p2, p3, p4);
        return;
    }
    public void onError(String p2)
    {
        this.mSubscriptionCallback.onError(p2);
        return;
    }
    public void onError(String p2, android.os.Bundle p3)
    {
        this.mSubscriptionCallback.onError(p2, p3);
        return;
    }
}
