package android.support.v4.graphics.drawable;
 class DrawableCompatLollipop {
     DrawableCompatLollipop()
    {
        return;
    }
    public static void setHotspot(android.graphics.drawable.Drawable p0, float p1, float p2)
    {
        p0.setHotspot(p1, p2);
        return;
    }
    public static void setHotspotBounds(android.graphics.drawable.Drawable p0, int p1, int p2, int p3, int p4)
    {
        p0.setHotspotBounds(p1, p2, p3, p4);
        return;
    }
    public static void setTint(android.graphics.drawable.Drawable p1, int p2)
    {
        if ((p1 instanceof android.support.v4.graphics.drawable.DrawableWrapperLollipop) == 0) {
            p1.setTint(p2);
        } else {
            android.support.v4.graphics.drawable.DrawableCompatBase.setTint(p1, p2);
        }
        return;
    }
    public static void setTintList(android.graphics.drawable.Drawable p1, android.content.res.ColorStateList p2)
    {
        if ((p1 instanceof android.support.v4.graphics.drawable.DrawableWrapperLollipop) == 0) {
            p1.setTintList(p2);
        } else {
            android.support.v4.graphics.drawable.DrawableCompatBase.setTintList(p1, p2);
        }
        return;
    }
    public static void setTintMode(android.graphics.drawable.Drawable p1, android.graphics.PorterDuff$Mode p2)
    {
        if ((p1 instanceof android.support.v4.graphics.drawable.DrawableWrapperLollipop) == 0) {
            p1.setTintMode(p2);
        } else {
            android.support.v4.graphics.drawable.DrawableCompatBase.setTintMode(p1, p2);
        }
        return;
    }
    public static android.graphics.drawable.Drawable wrapForTinting(android.graphics.drawable.Drawable p1)
    {
        if (((p1 instanceof android.graphics.drawable.GradientDrawable) != 0) || ((p1 instanceof android.graphics.drawable.DrawableContainer) != 0)) {
            p1 = new android.support.v4.graphics.drawable.DrawableWrapperLollipop(p1);
        }
        return p1;
    }
}
