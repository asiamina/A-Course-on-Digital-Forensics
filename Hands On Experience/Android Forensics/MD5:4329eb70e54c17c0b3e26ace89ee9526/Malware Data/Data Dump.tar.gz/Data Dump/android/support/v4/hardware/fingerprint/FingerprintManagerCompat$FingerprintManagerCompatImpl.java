package android.support.v4.hardware.fingerprint;
interface abstract class FingerprintManagerCompat$FingerprintManagerCompatImpl {
    abstract public void authenticate();
    abstract public boolean hasEnrolledFingerprints();
    abstract public boolean isHardwareDetected();
}
