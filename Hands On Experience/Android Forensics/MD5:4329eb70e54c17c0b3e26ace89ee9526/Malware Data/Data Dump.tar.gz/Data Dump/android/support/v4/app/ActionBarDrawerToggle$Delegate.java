package android.support.v4.app;
public interface abstract class ActionBarDrawerToggle$Delegate {
    abstract public android.graphics.drawable.Drawable getThemeUpIndicator();
    abstract public void setActionBarDescription();
    abstract public void setActionBarUpIndicator();
}
