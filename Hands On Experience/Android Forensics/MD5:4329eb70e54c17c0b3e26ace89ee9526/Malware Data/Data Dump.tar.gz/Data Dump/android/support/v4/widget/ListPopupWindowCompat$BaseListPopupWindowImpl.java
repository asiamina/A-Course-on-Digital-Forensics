package android.support.v4.widget;
 class ListPopupWindowCompat$BaseListPopupWindowImpl implements android.support.v4.widget.ListPopupWindowCompat$ListPopupWindowImpl {
     ListPopupWindowCompat$BaseListPopupWindowImpl()
    {
        return;
    }
    public android.view.View$OnTouchListener createDragToOpenListener(Object p2, android.view.View p3)
    {
        return 0;
    }
}
