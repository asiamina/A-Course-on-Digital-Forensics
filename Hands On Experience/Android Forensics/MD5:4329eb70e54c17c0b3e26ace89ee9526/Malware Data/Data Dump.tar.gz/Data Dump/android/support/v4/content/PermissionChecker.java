package android.support.v4.content;
final public class PermissionChecker {
    final public static int PERMISSION_DENIED;
    final public static int PERMISSION_DENIED_APP_OP;
    final public static int PERMISSION_GRANTED;
    public static int checkCallingPermission(android.content.Context p2, String p3, String p4)
    {
        if (android.os.Binder.getCallingPid() != android.os.Process.myPid()) {
            v0 = android.support.v4.content.PermissionChecker.checkPermission(p2, p3, android.os.Binder.getCallingPid(), android.os.Binder.getCallingUid(), p4);
        } else {
            v0 = -1;
        }
        return v0;
    }
    public static int checkPermission(android.content.Context p5, String p6, int p7, int p8, String p9)
    {
        v2 = -1;
        if (p5.checkPermission(p6, p7, p8) != -1) {
            v0 = android.support.v4.app.AppOpsManagerCompat.permissionToOp(p6);
            if (v0 != 0) {
                if (p9 == 0) {
                    v1 = p5.getPackageManager().getPackagesForUid(p8);
                    if ((v1 == 0) || (v1.length <= 0)) {
                        return v2;
                    } else {
                        p9 = v1[0];
                    }
                }
                if (android.support.v4.app.AppOpsManagerCompat.noteProxyOp(p5, v0, p9) == 0) {
                    v2 = 0;
                } else {
                    v2 = -2;
                }
            } else {
                v2 = 0;
            }
        }
    }
    public static int checkSelfPermission(android.content.Context p3, String p4)
    {
        return android.support.v4.content.PermissionChecker.checkPermission(p3, p4, android.os.Process.myPid(), android.os.Process.myUid(), p3.getPackageName());
    }
    private PermissionChecker()
    {
        return;
    }
    public static int checkCallingOrSelfPermission(android.content.Context p3, String p4)
    {
        if (android.os.Binder.getCallingPid() != android.os.Process.myPid()) {
            v0 = 0;
        } else {
            v0 = p3.getPackageName();
        }
        return android.support.v4.content.PermissionChecker.checkPermission(p3, p4, android.os.Binder.getCallingPid(), android.os.Binder.getCallingUid(), v0);
    }
}
