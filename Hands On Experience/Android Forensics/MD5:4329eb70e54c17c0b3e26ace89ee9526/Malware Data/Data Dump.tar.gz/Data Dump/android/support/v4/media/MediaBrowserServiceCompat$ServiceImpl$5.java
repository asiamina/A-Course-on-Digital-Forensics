package android.support.v4.media;
 class MediaBrowserServiceCompat$ServiceImpl$5 implements java.lang.Runnable {
    final synthetic android.support.v4.os.ResultReceiver val$receiver;
    final synthetic String val$mediaId;
    final synthetic android.support.v4.media.MediaBrowserServiceCompat$ServiceImpl this$1;
     MediaBrowserServiceCompat$ServiceImpl$5(android.support.v4.media.MediaBrowserServiceCompat$ServiceImpl p1, String p2, android.support.v4.os.ResultReceiver p3)
    {
        this.this$1 = p1;
        this.val$mediaId = p2;
        this.val$receiver = p3;
        return;
    }
    public void run()
    {
        android.support.v4.media.MediaBrowserServiceCompat.access$900(this.this$1.this$0, this.val$mediaId, this.val$receiver);
        return;
    }
}
