package android.support.v4.widget;
public class DrawerLayout extends android.view.ViewGroup implements android.support.v4.widget.DrawerLayoutImpl {
    private CharSequence mTitleRight;
    private int mLockModeLeft;
    final private android.support.v4.widget.ViewDragHelper mLeftDragger;
    final private android.support.v4.widget.ViewDragHelper mRightDragger;
    final private static int DEFAULT_SCRIM_COLOR;
    private float mInitialMotionX;
    private float mInitialMotionY;
    final private static boolean SET_DRAWER_SHADOW_FROM_ELEVATION;
    final public static int STATE_SETTLING;
    final private static int[] LAYOUT_ATTRS;
    private int mScrimColor;
    final private static boolean CHILDREN_DISALLOW_INTERCEPT;
    private android.graphics.drawable.Drawable mShadowStart;
    private android.graphics.drawable.Drawable mShadowRightResolved;
    private float mScrimOpacity;
    final private android.support.v4.widget.DrawerLayout$ViewDragCallback mRightCallback;
    final private static boolean ALLOW_EDGE_LOCK;
    final private static int PEEK_DELAY;
    final public static int LOCK_MODE_UNLOCKED;
    final public static int STATE_IDLE;
    final private static String TAG;
    private android.graphics.drawable.Drawable mShadowRight;
    private android.graphics.drawable.Drawable mStatusBarBackground;
    private android.graphics.drawable.Drawable mShadowLeft;
    final public static int LOCK_MODE_LOCKED_CLOSED;
    private boolean mFirstLayout;
    private boolean mChildrenCanceledTouch;
    private int mLockModeRight;
    private boolean mDrawStatusBarBackground;
    private Object mLastInsets;
    private int mMinDrawerMargin;
    final private static int MIN_DRAWER_MARGIN;
    final private static int DRAWER_ELEVATION;
    private android.support.v4.widget.DrawerLayout$DrawerListener mListener;
    final public static int LOCK_MODE_LOCKED_OPEN;
    final private java.util.ArrayList mNonDrawerViews;
    private boolean mDisallowInterceptRequested;
    final private static boolean CAN_HIDE_DESCENDANTS;
    private android.graphics.drawable.Drawable mShadowLeftResolved;
    final private static float TOUCH_SLOP_SENSITIVITY;
    private android.graphics.Paint mScrimPaint;
    private float mDrawerElevation;
    private int mDrawerState;
    private android.graphics.drawable.Drawable mShadowEnd;
    private CharSequence mTitleLeft;
    final static android.support.v4.widget.DrawerLayout$DrawerLayoutCompatImpl IMPL;
    final private android.support.v4.widget.DrawerLayout$ViewDragCallback mLeftCallback;
    final private android.support.v4.widget.DrawerLayout$ChildAccessibilityDelegate mChildAccessibilityDelegate;
    private boolean mInLayout;
    final private static int MIN_FLING_VELOCITY;
    final public static int STATE_DRAGGING;
    public void requestLayout()
    {
        if (this.mInLayout) {
            super.requestLayout();
        }
        return;
    }
    private android.graphics.drawable.Drawable resolveLeftShadow()
    {
        v0 = android.support.v4.view.ViewCompat.getLayoutDirection(this);
        if (v0 != 0) {
            if (this.mShadowEnd == 0) {
                v1 = this.mShadowLeft;
            } else {
                this.mirror(this.mShadowEnd, v0);
                v1 = this.mShadowEnd;
            }
        } else {
            } else {
                this.mirror(this.mShadowStart, v0);
                v1 = this.mShadowStart;
            }
        }
        return v1;
    }
    private android.graphics.drawable.Drawable resolveRightShadow()
    {
        v0 = android.support.v4.view.ViewCompat.getLayoutDirection(this);
        if (v0 != 0) {
            if (this.mShadowStart == 0) {
                v1 = this.mShadowRight;
            } else {
                this.mirror(this.mShadowStart, v0);
                v1 = this.mShadowStart;
            }
        } else {
            } else {
                this.mirror(this.mShadowEnd, v0);
                v1 = this.mShadowEnd;
            }
        }
        return v1;
    }
    private void resolveShadowDrawables()
    {
        if (!android.support.v4.widget.DrawerLayout.SET_DRAWER_SHADOW_FROM_ELEVATION) {
            this.resolveLeftShadow();
            this.mShadowLeftResolved = this;
            this.resolveRightShadow();
            this.mShadowRightResolved = this;
        }
        return;
    }
    public void setChildInsets(Object p2, boolean p3)
    {
        this.mLastInsets = p2;
        this.mDrawStatusBarBackground = p3;
        if ((p3 != 0) || (this.getBackground() != 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        this.setWillNotDraw(v0);
        this.requestLayout();
        return;
    }
    public void setDrawerElevation(float p4)
    {
        this.mDrawerElevation = p4;
        v1 = 0;
        while (v1 < this.getChildCount()) {
            v0 = this.getChildAt(v1);
            if (this.isDrawerView(v0) != 0) {
                android.support.v4.view.ViewCompat.setElevation(v0, this.mDrawerElevation);
            }
            v1++;
        }
        return;
    }
    public void setDrawerListener(android.support.v4.widget.DrawerLayout$DrawerListener p1)
    {
        this.mListener = p1;
        return;
    }
    public void setDrawerLockMode(int p2)
    {
        this.setDrawerLockMode(p2, 3);
        this.setDrawerLockMode(p2, 5);
        return;
    }
    public void setDrawerLockMode(int p7, int p8)
    {
        v0 = android.support.v4.view.GravityCompat.getAbsoluteGravity(p8, android.support.v4.view.ViewCompat.getLayoutDirection(this));
        if (v0 != 3) {
            if (v0 == 5) {
                this.mLockModeRight = p7;
            }
        } else {
            this.mLockModeLeft = p7;
        }
        if (p7 != 0) {
            if (v0 != 3) {
                v1 = this.mRightDragger;
            } else {
                v1 = this.mLeftDragger;
            }
            v1.cancel();
        }
        switch (p7) {
            case 1:
                v2 = this.findDrawerWithGravity(v0);
                if (v2 == 0) {
                } else {
                    this.closeDrawer(v2);
                }
                break;
            case 2:
                v3 = this.findDrawerWithGravity(v0);
                if (v3 == 0) {
                } else {
                    this.openDrawer(v3);
                }
                break;
        }
        return;
    }
    public void setDrawerLockMode(int p5, android.view.View p6)
    {
        if (this.isDrawerView(p6) != 0) {
            this.setDrawerLockMode(p5, p6.getLayoutParams().gravity);
            return;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("View ").append(p6).append(" is not a ").append("drawer with appropriate layout_gravity").toString());
        }
    }
    public void setDrawerShadow(int p2, int p3)
    {
        this.setDrawerShadow(this.getResources().getDrawable(p2), p3);
        return;
    }
    public void setDrawerShadow(android.graphics.drawable.Drawable p4, int p5)
    {
        if (!android.support.v4.widget.DrawerLayout.SET_DRAWER_SHADOW_FROM_ELEVATION) {
            if ((p5 & 1.1754947712118268e-38) != 1.1754947712118268e-38) {
                if ((p5 & 1.1754950514715197e-38) != 1.1754950514715197e-38) {
                    if ((p5 & 3) != 3) {
                        if ((p5 & 5) != 5) {
                            return;
                        } else {
                            this.mShadowRight = p4;
                        }
                    } else {
                        this.mShadowLeft = p4;
                    }
                } else {
                    this.mShadowEnd = p4;
                }
            } else {
                this.mShadowStart = p4;
            }
            this.resolveShadowDrawables();
            this.invalidate();
        }
    }
    public void setDrawerTitle(int p3, CharSequence p4)
    {
        v0 = android.support.v4.view.GravityCompat.getAbsoluteGravity(p3, android.support.v4.view.ViewCompat.getLayoutDirection(this));
        if (v0 != 3) {
            if (v0 == 5) {
                this.mTitleRight = p4;
            }
        } else {
            this.mTitleLeft = p4;
        }
        return;
    }
     void setDrawerViewOffset(android.view.View p3, float p4)
    {
        v0 = p3.getLayoutParams();
        if (p4 != v0.onScreen) {
            v0.onScreen = p4;
            this.dispatchOnDrawerSlide(p3, p4);
        }
        return;
    }
    public void setScrimColor(int p1)
    {
        this.mScrimColor = p1;
        this.invalidate();
        return;
    }
    public void setStatusBarBackground(int p2)
    {
        if (p2 == 0) {
            v0 = 0;
        } else {
            v0 = android.support.v4.content.ContextCompat.getDrawable(this.getContext(), p2);
        }
        this.mStatusBarBackground = v0;
        this.invalidate();
        return;
    }
    public void setStatusBarBackground(android.graphics.drawable.Drawable p1)
    {
        this.mStatusBarBackground = p1;
        this.invalidate();
        return;
    }
    public void setStatusBarBackgroundColor(int p2)
    {
        this.mStatusBarBackground = new android.graphics.drawable.ColorDrawable(p2);
        this.invalidate();
        return;
    }
    private void updateChildrenImportantForAccessibility(android.view.View p5, boolean p6)
    {
        v1 = this.getChildCount();
        v2 = 0;
        while (v2 < v1) {
            v0 = this.getChildAt(v2);
            if (((p6 != 0) || (this.isDrawerView(v0) != 0)) && ((p6 == 0) || (v0 != p5))) {
                android.support.v4.view.ViewCompat.setImportantForAccessibility(v0, 4);
            } else {
                android.support.v4.view.ViewCompat.setImportantForAccessibility(v0, 1);
            }
            v2++;
        }
        return;
    }
     void updateDrawerState(int p8, int p9, android.view.View p10)
    {
        v0 = this.mLeftDragger.getViewDragState();
        v2 = this.mRightDragger.getViewDragState();
        if ((v0 != 1) && (v2 != 1)) {
            if ((v0 != 2) && (v2 != 2)) {
                v3 = 0;
            } else {
                v3 = 2;
            }
        } else {
            v3 = 1;
        }
        if ((p10 != 0) && (p9 == 0)) {
            v1 = p10.getLayoutParams();
            if (v1.onScreen != 0) {
                if (v1.onScreen == 1.0) {
                    this.dispatchOnDrawerOpened(p10);
                }
            } else {
                this.dispatchOnDrawerClosed(p10);
            }
        }
        if (v3 != this.mDrawerState) {
            this.mDrawerState = v3;
            if (this.mListener != 0) {
                this.mListener.onDrawerStateChanged(v3);
            }
        }
        return;
    }
    static DrawerLayout()
    {
        v2 = 1;
        v1 = new int[1];
        v1[0] = 2.369405967361196e-38;
        android.support.v4.widget.DrawerLayout.LAYOUT_ATTRS = v1;
        if (android.os.Build$VERSION.SDK_INT < 19) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        android.support.v4.widget.DrawerLayout.CAN_HIDE_DESCENDANTS = v1;
        if (android.os.Build$VERSION.SDK_INT < 21) {
            v2 = 0;
        }
        android.support.v4.widget.DrawerLayout.SET_DRAWER_SHADOW_FROM_ELEVATION = v2;
        if (android.os.Build$VERSION.SDK_INT < 21) {
            android.support.v4.widget.DrawerLayout.IMPL = new android.support.v4.widget.DrawerLayout$DrawerLayoutCompatImplBase();
        } else {
            android.support.v4.widget.DrawerLayout.IMPL = new android.support.v4.widget.DrawerLayout$DrawerLayoutCompatImplApi21();
        }
        return;
    }
    public DrawerLayout(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }
    public DrawerLayout(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 0);
        return;
    }
    public DrawerLayout(android.content.Context p7, android.util.AttributeSet p8, int p9)
    {
        this(p7, p8, p9);
        this.mChildAccessibilityDelegate = new android.support.v4.widget.DrawerLayout$ChildAccessibilityDelegate(this);
        this.mScrimColor = -6.617444900424222e-24;
        this.mScrimPaint = new android.graphics.Paint();
        this.mFirstLayout = 1;
        this.mShadowStart = 0;
        this.mShadowEnd = 0;
        this.mShadowLeft = 0;
        this.mShadowRight = 0;
        this.setDescendantFocusability(3.6734198463196485e-40);
        v0 = this.getResources().getDisplayMetrics().density;
        this.mMinDrawerMargin = ((int) ((64.0 * v0) + 0.5));
        v1 = (400.0 * v0);
        this.mLeftCallback = new android.support.v4.widget.DrawerLayout$ViewDragCallback(this, 3);
        this.mRightCallback = new android.support.v4.widget.DrawerLayout$ViewDragCallback(this, 5);
        this.mLeftDragger = android.support.v4.widget.ViewDragHelper.create(this, 1.0, this.mLeftCallback);
        this.mLeftDragger.setEdgeTrackingEnabled(1);
        this.mLeftDragger.setMinVelocity(v1);
        this.mLeftCallback.setDragger(this.mLeftDragger);
        this.mRightDragger = android.support.v4.widget.ViewDragHelper.create(this, 1.0, this.mRightCallback);
        this.mRightDragger.setEdgeTrackingEnabled(2);
        this.mRightDragger.setMinVelocity(v1);
        this.mRightCallback.setDragger(this.mRightDragger);
        this.setFocusableInTouchMode(1);
        android.support.v4.view.ViewCompat.setImportantForAccessibility(this, 1);
        android.support.v4.view.ViewCompat.setAccessibilityDelegate(this, new android.support.v4.widget.DrawerLayout$AccessibilityDelegate(this));
        android.support.v4.view.ViewGroupCompat.setMotionEventSplittingEnabled(this, 0);
        if (android.support.v4.view.ViewCompat.getFitsSystemWindows(this) != 0) {
            android.support.v4.widget.DrawerLayout.IMPL.configureApplyInsets(this);
            this.mStatusBarBackground = android.support.v4.widget.DrawerLayout.IMPL.getDefaultStatusBarBackground(p7);
        }
        this.mDrawerElevation = (10.0 * v0);
        this.mNonDrawerViews = new java.util.ArrayList();
        return;
    }
    static synthetic int[] access$100()
    {
        return android.support.v4.widget.DrawerLayout.LAYOUT_ATTRS;
    }
    static synthetic boolean access$200()
    {
        return android.support.v4.widget.DrawerLayout.CAN_HIDE_DESCENDANTS;
    }
    static synthetic android.view.View access$300(android.support.v4.widget.DrawerLayout p1)
    {
        return p1.findVisibleDrawer();
    }
    static synthetic boolean access$400(android.view.View p1)
    {
        return android.support.v4.widget.DrawerLayout.includeChildForAccessibility(p1);
    }
    public void addFocusables(java.util.ArrayList p8, int p9, int p10)
    {
        if (this.getDescendantFocusability() != 5.510129769479473e-40) {
            v1 = this.getChildCount();
            v3 = 0;
            v2 = 0;
            while (v2 < v1) {
                v0 = this.getChildAt(v2);
                if (this.isDrawerView(v0) == 0) {
                    this.mNonDrawerViews.add(v0);
                } else {
                    if (this.isDrawerOpen(v0) != 0) {
                        v3 = 1;
                        v0.addFocusables(p8, p9, p10);
                    }
                }
                v2++;
            }
            if (v3 == 0) {
                v4 = this.mNonDrawerViews.size();
                v2 = 0;
                while (v2 < v4) {
                    v0 = this.mNonDrawerViews.get(v2);
                    if (v0.getVisibility() == 0) {
                        v0.addFocusables(p8, p9, p10);
                    }
                    v2++;
                }
            }
            this.mNonDrawerViews.clear();
        }
        return;
    }
    public void addView(android.view.View p3, int p4, android.view.ViewGroup$LayoutParams p5)
    {
        super.addView(p3, p4, p5);
        if ((this.findOpenDrawer() == 0) && (this.isDrawerView(p3) == 0)) {
            android.support.v4.view.ViewCompat.setImportantForAccessibility(p3, 1);
        } else {
            android.support.v4.view.ViewCompat.setImportantForAccessibility(p3, 4);
        }
        if (android.support.v4.widget.DrawerLayout.CAN_HIDE_DESCENDANTS) {
            android.support.v4.view.ViewCompat.setAccessibilityDelegate(p3, this.mChildAccessibilityDelegate);
        }
        return;
    }
     void cancelChildViewTouch()
    {
        if (this.mChildrenCanceledTouch) {
            v0 = android.os.SystemClock.uptimeMillis();
            v8 = android.view.MotionEvent.obtain(v0, v1, v0, v3, 3, 0, 0, 0);
            v9 = this.getChildCount();
            v10 = 0;
            while (v10 < v9) {
                this.getChildAt(v10).dispatchTouchEvent(v8);
                v10++;
            }
            v8.recycle();
            this.mChildrenCanceledTouch = 1;
        }
        return;
    }
     boolean checkDrawerViewAbsoluteGravity(android.view.View p3, int p4)
    {
        if ((this.getDrawerViewAbsoluteGravity(p3) & p4) != p4) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        return v1;
    }
    protected boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p2)
    {
        if (((p2 instanceof android.support.v4.widget.DrawerLayout$LayoutParams) == 0) || (super.checkLayoutParams(p2) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public void closeDrawer(int p5)
    {
        v0 = this.findDrawerWithGravity(p5);
        if (v0 != 0) {
            this.closeDrawer(v0);
            return;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("No drawer view found with gravity ").append(android.support.v4.widget.DrawerLayout.gravityToString(p5)).toString());
        }
    }
    public void closeDrawer(android.view.View p5)
    {
        if (this.isDrawerView(p5) != 0) {
            if (!this.mFirstLayout) {
                if (this.checkDrawerViewAbsoluteGravity(p5, 3) == 0) {
                    this.mRightDragger.smoothSlideViewTo(p5, this.getWidth(), p5.getTop());
                } else {
                    this.mLeftDragger.smoothSlideViewTo(p5, (- p5.getWidth()), p5.getTop());
                }
            } else {
                v0 = p5.getLayoutParams();
                v0.onScreen = 0;
                v0.knownOpen = 0;
            }
            this.invalidate();
            return;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("View ").append(p5).append(" is not a sliding drawer").toString());
        }
    }
    public void closeDrawers()
    {
        this.closeDrawers(0);
        return;
    }
     void closeDrawers(boolean p10)
    {
        v5 = 0;
        v1 = this.getChildCount();
        v3 = 0;
        while (v3 < v1) {
            v0 = this.getChildAt(v3);
            v4 = v0.getLayoutParams();
            if ((this.isDrawerView(v0) != 0) && ((p10 == 0) || (v4.isPeeking))) {
                v2 = v0.getWidth();
                if (this.checkDrawerViewAbsoluteGravity(v0, 3) == 0) {
                    v5 |= this.mRightDragger.smoothSlideViewTo(v0, this.getWidth(), v0.getTop());
                } else {
                    v5 |= this.mLeftDragger.smoothSlideViewTo(v0, (- v2), v0.getTop());
                }
                v4.isPeeking = 0;
            }
            v3++;
        }
        this.mLeftCallback.removeCallbacks();
        this.mRightCallback.removeCallbacks();
        if (v5 != 0) {
            this.invalidate();
        }
        return;
    }
    public void computeScroll()
    {
        v0 = this.getChildCount();
        v3 = 0;
        v1 = 0;
        while (v1 < v0) {
            v3 = Math.max(v3, this.getChildAt(v1).getLayoutParams().onScreen);
            v1++;
        }
        this.mScrimOpacity = v3;
        if ((this.mLeftDragger.continueSettling(1) | this.mRightDragger.continueSettling(1)) != 0) {
            android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
        }
        return;
    }
     void dispatchOnDrawerClosed(android.view.View p5)
    {
        v0 = p5.getLayoutParams();
        if (v0.knownOpen) {
            v0.knownOpen = 0;
            if (this.mListener != 0) {
                this.mListener.onDrawerClosed(p5);
            }
            this.updateChildrenImportantForAccessibility(p5, 0);
            if (this.hasWindowFocus() != 0) {
                v1 = this.getRootView();
                if (v1 != 0) {
                    v1.sendAccessibilityEvent(32);
                }
            }
        }
        return;
    }
     void dispatchOnDrawerOpened(android.view.View p4)
    {
        v0 = p4.getLayoutParams();
        if (v0.knownOpen) {
            v0.knownOpen = 1;
            if (this.mListener != 0) {
                this.mListener.onDrawerOpened(p4);
            }
            this.updateChildrenImportantForAccessibility(p4, 1);
            if (this.hasWindowFocus() != 0) {
                this.sendAccessibilityEvent(32);
            }
            p4.requestFocus();
        }
        return;
    }
     void dispatchOnDrawerSlide(android.view.View p2, float p3)
    {
        if (this.mListener != 0) {
            this.mListener.onDrawerSlide(p2, p3);
        }
        return;
    }
    protected boolean drawChild(android.graphics.Canvas p29, android.view.View p30, long p31)
    {
        v18 = this.getHeight();
        v17 = this.isContentView(p30);
        v13 = 0;
        v14 = this.getWidth();
        v21 = p29.save();
        if (v17 != 0) {
            v10 = this.getChildCount();
            v19 = 0;
            while (v19 < v10) {
                v25 = this.getChildAt(v19);
                if ((v25 != p30) && ((v25.getVisibility() == 0) && ((android.support.v4.widget.DrawerLayout.hasOpaqueBackground(v25) != 0) && ((this.isDrawerView(v25) != 0) && (v25.getHeight() >= v18))))) {
                    if (this.checkDrawerViewAbsoluteGravity(v25, 3) == 0) {
                        v26 = v25.getLeft();
                        if (v26 < v14) {
                            v14 = v26;
                        }
                    } else {
                        v27 = v25.getRight();
                        if (v27 > v13) {
                            v13 = v27;
                        }
                    }
                }
                v19++;
            }
            p29.clipRect(v13, 0, v14, this.getHeight());
        }
        v22 = this.drawChild(p29, p30, p31, v32);
        p29.restoreToCount(v21);
        if ((this.mScrimOpacity <= 0) || (v17 == 0)) {
            if ((this.mShadowLeftResolved == 0) || (this.checkDrawerViewAbsoluteGravity(p30, 3) == 0)) {
                if ((this.mShadowRightResolved != 0) && (this.checkDrawerViewAbsoluteGravity(p30, 5) != 0)) {
                    v23 = this.mShadowRightResolved.getIntrinsicWidth();
                    v11 = p30.getLeft();
                    v8 = Math.max(0, Math.min((((float) (this.getWidth() - v11)) / ((float) this.mRightDragger.getEdgeSize())), 1.0));
                    this.mShadowRightResolved.setBounds((v11 - v23), p30.getTop(), v11, p30.getBottom());
                    this.mShadowRightResolved.setAlpha(((int) (255.0 * v8)));
                    this.mShadowRightResolved.draw(p29);
                }
            } else {
                v23 = this.mShadowLeftResolved.getIntrinsicWidth();
                v12 = p30.getRight();
                v8 = Math.max(0, Math.min((((float) v12) / ((float) this.mLeftDragger.getEdgeSize())), 1.0));
                this.mShadowLeftResolved.setBounds(v12, p30.getTop(), (v12 + v23), p30.getBottom());
                this.mShadowLeftResolved.setAlpha(((int) (255.0 * v8)));
                this.mShadowLeftResolved.draw(p29);
            }
        } else {
            this.mScrimPaint.setColor(((((int) (((float) ((this.mScrimColor & -1.7014118346046923e+38) >> 24)) * this.mScrimOpacity)) << 24) | (this.mScrimColor & 2.3509885615147286e-38)));
            p29.drawRect(((float) v13), 0, ((float) v14), ((float) this.getHeight()), this.mScrimPaint);
        }
        return v22;
    }
     android.view.View findDrawerWithGravity(int p7)
    {
        v0 = (android.support.v4.view.GravityCompat.getAbsoluteGravity(p7, android.support.v4.view.ViewCompat.getLayoutDirection(this)) & 7);
        v3 = this.getChildCount();
        v4 = 0;
        while (v4 < v3) {
            v1 = this.getChildAt(v4);
            if ((this.getDrawerViewAbsoluteGravity(v1) & 7) != v0) {
                v4++;
            }
            return v1;
        }
        v1 = 0;
    }
     android.view.View findOpenDrawer()
    {
        v1 = this.getChildCount();
        v2 = 0;
        while (v2 < v1) {
            v0 = this.getChildAt(v2);
            if (!v0.getLayoutParams().knownOpen) {
                v2++;
            }
            return v0;
        }
        v0 = 0;
    }
    private android.view.View findVisibleDrawer()
    {
        v1 = this.getChildCount();
        v2 = 0;
        while (v2 < v1) {
            v0 = this.getChildAt(v2);
            if ((this.isDrawerView(v0) == 0) || (this.isDrawerVisible(v0) == 0)) {
                v2++;
            }
            return v0;
        }
        v0 = 0;
    }
    protected android.view.ViewGroup$LayoutParams generateDefaultLayoutParams()
    {
        return new android.support.v4.widget.DrawerLayout$LayoutParams(-1, -1);
    }
    public android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p3)
    {
        return new android.support.v4.widget.DrawerLayout$LayoutParams(this.getContext(), p3);
    }
    protected android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p2)
    {
        if ((p2 instanceof android.support.v4.widget.DrawerLayout$LayoutParams) == 0) {
            if ((p2 instanceof android.view.ViewGroup$MarginLayoutParams) == 0) {
                v0 = new android.support.v4.widget.DrawerLayout$LayoutParams(p2);
            } else {
                v0 = new android.support.v4.widget.DrawerLayout$LayoutParams(p2);
            }
        } else {
            v0 = new android.support.v4.widget.DrawerLayout$LayoutParams(p2);
        }
        return v0;
    }
    public float getDrawerElevation()
    {
        if (!android.support.v4.widget.DrawerLayout.SET_DRAWER_SHADOW_FROM_ELEVATION) {
            v0 = 0;
        } else {
            v0 = this.mDrawerElevation;
        }
        return v0;
    }
    public int getDrawerLockMode(int p3)
    {
        v0 = android.support.v4.view.GravityCompat.getAbsoluteGravity(p3, android.support.v4.view.ViewCompat.getLayoutDirection(this));
        if (v0 != 3) {
            if (v0 != 5) {
                v1 = 0;
            } else {
                v1 = this.mLockModeRight;
            }
        } else {
            v1 = this.mLockModeLeft;
        }
        return v1;
    }
    public int getDrawerLockMode(android.view.View p3)
    {
        v0 = this.getDrawerViewAbsoluteGravity(p3);
        if (v0 != 3) {
            if (v0 != 5) {
                v1 = 0;
            } else {
                v1 = this.mLockModeRight;
            }
        } else {
            v1 = this.mLockModeLeft;
        }
        return v1;
    }
    public CharSequence getDrawerTitle(int p3)
    {
        v0 = android.support.v4.view.GravityCompat.getAbsoluteGravity(p3, android.support.v4.view.ViewCompat.getLayoutDirection(this));
        if (v0 != 3) {
            if (v0 != 5) {
                v1 = 0;
            } else {
                v1 = this.mTitleRight;
            }
        } else {
            v1 = this.mTitleLeft;
        }
        return v1;
    }
     int getDrawerViewAbsoluteGravity(android.view.View p3)
    {
        return android.support.v4.view.GravityCompat.getAbsoluteGravity(p3.getLayoutParams().gravity, android.support.v4.view.ViewCompat.getLayoutDirection(this));
    }
     float getDrawerViewOffset(android.view.View p2)
    {
        return p2.getLayoutParams().onScreen;
    }
    public android.graphics.drawable.Drawable getStatusBarBackgroundDrawable()
    {
        return this.mStatusBarBackground;
    }
    static String gravityToString(int p2)
    {
        if ((p2 & 3) != 3) {
            if ((p2 & 5) != 5) {
                v0 = Integer.toHexString(p2);
            } else {
                v0 = "RIGHT";
            }
        } else {
            v0 = "LEFT";
        }
        return v0;
    }
    private static boolean hasOpaqueBackground(android.view.View p4)
    {
        v1 = 0;
        v0 = p4.getBackground();
        if ((v0 != 0) && (v0.getOpacity() == -1)) {
            v1 = 1;
        }
        return v1;
    }
    private boolean hasPeekingDrawer()
    {
        v0 = this.getChildCount();
        v1 = 0;
        while (v1 < v0) {
            if (!this.getChildAt(v1).getLayoutParams().isPeeking) {
                v1++;
            } else {
                v3 = 1;
            }
            return v3;
        }
        v3 = 0;
    }
    private boolean hasVisibleDrawer()
    {
        this.findVisibleDrawer();
        if (this == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    private static boolean includeChildForAccessibility(android.view.View p2)
    {
        if ((android.support.v4.view.ViewCompat.getImportantForAccessibility(p2) == 4) || (android.support.v4.view.ViewCompat.getImportantForAccessibility(p2) == 2)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
     boolean isContentView(android.view.View p2)
    {
        if (p2.getLayoutParams().gravity != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public boolean isDrawerOpen(int p3)
    {
        v0 = this.findDrawerWithGravity(p3);
        if (v0 == 0) {
            v1 = 0;
        } else {
            v1 = this.isDrawerOpen(v0);
        }
        return v1;
    }
    public boolean isDrawerOpen(android.view.View p4)
    {
        if (this.isDrawerView(p4) != 0) {
            return p4.getLayoutParams().knownOpen;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("View ").append(p4).append(" is not a drawer").toString());
        }
    }
     boolean isDrawerView(android.view.View p4)
    {
        if ((android.support.v4.view.GravityCompat.getAbsoluteGravity(p4.getLayoutParams().gravity, android.support.v4.view.ViewCompat.getLayoutDirection(p4)) & 7) == 0) {
            v2 = 0;
        } else {
            v2 = 1;
        }
        return v2;
    }
    public boolean isDrawerVisible(int p3)
    {
        v0 = this.findDrawerWithGravity(p3);
        if (v0 == 0) {
            v1 = 0;
        } else {
            v1 = this.isDrawerVisible(v0);
        }
        return v1;
    }
    public boolean isDrawerVisible(android.view.View p4)
    {
        if (this.isDrawerView(p4) != 0) {
            if (p4.getLayoutParams().onScreen <= 0) {
                v0 = 0;
            } else {
                v0 = 1;
            }
            return v0;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("View ").append(p4).append(" is not a drawer").toString());
        }
    }
    private boolean mirror(android.graphics.drawable.Drawable p2, int p3)
    {
        if ((p2 != 0) && (android.support.v4.graphics.drawable.DrawableCompat.isAutoMirrored(p2) != 0)) {
            android.support.v4.graphics.drawable.DrawableCompat.setLayoutDirection(p2, p3);
            v0 = 1;
        } else {
            v0 = 0;
        }
        return v0;
    }
     void moveDrawerToOffset(android.view.View p7, float p8)
    {
        v2 = this.getDrawerViewOffset(p7);
        v4 = p7.getWidth();
        v0 = (((int) (((float) v4) * p8)) - ((int) (((float) v4) * v2)));
        if (this.checkDrawerViewAbsoluteGravity(p7, 3) == 0) {
            v0 = (- v0);
        }
        p7.offsetLeftAndRight(v0);
        this.setDrawerViewOffset(p7, p8);
        return;
    }
    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        this.mFirstLayout = 1;
        return;
    }
    protected void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        this.mFirstLayout = 1;
        return;
    }
    public void onDraw(android.graphics.Canvas p5)
    {
        super.onDraw(p5);
        if ((this.mDrawStatusBarBackground) && (this.mStatusBarBackground != 0)) {
            v0 = android.support.v4.widget.DrawerLayout.IMPL.getTopInset(this.mLastInsets);
            if (v0 > 0) {
                this.mStatusBarBackground.setBounds(0, 0, this.getWidth(), v0);
                this.mStatusBarBackground.draw(p5);
            }
        }
        return;
    }
    public boolean onInterceptTouchEvent(android.view.MotionEvent p12)
    {
        v6 = 0;
        v0 = android.support.v4.view.MotionEventCompat.getActionMasked(p12);
        v2 = (this.mLeftDragger.shouldInterceptTouchEvent(p12) | this.mRightDragger.shouldInterceptTouchEvent(p12));
        v3 = 0;
        switch (v0) {
            case 0:
                v4 = p12.getX();
                v5 = p12.getY();
                this.mInitialMotionX = v4;
                this.mInitialMotionY = v5;
                if (this.mScrimOpacity > 0) {
                    v1 = this.mLeftDragger.findTopChildUnder(((int) v4), ((int) v5));
                    if ((v1 != 0) && (this.isContentView(v1) != 0)) {
                        v3 = 1;
                    }
                }
                this.mDisallowInterceptRequested = 0;
                this.mChildrenCanceledTouch = 0;
                break;
            case 1:
            case 3:
                this.closeDrawers(1);
                this.mDisallowInterceptRequested = 0;
                this.mChildrenCanceledTouch = 0;
                break;
            case 2:
                if (this.mLeftDragger.checkTouchSlop(3) == 0) {
                } else {
                    this.mLeftCallback.removeCallbacks();
                    this.mRightCallback.removeCallbacks();
                }
                break;
            default:
                if (v2 != 0) {
                    v6 = 1;
                    return v6;
                } else {
                    if (v3 != 0) {
                    } else {
                        this.hasPeekingDrawer();
                        }
                    }
                }
        }
        }
    }
    public boolean onKeyDown(int p2, android.view.KeyEvent p3)
    {
        if (p2 != 4) {
            v0 = super.onKeyDown(p2, p3);
        } else {
            this.hasVisibleDrawer();
            } else {
                android.support.v4.view.KeyEventCompat.startTracking(p3);
                v0 = 1;
            }
        }
        return v0;
    }
    public boolean onKeyUp(int p3, android.view.KeyEvent p4)
    {
        if (p3 != 4) {
            v1 = super.onKeyUp(p3, p4);
        } else {
            this.findVisibleDrawer();
            if ((this != 0) && (this.getDrawerLockMode(this) == 0)) {
                this.closeDrawers();
            }
            if (this == 0) {
                v1 = 0;
            } else {
                v1 = 1;
            }
        }
        return v1;
    }
    protected void onLayout(boolean p24, int p25, int p26, int p27, int p28)
    {
        this.mInLayout = 1;
        v17 = (p27 - p25);
        v6 = this.getChildCount();
        v12 = 0;
        while (v12 < v6) {
            v5 = this.getChildAt(v12);
            if (v5.getVisibility() != 8) {
                v13 = v5.getLayoutParams();
                if (this.isContentView(v5) == 0) {
                    v10 = v5.getMeasuredWidth();
                    v7 = v5.getMeasuredHeight();
                    if (this.checkDrawerViewAbsoluteGravity(v5, 3) == 0) {
                        v8 = (v17 - ((int) (((float) v10) * v13.onScreen)));
                        v14 = (((float) (v17 - v8)) / ((float) v10));
                    } else {
                        v8 = ((- v10) + ((int) (((float) v10) * v13.onScreen)));
                        v14 = (((float) (v10 + v8)) / ((float) v10));
                    }
                    if (v14 == v13.onScreen) {
                        v4 = 0;
                    } else {
                        v4 = 1;
                    }
                    switch ((v13.gravity & 112)) {
                        case 16:
                            v11 = (p28 - p26);
                            v9 = ((v11 - v7) / 2);
                            if (v9 >= v13.topMargin) {
                                if ((v9 + v7) > (v11 - v13.bottomMargin)) {
                                    v9 = ((v11 - v13.bottomMargin) - v7);
                                }
                            } else {
                                v9 = v13.topMargin;
                            }
                            v5.layout(v8, v9, (v8 + v10), (v9 + v7));
                            break;
                        case 80:
                            v11 = (p28 - p26);
                            v5.layout(v8, ((v11 - v13.bottomMargin) - v5.getMeasuredHeight()), (v8 + v10), (v11 - v13.bottomMargin));
                            break;
                        default:
                            v5.layout(v8, v13.topMargin, (v8 + v10), (v13.topMargin + v7));
                    }
                    if (v4 != 0) {
                        this.setDrawerViewOffset(v5, v14);
                    }
                    if (v13.onScreen <= 0) {
                        v15 = 4;
                    } else {
                        v15 = 0;
                    }
                    if (v5.getVisibility() != v15) {
                        v5.setVisibility(v15);
                    }
                } else {
                    v5.layout(v13.leftMargin, v13.topMargin, (v13.leftMargin + v5.getMeasuredWidth()), (v13.topMargin + v5.getMeasuredHeight()));
                }
            }
            v12++;
        }
        this.mInLayout = 0;
        this.mFirstLayout = 0;
        return;
    }
    protected void onMeasure(int p24, int p25)
    {
        v18 = android.view.View$MeasureSpec.getMode(p24);
        v13 = android.view.View$MeasureSpec.getMode(p25);
        v19 = android.view.View$MeasureSpec.getSize(p24);
        v14 = android.view.View$MeasureSpec.getSize(p25);
        if ((v18 != 2.0) || (v13 != 2.0)) {
            if (this.isInEditMode() == 0) {
                throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
            } else {
                if ((v18 != -0.0) && (v18 == 0)) {
                    v19 = 300;
                }
                if ((v13 != -0.0) && (v13 == 0)) {
                    v14 = 300;
                }
            }
        }
        this.setMeasuredDimension(v19, v14);
        if ((this.mLastInsets == 0) || (android.support.v4.view.ViewCompat.getFitsSystemWindows(this) == 0)) {
            v3 = 0;
        } else {
            v3 = 1;
        }
        v16 = android.support.v4.view.ViewCompat.getLayoutDirection(this);
        v6 = this.getChildCount();
        v15 = 0;
        while (v15 < v6) {
            v5 = this.getChildAt(v15);
            if (v5.getVisibility() != 8) {
                v17 = v5.getLayoutParams();
                if (v3 != 0) {
                    v4 = android.support.v4.view.GravityCompat.getAbsoluteGravity(v17.gravity, v16);
                    if (android.support.v4.view.ViewCompat.getFitsSystemWindows(v5) == 0) {
                        android.support.v4.widget.DrawerLayout.IMPL.applyMarginInsets(v17, this.mLastInsets, v4);
                    } else {
                        android.support.v4.widget.DrawerLayout.IMPL.dispatchChildInsets(v5, this.mLastInsets, v4);
                    }
                }
                if (this.isContentView(v5) == 0) {
                    if (this.isDrawerView(v5) == 0) {
                        throw new IllegalStateException(new StringBuilder().append("Child ").append(v5).append(" at index ").append(v15).append(" does not have a valid layout_gravity - must be Gravity.LEFT, ").append("Gravity.RIGHT or Gravity.NO_GRAVITY").toString());
                    } else {
                        if ((android.support.v4.widget.DrawerLayout.SET_DRAWER_SHADOW_FROM_ELEVATION) && (android.support.v4.view.ViewCompat.getElevation(v5) != this.mDrawerElevation)) {
                            android.support.v4.view.ViewCompat.setElevation(v5, this.mDrawerElevation);
                        }
                        v7 = (this.getDrawerViewAbsoluteGravity(v5) & 7);
                        if ((0 & v7) == 0) {
                            v5.measure(android.support.v4.widget.DrawerLayout.getChildMeasureSpec(p24, ((this.mMinDrawerMargin + v17.leftMargin) + v17.rightMargin), v17.width), android.support.v4.widget.DrawerLayout.getChildMeasureSpec(p25, (v17.topMargin + v17.bottomMargin), v17.height));
                        } else {
                            throw new IllegalStateException(new StringBuilder().append("Child drawer has absolute gravity ").append(android.support.v4.widget.DrawerLayout.gravityToString(v7)).append(" but this ").append("DrawerLayout").append(" already has a ").append("drawer view along that edge").toString());
                        }
                    }
                } else {
                    v5.measure(android.view.View$MeasureSpec.makeMeasureSpec(((v19 - v17.leftMargin) - v17.rightMargin), 2.0), android.view.View$MeasureSpec.makeMeasureSpec(((v14 - v17.topMargin) - v17.bottomMargin), 2.0));
                }
            }
            v15++;
        }
        return;
    }
    protected void onRestoreInstanceState(android.os.Parcelable p5)
    {
        v0 = p5;
        super.onRestoreInstanceState(v0.getSuperState());
        if (v0.openDrawerGravity != 0) {
            v1 = this.findDrawerWithGravity(v0.openDrawerGravity);
            if (v1 != 0) {
                this.openDrawer(v1);
            }
        }
        this.setDrawerLockMode(v0.lockModeLeft, 3);
        this.setDrawerLockMode(v0.lockModeRight, 5);
        return;
    }
    public void onRtlPropertiesChanged(int p1)
    {
        this.resolveShadowDrawables();
        return;
    }
    protected android.os.Parcelable onSaveInstanceState()
    {
        v1 = new android.support.v4.widget.DrawerLayout$SavedState(super.onSaveInstanceState());
        v0 = this.findOpenDrawer();
        if (v0 != 0) {
            v1.openDrawerGravity = v0.getLayoutParams().gravity;
        }
        v1.lockModeLeft = this.mLockModeLeft;
        v1.lockModeRight = this.mLockModeRight;
        return v1;
    }
    public boolean onTouchEvent(android.view.MotionEvent p14)
    {
        this.mLeftDragger.processTouchEvent(p14);
        this.mRightDragger.processTouchEvent(p14);
        switch ((p14.getAction() & 255)) {
            case 0:
                v8 = p14.getX();
                v9 = p14.getY();
                this.mInitialMotionX = v8;
                this.mInitialMotionY = v9;
                this.mDisallowInterceptRequested = 0;
                this.mChildrenCanceledTouch = 0;
                break;
            case 1:
                v8 = p14.getX();
                v9 = p14.getY();
                v4 = 1;
                v6 = this.mLeftDragger.findTopChildUnder(((int) v8), ((int) v9));
                if ((v6 != 0) && ((this.isContentView(v6) != 0) && ((((v8 - this.mInitialMotionX) * (v8 - this.mInitialMotionX)) + ((v9 - this.mInitialMotionY) * (v9 - this.mInitialMotionY))) < ((float) (this.mLeftDragger.getTouchSlop() * this.mLeftDragger.getTouchSlop()))))) {
                    v3 = this.findOpenDrawer();
                    if (v3 != 0) {
                        if (this.getDrawerLockMode(v3) != 2) {
                            v4 = 0;
                        } else {
                            v4 = 1;
                        }
                    }
                }
                this.closeDrawers(v4);
                this.mDisallowInterceptRequested = 0;
            case 2:
            default:
                break;
            case 3:
                this.closeDrawers(1);
                this.mDisallowInterceptRequested = 0;
                this.mChildrenCanceledTouch = 0;
                break;
        }
        return 1;
    }
    public void openDrawer(int p5)
    {
        v0 = this.findDrawerWithGravity(p5);
        if (v0 != 0) {
            this.openDrawer(v0);
            return;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("No drawer view found with gravity ").append(android.support.v4.widget.DrawerLayout.gravityToString(p5)).toString());
        }
    }
    public void openDrawer(android.view.View p5)
    {
        if (this.isDrawerView(p5) != 0) {
            if (!this.mFirstLayout) {
                if (this.checkDrawerViewAbsoluteGravity(p5, 3) == 0) {
                    this.mRightDragger.smoothSlideViewTo(p5, (this.getWidth() - p5.getWidth()), p5.getTop());
                } else {
                    this.mLeftDragger.smoothSlideViewTo(p5, 0, p5.getTop());
                }
            } else {
                v0 = p5.getLayoutParams();
                v0.onScreen = 1.0;
                v0.knownOpen = 1;
                this.updateChildrenImportantForAccessibility(p5, 1);
            }
            this.invalidate();
            return;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("View ").append(p5).append(" is not a sliding drawer").toString());
        }
    }
    public void requestDisallowInterceptTouchEvent(boolean p2)
    {
        super.requestDisallowInterceptTouchEvent(p2);
        this.mDisallowInterceptRequested = p2;
        if (p2 != 0) {
            this.closeDrawers(1);
        }
        return;
    }
}
