package android.support.v4.os;
public interface abstract class CancellationSignal$OnCancelListener {
    abstract public void onCancel();
}
