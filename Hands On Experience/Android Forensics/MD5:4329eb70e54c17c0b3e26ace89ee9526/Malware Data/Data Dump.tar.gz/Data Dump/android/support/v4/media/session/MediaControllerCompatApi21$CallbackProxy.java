package android.support.v4.media.session;
 class MediaControllerCompatApi21$CallbackProxy extends android.media.session.MediaController$Callback {
    final protected android.support.v4.media.session.MediaControllerCompatApi21$Callback mCallback;
    public MediaControllerCompatApi21$CallbackProxy(android.support.v4.media.session.MediaControllerCompatApi21$Callback p1)
    {
        this.mCallback = p1;
        return;
    }
    public void onMetadataChanged(android.media.MediaMetadata p2)
    {
        this.mCallback.onMetadataChanged(p2);
        return;
    }
    public void onPlaybackStateChanged(android.media.session.PlaybackState p2)
    {
        this.mCallback.onPlaybackStateChanged(p2);
        return;
    }
    public void onSessionDestroyed()
    {
        this.mCallback.onSessionDestroyed();
        return;
    }
    public void onSessionEvent(String p2, android.os.Bundle p3)
    {
        this.mCallback.onSessionEvent(p2, p3);
        return;
    }
}
