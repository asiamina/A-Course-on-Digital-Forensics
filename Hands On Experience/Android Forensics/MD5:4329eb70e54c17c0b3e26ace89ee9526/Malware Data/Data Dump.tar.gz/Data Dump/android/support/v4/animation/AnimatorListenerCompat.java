package android.support.v4.animation;
public interface abstract class AnimatorListenerCompat {
    abstract public void onAnimationCancel();
    abstract public void onAnimationEnd();
    abstract public void onAnimationRepeat();
    abstract public void onAnimationStart();
}
