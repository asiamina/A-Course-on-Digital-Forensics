package android.support.v4.app;
public class NotificationCompatJellybean$Builder implements android.support.v4.app.NotificationBuilderWithActions, android.support.v4.app.NotificationBuilderWithBuilderAccessor {
    private android.app.Notification$Builder b;
    final private android.os.Bundle mExtras;
    private java.util.List mActionExtrasList;
    public NotificationCompatJellybean$Builder(android.content.Context p8, android.app.Notification p9, CharSequence p10, CharSequence p11, CharSequence p12, android.widget.RemoteViews p13, int p14, android.app.PendingIntent p15, android.app.PendingIntent p16, android.graphics.Bitmap p17, int p18, int p19, boolean p20, boolean p21, int p22, CharSequence p23, boolean p24, android.os.Bundle p25, String p26, boolean p27, String p28)
    {
        this.mActionExtrasList = new java.util.ArrayList();
        v4 = new android.app.Notification$Builder(p8).setWhen(p9.when).setSmallIcon(p9.icon, p9.iconLevel).setContent(p9.contentView).setTicker(p9.tickerText, p13).setSound(p9.sound, p9.audioStreamType).setVibrate(p9.vibrate).setLights(p9.ledARGB, p9.ledOnMS, p9.ledOffMS);
        if ((p9.flags & 2) == 0) {
            v3 = 0;
        } else {
            v3 = 1;
        }
        v4 = v4.setOngoing(v3);
        if ((p9.flags & 8) == 0) {
            v3 = 0;
        } else {
            v3 = 1;
        }
        v4 = v4.setOnlyAlertOnce(v3);
        if ((p9.flags & 16) == 0) {
            v3 = 0;
        } else {
            v3 = 1;
        }
        v4 = v4.setAutoCancel(v3).setDefaults(p9.defaults).setContentTitle(p10).setContentText(p11).setSubText(p23).setContentInfo(p12).setContentIntent(p15).setDeleteIntent(p9.deleteIntent);
        if ((p9.flags & 128) == 0) {
            v3 = 0;
        } else {
            v3 = 1;
        }
        this.b = v4.setFullScreenIntent(p16, v3).setLargeIcon(p17).setNumber(p14).setUsesChronometer(p21).setPriority(p22).setProgress(p18, p19, p20);
        this.mExtras = new android.os.Bundle();
        if (p25 != 0) {
            this.mExtras.putAll(p25);
        }
        if (p24 != 0) {
            this.mExtras.putBoolean("android.support.localOnly", 1);
        }
        if (p26 != 0) {
            this.mExtras.putString("android.support.groupKey", p26);
            if (p27 == 0) {
                this.mExtras.putBoolean("android.support.useSideChannel", 1);
            } else {
                this.mExtras.putBoolean("android.support.isGroupSummary", 1);
            }
        }
        if (p28 != 0) {
            this.mExtras.putString("android.support.sortKey", p28);
        }
        return;
    }
    public void addAction(android.support.v4.app.NotificationCompatBase$Action p3)
    {
        this.mActionExtrasList.add(android.support.v4.app.NotificationCompatJellybean.writeActionAndGetExtras(this.b, p3));
        return;
    }
    public android.app.Notification build()
    {
        v5 = this.b.build();
        v1 = android.support.v4.app.NotificationCompatJellybean.getExtras(v5);
        v4 = new android.os.Bundle(this.mExtras);
        v2 = this.mExtras.keySet().iterator();
        while (v2.hasNext() != 0) {
            v3 = v2.next();
            if (v1.containsKey(v3) != 0) {
                v4.remove(v3);
            }
        }
        v1.putAll(v4);
        v0 = android.support.v4.app.NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
        if (v0 != 0) {
            android.support.v4.app.NotificationCompatJellybean.getExtras(v5).putSparseParcelableArray("android.support.actionExtras", v0);
        }
        return v5;
    }
    public android.app.Notification$Builder getBuilder()
    {
        return this.b;
    }
}
