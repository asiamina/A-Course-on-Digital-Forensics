package android.support.v4.app;
 class RemoteInputCompatBase {
     RemoteInputCompatBase()
    {
        return;
    }
}
