package android.support.v4.media.session;
final class PlaybackStateCompat$1 implements android.os.Parcelable$Creator {
     PlaybackStateCompat$1()
    {
        return;
    }
    public android.support.v4.media.session.PlaybackStateCompat createFromParcel(android.os.Parcel p3)
    {
        return new android.support.v4.media.session.PlaybackStateCompat(p3, 0);
    }
    public synthetic bridge Object createFromParcel(android.os.Parcel p2)
    {
        return this.createFromParcel(p2);
    }
    public android.support.v4.media.session.PlaybackStateCompat[] newArray(int p2)
    {
        v0 = new android.support.v4.media.session.PlaybackStateCompat[p2];
        return v0;
    }
    public synthetic bridge Object[] newArray(int p2)
    {
        return this.newArray(p2);
    }
}
