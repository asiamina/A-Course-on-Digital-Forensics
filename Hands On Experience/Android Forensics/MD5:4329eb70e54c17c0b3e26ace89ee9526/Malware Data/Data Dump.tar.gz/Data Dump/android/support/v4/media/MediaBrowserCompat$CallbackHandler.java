package android.support.v4.media;
 class MediaBrowserCompat$CallbackHandler extends android.os.Handler {
    private ref.WeakReference mCallbacksMessengerRef;
    final private android.support.v4.media.MediaBrowserCompat$MediaBrowserServiceCallbackImpl mCallbackImpl;
    public void handleMessage(android.os.Message p7)
    {
        if (this.mCallbacksMessengerRef != 0) {
            v0 = p7.getData();
            v0.setClassLoader(android.support.v4.media.session.MediaSessionCompat.getClassLoader());
            switch (p7.what) {
                case 1:
                    this.mCallbackImpl.onServiceConnected(this.mCallbacksMessengerRef.get(), v0.getString("data_media_item_id"), v0.getParcelable("data_media_session_token"), v0.getBundle("data_root_hints"));
                    break;
                case 2:
                    this.mCallbackImpl.onConnectionFailed(this.mCallbacksMessengerRef.get());
                    break;
                case 3:
                    this.mCallbackImpl.onLoadChildren(this.mCallbacksMessengerRef.get(), v0.getString("data_media_item_id"), v0.getParcelableArrayList("data_media_item_list"), v0.getBundle("data_options"));
                    break;
                default:
                    android.util.Log.w("MediaBrowserCompat", new StringBuilder().append("Unhandled message: ").append(p7).append("\n  Client version: ").append(1).append("\n  Service version: ").append(p7.arg1).toString());
            }
        }
        return;
    }
     void setCallbacksMessenger(android.os.Messenger p2)
    {
        this.mCallbacksMessengerRef = new ref.WeakReference(p2);
        return;
    }
     MediaBrowserCompat$CallbackHandler(android.support.v4.media.MediaBrowserCompat$MediaBrowserServiceCallbackImpl p1)
    {
        this.mCallbackImpl = p1;
        return;
    }
}
