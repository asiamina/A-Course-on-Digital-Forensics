package android.support.v4.media;
final public class MediaDescriptionCompat$Builder {
    private CharSequence mSubtitle;
    private CharSequence mTitle;
    private CharSequence mDescription;
    private String mMediaId;
    private android.os.Bundle mExtras;
    private android.net.Uri mIconUri;
    private android.net.Uri mMediaUri;
    private android.graphics.Bitmap mIcon;
    public MediaDescriptionCompat$Builder()
    {
        return;
    }
    public android.support.v4.media.MediaDescriptionCompat build()
    {
        return new android.support.v4.media.MediaDescriptionCompat(this.mMediaId, this.mTitle, this.mSubtitle, this.mDescription, this.mIcon, this.mIconUri, this.mExtras, this.mMediaUri, 0);
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setDescription(CharSequence p1)
    {
        this.mDescription = p1;
        return this;
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setExtras(android.os.Bundle p1)
    {
        this.mExtras = p1;
        return this;
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setIconBitmap(android.graphics.Bitmap p1)
    {
        this.mIcon = p1;
        return this;
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setIconUri(android.net.Uri p1)
    {
        this.mIconUri = p1;
        return this;
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setMediaId(String p1)
    {
        this.mMediaId = p1;
        return this;
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setMediaUri(android.net.Uri p1)
    {
        this.mMediaUri = p1;
        return this;
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setSubtitle(CharSequence p1)
    {
        this.mSubtitle = p1;
        return this;
    }
    public android.support.v4.media.MediaDescriptionCompat$Builder setTitle(CharSequence p1)
    {
        this.mTitle = p1;
        return this;
    }
}
