package android.support.v4.widget;
public class NestedScrollView extends android.widget.FrameLayout implements android.support.v4.view.NestedScrollingChild, android.support.v4.view.NestedScrollingParent, android.support.v4.view.ScrollingView {
    private android.view.VelocityTracker mVelocityTracker;
    final private int[] mScrollOffset;
    final private android.graphics.Rect mTempRect;
    final private static android.support.v4.widget.NestedScrollView$AccessibilityDelegate ACCESSIBILITY_DELEGATE;
    final private static int INVALID_POINTER;
    private int mNestedYOffset;
    private boolean mIsLayoutDirty;
    private android.support.v4.widget.NestedScrollView$OnScrollChangeListener mOnScrollChangeListener;
    final private static String TAG;
    private android.support.v4.widget.EdgeEffectCompat mEdgeGlowTop;
    private int mMaximumVelocity;
    final private android.support.v4.view.NestedScrollingParentHelper mParentHelper;
    final private static int[] SCROLLVIEW_STYLEABLE;
    private int mTouchSlop;
    private int mLastMotionY;
    private int mActivePointerId;
    private float mVerticalScrollFactor;
    final static int ANIMATED_SCROLL_GAP;
    private android.view.View mChildToScrollTo;
    private boolean mIsLaidOut;
    private boolean mFillViewport;
    final static float MAX_SCROLL_FACTOR;
    private android.support.v4.widget.ScrollerCompat mScroller;
    private int mMinimumVelocity;
    private boolean mIsBeingDragged;
    private android.support.v4.widget.EdgeEffectCompat mEdgeGlowBottom;
    private android.support.v4.widget.NestedScrollView$SavedState mSavedState;
    private boolean mSmoothScrollingEnabled;
    private long mLastScroll;
    final private int[] mScrollConsumed;
    final private android.support.v4.view.NestedScrollingChildHelper mChildHelper;
    protected int computeScrollDeltaToGetChildRectOnScreen(android.graphics.Rect p11)
    {
        if (this.getChildCount() != 0) {
            v3 = this.getHeight();
            v5 = this.getScrollY();
            v4 = (v5 + v3);
            v2 = this.getVerticalFadingEdgeLength();
            if (p11.top > 0) {
                v5 += v2;
            }
            if (p11.bottom < this.getChildAt(0).getHeight()) {
                v4 -= v2;
            }
            v6 = 0;
            if ((p11.bottom <= v4) || (p11.top <= v5)) {
                if ((p11.top < v5) && (p11.bottom < v4)) {
                    if (p11.height() <= v3) {
                        v6 = (0 - (v5 - p11.top));
                    } else {
                        v6 = (0 - (v4 - p11.bottom));
                    }
                    v6 = Math.max(v6, (- this.getScrollY()));
                }
            } else {
                if (p11.height() <= v3) {
                    v6 = (0 + (p11.bottom - v4));
                } else {
                    v6 = (0 + (p11.top - v5));
                }
                v6 = Math.min(v6, (this.getChildAt(0).getBottom() - v4));
            }
        } else {
            v6 = 0;
        }
        return v6;
    }
    public int computeVerticalScrollExtent()
    {
        return super.computeVerticalScrollExtent();
    }
    public int computeVerticalScrollOffset()
    {
        return Math.max(0, super.computeVerticalScrollOffset());
    }
    public int computeVerticalScrollRange()
    {
        v1 = this.getChildCount();
        v0 = ((this.getHeight() - this.getPaddingBottom()) - this.getPaddingTop());
        if (v1 != 0) {
            v3 = this.getChildAt(0).getBottom();
            v4 = this.getScrollY();
            v2 = Math.max(0, (v3 - v0));
            if (v4 >= 0) {
                if (v4 > v2) {
                    v3 += (v4 - v2);
                }
            } else {
                v3 -= v4;
            }
            v0 = v3;
        }
        return v0;
    }
    public boolean dispatchKeyEvent(android.view.KeyEvent p2)
    {
        if ((super.dispatchKeyEvent(p2) == 0) && (this.executeKeyEvent(p2) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public boolean dispatchNestedFling(float p2, float p3, boolean p4)
    {
        return this.mChildHelper.dispatchNestedFling(p2, p3, p4);
    }
    public boolean dispatchNestedPreFling(float p2, float p3)
    {
        return this.mChildHelper.dispatchNestedPreFling(p2, p3);
    }
    public boolean dispatchNestedPreScroll(int p2, int p3, int[] p4, int[] p5)
    {
        return this.mChildHelper.dispatchNestedPreScroll(p2, p3, p4, p5);
    }
    public boolean dispatchNestedScroll(int p7, int p8, int p9, int p10, int[] p11)
    {
        return this.mChildHelper.dispatchNestedScroll(p7, p8, p9, p10, p11);
    }
    private void doScrollY(int p3)
    {
        if (p3 != 0) {
            if (!this.mSmoothScrollingEnabled) {
                this.scrollBy(0, p3);
            } else {
                this.smoothScrollBy(0, p3);
            }
        }
        return;
    }
    public void draw(android.graphics.Canvas p8)
    {
        super.draw(p8);
        if (this.mEdgeGlowTop != 0) {
            v2 = this.getScrollY();
            if (this.mEdgeGlowTop.isFinished() == 0) {
                v1 = p8.save();
                v3 = ((this.getWidth() - this.getPaddingLeft()) - this.getPaddingRight());
                p8.translate(((float) this.getPaddingLeft()), ((float) Math.min(0, v2)));
                this.mEdgeGlowTop.setSize(v3, this.getHeight());
                if (this.mEdgeGlowTop.draw(p8) != 0) {
                    android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
                }
                p8.restoreToCount(v1);
            }
            if (this.mEdgeGlowBottom.isFinished() == 0) {
                v1 = p8.save();
                v3 = ((this.getWidth() - this.getPaddingLeft()) - this.getPaddingRight());
                v0 = this.getHeight();
                v4 = ((float) ((- v3) + this.getPaddingLeft()));
                this.getScrollRange();
                p8.translate(v4, ((float) (Math.max(this, v2) + v0)));
                p8.rotate(180.0, ((float) v3), 0);
                this.mEdgeGlowBottom.setSize(v3, v0);
                if (this.mEdgeGlowBottom.draw(p8) != 0) {
                    android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
                }
                p8.restoreToCount(v1);
            }
        }
        return;
    }
    private void endDrag()
    {
        this.mIsBeingDragged = 0;
        this.recycleVelocityTracker();
        this.stopNestedScroll();
        if (this.mEdgeGlowTop != 0) {
            this.mEdgeGlowTop.onRelease();
            this.mEdgeGlowBottom.onRelease();
        }
        return;
    }
    private void ensureGlows()
    {
        if (android.support.v4.view.ViewCompat.getOverScrollMode(this) == 2) {
            this.mEdgeGlowTop = 0;
            this.mEdgeGlowBottom = 0;
        } else {
            if (this.mEdgeGlowTop == 0) {
                v0 = this.getContext();
                this.mEdgeGlowTop = new android.support.v4.widget.EdgeEffectCompat(v0);
                this.mEdgeGlowBottom = new android.support.v4.widget.EdgeEffectCompat(v0);
            }
        }
        return;
    }
    public boolean executeKeyEvent(android.view.KeyEvent p8)
    {
        v3 = 0;
        this.mTempRect.setEmpty();
        this.canScroll();
        if (this != 0) {
            v1 = 0;
            if (p8.getAction() == 0) {
                switch (p8.getKeyCode()) {
                    case 19:
                        if (p8.isAltPressed() != 0) {
                            v1 = this.fullScroll(33);
                        } else {
                            v1 = this.arrowScroll(33);
                        }
                        break;
                    case 20:
                        if (p8.isAltPressed() != 0) {
                            v1 = this.fullScroll(130);
                        } else {
                            v1 = this.arrowScroll(130);
                        }
                        break;
                    case 62:
                        if (p8.isShiftPressed() == 0) {
                            v3 = 130;
                        } else {
                            v3 = 33;
                        }
                        this.pageScroll(v3);
                        break;
                }
            }
            v3 = v1;
        } else {
            if ((this.isFocused() != 0) && (p8.getKeyCode() != 4)) {
                v0 = this.findFocus();
                if (v0 == this) {
                    v0 = 0;
                }
                v2 = android.view.FocusFinder.getInstance().findNextFocus(this, v0, 130);
                if ((v2 != 0) && ((v2 != this) && (v2.requestFocus(130) != 0))) {
                    v3 = 1;
                }
            }
        }
        return v3;
    }
    private android.view.View findFocusableViewInBounds(boolean p12, int p13, int p14)
    {
        v2 = this.getFocusables(2);
        v1 = 0;
        v3 = 0;
        v0 = v2.size();
        v4 = 0;
        while (v4 < v0) {
            v5 = v2.get(v4);
            v9 = v5.getTop();
            v6 = v5.getBottom();
            if ((p13 < v6) && (v9 < p14)) {
                if ((p13 >= v9) || (v6 >= p14)) {
                    v8 = 0;
                } else {
                    v8 = 1;
                }
                if (v1 != 0) {
                    if (((p12 == 0) || (v9 >= v1.getTop())) && ((p12 != 0) || (v6 <= v1.getBottom()))) {
                        v7 = 0;
                    } else {
                        v7 = 1;
                    }
                    if (v3 == 0) {
                        if (v8 == 0) {
                            if (v7 != 0) {
                                v1 = v5;
                            }
                        } else {
                            v1 = v5;
                            v3 = 1;
                        }
                    } else {
                        if ((v8 != 0) && (v7 != 0)) {
                            v1 = v5;
                        }
                    }
                } else {
                    v1 = v5;
                    v3 = v8;
                }
            }
            v4++;
        }
        return v1;
    }
    public void fling(int p14)
    {
        if (this.getChildCount() > 0) {
            v12 = ((this.getHeight() - this.getPaddingBottom()) - this.getPaddingTop());
            this.mScroller.fling(this.getScrollX(), this.getScrollY(), 0, p14, 0, 0, 0, Math.max(0, (this.getChildAt(0).getHeight() - v12)), 0, (v12 / 2));
            android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
        }
        return;
    }
    private void flingWithNestedDispatch(int p5)
    {
        v1 = this.getScrollY();
        if ((v1 <= 0) && (p5 <= 0)) {
            v0 = 0;
        } else {
            this.getScrollRange();
            } else {
                v0 = 1;
            }
        }
        if (this.dispatchNestedPreFling(0, ((float) p5)) == 0) {
            this.dispatchNestedFling(0, ((float) p5), v0);
            if (v0 != 0) {
                this.fling(p5);
            }
        }
        return;
    }
    public boolean fullScroll(int p8)
    {
        if (p8 != 130) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        v2 = this.getHeight();
        this.mTempRect.top = 0;
        this.mTempRect.bottom = v2;
        if (v1 != 0) {
            v0 = this.getChildCount();
            if (v0 > 0) {
                this.mTempRect.bottom = (this.getChildAt((v0 - 1)).getBottom() + this.getPaddingBottom());
                this.mTempRect.top = (this.mTempRect.bottom - v2);
            }
        }
        this.scrollAndFocus(p8, this.mTempRect.top, this.mTempRect.bottom);
        return this;
    }
    protected float getBottomFadingEdgeStrength()
    {
        if (this.getChildCount() != 0) {
            v1 = this.getVerticalFadingEdgeLength();
            v2 = ((this.getChildAt(0).getBottom() - this.getScrollY()) - (this.getHeight() - this.getPaddingBottom()));
            if (v2 >= v1) {
                v3 = 1.0;
            } else {
                v3 = (((float) v2) / ((float) v1));
            }
        } else {
            v3 = 0;
        }
        return v3;
    }
    public int getMaxScrollAmount()
    {
        return ((int) (0.5 * ((float) this.getHeight())));
    }
    public int getNestedScrollAxes()
    {
        return this.mParentHelper.getNestedScrollAxes();
    }
    private int getScrollRange()
    {
        v1 = 0;
        if (this.getChildCount() > 0) {
            v1 = Math.max(0, (this.getChildAt(0).getHeight() - ((this.getHeight() - this.getPaddingBottom()) - this.getPaddingTop())));
        }
        return v1;
    }
    protected float getTopFadingEdgeStrength()
    {
        if (this.getChildCount() != 0) {
            v0 = this.getVerticalFadingEdgeLength();
            v1 = this.getScrollY();
            if (v1 >= v0) {
                v2 = 1.0;
            } else {
                v2 = (((float) v1) / ((float) v0));
            }
        } else {
            v2 = 0;
        }
        return v2;
    }
    private float getVerticalScrollFactorCompat()
    {
        if (this.mVerticalScrollFactor == 0) {
            v1 = new android.util.TypedValue();
            v0 = this.getContext();
            if (v0.getTheme().resolveAttribute(2.369377380872524e-38, v1, 1) != 0) {
                this.mVerticalScrollFactor = v1.getDimension(v0.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.mVerticalScrollFactor;
    }
    public boolean hasNestedScrollingParent()
    {
        return this.mChildHelper.hasNestedScrollingParent();
    }
    private boolean inChild(int p5, int p6)
    {
        v2 = 0;
        if (this.getChildCount() > 0) {
            v1 = this.getScrollY();
            v0 = this.getChildAt(0);
            if ((p6 >= (v0.getTop() - v1)) && ((p6 < (v0.getBottom() - v1)) && ((p5 >= v0.getLeft()) && (p5 < v0.getRight())))) {
                v2 = 1;
            }
        }
        return v2;
    }
    private void initOrResetVelocityTracker()
    {
        if (this.mVelocityTracker != 0) {
            this.mVelocityTracker.clear();
        } else {
            this.mVelocityTracker = android.view.VelocityTracker.obtain();
        }
        return;
    }
    private void initScrollView()
    {
        this.mScroller = new android.support.v4.widget.ScrollerCompat(this.getContext(), 0);
        this.setFocusable(1);
        this.setDescendantFocusability(3.6734198463196485e-40);
        this.setWillNotDraw(0);
        v0 = android.view.ViewConfiguration.get(this.getContext());
        this.mTouchSlop = v0.getScaledTouchSlop();
        this.mMinimumVelocity = v0.getScaledMinimumFlingVelocity();
        this.mMaximumVelocity = v0.getScaledMaximumFlingVelocity();
        return;
    }
    private void initVelocityTrackerIfNotExists()
    {
        if (this.mVelocityTracker == 0) {
            this.mVelocityTracker = android.view.VelocityTracker.obtain();
        }
        return;
    }
    public boolean isFillViewport()
    {
        return this.mFillViewport;
    }
    public boolean isNestedScrollingEnabled()
    {
        return this.mChildHelper.isNestedScrollingEnabled();
    }
    private boolean isOffScreen(android.view.View p3)
    {
        v0 = 0;
        this.isWithinDeltaOfScreen(p3, 0, this.getHeight());
        if (this == 0) {
            v0 = 1;
        }
        return v0;
    }
    public boolean isSmoothScrollingEnabled()
    {
        return this.mSmoothScrollingEnabled;
    }
    private static boolean isViewDescendantOf(android.view.View p3, android.view.View p4)
    {
        v1 = 1;
        if (p3 != p4) {
            v0 = p3.getParent();
            if (((v0 instanceof android.view.ViewGroup) == 0) || (android.support.v4.widget.NestedScrollView.isViewDescendantOf(v0, p4) == 0)) {
                v1 = 0;
            }
        }
        return v1;
    }
    private boolean isWithinDeltaOfScreen(android.view.View p3, int p4, int p5)
    {
        p3.getDrawingRect(this.mTempRect);
        this.offsetDescendantRectToMyCoords(p3, this.mTempRect);
        if (((this.mTempRect.bottom + p4) < this.getScrollY()) || ((this.mTempRect.top - p4) > (this.getScrollY() + p5))) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    protected void measureChild(android.view.View p7, int p8, int p9)
    {
        p7.measure(android.support.v4.widget.NestedScrollView.getChildMeasureSpec(p8, (this.getPaddingLeft() + this.getPaddingRight()), p7.getLayoutParams().width), android.view.View$MeasureSpec.makeMeasureSpec(0, 0));
        return;
    }
    protected void measureChildWithMargins(android.view.View p6, int p7, int p8, int p9, int p10)
    {
        v2 = p6.getLayoutParams();
        p6.measure(android.support.v4.widget.NestedScrollView.getChildMeasureSpec(p7, ((((this.getPaddingLeft() + this.getPaddingRight()) + v2.leftMargin) + v2.rightMargin) + p8), v2.width), android.view.View$MeasureSpec.makeMeasureSpec((v2.topMargin + v2.bottomMargin), 0));
        return;
    }
    public void onAttachedToWindow()
    {
        this.mIsLaidOut = 0;
        return;
    }
    public boolean onGenericMotionEvent(android.view.MotionEvent p7)
    {
        if ((android.support.v4.view.MotionEventCompat.getSource(p7) & 2) == 0) {
            v5 = 0;
        } else {
            switch (p7.getAction()) {
                case 8:
                    } else {
                        v4 = android.support.v4.view.MotionEventCompat.getAxisValue(p7, 9);
                        } else {
                            this.getVerticalScrollFactorCompat();
                            v0 = ((int) (this * v4));
                            this.getScrollRange();
                            v2 = this.getScrollY();
                            v1 = (v2 - v0);
                            if (v1 >= 0) {
                                if (v1 > this) {
                                    v1 = this;
                                }
                            } else {
                                v1 = 0;
                            }
                            } else {
                                super.scrollTo(this.getScrollX(), v1);
                                v5 = 1;
                            }
                        }
                    }
                    break;
                default:
            }
        }
        return v5;
    }
    public boolean onInterceptTouchEvent(android.view.MotionEvent p14)
    {
        v0 = 1;
        v3 = 0;
        v7 = p14.getAction();
        if ((v7 != 2) || (!this.mIsBeingDragged)) {
            switch ((v7 & 255)) {
                case 0:
                    v11 = ((int) p14.getY());
                    this.inChild(((int) p14.getX()), v11);
                    if (this != 0) {
                        this.mLastMotionY = v11;
                        this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p14, 0);
                        this.initOrResetVelocityTracker();
                        this.mVelocityTracker.addMovement(p14);
                        if (this.mScroller.isFinished() == 0) {
                            v3 = 1;
                        }
                        this.mIsBeingDragged = v3;
                        this.startNestedScroll(2);
                    } else {
                        this.mIsBeingDragged = 0;
                        this.recycleVelocityTracker();
                    }
                    break;
                case 1:
                case 3:
                    this.mIsBeingDragged = 0;
                    this.mActivePointerId = -1;
                    this.recycleVelocityTracker();
                    v1 = this.getScrollX();
                    v2 = this.getScrollY();
                    this.getScrollRange();
                    if (this.mScroller.springBack(v1, v2, 0, 0, 0, this) != 0) {
                        android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
                    }
                    this.stopNestedScroll();
                    break;
                case 2:
                    v8 = this.mActivePointerId;
                    if (v8 == -1) {
                    } else {
                        v10 = android.support.v4.view.MotionEventCompat.findPointerIndex(p14, v8);
                        if (v10 != -1) {
                            v11 = ((int) android.support.v4.view.MotionEventCompat.getY(p14, v10));
                            if ((Math.abs((v11 - this.mLastMotionY)) <= this.mTouchSlop) || ((this.getNestedScrollAxes() & 2) != 0)) {
                            } else {
                                this.mIsBeingDragged = 1;
                                this.mLastMotionY = v11;
                                this.initVelocityTrackerIfNotExists();
                                this.mVelocityTracker.addMovement(p14);
                                this.mNestedYOffset = 0;
                                v9 = this.getParent();
                                if (v9 == 0) {
                                } else {
                                    v9.requestDisallowInterceptTouchEvent(1);
                                }
                            }
                        } else {
                            android.util.Log.e("NestedScrollView", new StringBuilder().append("Invalid pointerId=").append(v8).append(" in onInterceptTouchEvent").toString());
                        }
                    }
                    break;
                case 4:
                case 5:
                default:
                    break;
                case 4:
                case 5:
                    break;
                case 6:
                    this.onSecondaryPointerUp(p14);
                    break;
            }
            v0 = this.mIsBeingDragged;
        }
        return v0;
    }
    protected void onLayout(boolean p7, int p8, int p9, int p10, int p11)
    {
        this.onLayout(p7, p8, p9, p10, p11);
        this.mIsLayoutDirty = 0;
        if ((this.mChildToScrollTo != 0) && (android.support.v4.widget.NestedScrollView.isViewDescendantOf(this.mChildToScrollTo, this) != 0)) {
            this.scrollToChild(this.mChildToScrollTo);
        }
        this.mChildToScrollTo = 0;
        if (this.mIsLaidOut) {
            if (this.mSavedState != 0) {
                this.scrollTo(this.getScrollX(), this.mSavedState.scrollPosition);
                this.mSavedState = 0;
            }
            if (this.getChildCount() <= 0) {
                v0 = 0;
            } else {
                v0 = this.getChildAt(0).getMeasuredHeight();
            }
            v1 = Math.max(0, (v0 - (((p11 - p9) - this.getPaddingBottom()) - this.getPaddingTop())));
            if (this.getScrollY() <= v1) {
                if (this.getScrollY() < 0) {
                    this.scrollTo(this.getScrollX(), 0);
                }
            } else {
                this.scrollTo(this.getScrollX(), v1);
            }
        }
        this.scrollTo(this.getScrollX(), this.getScrollY());
        this.mIsLaidOut = 1;
        return;
    }
    protected void onMeasure(int p9, int p10)
    {
        super.onMeasure(p9, p10);
        if ((this.mFillViewport) && ((android.view.View$MeasureSpec.getMode(p10) != 0) && (this.getChildCount() > 0))) {
            v0 = this.getChildAt(0);
            v3 = this.getMeasuredHeight();
            if (v0.getMeasuredHeight() < v3) {
                v0.measure(android.support.v4.widget.NestedScrollView.getChildMeasureSpec(p9, (this.getPaddingLeft() + this.getPaddingRight()), v0.getLayoutParams().width), android.view.View$MeasureSpec.makeMeasureSpec(((v3 - this.getPaddingTop()) - this.getPaddingBottom()), 2.0));
            }
        }
        return;
    }
    public boolean onNestedFling(android.view.View p2, float p3, float p4, boolean p5)
    {
        if (p5 != 0) {
            v0 = 0;
        } else {
            this.flingWithNestedDispatch(((int) p4));
            v0 = 1;
        }
        return v0;
    }
    public boolean onNestedPreFling(android.view.View p2, float p3, float p4)
    {
        return 0;
    }
    public void onNestedPreScroll(android.view.View p1, int p2, int p3, int[] p4)
    {
        return;
    }
    public void onNestedScroll(android.view.View p8, int p9, int p10, int p11, int p12)
    {
        v6 = this.getScrollY();
        this.scrollBy(0, p12);
        v2 = (this.getScrollY() - v6);
        this.dispatchNestedScroll(0, v2, 0, (p12 - v2), 0);
        return;
    }
    public void onNestedScrollAccepted(android.view.View p2, android.view.View p3, int p4)
    {
        this.mParentHelper.onNestedScrollAccepted(p2, p3, p4);
        this.startNestedScroll(2);
        return;
    }
    protected void onOverScrolled(int p1, int p2, boolean p3, boolean p4)
    {
        super.scrollTo(p1, p2);
        return;
    }
    protected boolean onRequestFocusInDescendants(int p5, android.graphics.Rect p6)
    {
        v1 = 0;
        if (p5 != 2) {
            if (p5 == 1) {
                p5 = 33;
            }
        } else {
            p5 = 130;
        }
        if (p6 != 0) {
            v0 = android.view.FocusFinder.getInstance().findNextFocusFromRect(this, p6, p5);
        } else {
            v0 = android.view.FocusFinder.getInstance().findNextFocus(this, 0, p5);
        }
        if (v0 != 0) {
            this.isOffScreen(v0);
            if (this == 0) {
                v1 = v0.requestFocus(p5, p6);
            }
        }
        return v1;
    }
    protected void onRestoreInstanceState(android.os.Parcelable p3)
    {
        v0 = p3;
        super.onRestoreInstanceState(v0.getSuperState());
        this.mSavedState = v0;
        this.requestLayout();
        return;
    }
    protected android.os.Parcelable onSaveInstanceState()
    {
        v0 = new android.support.v4.widget.NestedScrollView$SavedState(super.onSaveInstanceState());
        v0.scrollPosition = this.getScrollY();
        return v0;
    }
    protected void onScrollChanged(int p7, int p8, int p9, int p10)
    {
        super.onScrollChanged(p7, p8, p9, p10);
        if (this.mOnScrollChangeListener != 0) {
            this.mOnScrollChangeListener.onScrollChange(this, p7, p8, p9, p10);
        }
        return;
    }
    private void onSecondaryPointerUp(android.view.MotionEvent p6)
    {
        v2 = ((p6.getAction() & 9.147676375112406e-41) >> 8);
        if (android.support.v4.view.MotionEventCompat.getPointerId(p6, v2) == this.mActivePointerId) {
            if (v2 != 0) {
                v0 = 0;
            } else {
                v0 = 1;
            }
            this.mLastMotionY = ((int) android.support.v4.view.MotionEventCompat.getY(p6, v0));
            this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p6, v0);
            if (this.mVelocityTracker != 0) {
                this.mVelocityTracker.clear();
            }
        }
        return;
    }
    protected void onSizeChanged(int p4, int p5, int p6, int p7)
    {
        super.onSizeChanged(p4, p5, p6, p7);
        v0 = this.findFocus();
        if ((v0 != 0) && (this != v0)) {
            this.isWithinDeltaOfScreen(v0, 0, p7);
            if (this != 0) {
                v0.getDrawingRect(this.mTempRect);
                this.offsetDescendantRectToMyCoords(v0, this.mTempRect);
                this.doScrollY(this.computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
            }
        }
        return;
    }
    public boolean onStartNestedScroll(android.view.View p2, android.view.View p3, int p4)
    {
        if ((p4 & 2) == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public void onStopNestedScroll(android.view.View p2)
    {
        this.mParentHelper.onStopNestedScroll(p2);
        this.stopNestedScroll();
        return;
    }
    public boolean onTouchEvent(android.view.MotionEvent p34)
    {
        this.initVelocityTrackerIfNotExists();
        v31 = android.view.MotionEvent.obtain(p34);
        v21 = android.support.v4.view.MotionEventCompat.getActionMasked(p34);
        if (v21 == 0) {
            this.mNestedYOffset = 0;
        }
        v31.offsetLocation(0, ((float) this.mNestedYOffset));
        switch (v21) {
            case 0:
                if (this.getChildCount() != 0) {
                    if (this.mScroller.isFinished() != 0) {
                        v2 = 0;
                    } else {
                        v2 = 1;
                    }
                    this.mIsBeingDragged = v2;
                    if (v2 != 0) {
                        v28 = this.getParent();
                        if (v28 != 0) {
                            v28.requestDisallowInterceptTouchEvent(1);
                        }
                    }
                    if (this.mScroller.isFinished() == 0) {
                        this.mScroller.abortAnimation();
                    }
                    this.mLastMotionY = ((int) p34.getY());
                    this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p34, 0);
                    this.startNestedScroll(2);
                    if (this.mVelocityTracker != 0) {
                        this.mVelocityTracker.addMovement(v31);
                    }
                    v31.recycle();
                    v2 = 1;
                } else {
                    v2 = 0;
                }
                break;
            case 1:
                if (this.mIsBeingDragged) {
                    v30 = this.mVelocityTracker;
                    v30.computeCurrentVelocity(1000, ((float) this.mMaximumVelocity));
                    v25 = ((int) android.support.v4.view.VelocityTrackerCompat.getYVelocity(v30, this.mActivePointerId));
                    if (Math.abs(v25) <= this.mMinimumVelocity) {
                        v15 = this.getScrollX();
                        v16 = this.getScrollY();
                        this.getScrollRange();
                        if (this.mScroller.springBack(v15, v16, 0, 0, 0, this) != 0) {
                            android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
                        }
                    } else {
                        this.flingWithNestedDispatch((- v25));
                    }
                }
                this.mActivePointerId = -1;
                this.endDrag();
                break;
            case 2:
                v22 = android.support.v4.view.MotionEventCompat.findPointerIndex(p34, this.mActivePointerId);
                if (v22 != -1) {
                    v32 = ((int) android.support.v4.view.MotionEventCompat.getY(p34, v22));
                    v4 = (this.mLastMotionY - v32);
                    if (this.dispatchNestedPreScroll(0, v4, this.mScrollConsumed, this.mScrollOffset) != 0) {
                        v4 -= this.mScrollConsumed[1];
                        v31.offsetLocation(0, ((float) this.mScrollOffset[1]));
                        this.mNestedYOffset = (this.mNestedYOffset + this.mScrollOffset[1]);
                    }
                    if ((this.mIsBeingDragged) && (Math.abs(v4) > this.mTouchSlop)) {
                        v28 = this.getParent();
                        if (v28 != 0) {
                            v28.requestDisallowInterceptTouchEvent(1);
                        }
                        this.mIsBeingDragged = 1;
                        if (v4 <= 0) {
                            v4 += this.mTouchSlop;
                        } else {
                            v4 -= this.mTouchSlop;
                        }
                    }
                    if (!this.mIsBeingDragged) {
                    } else {
                        this.mLastMotionY = (v32 - this.mScrollOffset[1]);
                        v26 = this.getScrollY();
                        this.getScrollRange();
                        v27 = android.support.v4.view.ViewCompat.getOverScrollMode(this);
                        if ((v27 != 0) && ((v27 != 1) || (this <= 0))) {
                            v23 = 0;
                        } else {
                            v23 = 1;
                        }
                        if ((this.overScrollByCompat(0, v4, 0, this.getScrollY(), 0, this, 0, 0, 1) != 0) && (this.hasNestedScrollingParent() == 0)) {
                            this.mVelocityTracker.clear();
                        }
                        v11 = (this.getScrollY() - v26);
                        if (this.dispatchNestedScroll(0, v11, 0, (v4 - v11), this.mScrollOffset) == 0) {
                            if (v23 == 0) {
                            } else {
                                this.ensureGlows();
                                v29 = (v26 + v4);
                                if (v29 >= 0) {
                                    if (v29 > this) {
                                        this.mEdgeGlowBottom.onPull((((float) v4) / ((float) this.getHeight())), (1.0 - (android.support.v4.view.MotionEventCompat.getX(p34, v22) / ((float) this.getWidth()))));
                                        if (this.mEdgeGlowTop.isFinished() == 0) {
                                            this.mEdgeGlowTop.onRelease();
                                        }
                                    }
                                } else {
                                    this.mEdgeGlowTop.onPull((((float) v4) / ((float) this.getHeight())), (android.support.v4.view.MotionEventCompat.getX(p34, v22) / ((float) this.getWidth())));
                                    if (this.mEdgeGlowBottom.isFinished() == 0) {
                                        this.mEdgeGlowBottom.onRelease();
                                    }
                                }
                                if ((this.mEdgeGlowTop == 0) || ((this.mEdgeGlowTop.isFinished() != 0) && (this.mEdgeGlowBottom.isFinished() != 0))) {
                                } else {
                                    android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
                                }
                            }
                        } else {
                            this.mLastMotionY = (this.mLastMotionY - this.mScrollOffset[1]);
                            v31.offsetLocation(0, ((float) this.mScrollOffset[1]));
                            this.mNestedYOffset = (this.mNestedYOffset + this.mScrollOffset[1]);
                        }
                    }
                } else {
                    android.util.Log.e("NestedScrollView", new StringBuilder().append("Invalid pointerId=").append(this.mActivePointerId).append(" in onTouchEvent").toString());
                }
                break;
            case 3:
                if ((this.mIsBeingDragged) && (this.getChildCount() > 0)) {
                    v15 = this.getScrollX();
                    v16 = this.getScrollY();
                    this.getScrollRange();
                    if (this.mScroller.springBack(v15, v16, 0, 0, 0, this) != 0) {
                        android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
                    }
                }
                this.mActivePointerId = -1;
                this.endDrag();
            case 5:
                v24 = android.support.v4.view.MotionEventCompat.getActionIndex(p34);
                this.mLastMotionY = ((int) android.support.v4.view.MotionEventCompat.getY(p34, v24));
                this.mActivePointerId = android.support.v4.view.MotionEventCompat.getPointerId(p34, v24);
                break;
            case 6:
                this.onSecondaryPointerUp(p34);
                this.mLastMotionY = ((int) android.support.v4.view.MotionEventCompat.getY(p34, android.support.v4.view.MotionEventCompat.findPointerIndex(p34, this.mActivePointerId)));
                break;
            default:
        }
        return v2;
    }
     boolean overScrollByCompat(int p20, int p21, int p22, int p23, int p24, int p25, int p26, int p27, boolean p28)
    {
        v15 = android.support.v4.view.ViewCompat.getOverScrollMode(this);
        if (this.computeHorizontalScrollRange() <= this.computeHorizontalScrollExtent()) {
            v9 = 0;
        } else {
            v9 = 1;
        }
        if (this.computeVerticalScrollRange() <= this.computeVerticalScrollExtent()) {
            v10 = 0;
        } else {
            v10 = 1;
        }
        if ((v15 != 0) && ((v15 != 1) || (v9 == 0))) {
            v14 = 0;
        } else {
            v14 = 1;
        }
        if ((v15 != 0) && ((v15 != 1) || (v10 == 0))) {
            v16 = 0;
        } else {
            v16 = 1;
        }
        v2 = (p22 + p20);
        if (v14 == 0) {
            p26 = 0;
        }
        v3 = (p23 + p21);
        if (v16 == 0) {
            p27 = 0;
        }
        v13 = (- p26);
        v17 = (p26 + p24);
        v18 = (- p27);
        v8 = (p27 + p25);
        v11 = 0;
        if (v2 <= v17) {
            if (v2 < v13) {
                v2 = v13;
                v11 = 1;
            }
        } else {
            v2 = v17;
            v11 = 1;
        }
        v12 = 0;
        if (v3 <= v8) {
            if (v3 < v18) {
                v3 = v18;
                v12 = 1;
            }
        } else {
            v3 = v8;
            v12 = 1;
        }
        if (v12 != 0) {
            this.getScrollRange();
            this.mScroller.springBack(v2, v3, 0, 0, 0, this);
        }
        this.onOverScrolled(v2, v3, v11, v12);
        if ((v11 == 0) && (v12 == 0)) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        return v1;
    }
    public boolean pageScroll(int p8)
    {
        if (p8 != 130) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        v2 = this.getHeight();
        if (v1 == 0) {
            this.mTempRect.top = (this.getScrollY() - v2);
            if (this.mTempRect.top < 0) {
                this.mTempRect.top = 0;
            }
        } else {
            this.mTempRect.top = (this.getScrollY() + v2);
            v0 = this.getChildCount();
            if (v0 > 0) {
                v3 = this.getChildAt((v0 - 1));
                if ((this.mTempRect.top + v2) > v3.getBottom()) {
                    this.mTempRect.top = (v3.getBottom() - v2);
                }
            }
        }
        this.mTempRect.bottom = (this.mTempRect.top + v2);
        this.scrollAndFocus(p8, this.mTempRect.top, this.mTempRect.bottom);
        return this;
    }
    private void recycleVelocityTracker()
    {
        if (this.mVelocityTracker != 0) {
            this.mVelocityTracker.recycle();
            this.mVelocityTracker = 0;
        }
        return;
    }
    public void requestChildFocus(android.view.View p2, android.view.View p3)
    {
        if (this.mIsLayoutDirty) {
            this.mChildToScrollTo = p3;
        } else {
            this.scrollToChild(p3);
        }
        super.requestChildFocus(p2, p3);
        return;
    }
    public boolean requestChildRectangleOnScreen(android.view.View p4, android.graphics.Rect p5, boolean p6)
    {
        p5.offset((p4.getLeft() - p4.getScrollX()), (p4.getTop() - p4.getScrollY()));
        this.scrollToChildRect(p5, p6);
        return this;
    }
    public void requestDisallowInterceptTouchEvent(boolean p1)
    {
        if (p1 != 0) {
            this.recycleVelocityTracker();
        }
        super.requestDisallowInterceptTouchEvent(p1);
        return;
    }
    public void requestLayout()
    {
        this.mIsLayoutDirty = 1;
        super.requestLayout();
        return;
    }
    private boolean scrollAndFocus(int p9, int p10, int p11)
    {
        v3 = 1;
        v4 = this.getHeight();
        v1 = this.getScrollY();
        v0 = (v1 + v4);
        if (p9 != 33) {
            v6 = 0;
        } else {
            v6 = 1;
        }
        this.findFocusableViewInBounds(v6, p10, p11);
        v5 = this;
        if (this == 0) {
            v5 = this;
        }
        if ((p10 < v1) || (p11 > v0)) {
            if (v6 == 0) {
                v2 = (p11 - v0);
            } else {
                v2 = (p10 - v1);
            }
            this.doScrollY(v2);
        } else {
            v3 = 0;
        }
        if (v5 != this.findFocus()) {
            v5.requestFocus(p9);
        }
        return v3;
    }
    public void scrollTo(int p4, int p5)
    {
        if (this.getChildCount() > 0) {
            v0 = this.getChildAt(0);
            p4 = android.support.v4.widget.NestedScrollView.clamp(p4, ((this.getWidth() - this.getPaddingRight()) - this.getPaddingLeft()), v0.getWidth());
            p5 = android.support.v4.widget.NestedScrollView.clamp(p5, ((this.getHeight() - this.getPaddingBottom()) - this.getPaddingTop()), v0.getHeight());
            if ((p4 != this.getScrollX()) || (p5 != this.getScrollY())) {
                super.scrollTo(p4, p5);
            }
        }
        return;
    }
    private void scrollToChild(android.view.View p3)
    {
        p3.getDrawingRect(this.mTempRect);
        this.offsetDescendantRectToMyCoords(p3, this.mTempRect);
        v0 = this.computeScrollDeltaToGetChildRectOnScreen(this.mTempRect);
        if (v0 != 0) {
            this.scrollBy(0, v0);
        }
        return;
    }
    private boolean scrollToChildRect(android.graphics.Rect p4, boolean p5)
    {
        v0 = this.computeScrollDeltaToGetChildRectOnScreen(p4);
        if (v0 == 0) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        if (v1 != 0) {
            if (p5 == 0) {
                this.smoothScrollBy(0, v0);
            } else {
                this.scrollBy(0, v0);
            }
        }
        return v1;
    }
    public void setFillViewport(boolean p2)
    {
        if (p2 != this.mFillViewport) {
            this.mFillViewport = p2;
            this.requestLayout();
        }
        return;
    }
    public void setNestedScrollingEnabled(boolean p2)
    {
        this.mChildHelper.setNestedScrollingEnabled(p2);
        return;
    }
    public void setOnScrollChangeListener(android.support.v4.widget.NestedScrollView$OnScrollChangeListener p1)
    {
        this.mOnScrollChangeListener = p1;
        return;
    }
    public void setSmoothScrollingEnabled(boolean p1)
    {
        this.mSmoothScrollingEnabled = p1;
        return;
    }
    public boolean shouldDelayChildPressedState()
    {
        return 1;
    }
    public final void smoothScrollBy(int p12, int p13)
    {
        if (this.getChildCount() != 0) {
            if ((android.view.animation.AnimationUtils.currentAnimationTimeMillis() - this.mLastScroll) <= 250.0) {
                if (this.mScroller.isFinished() == 0) {
                    this.mScroller.abortAnimation();
                }
                this.scrollBy(p12, p13);
            } else {
                v4 = Math.max(0, (this.getChildAt(0).getHeight() - ((this.getHeight() - this.getPaddingBottom()) - this.getPaddingTop())));
                v5 = this.getScrollY();
                this.mScroller.startScroll(this.getScrollX(), v5, 0, (Math.max(0, Math.min((v5 + p13), v4)) - v5));
                android.support.v4.view.ViewCompat.postInvalidateOnAnimation(this);
            }
            this.mLastScroll = android.view.animation.AnimationUtils.currentAnimationTimeMillis();
        }
        return;
    }
    public final void smoothScrollTo(int p3, int p4)
    {
        this.smoothScrollBy((p3 - this.getScrollX()), (p4 - this.getScrollY()));
        return;
    }
    public boolean startNestedScroll(int p2)
    {
        return this.mChildHelper.startNestedScroll(p2);
    }
    public void stopNestedScroll()
    {
        this.mChildHelper.stopNestedScroll();
        return;
    }
    static NestedScrollView()
    {
        android.support.v4.widget.NestedScrollView.ACCESSIBILITY_DELEGATE = new android.support.v4.widget.NestedScrollView$AccessibilityDelegate();
        v0 = new int[1];
        v0[0] = 2.369461739040076e-38;
        android.support.v4.widget.NestedScrollView.SCROLLVIEW_STYLEABLE = v0;
        return;
    }
    public NestedScrollView(android.content.Context p2)
    {
        this(p2, 0);
        return;
    }
    public NestedScrollView(android.content.Context p2, android.util.AttributeSet p3)
    {
        this(p2, p3, 0);
        return;
    }
    public NestedScrollView(android.content.Context p6, android.util.AttributeSet p7, int p8)
    {
        this(p6, p7, p8);
        this.mTempRect = new android.graphics.Rect();
        this.mIsLayoutDirty = 1;
        this.mIsLaidOut = 0;
        this.mChildToScrollTo = 0;
        this.mIsBeingDragged = 0;
        this.mSmoothScrollingEnabled = 1;
        this.mActivePointerId = -1;
        v1 = new int[2];
        this.mScrollOffset = v1;
        v1 = new int[2];
        this.mScrollConsumed = v1;
        this.initScrollView();
        v0 = p6.obtainStyledAttributes(p7, android.support.v4.widget.NestedScrollView.SCROLLVIEW_STYLEABLE, p8, 0);
        this.setFillViewport(v0.getBoolean(0, 0));
        v0.recycle();
        this.mParentHelper = new android.support.v4.view.NestedScrollingParentHelper(this);
        this.mChildHelper = new android.support.v4.view.NestedScrollingChildHelper(this);
        this.setNestedScrollingEnabled(1);
        android.support.v4.view.ViewCompat.setAccessibilityDelegate(this, android.support.v4.widget.NestedScrollView.ACCESSIBILITY_DELEGATE);
        return;
    }
    static synthetic int access$000(android.support.v4.widget.NestedScrollView p1)
    {
        return p1.getScrollRange();
    }
    public void addView(android.view.View p3)
    {
        if (this.getChildCount() <= 0) {
            super.addView(p3);
            return;
        } else {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
    }
    public void addView(android.view.View p3, int p4)
    {
        if (this.getChildCount() <= 0) {
            super.addView(p3, p4);
            return;
        } else {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
    }
    public void addView(android.view.View p3, int p4, android.view.ViewGroup$LayoutParams p5)
    {
        if (this.getChildCount() <= 0) {
            super.addView(p3, p4, p5);
            return;
        } else {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
    }
    public void addView(android.view.View p3, android.view.ViewGroup$LayoutParams p4)
    {
        if (this.getChildCount() <= 0) {
            super.addView(p3, p4);
            return;
        } else {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
    }
    public boolean arrowScroll(int p12)
    {
        v7 = 0;
        v0 = this.findFocus();
        if (v0 == this) {
            v0 = 0;
        }
        v4 = android.view.FocusFinder.getInstance().findNextFocus(this, v0, p12);
        v3 = this.getMaxScrollAmount();
        if (v4 == 0) {
            v6 = v3;
            if ((p12 != 33) || (this.getScrollY() >= v6)) {
                if ((p12 == 130) && (this.getChildCount() > 0)) {
                    v1 = this.getChildAt(0).getBottom();
                    v5 = ((this.getScrollY() + this.getHeight()) - this.getPaddingBottom());
                    if ((v1 - v5) < v3) {
                        v6 = (v1 - v5);
                    }
                }
            } else {
                v6 = this.getScrollY();
            }
            if (v6 != 0) {
                if (p12 != 130) {
                    v7 = (- v6);
                } else {
                    v7 = v6;
                }
                this.doScrollY(v7);
                if ((v0 != 0) && (v0.isFocused() != 0)) {
                    this.isOffScreen(v0);
                    if (this != 0) {
                        v2 = this.getDescendantFocusability();
                        this.setDescendantFocusability(1.8367099231598242e-40);
                        this.requestFocus();
                        this.setDescendantFocusability(v2);
                    }
                }
                v7 = 1;
            }
        } else {
            this.isWithinDeltaOfScreen(v4, v3, this.getHeight());
            } else {
                v4.getDrawingRect(this.mTempRect);
                this.offsetDescendantRectToMyCoords(v4, this.mTempRect);
                this.doScrollY(this.computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
                v4.requestFocus(p12);
            }
        }
        return v7;
    }
    private boolean canScroll()
    {
        v2 = 0;
        v0 = this.getChildAt(0);
        if ((v0 != 0) && (this.getHeight() < ((this.getPaddingTop() + v0.getHeight()) + this.getPaddingBottom()))) {
            v2 = 1;
        }
        return v2;
    }
    private static int clamp(int p1, int p2, int p3)
    {
        if ((p2 < p3) && (p1 >= 0)) {
            if ((p2 + p1) > p3) {
                p1 = (p3 - p2);
            }
        } else {
            p1 = 0;
        }
        return p1;
    }
    public int computeHorizontalScrollExtent()
    {
        return super.computeHorizontalScrollExtent();
    }
    public int computeHorizontalScrollOffset()
    {
        return super.computeHorizontalScrollOffset();
    }
    public int computeHorizontalScrollRange()
    {
        return super.computeHorizontalScrollRange();
    }
    public void computeScroll()
    {
        v10 = 1;
        if (this.mScroller.computeScrollOffset() != 0) {
            v3 = this.getScrollX();
            v4 = this.getScrollY();
            v12 = this.mScroller.getCurrX();
            v13 = this.mScroller.getCurrY();
            if ((v3 != v12) || (v4 != v13)) {
                this.getScrollRange();
                v11 = android.support.v4.view.ViewCompat.getOverScrollMode(this);
                if ((v11 != 0) && ((v11 != 1) || (this <= 0))) {
                    v10 = 0;
                }
                this.overScrollByCompat((v12 - v3), (v13 - v4), v3, v4, 0, this, 0, 0, 0);
                if (v10 != 0) {
                    this.ensureGlows();
                    if ((v13 > 0) || (v4 <= 0)) {
                        if ((v13 >= this) && (v4 < this)) {
                            this.mEdgeGlowBottom.onAbsorb(((int) this.mScroller.getCurrVelocity()));
                        }
                    } else {
                        this.mEdgeGlowTop.onAbsorb(((int) this.mScroller.getCurrVelocity()));
                    }
                }
            }
        }
        return;
    }
}
