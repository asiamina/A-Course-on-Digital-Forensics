package android.support.v4.media;
 class MediaBrowserCompat$MediaBrowserImplApi21$1 implements java.lang.Runnable {
    final synthetic android.support.v4.media.MediaBrowserCompat$ItemCallback val$cb;
    final synthetic String val$mediaId;
    final synthetic android.support.v4.media.MediaBrowserCompat$MediaBrowserImplApi21 this$0;
     MediaBrowserCompat$MediaBrowserImplApi21$1(android.support.v4.media.MediaBrowserCompat$MediaBrowserImplApi21 p1, android.support.v4.media.MediaBrowserCompat$ItemCallback p2, String p3)
    {
        this.this$0 = p1;
        this.val$cb = p2;
        this.val$mediaId = p3;
        return;
    }
    public void run()
    {
        this.val$cb.onError(this.val$mediaId);
        return;
    }
}
