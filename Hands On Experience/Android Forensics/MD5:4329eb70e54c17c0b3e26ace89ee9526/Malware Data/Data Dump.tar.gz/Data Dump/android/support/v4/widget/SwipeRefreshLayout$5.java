package android.support.v4.widget;
 class SwipeRefreshLayout$5 implements android.view.animation.Animation$AnimationListener {
    final synthetic android.support.v4.widget.SwipeRefreshLayout this$0;
    public void onAnimationStart(android.view.animation.Animation p1)
    {
        return;
    }
     SwipeRefreshLayout$5(android.support.v4.widget.SwipeRefreshLayout p1)
    {
        this.this$0 = p1;
        return;
    }
    public void onAnimationEnd(android.view.animation.Animation p3)
    {
        if (android.support.v4.widget.SwipeRefreshLayout.access$600(this.this$0) == 0) {
            android.support.v4.widget.SwipeRefreshLayout.access$1000(this.this$0, 0);
        }
        return;
    }
    public void onAnimationRepeat(android.view.animation.Animation p1)
    {
        return;
    }
}
