package android.support.v4.widget;
 class ScrollerCompat$ScrollerCompatImplBase implements android.support.v4.widget.ScrollerCompat$ScrollerCompatImpl {
    public int getCurrX(Object p2)
    {
        return p2.getCurrX();
    }
    public int getCurrY(Object p2)
    {
        return p2.getCurrY();
    }
    public int getFinalX(Object p2)
    {
        return p2.getFinalX();
    }
    public int getFinalY(Object p2)
    {
        return p2.getFinalY();
    }
    public boolean isFinished(Object p2)
    {
        return p2.isFinished();
    }
    public boolean isOverScrolled(Object p2)
    {
        return 0;
    }
    public void notifyHorizontalEdgeReached(Object p1, int p2, int p3, int p4)
    {
        return;
    }
    public void notifyVerticalEdgeReached(Object p1, int p2, int p3, int p4)
    {
        return;
    }
    public boolean springBack(Object p2, int p3, int p4, int p5, int p6, int p7, int p8)
    {
        return 0;
    }
    public void startScroll(Object p1, int p2, int p3, int p4, int p5)
    {
        p1.startScroll(p2, p3, p4, p5);
        return;
    }
    public void startScroll(Object p7, int p8, int p9, int p10, int p11, int p12)
    {
        p7.startScroll(p8, p9, p10, p11, p12);
        return;
    }
     ScrollerCompat$ScrollerCompatImplBase()
    {
        return;
    }
    public void abortAnimation(Object p1)
    {
        p1.abortAnimation();
        return;
    }
    public boolean computeScrollOffset(Object p3)
    {
        return p3.computeScrollOffset();
    }
    public Object createScroller(android.content.Context p2, android.view.animation.Interpolator p3)
    {
        if (p3 == 0) {
            v0 = new android.widget.Scroller(p2);
        } else {
            v0 = new android.widget.Scroller(p2, p3);
        }
        return v0;
    }
    public void fling(Object p10, int p11, int p12, int p13, int p14, int p15, int p16, int p17, int p18)
    {
        p10.fling(p11, p12, p13, p14, p15, p16, p17, p18);
        return;
    }
    public void fling(Object p10, int p11, int p12, int p13, int p14, int p15, int p16, int p17, int p18, int p19, int p20)
    {
        p10.fling(p11, p12, p13, p14, p15, p16, p17, p18);
        return;
    }
    public float getCurrVelocity(Object p2)
    {
        return 0;
    }
}
