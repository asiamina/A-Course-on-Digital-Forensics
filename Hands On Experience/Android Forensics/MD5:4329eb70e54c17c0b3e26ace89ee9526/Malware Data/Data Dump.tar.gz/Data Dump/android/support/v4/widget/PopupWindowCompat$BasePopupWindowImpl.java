package android.support.v4.widget;
 class PopupWindowCompat$BasePopupWindowImpl implements android.support.v4.widget.PopupWindowCompat$PopupWindowImpl {
     PopupWindowCompat$BasePopupWindowImpl()
    {
        return;
    }
    public boolean getOverlapAnchor(android.widget.PopupWindow p2)
    {
        return 0;
    }
    public int getWindowLayoutType(android.widget.PopupWindow p2)
    {
        return 0;
    }
    public void setOverlapAnchor(android.widget.PopupWindow p1, boolean p2)
    {
        return;
    }
    public void setWindowLayoutType(android.widget.PopupWindow p1, int p2)
    {
        return;
    }
    public void showAsDropDown(android.widget.PopupWindow p1, android.view.View p2, int p3, int p4, int p5)
    {
        p1.showAsDropDown(p2, p3, p4);
        return;
    }
}
