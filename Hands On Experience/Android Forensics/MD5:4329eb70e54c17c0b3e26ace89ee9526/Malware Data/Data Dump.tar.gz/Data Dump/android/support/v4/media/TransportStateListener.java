package android.support.v4.media;
public class TransportStateListener {
    public TransportStateListener()
    {
        return;
    }
    public void onPlayingChanged(android.support.v4.media.TransportController p1)
    {
        return;
    }
    public void onTransportControlsChanged(android.support.v4.media.TransportController p1)
    {
        return;
    }
}
