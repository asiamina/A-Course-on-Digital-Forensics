package android.support.v4.view.accessibility;
 class AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanMr1Impl extends android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl {
    public Object getLabeledBy(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellybeanMr1.getLabeledBy(p2);
    }
    public void setLabelFor(Object p1, android.view.View p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellybeanMr1.setLabelFor(p1, p2);
        return;
    }
    public void setLabelFor(Object p1, android.view.View p2, int p3)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellybeanMr1.setLabelFor(p1, p2, p3);
        return;
    }
    public void setLabeledBy(Object p1, android.view.View p2)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellybeanMr1.setLabeledBy(p1, p2);
        return;
    }
    public void setLabeledBy(Object p1, android.view.View p2, int p3)
    {
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellybeanMr1.setLabeledBy(p1, p2, p3);
        return;
    }
     AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanMr1Impl()
    {
        return;
    }
    public Object getLabelFor(Object p2)
    {
        return android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellybeanMr1.getLabelFor(p2);
    }
}
