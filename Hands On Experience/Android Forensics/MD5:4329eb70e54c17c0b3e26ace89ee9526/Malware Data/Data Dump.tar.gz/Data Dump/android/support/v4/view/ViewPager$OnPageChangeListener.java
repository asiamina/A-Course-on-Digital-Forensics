package android.support.v4.view;
public interface abstract class ViewPager$OnPageChangeListener {
    abstract public void onPageScrollStateChanged();
    abstract public void onPageScrolled();
    abstract public void onPageSelected();
}
