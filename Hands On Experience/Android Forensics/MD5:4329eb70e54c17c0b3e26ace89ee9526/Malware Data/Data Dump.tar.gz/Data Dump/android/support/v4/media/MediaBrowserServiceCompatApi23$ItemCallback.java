package android.support.v4.media;
public interface abstract class MediaBrowserServiceCompatApi23$ItemCallback {
    abstract public void onItemLoaded();
}
