package android.support.multidex;
 class MultiDexExtractor$1 implements java.io.FileFilter {
    final private synthetic String val$extractedFilePrefix;
     MultiDexExtractor$1(String p1)
    {
        this.val$extractedFilePrefix = p1;
        return;
    }
    public boolean accept(java.io.File p3)
    {
        if (p3.getName().startsWith(this.val$extractedFilePrefix) == 0) {
            v0 = 1;
        } else {
            v0 = 0;
        }
        return v0;
    }
}
