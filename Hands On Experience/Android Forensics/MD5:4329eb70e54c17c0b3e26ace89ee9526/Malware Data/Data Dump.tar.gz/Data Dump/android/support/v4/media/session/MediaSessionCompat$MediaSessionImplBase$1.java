package android.support.v4.media.session;
 class MediaSessionCompat$MediaSessionImplBase$1 extends android.support.v4.media.VolumeProviderCompat$Callback {
    final synthetic android.support.v4.media.session.MediaSessionCompat$MediaSessionImplBase this$0;
     MediaSessionCompat$MediaSessionImplBase$1(android.support.v4.media.session.MediaSessionCompat$MediaSessionImplBase p1)
    {
        this.this$0 = p1;
        return;
    }
    public void onVolumeChanged(android.support.v4.media.VolumeProviderCompat p7)
    {
        if (android.support.v4.media.session.MediaSessionCompat$MediaSessionImplBase.access$300(this.this$0) == p7) {
            android.support.v4.media.session.MediaSessionCompat$MediaSessionImplBase.access$600(this.this$0, new android.support.v4.media.session.ParcelableVolumeInfo(v1, android.support.v4.media.session.MediaSessionCompat$MediaSessionImplBase.access$500(this.this$0), p7.getVolumeControl(), p7.getMaxVolume(), p7.getCurrentVolume()));
        }
        return;
    }
}
