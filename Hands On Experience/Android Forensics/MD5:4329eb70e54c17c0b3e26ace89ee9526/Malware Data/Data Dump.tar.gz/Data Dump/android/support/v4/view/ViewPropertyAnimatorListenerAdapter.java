package android.support.v4.view;
public class ViewPropertyAnimatorListenerAdapter implements android.support.v4.view.ViewPropertyAnimatorListener {
    public void onAnimationEnd(android.view.View p1)
    {
        return;
    }
    public void onAnimationStart(android.view.View p1)
    {
        return;
    }
    public ViewPropertyAnimatorListenerAdapter()
    {
        return;
    }
    public void onAnimationCancel(android.view.View p1)
    {
        return;
    }
}
