package android.support.v4.app;
abstract class BaseFragmentActivityDonut extends android.app.Activity {
    abstract android.view.View dispatchFragmentsOnCreateView();
    protected void onCreate(android.os.Bundle p3)
    {
        if ((android.os.Build$VERSION.SDK_INT < 11) && (this.getLayoutInflater().getFactory() == 0)) {
            this.getLayoutInflater().setFactory(this);
        }
        super.onCreate(p3);
        return;
    }
    public android.view.View onCreateView(String p3, android.content.Context p4, android.util.AttributeSet p5)
    {
        v0 = this.dispatchFragmentsOnCreateView(0, p3, p4, p5);
        if (v0 == 0) {
            v0 = super.onCreateView(p3, p4, p5);
        }
        return v0;
    }
     BaseFragmentActivityDonut()
    {
        return;
    }
}
