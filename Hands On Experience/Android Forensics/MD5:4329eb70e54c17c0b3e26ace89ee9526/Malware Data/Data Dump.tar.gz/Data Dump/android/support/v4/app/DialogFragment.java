package android.support.v4.app;
public class DialogFragment extends android.support.v4.app.Fragment implements android.content.DialogInterface$OnCancelListener, android.content.DialogInterface$OnDismissListener {
    final private static String SAVED_STYLE;
    final public static int STYLE_NO_INPUT;
     boolean mViewDestroyed;
    final private static String SAVED_SHOWS_DIALOG;
     android.app.Dialog mDialog;
    final private static String SAVED_CANCELABLE;
     boolean mShowsDialog;
    final private static String SAVED_BACK_STACK_ID;
    final public static int STYLE_NO_TITLE;
     boolean mCancelable;
    final private static String SAVED_DIALOG_STATE_TAG;
    final public static int STYLE_NORMAL;
     int mTheme;
     boolean mDismissed;
    final private static String SAVED_THEME;
     int mStyle;
     int mBackStackId;
    final public static int STYLE_NO_FRAME;
     boolean mShownByMe;
    public DialogFragment()
    {
        this.mStyle = 0;
        this.mTheme = 0;
        this.mCancelable = 1;
        this.mShowsDialog = 1;
        this.mBackStackId = -1;
        return;
    }
    public void dismiss()
    {
        this.dismissInternal(0);
        return;
    }
    public void dismissAllowingStateLoss()
    {
        this.dismissInternal(1);
        return;
    }
     void dismissInternal(boolean p5)
    {
        if (!this.mDismissed) {
            this.mDismissed = 1;
            this.mShownByMe = 0;
            if (this.mDialog != 0) {
                this.mDialog.dismiss();
                this.mDialog = 0;
            }
            this.mViewDestroyed = 1;
            if (this.mBackStackId < 0) {
                v0 = this.getFragmentManager().beginTransaction();
                v0.remove(this);
                if (p5 == 0) {
                    v0.commit();
                } else {
                    v0.commitAllowingStateLoss();
                }
            } else {
                this.getFragmentManager().popBackStack(this.mBackStackId, 1);
                this.mBackStackId = -1;
            }
        }
        return;
    }
    public android.app.Dialog getDialog()
    {
        return this.mDialog;
    }
    public android.view.LayoutInflater getLayoutInflater(android.os.Bundle p3)
    {
        if (this.mShowsDialog) {
            this.mDialog = this.onCreateDialog(p3);
            if (this.mDialog == 0) {
                v0 = this.mHost.getContext().getSystemService("layout_inflater");
            } else {
                this.setupDialog(this.mDialog, this.mStyle);
                v0 = this.mDialog.getContext().getSystemService("layout_inflater");
            }
        } else {
            v0 = super.getLayoutInflater(p3);
        }
        return v0;
    }
    public boolean getShowsDialog()
    {
        return this.mShowsDialog;
    }
    public int getTheme()
    {
        return this.mTheme;
    }
    public boolean isCancelable()
    {
        return this.mCancelable;
    }
    public void onActivityCreated(android.os.Bundle p5)
    {
        super.onActivityCreated(p5);
        if (this.mShowsDialog) {
            v1 = this.getView();
            if (v1 != 0) {
                if (v1.getParent() == 0) {
                    this.mDialog.setContentView(v1);
                } else {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
            }
            this.mDialog.setOwnerActivity(this.getActivity());
            this.mDialog.setCancelable(this.mCancelable);
            this.mDialog.setOnCancelListener(this);
            this.mDialog.setOnDismissListener(this);
            if (p5 != 0) {
                v0 = p5.getBundle("android:savedDialogState");
                if (v0 != 0) {
                    this.mDialog.onRestoreInstanceState(v0);
                }
            }
        }
        return;
    }
    public void onAttach(android.app.Activity p2)
    {
        super.onAttach(p2);
        if (this.mShownByMe) {
            this.mDismissed = 0;
        }
        return;
    }
    public void onCancel(android.content.DialogInterface p1)
    {
        return;
    }
    public void onCreate(android.os.Bundle p4)
    {
        super.onCreate(p4);
        if (this.mContainerId != 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        this.mShowsDialog = v0;
        if (p4 != 0) {
            this.mStyle = p4.getInt("android:style", 0);
            this.mTheme = p4.getInt("android:theme", 0);
            this.mCancelable = p4.getBoolean("android:cancelable", 1);
            this.mShowsDialog = p4.getBoolean("android:showsDialog", this.mShowsDialog);
            this.mBackStackId = p4.getInt("android:backStackId", -1);
        }
        return;
    }
    public android.app.Dialog onCreateDialog(android.os.Bundle p4)
    {
        return new android.app.Dialog(this.getActivity(), this.getTheme());
    }
    public void onDestroyView()
    {
        super.onDestroyView();
        if (this.mDialog != 0) {
            this.mViewDestroyed = 1;
            this.mDialog.dismiss();
            this.mDialog = 0;
        }
        return;
    }
    public void onDetach()
    {
        super.onDetach();
        if ((this.mShownByMe) && (this.mDismissed)) {
            this.mDismissed = 1;
        }
        return;
    }
    public void onDismiss(android.content.DialogInterface p2)
    {
        if (this.mViewDestroyed) {
            this.dismissInternal(1);
        }
        return;
    }
    public void onSaveInstanceState(android.os.Bundle p4)
    {
        super.onSaveInstanceState(p4);
        if (this.mDialog != 0) {
            v0 = this.mDialog.onSaveInstanceState();
            if (v0 != 0) {
                p4.putBundle("android:savedDialogState", v0);
            }
        }
        if (this.mStyle != 0) {
            p4.putInt("android:style", this.mStyle);
        }
        if (this.mTheme != 0) {
            p4.putInt("android:theme", this.mTheme);
        }
        if (this.mCancelable) {
            p4.putBoolean("android:cancelable", this.mCancelable);
        }
        if (this.mShowsDialog) {
            p4.putBoolean("android:showsDialog", this.mShowsDialog);
        }
        if (this.mBackStackId != -1) {
            p4.putInt("android:backStackId", this.mBackStackId);
        }
        return;
    }
    public void onStart()
    {
        super.onStart();
        if (this.mDialog != 0) {
            this.mViewDestroyed = 0;
            this.mDialog.show();
        }
        return;
    }
    public void onStop()
    {
        super.onStop();
        if (this.mDialog != 0) {
            this.mDialog.hide();
        }
        return;
    }
    public void setCancelable(boolean p2)
    {
        this.mCancelable = p2;
        if (this.mDialog != 0) {
            this.mDialog.setCancelable(p2);
        }
        return;
    }
    public void setShowsDialog(boolean p1)
    {
        this.mShowsDialog = p1;
        return;
    }
    public void setStyle(int p3, int p4)
    {
        this.mStyle = p3;
        if ((this.mStyle == 2) || (this.mStyle == 3)) {
            this.mTheme = 2.4061149424520347e-38;
        }
        if (p4 != 0) {
            this.mTheme = p4;
        }
        return;
    }
    public void setupDialog(android.app.Dialog p3, int p4)
    {
        switch (p4) {
            case 1:
            case 2:
                p3.requestWindowFeature(1);
                break;
            case 3:
                p3.getWindow().addFlags(24);
                break;
        }
        return;
    }
    public int show(android.support.v4.app.FragmentTransaction p3, String p4)
    {
        this.mDismissed = 0;
        this.mShownByMe = 1;
        p3.add(this, p4);
        this.mViewDestroyed = 0;
        this.mBackStackId = p3.commit();
        return this.mBackStackId;
    }
    public void show(android.support.v4.app.FragmentManager p3, String p4)
    {
        this.mDismissed = 0;
        this.mShownByMe = 1;
        v0 = p3.beginTransaction();
        v0.add(this, p4);
        v0.commit();
        return;
    }
}
