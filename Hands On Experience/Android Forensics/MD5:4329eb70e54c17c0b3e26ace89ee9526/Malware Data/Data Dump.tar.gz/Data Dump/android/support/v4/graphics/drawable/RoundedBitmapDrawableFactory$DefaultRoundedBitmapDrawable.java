package android.support.v4.graphics.drawable;
 class RoundedBitmapDrawableFactory$DefaultRoundedBitmapDrawable extends android.support.v4.graphics.drawable.RoundedBitmapDrawable {
     RoundedBitmapDrawableFactory$DefaultRoundedBitmapDrawable(android.content.res.Resources p1, android.graphics.Bitmap p2)
    {
        this(p1, p2);
        return;
    }
     void gravityCompatApply(int p7, int p8, int p9, android.graphics.Rect p10, android.graphics.Rect p11)
    {
        android.support.v4.view.GravityCompat.apply(p7, p8, p9, p10, p11, 0);
        return;
    }
    public boolean hasMipMap()
    {
        if ((this.mBitmap == 0) || (android.support.v4.graphics.BitmapCompat.hasMipMap(this.mBitmap) == 0)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public void setMipMap(boolean p2)
    {
        if (this.mBitmap != 0) {
            android.support.v4.graphics.BitmapCompat.setHasMipMap(this.mBitmap, p2);
            this.invalidateSelf();
        }
        return;
    }
}
