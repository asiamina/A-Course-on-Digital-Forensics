package android.support.v4.hardware.fingerprint;
 class FingerprintManagerCompat$Api23FingerprintManagerCompatImpl implements android.support.v4.hardware.fingerprint.FingerprintManagerCompat$FingerprintManagerCompatImpl {
    public FingerprintManagerCompat$Api23FingerprintManagerCompatImpl()
    {
        return;
    }
    static synthetic android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject access$000(android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject p1)
    {
        return android.support.v4.hardware.fingerprint.FingerprintManagerCompat$Api23FingerprintManagerCompatImpl.unwrapCryptoObject(p1);
    }
    public void authenticate(android.content.Context p7, android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject p8, int p9, android.support.v4.os.CancellationSignal p10, android.support.v4.hardware.fingerprint.FingerprintManagerCompat$AuthenticationCallback p11, android.os.Handler p12)
    {
        v1 = android.support.v4.hardware.fingerprint.FingerprintManagerCompat$Api23FingerprintManagerCompatImpl.wrapCryptoObject(p8);
        if (p10 == 0) {
            v3 = 0;
        } else {
            v3 = p10.getCancellationSignalObject();
        }
        android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23.authenticate(p7, v1, p9, v3, android.support.v4.hardware.fingerprint.FingerprintManagerCompat$Api23FingerprintManagerCompatImpl.wrapCallback(p11), p12);
        return;
    }
    public boolean hasEnrolledFingerprints(android.content.Context p2)
    {
        return android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23.hasEnrolledFingerprints(p2);
    }
    public boolean isHardwareDetected(android.content.Context p2)
    {
        return android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23.isHardwareDetected(p2);
    }
    private static android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject unwrapCryptoObject(android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject p2)
    {
        v0 = 0;
        if (p2 != 0) {
            if (p2.getCipher() == 0) {
                if (p2.getSignature() == 0) {
                    if (p2.getMac() != 0) {
                        v0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject(p2.getMac());
                    }
                } else {
                    v0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject(p2.getSignature());
                }
            } else {
                v0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject(p2.getCipher());
            }
        }
        return v0;
    }
    private static android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$AuthenticationCallback wrapCallback(android.support.v4.hardware.fingerprint.FingerprintManagerCompat$AuthenticationCallback p1)
    {
        return new android.support.v4.hardware.fingerprint.FingerprintManagerCompat$Api23FingerprintManagerCompatImpl$1(p1);
    }
    private static android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject wrapCryptoObject(android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject p2)
    {
        v0 = 0;
        if (p2 != 0) {
            if (p2.getCipher() == 0) {
                if (p2.getSignature() == 0) {
                    if (p2.getMac() != 0) {
                        v0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject(p2.getMac());
                    }
                } else {
                    v0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject(p2.getSignature());
                }
            } else {
                v0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject(p2.getCipher());
            }
        }
        return v0;
    }
}
