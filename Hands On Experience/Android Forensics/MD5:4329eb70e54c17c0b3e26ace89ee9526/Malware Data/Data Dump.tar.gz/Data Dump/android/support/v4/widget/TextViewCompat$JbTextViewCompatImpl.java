package android.support.v4.widget;
 class TextViewCompat$JbTextViewCompatImpl extends android.support.v4.widget.TextViewCompat$BaseTextViewCompatImpl {
     TextViewCompat$JbTextViewCompatImpl()
    {
        return;
    }
    public int getMaxLines(android.widget.TextView p2)
    {
        return android.support.v4.widget.TextViewCompatJb.getMaxLines(p2);
    }
    public int getMinLines(android.widget.TextView p2)
    {
        return android.support.v4.widget.TextViewCompatJb.getMinLines(p2);
    }
}
