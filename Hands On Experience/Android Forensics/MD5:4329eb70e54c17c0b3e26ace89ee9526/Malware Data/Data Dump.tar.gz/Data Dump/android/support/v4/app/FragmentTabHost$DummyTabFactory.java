package android.support.v4.app;
 class FragmentTabHost$DummyTabFactory implements android.widget.TabHost$TabContentFactory {
    final private android.content.Context mContext;
    public FragmentTabHost$DummyTabFactory(android.content.Context p1)
    {
        this.mContext = p1;
        return;
    }
    public android.view.View createTabContent(String p4)
    {
        v0 = new android.view.View(this.mContext);
        v0.setMinimumWidth(0);
        v0.setMinimumHeight(0);
        return v0;
    }
}
