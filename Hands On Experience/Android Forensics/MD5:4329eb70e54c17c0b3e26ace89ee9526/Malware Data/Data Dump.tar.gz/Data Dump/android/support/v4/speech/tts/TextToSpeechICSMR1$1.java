package android.support.v4.speech.tts;
final class TextToSpeechICSMR1$1 extends android.speech.tts.UtteranceProgressListener {
    final synthetic android.support.v4.speech.tts.TextToSpeechICSMR1$UtteranceProgressListenerICSMR1 val$listener;
    public void onStart(String p2)
    {
        this.val$listener.onStart(p2);
        return;
    }
     TextToSpeechICSMR1$1(android.support.v4.speech.tts.TextToSpeechICSMR1$UtteranceProgressListenerICSMR1 p1)
    {
        this.val$listener = p1;
        return;
    }
    public void onDone(String p2)
    {
        this.val$listener.onDone(p2);
        return;
    }
    public void onError(String p2)
    {
        this.val$listener.onError(p2);
        return;
    }
}
