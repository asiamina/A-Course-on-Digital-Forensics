package org.json.alipay;
final public class c {
    private int a;
    private char c;
    private java.io.Reader b;
    private boolean d;
    private String a(int p5)
    {
        v0 = 0;
        if (p5 != 0) {
            v1 = new char[p5];
            if (this.d) {
                this.d = 0;
                v1[0] = this.c;
                v0 = 1;
            }
            while (v0 < p5) {
                v2 = this.b.read(v1, v0, (p5 - v0));
                if (v2 == -1) {
                    break;
                }
                v0 += v2;
            }
            this.a = (this.a + v0);
            if (v0 >= p5) {
                this.c = v1[(p5 - 1)];
                v0 = new String(v1);
            } else {
                throw this.a("Substring bounds error");
            }
        } else {
            v0 = "";
        }
        return v0;
    }
    public final org.json.alipay.JSONException a(String p4)
    {
        return new org.json.alipay.JSONException(new StringBuilder().append(p4).append(this.toString()).toString());
    }
    public final void a()
    {
        if ((this.d) && (this.a > 0)) {
            this.a = (this.a - 1);
            this.d = 1;
            return;
        } else {
            throw new org.json.alipay.JSONException("Stepping back two steps is not supported");
        }
    }
    public final char b()
    {
        v0 = 0;
        if (!this.d) {
            v1 = this.b.read();
            if (v1 > 0) {
                this.a = (this.a + 1);
                this.c = ((char) v1);
                v0 = this.c;
            } else {
                this.c = 0;
            }
        } else {
            this.d = 0;
            if (this.c != 0) {
                this.a = (this.a + 1);
            }
            v0 = this.c;
        }
        return v0;
    }
    public final char c()
    {
        v0 = 47;
        do {
            v1 = this.b();
            if (v1 != 47) {
                if (v1 != 35) {
                    if ((v1 != 0) && (v1 <= 32)) {
                        break;
                    }
                    v0 = v1;
                    return v0;
                }
                do {
                    v1 = this.b();
                } while((v1 != 10) && ((v1 != 13) && (v1 != 0)));
            } else {
                switch (this.b()) {
                    case 42:
                    case 47:
                        do {
                            v1 = this.b();
                        } while((v1 != 10) && ((v1 != 13) && (v1 != 0)));
                        break;
                    default:
                        this.a();
                }
                while(true) {
                    v1 = this.b();
                    if (v1 != 0) {
                        if (v1 == 42) {
                            if (this.b() == 47) {
                                break;
                            }
                            this.a();
                        }
                    } else {
                        throw this.a("Unclosed comment");
                    }
                }
            }
        } while((v1 == 10) && ((v1 == 13) && (v1 != 0)));
    }
    public final Object d()
    {
        v2 = this.c();
        switch (v2) {
            case 34:
            case 39:
                v0 = new StringBuffer();
                while(true) {
                    v1 = this.b();
                    switch (v1) {
                        case 0:
                        case 10:
                        case 13:
                            throw this.a("Unterminated string");
                            break;
                        case 92:
                            v1 = this.b();
                            switch (v1) {
                                case 98:
                                    v0.append(8);
                                    break;
                                case 102:
                                    v0.append(12);
                                    break;
                                case 110:
                                    v0.append(10);
                                    break;
                                case 114:
                                    v0.append(13);
                                    break;
                                case 116:
                                    v0.append(9);
                                    break;
                                case 117:
                                    this.a(4);
                                    v0.append(((char) Integer.parseInt(this, 16)));
                                    break;
                                case 120:
                                    this.a(2);
                                    v0.append(((char) Integer.parseInt(this, 16)));
                                    break;
                                default:
                                    v0.append(v1);
                            }
                            break;
                        default:
                            if (v1 == v2) {
                                break;
                            }
                            v0.append(v1);
                    }
                }
                v0 = v0.toString();
                break;
            case 40:
            case 91:
                this.a();
                v0 = new org.json.alipay.a(this);
                break;
            case 123:
                this.a();
                v0 = new org.json.alipay.b(this);
                break;
            default:
                v1 = new StringBuffer();
                v0 = v2;
                while ((v0 >= 32) && (",:]}/\\\"[{;=#".indexOf(v0) < 0)) {
                    v1.append(v0);
                    v0 = this.b();
                }
                this.a();
                v1 = v1.toString().trim();
                if (v1.equals("") == 0) {
                    if (v1.equalsIgnoreCase("true") == 0) {
                        if (v1.equalsIgnoreCase("false") == 0) {
                            if (v1.equalsIgnoreCase("null") == 0) {
                                if (((v2 < 48) || (v2 > 57)) && ((v2 != 46) && ((v2 != 45) && (v2 != 43)))) {
                                    v0 = v1;
                                } else {
                                    if (v2 != 48) {
                                        v0 = new Integer(v1);
                                    } else {
                                        if ((v1.length() <= 2) || ((v1.charAt(1) != 120) && (v1.charAt(1) != 88))) {
                                            v0 = new Integer(Integer.parseInt(v1, 8));
                                        } else {
                                            v0 = new Integer(Integer.parseInt(v1.substring(2), 16));
                                        }
                                    }
                                }
                            } else {
                                v0 = org.json.alipay.b.a;
                            }
                        } else {
                            v0 = Boolean.FALSE;
                        }
                    } else {
                        v0 = Boolean.TRUE;
                    }
                } else {
                    throw this.a("Missing value");
                }
        }
        return v0;
    }
    public final String toString()
    {
        return new StringBuilder(" at character ").append(this.a).toString();
    }
    private c(java.io.Reader p3)
    {
        if (p3.markSupported() == 0) {
            p3 = new java.io.BufferedReader(p3);
        }
        this.b = p3;
        this.d = 0;
        this.a = 0;
        return;
    }
    public c(String p2)
    {
        this(new java.io.StringReader(p2));
        return;
    }
}
