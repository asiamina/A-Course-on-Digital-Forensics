package org.apache.commons.codec.language.bm;
final class Languages$1 extends org.apache.commons.codec.language.bm.Languages$LanguageSet {
    public String toString()
    {
        return "NO_LANGUAGES";
    }
     Languages$1()
    {
        return;
    }
    public boolean contains(String p2)
    {
        return 0;
    }
    public String getAny()
    {
        throw new java.util.NoSuchElementException("Can\'t fetch any language from the empty language set.");
    }
    public boolean isEmpty()
    {
        return 1;
    }
    public boolean isSingleton()
    {
        return 0;
    }
    public org.apache.commons.codec.language.bm.Languages$LanguageSet restrictTo(org.apache.commons.codec.language.bm.Languages$LanguageSet p1)
    {
        return this;
    }
}
