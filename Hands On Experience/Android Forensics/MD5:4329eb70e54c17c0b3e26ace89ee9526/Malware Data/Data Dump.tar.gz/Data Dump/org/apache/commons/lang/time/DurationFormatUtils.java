package org.apache.commons.lang.time;
public class DurationFormatUtils {
    final static Object M;
    final static Object d;
    final static Object H;
    final static Object m;
    final public static String ISO_EXTENDED_FORMAT_PATTERN;
    final static Object s;
    final static Object S;
    final static Object y;
    public static String formatDurationHMS(long p1)
    {
        return org.apache.commons.lang.time.DurationFormatUtils.formatDuration(p1, "H:mm:ss.SSS");
    }
    public static String formatDurationISO(long p2)
    {
        return org.apache.commons.lang.time.DurationFormatUtils.formatDuration(p2, "\'P\'yyyy\'Y\'M\'M\'d\'DT\'H\'H\'m\'M\'s.S\'S\'", 0);
    }
    public static String formatDurationWords(long p4, boolean p6, boolean p7)
    {
        v0 = org.apache.commons.lang.time.DurationFormatUtils.formatDuration(p4, "d\' days \'H\' hours \'m\' minutes \'s\' seconds\'");
        if (p6 != 0) {
            v0 = new StringBuffer().append(" ").append(v0).toString();
            v1 = org.apache.commons.lang.StringUtils.replaceOnce(v0, " 0 days", "");
            if (v1.length() != v0.length()) {
                v0 = v1;
                v1 = org.apache.commons.lang.StringUtils.replaceOnce(v0, " 0 hours", "");
                if (v1.length() != v0.length()) {
                    v1 = org.apache.commons.lang.StringUtils.replaceOnce(v1, " 0 minutes", "");
                    v0 = v1;
                    if (v1.length() != v0.length()) {
                        v0 = org.apache.commons.lang.StringUtils.replaceOnce(v1, " 0 seconds", "");
                    }
                }
            }
            if (v0.length() != 0) {
                v0 = v0.substring(1);
            }
        }
        if (p7 != 0) {
            v1 = org.apache.commons.lang.StringUtils.replaceOnce(v0, " 0 seconds", "");
            if (v1.length() != v0.length()) {
                v0 = v1;
                v1 = org.apache.commons.lang.StringUtils.replaceOnce(v0, " 0 minutes", "");
                if (v1.length() != v0.length()) {
                    v0 = v1;
                    v1 = org.apache.commons.lang.StringUtils.replaceOnce(v0, " 0 hours", "");
                    if (v1.length() != v0.length()) {
                        v0 = org.apache.commons.lang.StringUtils.replaceOnce(v1, " 0 days", "");
                    }
                }
            }
        }
        return org.apache.commons.lang.StringUtils.replaceOnce(org.apache.commons.lang.StringUtils.replaceOnce(org.apache.commons.lang.StringUtils.replaceOnce(org.apache.commons.lang.StringUtils.replaceOnce(new StringBuffer().append(" ").append(v0).toString(), " 1 seconds", " 1 second"), " 1 minutes", " 1 minute"), " 1 hours", " 1 hour"), " 1 days", " 1 day").trim();
    }
    public static String formatPeriod(long p7, long p9, String p11)
    {
        return org.apache.commons.lang.time.DurationFormatUtils.formatPeriod(p7, v1, p9, v3, p11, 1, java.util.TimeZone.getDefault());
    }
    public static String formatPeriod(long p17, long p19, String p21, boolean p22, java.util.TimeZone p23)
    {
        v12 = (p19 - p17);
        if (v12 >= 1.1952436104e-314) {
            v2 = org.apache.commons.lang.time.DurationFormatUtils.lexx(p21);
            v14 = java.util.Calendar.getInstance(p23);
            v14.setTime(new java.util.Date(p17));
            v11 = java.util.Calendar.getInstance(p23);
            v11.setTime(new java.util.Date(p19));
            v9 = (v11.get(14) - v14.get(14));
            v8 = (v11.get(13) - v14.get(13));
            v7 = (v11.get(12) - v14.get(12));
            v6 = (v11.get(11) - v14.get(11));
            v5 = (v11.get(5) - v14.get(5));
            v4 = (v11.get(2) - v14.get(2));
            v3 = (v11.get(1) - v14.get(1));
            while (v9 < 0) {
                v9 += 1000;
                v8--;
            }
            while (v8 < 0) {
                v8 += 60;
                v7--;
            }
            while (v7 < 0) {
                v7 += 60;
                v6--;
            }
            while (v6 < 0) {
                v6 += 24;
                v5--;
            }
            while (v5 < 0) {
                v5 += 31;
                v4--;
            }
            while (v4 < 0) {
                v4 += 12;
                v3--;
            }
            v9 -= org.apache.commons.lang.time.DurationFormatUtils.reduceAndCorrect(v14, v11, 14, v9);
            v8 -= org.apache.commons.lang.time.DurationFormatUtils.reduceAndCorrect(v14, v11, 13, v8);
            v7 -= org.apache.commons.lang.time.DurationFormatUtils.reduceAndCorrect(v14, v11, 12, v7);
            v6 -= org.apache.commons.lang.time.DurationFormatUtils.reduceAndCorrect(v14, v11, 11, v6);
            v5 -= org.apache.commons.lang.time.DurationFormatUtils.reduceAndCorrect(v14, v11, 5, v5);
            v4 -= org.apache.commons.lang.time.DurationFormatUtils.reduceAndCorrect(v14, v11, 2, v4);
            v3 -= org.apache.commons.lang.time.DurationFormatUtils.reduceAndCorrect(v14, v11, 1, v3);
            if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v2, org.apache.commons.lang.time.DurationFormatUtils.y) == 0) {
                if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v2, org.apache.commons.lang.time.DurationFormatUtils.M) == 0) {
                    v5 += (v3 * 365);
                    v3 = 0;
                } else {
                    v4 += (v3 * 12);
                    v3 = 0;
                }
            }
            if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v2, org.apache.commons.lang.time.DurationFormatUtils.M) == 0) {
                v5 += (v11.get(6) - v14.get(6));
                v4 = 0;
            }
            if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v2, org.apache.commons.lang.time.DurationFormatUtils.d) == 0) {
                v6 += (v5 * 24);
                v5 = 0;
            }
            if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v2, org.apache.commons.lang.time.DurationFormatUtils.H) == 0) {
                v7 += (v6 * 60);
                v6 = 0;
            }
            if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v2, org.apache.commons.lang.time.DurationFormatUtils.m) == 0) {
                v8 += (v7 * 60);
                v7 = 0;
            }
            if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v2, org.apache.commons.lang.time.DurationFormatUtils.s) == 0) {
                v9 += (v8 * 1000);
                v8 = 0;
            }
            v10 = org.apache.commons.lang.time.DurationFormatUtils.format(v2, v3, v4, v5, v6, v7, v8, v9, p22);
        } else {
            v10 = org.apache.commons.lang.time.DurationFormatUtils.formatDuration(v12, p21, p22);
        }
        return v10;
    }
    public static String formatPeriodISO(long p7, long p9)
    {
        return org.apache.commons.lang.time.DurationFormatUtils.formatPeriod(p7, v1, p9, v3, "\'P\'yyyy\'Y\'M\'M\'d\'DT\'H\'H\'m\'M\'s.S\'S\'", 0, java.util.TimeZone.getDefault());
    }
    static org.apache.commons.lang.time.DurationFormatUtils$Token[] lexx(String p11)
    {
        v0 = p11.toCharArray();
        v5 = new java.util.ArrayList(v0.length);
        v4 = 0;
        v1 = 0;
        v6 = 0;
        v7 = v0.length;
        v3 = 0;
        while (v3 < v7) {
            v2 = v0[v3];
            if ((v4 == 0) || (v2 == 39)) {
                v9 = 0;
                switch (v2) {
                    case 39:
                        if (v4 == 0) {
                            v1 = new StringBuffer();
                            v5.add(new org.apache.commons.lang.time.DurationFormatUtils$Token(v1));
                            v4 = 1;
                        } else {
                            v1 = 0;
                            v4 = 0;
                        }
                        break;
                    case 72:
                        v9 = org.apache.commons.lang.time.DurationFormatUtils.H;
                        break;
                    case 77:
                        v9 = org.apache.commons.lang.time.DurationFormatUtils.M;
                        break;
                    case 83:
                        v9 = org.apache.commons.lang.time.DurationFormatUtils.S;
                        break;
                    case 100:
                        v9 = org.apache.commons.lang.time.DurationFormatUtils.d;
                        break;
                    case 109:
                        v9 = org.apache.commons.lang.time.DurationFormatUtils.m;
                        break;
                    case 115:
                        v9 = org.apache.commons.lang.time.DurationFormatUtils.s;
                        break;
                    case 121:
                        v9 = org.apache.commons.lang.time.DurationFormatUtils.y;
                        break;
                    default:
                        if (v1 == 0) {
                            v1 = new StringBuffer();
                            v5.add(new org.apache.commons.lang.time.DurationFormatUtils$Token(v1));
                        }
                        v1.append(v2);
                }
                if (v9 != 0) {
                    if ((v6 == 0) || (v6.getValue() != v9)) {
                        v8 = new org.apache.commons.lang.time.DurationFormatUtils$Token(v9);
                        v5.add(v8);
                        v6 = v8;
                    } else {
                        v6.increment();
                    }
                    v1 = 0;
                }
            } else {
                v1.append(v2);
            }
            v3++;
        }
        v10 = new org.apache.commons.lang.time.DurationFormatUtils$Token[0];
        return v5.toArray(v10);
    }
    static int reduceAndCorrect(java.util.Calendar p4, java.util.Calendar p5, int p6, int p7)
    {
        p5.add(p6, (p7 * -1));
        v0 = p5.get(p6);
        v2 = p4.get(p6);
        if (v0 >= v2) {
            v1 = 0;
        } else {
            v1 = (v2 - v0);
            p5.add(p6, v1);
        }
        return v1;
    }
    static DurationFormatUtils()
    {
        org.apache.commons.lang.time.DurationFormatUtils.y = "y";
        org.apache.commons.lang.time.DurationFormatUtils.M = "M";
        org.apache.commons.lang.time.DurationFormatUtils.d = "d";
        org.apache.commons.lang.time.DurationFormatUtils.H = "H";
        org.apache.commons.lang.time.DurationFormatUtils.m = "m";
        org.apache.commons.lang.time.DurationFormatUtils.s = "s";
        org.apache.commons.lang.time.DurationFormatUtils.S = "S";
        return;
    }
    public DurationFormatUtils()
    {
        return;
    }
    static String format(org.apache.commons.lang.time.DurationFormatUtils$Token[] p11, int p12, int p13, int p14, int p15, int p16, int p17, int p18, boolean p19)
    {
        v1 = new StringBuffer();
        v4 = 0;
        v6 = p11.length;
        v3 = 0;
        while (v3 < v6) {
            v7 = p11[v3];
            v8 = v7.getValue();
            v2 = v7.getCount();
            if ((v8 instanceof StringBuffer) == 0) {
                if (v8 != org.apache.commons.lang.time.DurationFormatUtils.y) {
                    if (v8 != org.apache.commons.lang.time.DurationFormatUtils.M) {
                        if (v8 != org.apache.commons.lang.time.DurationFormatUtils.d) {
                            if (v8 != org.apache.commons.lang.time.DurationFormatUtils.H) {
                                if (v8 != org.apache.commons.lang.time.DurationFormatUtils.m) {
                                    if (v8 != org.apache.commons.lang.time.DurationFormatUtils.s) {
                                        if (v8 == org.apache.commons.lang.time.DurationFormatUtils.S) {
                                            if (v4 == 0) {
                                                if (p19 == 0) {
                                                    v9 = Integer.toString(p18);
                                                } else {
                                                    v9 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p18), v2, 48);
                                                }
                                                v1.append(v9);
                                            } else {
                                                p18 += 1000;
                                                if (p19 == 0) {
                                                    v5 = Integer.toString(p18);
                                                } else {
                                                    v5 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p18), v2, 48);
                                                }
                                                v1.append(v5.substring(1));
                                            }
                                            v4 = 0;
                                        }
                                    } else {
                                        if (p19 == 0) {
                                            v9 = Integer.toString(p17);
                                        } else {
                                            v9 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p17), v2, 48);
                                        }
                                        v1.append(v9);
                                        v4 = 1;
                                    }
                                } else {
                                    if (p19 == 0) {
                                        v9 = Integer.toString(p16);
                                    } else {
                                        v9 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p16), v2, 48);
                                    }
                                    v1.append(v9);
                                    v4 = 0;
                                }
                            } else {
                                if (p19 == 0) {
                                    v9 = Integer.toString(p15);
                                } else {
                                    v9 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p15), v2, 48);
                                }
                                v1.append(v9);
                                v4 = 0;
                            }
                        } else {
                            if (p19 == 0) {
                                v9 = Integer.toString(p14);
                            } else {
                                v9 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p14), v2, 48);
                            }
                            v1.append(v9);
                            v4 = 0;
                        }
                    } else {
                        if (p19 == 0) {
                            v9 = Integer.toString(p13);
                        } else {
                            v9 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p13), v2, 48);
                        }
                        v1.append(v9);
                        v4 = 0;
                    }
                } else {
                    if (p19 == 0) {
                        v9 = Integer.toString(p12);
                    } else {
                        v9 = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(p12), v2, 48);
                    }
                    v1.append(v9);
                    v4 = 0;
                }
            } else {
                v1.append(v8.toString());
            }
            v3++;
        }
        return v1.toString();
    }
    public static String formatDuration(long p1, String p3)
    {
        return org.apache.commons.lang.time.DurationFormatUtils.formatDuration(p1, p3, 1);
    }
    public static String formatDuration(long p10, String p12, boolean p13)
    {
        v0 = org.apache.commons.lang.time.DurationFormatUtils.lexx(p12);
        v3 = 0;
        v4 = 0;
        v5 = 0;
        v6 = 0;
        v7 = 0;
        if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v0, org.apache.commons.lang.time.DurationFormatUtils.d) != 0) {
            v3 = ((int) (p10 / 86400000.0));
            p10 -= (((long) v3) * 86400000.0);
        }
        if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v0, org.apache.commons.lang.time.DurationFormatUtils.H) != 0) {
            v4 = ((int) (p10 / 3600000.0));
            p10 -= (((long) v4) * 3600000.0);
        }
        if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v0, org.apache.commons.lang.time.DurationFormatUtils.m) != 0) {
            v5 = ((int) (p10 / 60000.0));
            p10 -= (((long) v5) * 60000.0);
        }
        if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v0, org.apache.commons.lang.time.DurationFormatUtils.s) != 0) {
            v6 = ((int) (p10 / 1000.0));
            p10 -= (((long) v6) * 1000.0);
        }
        if (org.apache.commons.lang.time.DurationFormatUtils$Token.containsTokenWithValue(v0, org.apache.commons.lang.time.DurationFormatUtils.S) != 0) {
            v7 = ((int) p10);
        }
        return org.apache.commons.lang.time.DurationFormatUtils.format(v0, 0, 0, v3, v4, v5, v6, v7, p13);
    }
}
