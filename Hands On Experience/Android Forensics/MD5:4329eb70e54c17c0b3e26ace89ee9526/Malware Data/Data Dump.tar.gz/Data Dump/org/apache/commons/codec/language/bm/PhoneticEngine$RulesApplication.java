package org.apache.commons.codec.language.bm;
final class PhoneticEngine$RulesApplication {
    private int i;
    private boolean found;
    private org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder phonemeBuilder;
    final private CharSequence input;
    final private java.util.List finalRules;
    public PhoneticEngine$RulesApplication(java.util.List p3, CharSequence p4, org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder p5, int p6)
    {
        if (p3 != 0) {
            this.finalRules = p3;
            this.phonemeBuilder = p5;
            this.input = p4;
            this.i = p6;
            return;
        } else {
            throw new NullPointerException("The finalRules argument must not be null");
        }
    }
    public int getI()
    {
        return this.i;
    }
    public org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder getPhonemeBuilder()
    {
        return this.phonemeBuilder;
    }
    public org.apache.commons.codec.language.bm.PhoneticEngine$RulesApplication invoke()
    {
        this.found = 0;
        v2 = 0;
        v0 = this.finalRules.iterator();
        while (v0.hasNext() != 0) {
            v3 = v0.next();
            v2 = v3.getPattern().length();
            if (v3.patternAndContextMatches(this.input, this.i) != 0) {
                this.phonemeBuilder = this.phonemeBuilder.apply(v3.getPhoneme());
                this.found = 1;
                break;
            }
        }
        if (this.found) {
            v2 = 1;
        }
        this.i = (this.i + v2);
        return this;
    }
    public boolean isFound()
    {
        return this.found;
    }
}
