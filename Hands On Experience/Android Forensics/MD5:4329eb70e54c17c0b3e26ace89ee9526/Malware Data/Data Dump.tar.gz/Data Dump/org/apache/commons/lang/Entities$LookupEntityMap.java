package org.apache.commons.lang;
 class Entities$LookupEntityMap extends org.apache.commons.lang.Entities$PrimitiveEntityMap {
    private int LOOKUP_TABLE_SIZE;
    private String[] lookupTable;
    private void createLookupTable()
    {
        v1 = new String[this.LOOKUP_TABLE_SIZE];
        this.lookupTable = v1;
        v0 = 0;
        while (v0 < this.LOOKUP_TABLE_SIZE) {
            this.lookupTable[v0] = super.name(v0);
            v0++;
        }
        return;
    }
    private String[] lookupTable()
    {
        if (this.lookupTable == 0) {
            this.createLookupTable();
        }
        return this.lookupTable;
    }
    public String name(int p2)
    {
        if (p2 >= this.LOOKUP_TABLE_SIZE) {
            v0 = super.name(p2);
        } else {
            this.lookupTable();
            v0 = this[p2];
        }
        return v0;
    }
     Entities$LookupEntityMap()
    {
        this.LOOKUP_TABLE_SIZE = 256;
        return;
    }
}
