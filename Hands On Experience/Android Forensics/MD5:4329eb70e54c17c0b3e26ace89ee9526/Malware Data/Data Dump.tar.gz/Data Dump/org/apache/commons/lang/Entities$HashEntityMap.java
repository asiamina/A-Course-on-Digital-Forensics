package org.apache.commons.lang;
 class Entities$HashEntityMap extends org.apache.commons.lang.Entities$MapIntMap {
    public Entities$HashEntityMap()
    {
        this.mapNameToValue = new java.util.HashMap();
        this.mapValueToName = new java.util.HashMap();
        return;
    }
}
