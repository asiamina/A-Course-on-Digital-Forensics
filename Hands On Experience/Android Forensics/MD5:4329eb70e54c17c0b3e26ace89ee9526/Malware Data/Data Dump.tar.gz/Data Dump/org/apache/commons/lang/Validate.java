package org.apache.commons.lang;
public class Validate {
    public Validate()
    {
        return;
    }
    public static void allElementsOfType(java.util.Collection p5, Class p6)
    {
        org.apache.commons.lang.Validate.notNull(p5);
        org.apache.commons.lang.Validate.notNull(p6);
        v0 = 0;
        v1 = p5.iterator();
        while (v1.hasNext() != 0) {
            if (p6.isInstance(v1.next()) != 0) {
                v0++;
            } else {
                throw new IllegalArgumentException(new StringBuffer().append("The validated collection contains an element not of type ").append(p6.getName()).append(" at index: ").append(v0).toString());
            }
        }
        return;
    }
    public static void allElementsOfType(java.util.Collection p2, Class p3, String p4)
    {
        org.apache.commons.lang.Validate.notNull(p2);
        org.apache.commons.lang.Validate.notNull(p3);
        v0 = p2.iterator();
        while (v0.hasNext() != 0) {
            if (p3.isInstance(v0.next()) == 0) {
                throw new IllegalArgumentException(p4);
            }
        }
        return;
    }
    public static void isTrue(boolean p2)
    {
        if (p2 != 0) {
            return;
        } else {
            throw new IllegalArgumentException("The validated expression is false");
        }
    }
    public static void isTrue(boolean p1, String p2)
    {
        if (p1 != 0) {
            return;
        } else {
            throw new IllegalArgumentException(p2);
        }
    }
    public static void isTrue(boolean p2, String p3, double p4)
    {
        if (p2 != 0) {
            return;
        } else {
            throw new IllegalArgumentException(new StringBuffer().append(p3).append(p4).toString());
        }
    }
    public static void isTrue(boolean p2, String p3, long p4)
    {
        if (p2 != 0) {
            return;
        } else {
            throw new IllegalArgumentException(new StringBuffer().append(p3).append(p4).toString());
        }
    }
    public static void isTrue(boolean p2, String p3, Object p4)
    {
        if (p2 != 0) {
            return;
        } else {
            throw new IllegalArgumentException(new StringBuffer().append(p3).append(p4).toString());
        }
    }
    public static void noNullElements(java.util.Collection p5)
    {
        org.apache.commons.lang.Validate.notNull(p5);
        v0 = 0;
        v1 = p5.iterator();
        while (v1.hasNext() != 0) {
            if (v1.next() != 0) {
                v0++;
            } else {
                throw new IllegalArgumentException(new StringBuffer().append("The validated collection contains null element at index: ").append(v0).toString());
            }
        }
        return;
    }
    public static void noNullElements(java.util.Collection p2, String p3)
    {
        org.apache.commons.lang.Validate.notNull(p2);
        v0 = p2.iterator();
        while (v0.hasNext() != 0) {
            if (v0.next() == 0) {
                throw new IllegalArgumentException(p3);
            }
        }
        return;
    }
    public static void noNullElements(Object[] p4)
    {
        org.apache.commons.lang.Validate.notNull(p4);
        v0 = 0;
        while (v0 < p4.length) {
            if (p4[v0] != 0) {
                v0++;
            } else {
                throw new IllegalArgumentException(new StringBuffer().append("The validated array contains null element at index: ").append(v0).toString());
            }
        }
        return;
    }
    public static void noNullElements(Object[] p2, String p3)
    {
        org.apache.commons.lang.Validate.notNull(p2);
        v0 = 0;
        while (v0 < p2.length) {
            if (p2[v0] != 0) {
                v0++;
            } else {
                throw new IllegalArgumentException(p3);
            }
        }
        return;
    }
    public static void notEmpty(String p2)
    {
        if ((p2 != 0) && (p2.length() != 0)) {
            return;
        } else {
            throw new IllegalArgumentException("The validated string is empty");
        }
    }
    public static void notEmpty(String p1, String p2)
    {
        if ((p1 != 0) && (p1.length() != 0)) {
            return;
        } else {
            throw new IllegalArgumentException(p2);
        }
    }
    public static void notEmpty(java.util.Collection p2)
    {
        if ((p2 != 0) && (p2.size() != 0)) {
            return;
        } else {
            throw new IllegalArgumentException("The validated collection is empty");
        }
    }
    public static void notEmpty(java.util.Collection p1, String p2)
    {
        if ((p1 != 0) && (p1.size() != 0)) {
            return;
        } else {
            throw new IllegalArgumentException(p2);
        }
    }
    public static void notEmpty(java.util.Map p2)
    {
        if ((p2 != 0) && (p2.size() != 0)) {
            return;
        } else {
            throw new IllegalArgumentException("The validated map is empty");
        }
    }
    public static void notEmpty(java.util.Map p1, String p2)
    {
        if ((p1 != 0) && (p1.size() != 0)) {
            return;
        } else {
            throw new IllegalArgumentException(p2);
        }
    }
    public static void notEmpty(Object[] p2)
    {
        if ((p2 != 0) && (p2.length != 0)) {
            return;
        } else {
            throw new IllegalArgumentException("The validated array is empty");
        }
    }
    public static void notEmpty(Object[] p1, String p2)
    {
        if ((p1 != 0) && (p1.length != 0)) {
            return;
        } else {
            throw new IllegalArgumentException(p2);
        }
    }
    public static void notNull(Object p2)
    {
        if (p2 != 0) {
            return;
        } else {
            throw new IllegalArgumentException("The validated object is null");
        }
    }
    public static void notNull(Object p1, String p2)
    {
        if (p1 != 0) {
            return;
        } else {
            throw new IllegalArgumentException(p2);
        }
    }
}
