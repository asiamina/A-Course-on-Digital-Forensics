package org.apache.commons.lang.builder;
public class CompareToBuilder {
    private int comparison;
    public CompareToBuilder()
    {
        this.comparison = 0;
        return;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(byte p2, byte p3)
    {
        if (this.comparison == 0) {
            if (p2 >= p3) {
                if (p2 <= p3) {
                    v0 = 0;
                } else {
                    v0 = 1;
                }
            } else {
                v0 = -1;
            }
            this.comparison = v0;
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(char p2, char p3)
    {
        if (this.comparison == 0) {
            if (p2 >= p3) {
                if (p2 <= p3) {
                    v0 = 0;
                } else {
                    v0 = 1;
                }
            } else {
                v0 = -1;
            }
            this.comparison = v0;
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(double p2, double p4)
    {
        if (this.comparison == 0) {
            this.comparison = org.apache.commons.lang.math.NumberUtils.compare(p2, p4);
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(float p2, float p3)
    {
        if (this.comparison == 0) {
            this.comparison = org.apache.commons.lang.math.NumberUtils.compare(p2, p3);
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(int p2, int p3)
    {
        if (this.comparison == 0) {
            if (p2 >= p3) {
                if (p2 <= p3) {
                    v0 = 0;
                } else {
                    v0 = 1;
                }
            } else {
                v0 = -1;
            }
            this.comparison = v0;
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(long p2, long p4)
    {
        if (this.comparison == 0) {
            if (p2 >= p4) {
                if (p2 <= p4) {
                    v0 = 0;
                } else {
                    v0 = 1;
                }
            } else {
                v0 = -1;
            }
            this.comparison = v0;
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(Object p2, Object p3)
    {
        return this.append(p2, p3, 0);
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(Object p2, Object p3, java.util.Comparator p4)
    {
        if ((this.comparison == 0) && (p2 != p3)) {
            if (p2 != 0) {
                if (p3 != 0) {
                    if (p2.getClass().isArray() == 0) {
                        if (p4 != 0) {
                            this.comparison = p4.compare(p2, p3);
                        } else {
                            this.comparison = p2.compareTo(p3);
                        }
                    } else {
                        if ((p2 instanceof long[]) == 0) {
                            if ((p2 instanceof int[]) == 0) {
                                if ((p2 instanceof short[]) == 0) {
                                    if ((p2 instanceof char[]) == 0) {
                                        if ((p2 instanceof byte[]) == 0) {
                                            if ((p2 instanceof double[]) == 0) {
                                                if ((p2 instanceof float[]) == 0) {
                                                    if ((p2 instanceof boolean[]) == 0) {
                                                        this.append(p2, p3, p4);
                                                    } else {
                                                        this.append(p2, p3);
                                                    }
                                                } else {
                                                    this.append(p2, p3);
                                                }
                                            } else {
                                                this.append(p2, p3);
                                            }
                                        } else {
                                            this.append(p2, p3);
                                        }
                                    } else {
                                        this.append(p2, p3);
                                    }
                                } else {
                                    this.append(p2, p3);
                                }
                            } else {
                                this.append(p2, p3);
                            }
                        } else {
                            this.append(p2, p3);
                        }
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(short p2, short p3)
    {
        if (this.comparison == 0) {
            if (p2 >= p3) {
                if (p2 <= p3) {
                    v0 = 0;
                } else {
                    v0 = 1;
                }
            } else {
                v0 = -1;
            }
            this.comparison = v0;
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(boolean p2, boolean p3)
    {
        if ((this.comparison == 0) && (p2 != p3)) {
            if (p2 != 0) {
                this.comparison = 1;
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(byte[] p6, byte[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(char[] p6, char[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(double[] p6, double[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(float[] p6, float[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(int[] p6, int[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(long[] p6, long[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(Object[] p2, Object[] p3)
    {
        return this.append(p2, p3, 0);
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(Object[] p6, Object[] p7, java.util.Comparator p8)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0], p8);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(short[] p6, short[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder append(boolean[] p6, boolean[] p7)
    {
        v1 = -1;
        if ((this.comparison == 0) && (p6 != p7)) {
            if (p6 != 0) {
                if (p7 != 0) {
                    if (p6.length == p7.length) {
                        v0 = 0;
                        while ((v0 < p6.length) && (this.comparison == 0)) {
                            this.append(p6[v0], p7[v0]);
                            v0++;
                        }
                    } else {
                        if (p6.length >= p7.length) {
                            v1 = 1;
                        }
                        this.comparison = v1;
                    }
                } else {
                    this.comparison = 1;
                }
            } else {
                this.comparison = -1;
            }
        }
        return this;
    }
    public org.apache.commons.lang.builder.CompareToBuilder appendSuper(int p2)
    {
        if (this.comparison == 0) {
            this.comparison = p2;
        }
        return this;
    }
    private static void reflectionAppend(Object p7, Object p8, Class p9, org.apache.commons.lang.builder.CompareToBuilder p10, boolean p11, String[] p12)
    {
        v3 = p9.getDeclaredFields();
        if (p12 == 0) {
            v1 = java.util.Collections.EMPTY_LIST;
        } else {
            v1 = java.util.Arrays.asList(p12);
        }
        reflect.AccessibleObject.setAccessible(v3, 1);
        v4 = 0;
        while ((v4 < v3.length) && (p10.comparison == 0)) {
            v2 = v3[v4];
            if (((v1.contains(v2.getName()) == 0) && ((v2.getName().indexOf(36) == -1) && ((p11 != 0) || (reflect.Modifier.isTransient(v2.getModifiers()) == 0)))) && (reflect.Modifier.isStatic(v2.getModifiers()) == 0)) {
                p10.append(v2.get(p7), v2.get(p8));
            }
            v4++;
        }
        return;
    }
    public static int reflectionCompare(Object p2, Object p3)
    {
        return org.apache.commons.lang.builder.CompareToBuilder.reflectionCompare(p2, p3, 0, 0, 0);
    }
    public static int reflectionCompare(Object p1, Object p2, java.util.Collection p3)
    {
        return org.apache.commons.lang.builder.CompareToBuilder.reflectionCompare(p1, p2, org.apache.commons.lang.builder.ReflectionToStringBuilder.toNoNullStringArray(p3));
    }
    public static int reflectionCompare(Object p1, Object p2, boolean p3)
    {
        return org.apache.commons.lang.builder.CompareToBuilder.reflectionCompare(p1, p2, p3, 0, 0);
    }
    public static int reflectionCompare(Object p2, Object p3, boolean p4, Class p5)
    {
        return org.apache.commons.lang.builder.CompareToBuilder.reflectionCompare(p2, p3, 0, p5, 0);
    }
    public static int reflectionCompare(Object p6, Object p7, boolean p8, Class p9, String[] p10)
    {
        if (p6 != p7) {
            if ((p6 != 0) && (p7 != 0)) {
                v2 = p6.getClass();
                if (v2.isInstance(p7) != 0) {
                    v3 = new org.apache.commons.lang.builder.CompareToBuilder();
                    org.apache.commons.lang.builder.CompareToBuilder.reflectionAppend(p6, p7, v2, v3, p8, p10);
                    while ((v2.getSuperclass() != 0) && (v2 != p9)) {
                        v2 = v2.getSuperclass();
                        org.apache.commons.lang.builder.CompareToBuilder.reflectionAppend(p6, p7, v2, v3, p8, p10);
                    }
                    v0 = v3.toComparison();
                } else {
                    throw new ClassCastException();
                }
            } else {
                throw new NullPointerException();
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
    public static int reflectionCompare(Object p2, Object p3, String[] p4)
    {
        return org.apache.commons.lang.builder.CompareToBuilder.reflectionCompare(p2, p3, 0, 0, p4);
    }
    public int toComparison()
    {
        return this.comparison;
    }
}
