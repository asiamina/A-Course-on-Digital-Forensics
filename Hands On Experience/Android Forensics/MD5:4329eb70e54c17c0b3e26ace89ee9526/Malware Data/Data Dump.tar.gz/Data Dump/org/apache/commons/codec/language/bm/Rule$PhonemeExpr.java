package org.apache.commons.codec.language.bm;
public interface abstract class Rule$PhonemeExpr {
    abstract public Iterable getPhonemes();
}
