package org.apache.commons.lang.math;
final public class FloatRange extends org.apache.commons.lang.math.Range implements java.io.Serializable {
    private transient Float maxObject;
    final private float min;
    final private float max;
    private transient int hashCode;
    private transient Float minObject;
    private transient String toString;
    final private static long serialVersionUID;
    public long getMinimumLong()
    {
        return ((long) this.min);
    }
    public Number getMinimumNumber()
    {
        if (this.minObject == 0) {
            this.minObject = new Float(this.min);
        }
        return this.minObject;
    }
    public int hashCode()
    {
        if (this.hashCode == 0) {
            this.hashCode = 17;
            this.hashCode = ((this.hashCode * 37) + this.getClass().hashCode());
            this.hashCode = ((this.hashCode * 37) + Float.floatToIntBits(this.min));
            this.hashCode = ((this.hashCode * 37) + Float.floatToIntBits(this.max));
        }
        return this.hashCode;
    }
    public boolean overlapsRange(org.apache.commons.lang.math.Range p3)
    {
        v0 = 0;
        if ((p3 != 0) && ((p3.containsFloat(this.min) != 0) || ((p3.containsFloat(this.max) != 0) || (this.containsFloat(p3.getMinimumFloat()) != 0)))) {
            v0 = 1;
        }
        return v0;
    }
    public String toString()
    {
        if (this.toString == 0) {
            v0 = new StringBuffer(32);
            v0.append("Range[");
            v0.append(this.min);
            v0.append(44);
            v0.append(this.max);
            v0.append(93);
            this.toString = v0.toString();
        }
        return this.toString;
    }
    public FloatRange(float p3)
    {
        this.minObject = 0;
        this.maxObject = 0;
        this.hashCode = 0;
        this.toString = 0;
        if (Float.isNaN(p3) == 0) {
            this.min = p3;
            this.max = p3;
            return;
        } else {
            throw new IllegalArgumentException("The number must not be NaN");
        }
    }
    public FloatRange(float p3, float p4)
    {
        this.minObject = 0;
        this.maxObject = 0;
        this.hashCode = 0;
        this.toString = 0;
        if ((Float.isNaN(p3) == 0) && (Float.isNaN(p4) == 0)) {
            if (p4 >= p3) {
                this.min = p3;
                this.max = p4;
            } else {
                this.min = p4;
                this.max = p3;
            }
            return;
        } else {
            throw new IllegalArgumentException("The numbers must not be NaN");
        }
    }
    public FloatRange(Number p3)
    {
        this.minObject = 0;
        this.maxObject = 0;
        this.hashCode = 0;
        this.toString = 0;
        if (p3 != 0) {
            this.min = p3.floatValue();
            this.max = p3.floatValue();
            if ((Float.isNaN(this.min) == 0) && (Float.isNaN(this.max) == 0)) {
                if ((p3 instanceof Float) != 0) {
                    this.minObject = p3;
                    this.maxObject = p3;
                }
                return;
            } else {
                throw new IllegalArgumentException("The number must not be NaN");
            }
        } else {
            throw new IllegalArgumentException("The number must not be null");
        }
    }
    public FloatRange(Number p5, Number p6)
    {
        this.minObject = 0;
        this.maxObject = 0;
        this.hashCode = 0;
        this.toString = 0;
        if ((p5 != 0) && (p6 != 0)) {
            v0 = p5.floatValue();
            v1 = p6.floatValue();
            if ((Float.isNaN(v0) == 0) && (Float.isNaN(v1) == 0)) {
                if (v1 >= v0) {
                    this.min = v0;
                    this.max = v1;
                    if ((p5 instanceof Float) != 0) {
                        this.minObject = p5;
                    }
                    if ((p6 instanceof Float) != 0) {
                        this.maxObject = p6;
                    }
                } else {
                    this.min = v1;
                    this.max = v0;
                    if ((p6 instanceof Float) != 0) {
                        this.minObject = p6;
                    }
                    if ((p5 instanceof Float) != 0) {
                        this.maxObject = p5;
                    }
                }
                return;
            } else {
                throw new IllegalArgumentException("The numbers must not be NaN");
            }
        } else {
            throw new IllegalArgumentException("The numbers must not be null");
        }
    }
    public boolean containsFloat(float p2)
    {
        if ((p2 < this.min) || (p2 > this.max)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public boolean containsNumber(Number p2)
    {
        if (p2 != 0) {
            v0 = this.containsFloat(p2.floatValue());
        } else {
            v0 = 0;
        }
        return v0;
    }
    public boolean containsRange(org.apache.commons.lang.math.Range p3)
    {
        v0 = 0;
        if ((p3 != 0) && ((this.containsFloat(p3.getMinimumFloat()) != 0) && (this.containsFloat(p3.getMaximumFloat()) != 0))) {
            v0 = 1;
        }
        return v0;
    }
    public boolean equals(Object p6)
    {
        v1 = 1;
        if (p6 != this) {
            if ((p6 instanceof org.apache.commons.lang.math.FloatRange) != 0) {
                v0 = p6;
                if ((Float.floatToIntBits(this.min) != Float.floatToIntBits(v0.min)) || (Float.floatToIntBits(this.max) != Float.floatToIntBits(v0.max))) {
                    v1 = 0;
                }
            } else {
                v1 = 0;
            }
        }
        return v1;
    }
    public double getMaximumDouble()
    {
        return ((double) this.max);
    }
    public float getMaximumFloat()
    {
        return this.max;
    }
    public int getMaximumInteger()
    {
        return ((int) this.max);
    }
    public long getMaximumLong()
    {
        return ((long) this.max);
    }
    public Number getMaximumNumber()
    {
        if (this.maxObject == 0) {
            this.maxObject = new Float(this.max);
        }
        return this.maxObject;
    }
    public double getMinimumDouble()
    {
        return ((double) this.min);
    }
    public float getMinimumFloat()
    {
        return this.min;
    }
    public int getMinimumInteger()
    {
        return ((int) this.min);
    }
}
