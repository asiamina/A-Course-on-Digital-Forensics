package org.apache.commons.codec.language.bm;
final public enum class RuleType extends java.lang.Enum {
    final public static enum org.apache.commons.codec.language.bm.RuleType RULES;
    final private synthetic static org.apache.commons.codec.language.bm.RuleType[] $VALUES;
    final public static enum org.apache.commons.codec.language.bm.RuleType APPROX;
    final public static enum org.apache.commons.codec.language.bm.RuleType EXACT;
    final private String name;
    public String getName()
    {
        return this.name;
    }
    public static org.apache.commons.codec.language.bm.RuleType valueOf(String p1)
    {
        return Enum.valueOf(org.apache.commons.codec.language.bm.RuleType, p1);
    }
    public static org.apache.commons.codec.language.bm.RuleType[] values()
    {
        return org.apache.commons.codec.language.bm.RuleType.$VALUES.clone();
    }
    static RuleType()
    {
        org.apache.commons.codec.language.bm.RuleType.APPROX = new org.apache.commons.codec.language.bm.RuleType("APPROX", 0, "approx");
        org.apache.commons.codec.language.bm.RuleType.EXACT = new org.apache.commons.codec.language.bm.RuleType("EXACT", 1, "exact");
        org.apache.commons.codec.language.bm.RuleType.RULES = new org.apache.commons.codec.language.bm.RuleType("RULES", 2, "rules");
        v0 = new org.apache.commons.codec.language.bm.RuleType[3];
        v0[0] = org.apache.commons.codec.language.bm.RuleType.APPROX;
        v0[1] = org.apache.commons.codec.language.bm.RuleType.EXACT;
        v0[2] = org.apache.commons.codec.language.bm.RuleType.RULES;
        org.apache.commons.codec.language.bm.RuleType.$VALUES = v0;
        return;
    }
    private RuleType(String p1, int p2, String p3)
    {
        this(p1, p2);
        this.name = p3;
        return;
    }
}
