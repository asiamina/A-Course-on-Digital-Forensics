package org.apache.commons.codec.net;
 class Utils {
     Utils()
    {
        return;
    }
    static int digit16(byte p4)
    {
        v0 = Character.digit(((char) p4), 16);
        if (v0 != -1) {
            return v0;
        } else {
            throw new org.apache.commons.codec.DecoderException(new StringBuilder().append("Invalid URL encoding: not a valid digit (radix 16): ").append(p4).toString());
        }
    }
}
