package org.apache.commons.lang.mutable;
public class MutableFloat extends java.lang.Number implements java.lang.Comparable, org.apache.commons.lang.mutable.Mutable {
    private float value;
    final private static long serialVersionUID;
    public void increment()
    {
        this.value = (this.value + 1.0);
        return;
    }
    public int intValue()
    {
        return ((int) this.value);
    }
    public boolean isInfinite()
    {
        return Float.isInfinite(this.value);
    }
    public boolean isNaN()
    {
        return Float.isNaN(this.value);
    }
    public long longValue()
    {
        return ((long) this.value);
    }
    public void setValue(float p1)
    {
        this.value = p1;
        return;
    }
    public void setValue(Object p2)
    {
        this.setValue(p2.floatValue());
        return;
    }
    public void subtract(float p2)
    {
        this.value = (this.value - p2);
        return;
    }
    public void subtract(Number p3)
    {
        this.value = (this.value - p3.floatValue());
        return;
    }
    public Float toFloat()
    {
        return new Float(this.floatValue());
    }
    public String toString()
    {
        return String.valueOf(this.value);
    }
    public MutableFloat()
    {
        return;
    }
    public MutableFloat(float p1)
    {
        this.value = p1;
        return;
    }
    public MutableFloat(Number p2)
    {
        this.value = p2.floatValue();
        return;
    }
    public void add(float p2)
    {
        this.value = (this.value + p2);
        return;
    }
    public void add(Number p3)
    {
        this.value = (this.value + p3.floatValue());
        return;
    }
    public int compareTo(Object p4)
    {
        return org.apache.commons.lang.math.NumberUtils.compare(this.value, p4.value);
    }
    public void decrement()
    {
        this.value = (this.value - 1.0);
        return;
    }
    public double doubleValue()
    {
        return ((double) this.value);
    }
    public boolean equals(Object p3)
    {
        if (((p3 instanceof org.apache.commons.lang.mutable.MutableFloat) == 0) || (Float.floatToIntBits(p3.value) != Float.floatToIntBits(this.value))) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public float floatValue()
    {
        return this.value;
    }
    public Object getValue()
    {
        return new Float(this.value);
    }
    public int hashCode()
    {
        return Float.floatToIntBits(this.value);
    }
}
