package org.apache.commons.codec.binary;
public class BaseNCodecOutputStream extends java.io.FilterOutputStream {
    final private byte[] singleByte;
    final private org.apache.commons.codec.binary.BaseNCodec baseNCodec;
    final private boolean doEncode;
    public BaseNCodecOutputStream(java.io.OutputStream p2, org.apache.commons.codec.binary.BaseNCodec p3, boolean p4)
    {
        this(p2);
        v0 = new byte[1];
        this.singleByte = v0;
        this.baseNCodec = p3;
        this.doEncode = p4;
        return;
    }
    public void close()
    {
        if (!this.doEncode) {
            this.baseNCodec.decode(this.singleByte, 0, -1);
        } else {
            this.baseNCodec.encode(this.singleByte, 0, -1);
        }
        this.flush();
        this.out.close();
        return;
    }
    public void flush()
    {
        this.flush(1);
        return;
    }
    private void flush(boolean p6)
    {
        v0 = this.baseNCodec.available();
        if (v0 > 0) {
            v1 = new byte[v0];
            v2 = this.baseNCodec.readResults(v1, 0, v0);
            if (v2 > 0) {
                this.out.write(v1, 0, v2);
            }
        }
        if (p6 != 0) {
            this.out.flush();
        }
        return;
    }
    public void write(int p4)
    {
        this.singleByte[0] = ((byte) p4);
        this.write(this.singleByte, 0, 1);
        return;
    }
    public void write(byte[] p3, int p4, int p5)
    {
        if (p3 != 0) {
            if ((p4 >= 0) && (p5 >= 0)) {
                if ((p4 <= p3.length) && ((p4 + p5) <= p3.length)) {
                    if (p5 > 0) {
                        if (!this.doEncode) {
                            this.baseNCodec.decode(p3, p4, p5);
                        } else {
                            this.baseNCodec.encode(p3, p4, p5);
                        }
                        this.flush(0);
                    }
                    return;
                } else {
                    throw new IndexOutOfBoundsException();
                }
            } else {
                throw new IndexOutOfBoundsException();
            }
        } else {
            throw new NullPointerException();
        }
    }
}
