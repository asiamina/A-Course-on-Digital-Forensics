package org.apache.http.entity.mime.content;
public interface abstract class ContentDescriptor {
    abstract public long e();
    abstract public String a();
    abstract public String c();
    abstract public String d();
}
