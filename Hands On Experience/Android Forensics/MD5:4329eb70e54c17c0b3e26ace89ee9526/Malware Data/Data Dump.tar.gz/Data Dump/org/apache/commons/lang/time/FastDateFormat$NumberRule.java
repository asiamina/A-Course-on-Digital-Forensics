package org.apache.commons.lang.time;
interface abstract class FastDateFormat$NumberRule implements org.apache.commons.lang.time.FastDateFormat$Rule {
    abstract public void appendTo();
}
