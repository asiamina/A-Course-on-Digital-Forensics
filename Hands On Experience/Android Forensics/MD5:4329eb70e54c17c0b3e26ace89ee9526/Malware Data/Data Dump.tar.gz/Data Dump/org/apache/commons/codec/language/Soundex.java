package org.apache.commons.codec.language;
public class Soundex implements org.apache.commons.codec.StringEncoder {
    final private static char[] US_ENGLISH_MAPPING;
    private int maxLength;
    final public static String US_ENGLISH_MAPPING_STRING;
    final private char[] soundexMapping;
    final public static org.apache.commons.codec.language.Soundex US_ENGLISH;
    public void setMaxLength(int p1)
    {
        this.maxLength = p1;
        return;
    }
    public String soundex(String p10)
    {
        if (p10 != 0) {
            p10 = org.apache.commons.codec.language.SoundexUtils.clean(p10);
            if (p10.length() != 0) {
                v6 = new char[4];
                v6 = {48, 0, 48, 0, 48, 0, 48};
                v2 = 1;
                v0 = 1;
                v6[0] = p10.charAt(0);
                this.getMappingCode(p10, 0);
                v4 = this;
                while ((v2 < p10.length()) && (v0 < v6.length)) {
                    v3 = (v2 + 1);
                    this.getMappingCode(p10, v2);
                    if (this == 0) {
                        v2 = v3;
                    } else {
                        if ((this != 48) && (this != v4)) {
                            v1 = (v0 + 1);
                            v6[v0] = this;
                            v0 = v1;
                        }
                        v4 = this;
                        v2 = v3;
                    }
                }
                v7 = new String(v6);
            } else {
                v7 = p10;
            }
        } else {
            v7 = 0;
        }
        return v7;
    }
    static Soundex()
    {
        org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING = "01230120022455012623010202".toCharArray();
        org.apache.commons.codec.language.Soundex.US_ENGLISH = new org.apache.commons.codec.language.Soundex();
        return;
    }
    public Soundex()
    {
        this.maxLength = 4;
        this.soundexMapping = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        return;
    }
    public Soundex(String p2)
    {
        this.maxLength = 4;
        this.soundexMapping = p2.toCharArray();
        return;
    }
    public Soundex(char[] p4)
    {
        this.maxLength = 4;
        v0 = new char[p4.length];
        this.soundexMapping = v0;
        System.arraycopy(p4, 0, this.soundexMapping, 0, p4.length);
        return;
    }
    public int difference(String p2, String p3)
    {
        return org.apache.commons.codec.language.SoundexUtils.difference(this, p2, p3);
    }
    public Object encode(Object p3)
    {
        if ((p3 instanceof String) != 0) {
            return this.soundex(p3);
        } else {
            throw new org.apache.commons.codec.EncoderException("Parameter supplied to Soundex encode is not of type java.lang.String");
        }
    }
    public String encode(String p2)
    {
        return this.soundex(p2);
    }
    private char getMappingCode(String p8, int p9)
    {
        this.map(p8.charAt(p9));
        v2 = this;
        if ((p9 > 1) && (this != 48)) {
            v1 = p8.charAt((p9 - 1));
            if ((72 == v1) || (87 == v1)) {
                v3 = p8.charAt((p9 - 2));
                this.map(v3);
                if ((this == this) || ((72 == v3) || (87 == v3))) {
                    v2 = 0;
                }
            }
        }
        return v2;
    }
    public int getMaxLength()
    {
        return this.maxLength;
    }
    private char[] getSoundexMapping()
    {
        return this.soundexMapping;
    }
    private char map(char p5)
    {
        v0 = (p5 - 65);
        if (v0 >= 0) {
            this.getSoundexMapping();
            if (v0 < this.length) {
                this.getSoundexMapping();
                return this[v0];
            }
        }
        throw new IllegalArgumentException(new StringBuilder().append("The character is not mapped: ").append(p5).toString());
    }
}
