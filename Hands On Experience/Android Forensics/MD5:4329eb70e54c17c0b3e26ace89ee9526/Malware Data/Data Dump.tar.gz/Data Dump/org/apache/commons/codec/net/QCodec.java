package org.apache.commons.codec.net;
public class QCodec extends org.apache.commons.codec.net.RFC1522Codec implements org.apache.commons.codec.StringDecoder, org.apache.commons.codec.StringEncoder {
    private boolean encodeBlanks;
    final private String charset;
    final private static java.util.BitSet PRINTABLE_CHARS;
    final private static byte UNDERSCORE;
    final private static byte BLANK;
    static QCodec()
    {
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS = new java.util.BitSet(256);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(32);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(33);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(34);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(35);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(36);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(37);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(38);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(39);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(40);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(41);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(42);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(43);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(44);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(45);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(46);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(47);
        v0 = 48;
        while (v0 <= 57) {
            org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(v0);
            v0++;
        }
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(58);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(59);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(60);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(62);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(64);
        v0 = 65;
        while (v0 <= 90) {
            org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(v0);
            v0++;
        }
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(91);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(92);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(93);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(94);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(96);
        v0 = 97;
        while (v0 <= 122) {
            org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(v0);
            v0++;
        }
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(123);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(124);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(125);
        org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS.set(126);
        return;
    }
    public QCodec()
    {
        this("UTF-8");
        return;
    }
    public QCodec(String p2)
    {
        this.encodeBlanks = 0;
        this.charset = p2;
        return;
    }
    public Object decode(Object p4)
    {
        if (p4 != 0) {
            if ((p4 instanceof String) == 0) {
                throw new org.apache.commons.codec.DecoderException(new StringBuilder().append("Objects of type ").append(p4.getClass().getName()).append(" cannot be decoded using Q codec").toString());
            } else {
                v0 = this.decode(p4);
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
    public String decode(String p4)
    {
        if (p4 != 0) {
            v1 = this.decodeText(p4);
        } else {
            v1 = 0;
        }
        return v1;
    }
    protected byte[] doDecoding(byte[] p10)
    {
        if (p10 != 0) {
            v2 = 0;
            v0 = p10;
            v4 = 0;
            while (v4 < v0.length) {
                if (v0[v4] != 95) {
                    v4++;
                } else {
                    v2 = 1;
                    break;
                }
            }
            if (v2 == 0) {
                v7 = org.apache.commons.codec.net.QuotedPrintableCodec.decodeQuotedPrintable(p10);
            } else {
                v6 = new byte[p10.length];
                v3 = 0;
                while (v3 < p10.length) {
                    v1 = p10[v3];
                    if (v1 == 95) {
                        v6[v3] = 32;
                    } else {
                        v6[v3] = v1;
                    }
                    v3++;
                }
                v7 = org.apache.commons.codec.net.QuotedPrintableCodec.decodeQuotedPrintable(v6);
            }
        } else {
            v7 = 0;
        }
        return v7;
    }
    protected byte[] doEncoding(byte[] p5)
    {
        if (p5 != 0) {
            v0 = org.apache.commons.codec.net.QuotedPrintableCodec.encodeQuotedPrintable(org.apache.commons.codec.net.QCodec.PRINTABLE_CHARS, p5);
            if (this.encodeBlanks) {
                v1 = 0;
                while (v1 < v0.length) {
                    if (v0[v1] == 32) {
                        v0[v1] = 95;
                    }
                    v1++;
                }
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
    public Object encode(Object p4)
    {
        if (p4 != 0) {
            if ((p4 instanceof String) == 0) {
                throw new org.apache.commons.codec.EncoderException(new StringBuilder().append("Objects of type ").append(p4.getClass().getName()).append(" cannot be encoded using Q codec").toString());
            } else {
                v0 = this.encode(p4);
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
    public String encode(String p2)
    {
        if (p2 != 0) {
            v0 = this.encode(p2, this.getDefaultCharset());
        } else {
            v0 = 0;
        }
        return v0;
    }
    public String encode(String p4, String p5)
    {
        if (p4 != 0) {
            v1 = this.encodeText(p4, p5);
        } else {
            v1 = 0;
        }
        return v1;
    }
    public String getDefaultCharset()
    {
        return this.charset;
    }
    protected String getEncoding()
    {
        return "Q";
    }
    public boolean isEncodeBlanks()
    {
        return this.encodeBlanks;
    }
    public void setEncodeBlanks(boolean p1)
    {
        this.encodeBlanks = p1;
        return;
    }
}
