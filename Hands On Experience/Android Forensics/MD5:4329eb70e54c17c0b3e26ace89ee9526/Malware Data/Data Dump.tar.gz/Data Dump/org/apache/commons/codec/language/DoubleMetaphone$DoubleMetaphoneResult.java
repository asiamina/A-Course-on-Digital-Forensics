package org.apache.commons.codec.language;
public class DoubleMetaphone$DoubleMetaphoneResult {
    final private StringBuffer alternate;
    final private StringBuffer primary;
    final synthetic org.apache.commons.codec.language.DoubleMetaphone this$0;
    final private int maxLength;
    public DoubleMetaphone$DoubleMetaphoneResult(org.apache.commons.codec.language.DoubleMetaphone p3, int p4)
    {
        this.this$0 = p3;
        this.primary = new StringBuffer(this.this$0.getMaxCodeLen());
        this.alternate = new StringBuffer(this.this$0.getMaxCodeLen());
        this.maxLength = p4;
        return;
    }
    public void append(char p1)
    {
        this.appendPrimary(p1);
        this.appendAlternate(p1);
        return;
    }
    public void append(char p1, char p2)
    {
        this.appendPrimary(p1);
        this.appendAlternate(p2);
        return;
    }
    public void append(String p1)
    {
        this.appendPrimary(p1);
        this.appendAlternate(p1);
        return;
    }
    public void append(String p1, String p2)
    {
        this.appendPrimary(p1);
        this.appendAlternate(p2);
        return;
    }
    public void appendAlternate(char p3)
    {
        if (this.alternate.length() < this.maxLength) {
            this.alternate.append(p3);
        }
        return;
    }
    public void appendAlternate(String p4)
    {
        v0 = (this.maxLength - this.alternate.length());
        if (p4.length() > v0) {
            this.alternate.append(p4.substring(0, v0));
        } else {
            this.alternate.append(p4);
        }
        return;
    }
    public void appendPrimary(char p3)
    {
        if (this.primary.length() < this.maxLength) {
            this.primary.append(p3);
        }
        return;
    }
    public void appendPrimary(String p4)
    {
        v0 = (this.maxLength - this.primary.length());
        if (p4.length() > v0) {
            this.primary.append(p4.substring(0, v0));
        } else {
            this.primary.append(p4);
        }
        return;
    }
    public String getAlternate()
    {
        return this.alternate.toString();
    }
    public String getPrimary()
    {
        return this.primary.toString();
    }
    public boolean isComplete()
    {
        if ((this.primary.length() < this.maxLength) || (this.alternate.length() < this.maxLength)) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
}
