package org.apache.commons.codec;
public interface abstract class Encoder {
    abstract public Object encode();
}
