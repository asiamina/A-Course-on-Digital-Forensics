package org.apache.commons.lang.exception;
public class ExceptionUtils {
    final private static reflect.Method THROWABLE_INITCAUSE_METHOD;
    static Class class$java$lang$Throwable;
    final static String WRAPPED_MARKER;
    private static String[] CAUSE_METHOD_NAMES;
    final private static reflect.Method THROWABLE_CAUSE_METHOD;
    public static int indexOfThrowable(Throwable p1, Class p2, int p3)
    {
        return org.apache.commons.lang.exception.ExceptionUtils.indexOf(p1, p2, p3, 0);
    }
    public static int indexOfType(Throwable p2, Class p3)
    {
        return org.apache.commons.lang.exception.ExceptionUtils.indexOf(p2, p3, 0, 1);
    }
    public static int indexOfType(Throwable p1, Class p2, int p3)
    {
        return org.apache.commons.lang.exception.ExceptionUtils.indexOf(p1, p2, p3, 1);
    }
    public static boolean isCauseMethodName(String p1)
    {
        if (org.apache.commons.lang.ArrayUtils.indexOf(org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES, p1) < 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static boolean isNestedThrowable(Throwable p10)
    {
        v6 = 0;
        if (p10 != 0) {
            if ((p10 instanceof org.apache.commons.lang.exception.Nestable) == 0) {
                if ((p10 instanceof java.sql.SQLException) == 0) {
                    if ((p10 instanceof reflect.InvocationTargetException) == 0) {
                        if (org.apache.commons.lang.exception.ExceptionUtils.isThrowableNested() == 0) {
                            v0 = p10.getClass();
                            v2 = 0;
                            while (v2 < org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES.length) {
                                v5 = v0.getMethod(org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES[v2], 0);
                                if (v5 != 0) {
                                    if (org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable != 0) {
                                        v8 = org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable;
                                    } else {
                                        v8 = org.apache.commons.lang.exception.ExceptionUtils.class$("java.lang.Throwable");
                                        org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable = v8;
                                    }
                                    if (v8.isAssignableFrom(v5.getReturnType()) != 0) {
                                        v6 = 1;
                                        return v6;
                                    }
                                }
                                v2++;
                            }
                            if (v0.getField("detail") != 0) {
                                v6 = 1;
                            }
                        } else {
                            v6 = 1;
                        }
                    } else {
                        v6 = 1;
                    }
                } else {
                    v6 = 1;
                }
            } else {
                v6 = 1;
            }
        }
    }
    public static boolean isThrowableNested()
    {
        if (org.apache.commons.lang.exception.ExceptionUtils.THROWABLE_CAUSE_METHOD == 0) {
            v0 = 0;
        } else {
            v0 = 1;
        }
        return v0;
    }
    public static void printRootCauseStackTrace(Throwable p1)
    {
        org.apache.commons.lang.exception.ExceptionUtils.printRootCauseStackTrace(p1, System.err);
        return;
    }
    public static void printRootCauseStackTrace(Throwable p4, java.io.PrintStream p5)
    {
        if (p4 != 0) {
            if (p5 != 0) {
                v1 = org.apache.commons.lang.exception.ExceptionUtils.getRootCauseStackTrace(p4);
                v0 = 0;
                while (v0 < v1.length) {
                    p5.println(v1[v0]);
                    v0++;
                }
                p5.flush();
            } else {
                throw new IllegalArgumentException("The PrintStream must not be null");
            }
        }
        return;
    }
    public static void printRootCauseStackTrace(Throwable p4, java.io.PrintWriter p5)
    {
        if (p4 != 0) {
            if (p5 != 0) {
                v1 = org.apache.commons.lang.exception.ExceptionUtils.getRootCauseStackTrace(p4);
                v0 = 0;
                while (v0 < v1.length) {
                    p5.println(v1[v0]);
                    v0++;
                }
                p5.flush();
            } else {
                throw new IllegalArgumentException("The PrintWriter must not be null");
            }
        }
        return;
    }
    public static void removeCauseMethodName(String p2)
    {
        if (org.apache.commons.lang.StringUtils.isNotEmpty(p2) != 0) {
            v0 = org.apache.commons.lang.exception.ExceptionUtils.getCauseMethodNameList();
            if (v0.remove(p2) != 0) {
                org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES = org.apache.commons.lang.exception.ExceptionUtils.toArray(v0);
            }
        }
        return;
    }
    public static void removeCommonFrames(java.util.List p6, java.util.List p7)
    {
        if ((p6 != 0) && (p7 != 0)) {
            v1 = (p6.size() - 1);
            v3 = (p7.size() - 1);
            while ((v1 >= 0) && (v3 >= 0)) {
                if (p6.get(v1).equals(p7.get(v3)) != 0) {
                    p6.remove(v1);
                }
                v1--;
                v3--;
            }
            return;
        } else {
            throw new IllegalArgumentException("The List must not be null");
        }
    }
    public static boolean setCause(Throwable p9, Throwable p10)
    {
        if (p9 != 0) {
            v0 = new Object[1];
            v0[0] = p10;
            if (org.apache.commons.lang.exception.ExceptionUtils.THROWABLE_INITCAUSE_METHOD != 0) {
                org.apache.commons.lang.exception.ExceptionUtils.THROWABLE_INITCAUSE_METHOD.invoke(p9, v0);
            }
            v5 = p9.getClass();
            v7 = new Class[1];
            if (org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable != 0) {
                v4 = org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable;
            } else {
                v4 = org.apache.commons.lang.exception.ExceptionUtils.class$("java.lang.Throwable");
                org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable = v4;
            }
            v7[0] = v4;
            v5.getMethod("setCause", v7).invoke(p9, v0);
            return 1;
        } else {
            throw new org.apache.commons.lang.NullArgumentException("target");
        }
    }
    private static String[] toArray(java.util.List p1)
    {
        v0 = new String[p1.size()];
        return p1.toArray(v0);
    }
    static ExceptionUtils()
    {
        v2 = new String[12];
        v2[0] = "getCause";
        v2[1] = "getNextException";
        v2[2] = "getTargetException";
        v2[3] = "getException";
        v2[4] = "getSourceException";
        v2[5] = "getRootCause";
        v2[6] = "getCausedByException";
        v2[7] = "getNested";
        v2[8] = "getLinkedException";
        v2[9] = "getNestedException";
        v2[10] = "getLinkedCause";
        v2[11] = "getThrowable";
        org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES = v2;
        if (org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable != 0) {
            v2 = org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable;
        } else {
            v2 = org.apache.commons.lang.exception.ExceptionUtils.class$("java.lang.Throwable");
            org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable = v2;
        }
        org.apache.commons.lang.exception.ExceptionUtils.THROWABLE_CAUSE_METHOD = v2.getMethod("getCause", 0);
        if (org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable != 0) {
            v3 = org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable;
        } else {
            v2 = org.apache.commons.lang.exception.ExceptionUtils.class$("java.lang.Throwable");
            org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable = v2;
            v3 = v2;
        }
        v5 = new Class[1];
        if (org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable != 0) {
            v2 = org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable;
        } else {
            v2 = org.apache.commons.lang.exception.ExceptionUtils.class$("java.lang.Throwable");
            org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable = v2;
        }
        v5[0] = v2;
        org.apache.commons.lang.exception.ExceptionUtils.THROWABLE_INITCAUSE_METHOD = v3.getMethod("initCause", v5);
        return;
    }
    public ExceptionUtils()
    {
        return;
    }
    public static void addCauseMethodName(String p2)
    {
        if ((org.apache.commons.lang.StringUtils.isNotEmpty(p2) != 0) && (org.apache.commons.lang.exception.ExceptionUtils.isCauseMethodName(p2) == 0)) {
            v0 = org.apache.commons.lang.exception.ExceptionUtils.getCauseMethodNameList();
            if (v0.add(p2) != 0) {
                org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES = org.apache.commons.lang.exception.ExceptionUtils.toArray(v0);
            }
        }
        return;
    }
    static Class class$(String p3)
    {
        return Class.forName(p3);
    }
    public static Throwable getCause(Throwable p1)
    {
        return org.apache.commons.lang.exception.ExceptionUtils.getCause(p1, org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES);
    }
    public static Throwable getCause(Throwable p4, String[] p5)
    {
        if (p4 != 0) {
            v0 = org.apache.commons.lang.exception.ExceptionUtils.getCauseUsingWellKnownTypes(p4);
            if (v0 == 0) {
                if (p5 == 0) {
                    p5 = org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES;
                }
                v1 = 0;
                while (v1 < p5.length) {
                    v2 = p5[v1];
                    if (v2 != 0) {
                        v0 = org.apache.commons.lang.exception.ExceptionUtils.getCauseUsingMethodName(p4, v2);
                        if (v0 != 0) {
                            break;
                        }
                    }
                    v1++;
                }
                if (v0 == 0) {
                    v0 = org.apache.commons.lang.exception.ExceptionUtils.getCauseUsingFieldName(p4, "detail");
                }
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
    private static java.util.ArrayList getCauseMethodNameList()
    {
        return new java.util.ArrayList(java.util.Arrays.asList(org.apache.commons.lang.exception.ExceptionUtils.CAUSE_METHOD_NAMES));
    }
    private static Throwable getCauseUsingFieldName(Throwable p4, String p5)
    {
        v0 = p4.getClass().getField(p5);
        if (v0 == 0) {
            v2 = 0;
        } else {
            if (org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable != 0) {
                v2 = org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable;
            } else {
                v2 = org.apache.commons.lang.exception.ExceptionUtils.class$("java.lang.Throwable");
                org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable = v2;
            }
            } else {
                v2 = v0.get(p4);
            }
        }
        return v2;
    }
    private static Throwable getCauseUsingMethodName(Throwable p5, String p6)
    {
        v1 = p5.getClass().getMethod(p6, 0);
        if (v1 == 0) {
            v2 = 0;
        } else {
            if (org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable != 0) {
                v2 = org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable;
            } else {
                v2 = org.apache.commons.lang.exception.ExceptionUtils.class$("java.lang.Throwable");
                org.apache.commons.lang.exception.ExceptionUtils.class$java$lang$Throwable = v2;
            }
            } else {
                v2 = v1.invoke(p5, org.apache.commons.lang.ArrayUtils.EMPTY_OBJECT_ARRAY);
            }
        }
        return v2;
    }
    private static Throwable getCauseUsingWellKnownTypes(Throwable p1)
    {
        if ((p1 instanceof org.apache.commons.lang.exception.Nestable) == 0) {
            if ((p1 instanceof java.sql.SQLException) == 0) {
                if ((p1 instanceof reflect.InvocationTargetException) == 0) {
                    v0 = 0;
                } else {
                    v0 = p1.getTargetException();
                }
            } else {
                v0 = p1.getNextException();
            }
        } else {
            v0 = p1.getCause();
        }
        return v0;
    }
    public static String getFullStackTrace(Throwable p5)
    {
        v2 = new java.io.StringWriter();
        v1 = new java.io.PrintWriter(v2, 1);
        v3 = org.apache.commons.lang.exception.ExceptionUtils.getThrowables(p5);
        v0 = 0;
        while (v0 < v3.length) {
            v3[v0].printStackTrace(v1);
            if (org.apache.commons.lang.exception.ExceptionUtils.isNestedThrowable(v3[v0]) != 0) {
                break;
            }
            v0++;
        }
        return v2.getBuffer().toString();
    }
    public static String getMessage(Throwable p4)
    {
        if (p4 != 0) {
            v2 = new StringBuffer().append(org.apache.commons.lang.ClassUtils.getShortClassName(p4, 0)).append(": ").append(org.apache.commons.lang.StringUtils.defaultString(p4.getMessage())).toString();
        } else {
            v2 = "";
        }
        return v2;
    }
    public static Throwable getRootCause(Throwable p3)
    {
        v0 = org.apache.commons.lang.exception.ExceptionUtils.getThrowableList(p3);
        if (v0.size() >= 2) {
            v1 = v0.get((v0.size() - 1));
        } else {
            v1 = 0;
        }
        return v1;
    }
    public static String getRootCauseMessage(Throwable p2)
    {
        v0 = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(p2);
        if (v0 == 0) {
            v0 = p2;
        }
        return org.apache.commons.lang.exception.ExceptionUtils.getMessage(v0);
    }
    public static String[] getRootCauseStackTrace(Throwable p9)
    {
        if (p9 != 0) {
            v5 = org.apache.commons.lang.exception.ExceptionUtils.getThrowables(p9);
            v0 = v5.length;
            v1 = new java.util.ArrayList();
            v4 = org.apache.commons.lang.exception.ExceptionUtils.getStackFrameList(v5[(v0 - 1)]);
            v2 = v0;
            do {
                v2--;
                if (v2 >= 0) {
                    v6 = v4;
                    if (v2 != 0) {
                        v4 = org.apache.commons.lang.exception.ExceptionUtils.getStackFrameList(v5[(v2 - 1)]);
                        org.apache.commons.lang.exception.ExceptionUtils.removeCommonFrames(v6, v4);
                    }
                    if (v2 != (v0 - 1)) {
                        v1.add(new StringBuffer().append(" [wrapped] ").append(v5[v2].toString()).toString());
                    } else {
                        v1.add(v5[v2].toString());
                    }
                    v3 = 0;
                } else {
                    v7 = new String[0];
                    v7 = v1.toArray(v7);
                }
            } while(v3 >= v6.size());
            v1.add(v6.get(v3));
            v3++;
            while (v3 < v6.size()) {
            }
        } else {
            v7 = org.apache.commons.lang.ArrayUtils.EMPTY_STRING_ARRAY;
        }
        return v7;
    }
    static java.util.List getStackFrameList(Throwable p8)
    {
        v1 = new java.util.StringTokenizer(org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(p8), org.apache.commons.lang.SystemUtils.LINE_SEPARATOR);
        v3 = new java.util.ArrayList();
        v6 = 0;
        while (v1.hasMoreTokens() != 0) {
            v5 = v1.nextToken();
            v0 = v5.indexOf("at");
            if ((v0 == -1) || (v5.substring(0, v0).trim().length() != 0)) {
                if (v6 != 0) {
                    break;
                }
            } else {
                v6 = 1;
                v3.add(v5);
            }
        }
        return v3;
    }
    static String[] getStackFrames(String p4)
    {
        v0 = new java.util.StringTokenizer(p4, org.apache.commons.lang.SystemUtils.LINE_SEPARATOR);
        v2 = new java.util.ArrayList();
        while (v0.hasMoreTokens() != 0) {
            v2.add(v0.nextToken());
        }
        return org.apache.commons.lang.exception.ExceptionUtils.toArray(v2);
    }
    public static String[] getStackFrames(Throwable p1)
    {
        if (p1 != 0) {
            v0 = org.apache.commons.lang.exception.ExceptionUtils.getStackFrames(org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(p1));
        } else {
            v0 = org.apache.commons.lang.ArrayUtils.EMPTY_STRING_ARRAY;
        }
        return v0;
    }
    public static String getStackTrace(Throwable p3)
    {
        v1 = new java.io.StringWriter();
        p3.printStackTrace(new java.io.PrintWriter(v1, 1));
        return v1.getBuffer().toString();
    }
    public static int getThrowableCount(Throwable p1)
    {
        return org.apache.commons.lang.exception.ExceptionUtils.getThrowableList(p1).size();
    }
    public static java.util.List getThrowableList(Throwable p2)
    {
        v0 = new java.util.ArrayList();
        while ((p2 != 0) && (v0.contains(p2) == 0)) {
            v0.add(p2);
            p2 = org.apache.commons.lang.exception.ExceptionUtils.getCause(p2);
        }
        return v0;
    }
    public static Throwable[] getThrowables(Throwable p2)
    {
        v0 = org.apache.commons.lang.exception.ExceptionUtils.getThrowableList(p2);
        v1 = new Throwable[v0.size()];
        return v0.toArray(v1);
    }
    private static int indexOf(Throwable p4, Class p5, int p6, boolean p7)
    {
        if ((p4 != 0) && (p5 != 0)) {
            if (p6 < 0) {
                p6 = 0;
            }
            v1 = org.apache.commons.lang.exception.ExceptionUtils.getThrowables(p4);
            if (p6 < v1.length) {
                if (p7 == 0) {
                    v0 = p6;
                    while (v0 < v1.length) {
                        if (p5.equals(v1[v0].getClass()) != 0) {
                            return v0;
                        } else {
                            v0++;
                        }
                    }
                } else {
                    v0 = p6;
                    while (v0 < v1.length) {
                        } else {
                            v0++;
                        }
                    }
                }
                v0 = -1;
            } else {
                v0 = -1;
            }
        } else {
            v0 = -1;
        }
    }
    public static int indexOfThrowable(Throwable p1, Class p2)
    {
        return org.apache.commons.lang.exception.ExceptionUtils.indexOf(p1, p2, 0, 0);
    }
}
