package org.apache.commons.lang.time;
 class FastDateFormat$TwentyFourHourField implements org.apache.commons.lang.time.FastDateFormat$NumberRule {
    final private org.apache.commons.lang.time.FastDateFormat$NumberRule mRule;
     FastDateFormat$TwentyFourHourField(org.apache.commons.lang.time.FastDateFormat$NumberRule p1)
    {
        this.mRule = p1;
        return;
    }
    public void appendTo(StringBuffer p2, int p3)
    {
        this.mRule.appendTo(p2, p3);
        return;
    }
    public void appendTo(StringBuffer p3, java.util.Calendar p4)
    {
        v0 = p4.get(11);
        if (v0 == 0) {
            v0 = (p4.getMaximum(11) + 1);
        }
        this.mRule.appendTo(p3, v0);
        return;
    }
    public int estimateLength()
    {
        return this.mRule.estimateLength();
    }
}
