package org.apache.commons.codec.language.bm;
public interface abstract class Rule$RPattern {
    abstract public boolean isMatch();
}
