package org.apache.commons.codec.binary;
public class Base64InputStream extends org.apache.commons.codec.binary.BaseNCodecInputStream {
    public Base64InputStream(java.io.InputStream p2)
    {
        this(p2, 0);
        return;
    }
    public Base64InputStream(java.io.InputStream p3, boolean p4)
    {
        this(p3, new org.apache.commons.codec.binary.Base64(0), p4);
        return;
    }
    public Base64InputStream(java.io.InputStream p2, boolean p3, int p4, byte[] p5)
    {
        this(p2, new org.apache.commons.codec.binary.Base64(p4, p5), p3);
        return;
    }
}
