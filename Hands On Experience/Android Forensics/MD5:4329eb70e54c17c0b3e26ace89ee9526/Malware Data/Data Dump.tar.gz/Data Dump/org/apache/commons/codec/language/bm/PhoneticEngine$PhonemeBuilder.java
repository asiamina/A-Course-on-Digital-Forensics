package org.apache.commons.codec.language.bm;
final class PhoneticEngine$PhonemeBuilder {
    final private java.util.Set phonemes;
    private PhoneticEngine$PhonemeBuilder(java.util.Set p1)
    {
        this.phonemes = p1;
        return;
    }
    synthetic PhoneticEngine$PhonemeBuilder(java.util.Set p1, org.apache.commons.codec.language.bm.PhoneticEngine$1 p2)
    {
        this(p1);
        return;
    }
    public org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder append(CharSequence p5)
    {
        v1 = new java.util.HashSet();
        v0 = this.phonemes.iterator();
        while (v0.hasNext() != 0) {
            v1.add(v0.next().append(p5));
        }
        return new org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder(v1);
    }
    public org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder apply(org.apache.commons.codec.language.bm.Rule$PhonemeExpr p8)
    {
        v4 = new java.util.HashSet();
        v0 = this.phonemes.iterator();
        while (v0.hasNext() != 0) {
            v3 = v0.next();
            v1 = p8.getPhonemes().iterator();
            while (v1.hasNext() != 0) {
                v2 = v3.join(v1.next());
                if (v2.getLanguages().isEmpty() == 0) {
                    v4.add(v2);
                }
            }
        }
        return new org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder(v4);
    }
    public static org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder empty(org.apache.commons.codec.language.bm.Languages$LanguageSet p3)
    {
        return new org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder(java.util.Collections.singleton(new org.apache.commons.codec.language.bm.Rule$Phoneme("", p3)));
    }
    public java.util.Set getPhonemes()
    {
        return this.phonemes;
    }
    public String makeString()
    {
        v2 = new StringBuilder();
        v0 = this.phonemes.iterator();
        while (v0.hasNext() != 0) {
            v1 = v0.next();
            if (v2.length() > 0) {
                v2.append("|");
            }
            v2.append(v1.getPhonemeText());
        }
        return v2.toString();
    }
}
